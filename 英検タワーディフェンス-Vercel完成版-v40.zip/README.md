# 英検タワーディフェンス — Vercel + AI例文版

iPhoneのSafari/PWAで動かすことを前提に、ゲーム本体と例文生成を分離した構成です。

## 構成

- `index.html` — 画面
- `styles.css` — スタイル
- `app.js` — ゲーム本体
- `sentence-engine.js` — 例文生成・検証・IndexedDBキャッシュ
- `api/generate-example.js` — Vercel Function。OpenAI APIをサーバー側から呼び出す
- `sw.js` — PWA用Service Worker
- `manifest.webmanifest` — ホーム画面追加用
- `vercel.json` — Vercel Function設定
- `.env.example` — 必要な環境変数の見本

## AI例文の流れ

1. 端末内IndexedDBに保存済みの良質な例文を確認
2. なければ `/api/generate-example` を呼び出す
3. Vercel FunctionからOpenAI Responses APIへ安全にリクエスト
4. ブラウザ側で単語・品詞・文法・長さなどを検証
5. 合格した例文をIndexedDBへ30日キャッシュ
6. 現在WAVEだけでなく次WAVEもバックグラウンドで先読み
7. AIが使えない場合はローカル/外部例文のフォールバックへ

## Vercelへのデプロイ

### 1. GitHubへ配置

このフォルダをGitHubリポジトリのルートに置き、VercelでImportしてください。

ビルド設定は基本的に不要です。静的サイトとして公開され、`api/generate-example.js` がVercel Functionになります。

### 2. 環境変数を設定

Vercelの **Project → Settings → Environment Variables** で次を追加します。

- `OPENAI_API_KEY` — OpenAI APIキー（必須）
- `OPENAI_MODEL` — 任意。未設定なら `gpt-5-mini`

ProductionだけでなくPreview/Developmentでもテストするなら、それぞれの環境に設定してください。

環境変数を追加・変更した後は再デプロイしてください。

### 3. 動作確認

デプロイ後、ブラウザから通常どおりゲームを開きます。
例文取得時にはブラウザからOpenAIへ直接接続せず、`/api/generate-example` 経由でAIを呼び出します。

## iPhone

HTTPSで公開したVercel URLをSafariで開き、共有メニューから「ホーム画面に追加」を選ぶとPWAとして起動できます。

## セキュリティ

`OPENAI_API_KEY` はブラウザコードに書かないでください。`api/generate-example.js` 内だけで `process.env.OPENAI_API_KEY` を使用します。
