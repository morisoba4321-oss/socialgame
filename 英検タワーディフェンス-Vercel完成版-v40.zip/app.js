(function(){
  const screen = document.getElementById('app-loading-screen');
  const percent = document.getElementById('loading-percent');
  const fill = document.getElementById('loading-bar-fill');
  const status = document.getElementById('loading-status');

  if(!screen || !percent || !fill || !status) return;

  // 「イベント待ち」で停止しないよう、段階的に進める。
  const stages = [
    [8,  'HTMLを読み込んでいます…'],
    [20, 'ゲームデータを準備しています…'],
    [35, 'AIキャラクター画像を準備しています…'],
    [52, '単語データを読み込んでいます…'],
    [68, 'ゲームシステムを初期化しています…'],
    [82, '画面を準備しています…'],
    [94, '最終確認をしています…']
  ];

  let index = 0;
  let finished = false;

  function setProgress(value, text){
    percent.textContent = value + '%';
    fill.style.width = value + '%';
    status.textContent = text;
  }

  function nextStage(){
    if(finished) return;
    if(index < stages.length){
      setProgress(stages[index][0], stages[index][1]);
      index++;
      setTimeout(nextStage, 180);
    }
  }

  function finish(){
    if(finished) return;
    finished = true;
    setProgress(100, '読み込み完了！');
    setTimeout(function(){
      screen.classList.add('is-hidden');
      setTimeout(function(){
        if(screen && screen.parentNode) screen.parentNode.removeChild(screen);
      }, 300);
    }, 220);
  }

  // まず必ず動き始める。DOMContentLoadedを待たない。
  nextStage();

  // 通常のページ読み込み完了時に100%へ。
  if(document.readyState === 'complete'){
    finish();
  } else {
    window.addEventListener('load', finish, {once:true});
  }

  // 万一、外部リソース等でloadが遅延しても画面が永久に残らないよう、
  // 最大8秒で完了扱いにする。
  setTimeout(finish, 8000);
})();

// ========== DATA ==========
const SEED_WORD_BANKS = {
  "3": [
    { w: "apple", m: "りんご", ex: "I had an ___ with my lunch today.", answerForm: "apple", exJa: "今日の昼食にりんごを食べました。", opts: ["apple","table","window","river"], col: ["apple","orange","bread","milk"] },
    { w: "book", m: "本", ex: "She is reading a ___ about animals.", answerForm: "book", exJa: "彼女は動物についての本を読んでいます。", opts: ["book","door","phone","chair"], col: ["book","magazine","novel","paper"] },
    { w: "happy", m: "幸せな", ex: "I feel ___ when I talk with my friends.", answerForm: "happy", exJa: "友達と話していると幸せな気持ちになります。", opts: ["happy","heavy","hungry","hard"], col: ["happy","glad","pleased","joyful"] },
    { w: "school", m: "学校", ex: "We go to ___ by bus every morning.", answerForm: "school", exJa: "私たちは毎朝バスで学校に行きます。", opts: ["school","station","office","park"], col: ["school","class","student","teacher"] },
    { w: "friend", m: "友達", ex: "He has been my best ___ since elementary school.", answerForm: "friend", exJa: "彼は小学校からの親友です。", opts: ["friend","father","farmer","field"], col: ["friend","buddy","pal","classmate"] },
    { w: "water", m: "水", ex: "Please drink some ___ after you exercise.", answerForm: "water", exJa: "運動のあとは水を飲んでください。", opts: ["water","winter","waiter","watch"], col: ["water","tea","juice","milk"] },
    { w: "music", m: "音楽", ex: "I like listening to ___ on my way to school.", answerForm: "music", exJa: "学校へ向かう道で音楽を聴くのが好きです。", opts: ["music","museum","message","movie"], col: ["music","song","melody","sound"] },
    { w: "family", m: "家族", ex: "My ___ eats dinner together every night.", answerForm: "family", exJa: "私の家族は毎晩一緒に夕食をとります。", opts: ["family","factory","farmer","fashion"], col: ["family","parents","relative","home"] },
    { w: "city", m: "都市", ex: "Tokyo is a large ___ with many train lines.", answerForm: "city", exJa: "東京は多くの路線がある大きな都市です。", opts: ["city","circle","citizen","cinema"], col: ["city","town","capital","area"] },
    { w: "study", m: "勉強する", ex: "I ___ English for thirty minutes every night.", answerForm: "study", exJa: "毎晩30分英語を勉強します。", opts: ["study","start","stand","stop"], col: ["study","learn","practice","review"] }
  ],
  "pre2": [
    { w: "decide", m: "決める", ex: "We need to ___ on a date for the meeting.", answerForm: "decide", exJa: "会議の日程を決める必要があります。", opts: ["decide","describe","deliver","develop"], col: ["decide","choose","select","determine"] },
    { w: "improve", m: "改善する", ex: "She is taking an online course to ___ her English.", answerForm: "improve", exJa: "彼女は英語を上達させるためにオンライン講座を受けています。", opts: ["improve","import","impress","include"], col: ["improve","better","enhance","develop"] },
    { w: "experience", m: "経験", ex: "Working abroad gave him valuable ___ in business.", answerForm: "experience", exJa: "海外勤務は彼に貴重なビジネス経験を与えました。", opts: ["experience","expense","example","exercise"], col: ["experience","practice","skill","knowledge"] },
    { w: "environment", m: "環境", ex: "We must protect the natural ___ for future generations.", answerForm: "environment", exJa: "将来の世代のために自然環境を守らなければなりません。", opts: ["environment","equipment","event","effort"], col: ["environment","nature","surroundings","ecology"] },
    { w: "opportunity", m: "機会", ex: "This program gives students an ___ to study abroad.", answerForm: "opportunity", exJa: "このプログラムは学生に留学の機会を与えます。", opts: ["opportunity","opinion","option","operation"], col: ["opportunity","chance","occasion","opening"] },
    { w: "responsible", m: "責任がある", ex: "You are ___ for locking the door before you leave.", answerForm: "responsible", exJa: "出かける前に鍵をかける責任があります。", opts: ["responsible","possible","comfortable","available"], col: ["responsible","accountable","in charge","reliable"] },
    { w: "suggest", m: "提案する", ex: "I ___ that we take a short break now.", answerForm: "suggest", exJa: "少し休憩をとることを提案します。", opts: ["suggest","support","supply","succeed"], col: ["suggest","propose","recommend","advise"] },
    { w: "popular", m: "人気のある", ex: "This song has become very ___ among teenagers.", answerForm: "popular", exJa: "この曲は10代の間でとても人気になっています。", opts: ["popular","possible","personal","practical"], col: ["popular","well-known","liked","famous"] },
    { w: "necessary", m: "必要な", ex: "A good night's sleep is ___ for your health.", answerForm: "necessary", exJa: "健康のためには十分な睡眠が必要です。", opts: ["necessary","natural","national","normal"], col: ["necessary","essential","required","needed"] },
    { w: "continue", m: "続ける", ex: "Please ___ reading the next paragraph.", answerForm: "continue", exJa: "次の段落を読み続けてください。", opts: ["continue","contain","control","consider"], col: ["continue","keep","go on","proceed"] }
  ],
  "2": [
    { w: "achieve", m: "達成する", ex: "She worked hard to ___ her goal of becoming a nurse.", answerForm: "achieve", exJa: "彼女は看護師になるという目標を達成するために努力しました。", opts: ["achieve","accept","affect","allow"], col: ["achieve","accomplish","reach","attain"] },
    { w: "benefit", m: "利益・恩恵", ex: "Regular exercise has many ___ for your health.", answerForm: "benefits", exJa: "定期的な運動は健康に多くの恩恵があります。", opts: ["benefits","behaviors","borders","branches"], col: ["benefit","advantage","merit","gain"] },
    { w: "consequence", m: "結果・影響", ex: "You should think about the ___ of your decision.", answerForm: "consequences", exJa: "自分の決断の結果について考えるべきです。", opts: ["consequences","conditions","connections","conclusions"], col: ["consequence","result","outcome","effect"] },
    { w: "contribute", m: "貢献する", ex: "Everyone should ___ ideas to the group discussion.", answerForm: "contribute", exJa: "全員がグループ討論に意見を出すべきです。", opts: ["contribute","continue","control","consider"], col: ["contribute","add","donate","help"] },
    { w: "essential", m: "不可欠な", ex: "Clean water is ___ for a healthy life.", answerForm: "essential", exJa: "きれいな水は健康な生活に不可欠です。", opts: ["essential","expensive","exciting","excellent"], col: ["essential","vital","necessary","crucial"] },
    { w: "influence", m: "影響を与える", ex: "Parents strongly ___ their children's habits.", answerForm: "influence", exJa: "親は子どもの習慣に強く影響を与えます。", opts: ["influence","increase","include","inform"], col: ["influence","affect","shape","impact"] },
    { w: "maintain", m: "維持する", ex: "It is difficult to ___ a high level of fitness.", answerForm: "maintain", exJa: "高いフィットネスレベルを維持するのは難しいです。", opts: ["maintain","mention","manage","measure"], col: ["maintain","keep","preserve","sustain"] },
    { w: "significant", m: "重要な", ex: "There has been a ___ change in the company policy.", answerForm: "significant", exJa: "会社の方針に重要な変化がありました。", opts: ["significant","similar","simple","several"], col: ["significant","important","major","notable"] },
    { w: "tend", m: "〜する傾向がある", ex: "People ___ to check their phones too often.", answerForm: "tend", exJa: "人はスマートフォンを確認しすぎる傾向があります。", opts: ["tend","try","turn","take"], col: ["tend","be likely","incline","usually"] },
    { w: "vary", m: "異なる・変わる", ex: "Prices ___ depending on the season and location.", answerForm: "vary", exJa: "価格は季節や場所によって異なります。", opts: ["vary","visit","value","view"], col: ["vary","differ","change","range"] }
  ],
  "pre1": [
    { w: "accommodate", m: "収容する・適応する", ex: "The new hall can ___ up to three hundred guests.", answerForm: "accommodate", exJa: "新しいホールは最大300人の客を収容できます。", opts: ["accommodate","accomplish","accumulate","acknowledge"], col: ["accommodate","house","hold","adapt"] },
    { w: "comprehensive", m: "包括的な", ex: "The report provides a ___ overview of the market.", answerForm: "comprehensive", exJa: "その報告書は市場の包括的な概観を示しています。", opts: ["comprehensive","competitive","comparative","compulsory"], col: ["comprehensive","complete","thorough","wide-ranging"] },
    { w: "deteriorate", m: "悪化する", ex: "Without treatment, his condition may ___ quickly.", answerForm: "deteriorate", exJa: "治療をしなければ、彼の状態は急速に悪化するかもしれません。", opts: ["deteriorate","determine","demonstrate","develop"], col: ["deteriorate","worsen","decline","degenerate"] },
    { w: "elaborate", m: "詳細に述べる", ex: "Could you ___ on the main points of your plan?", answerForm: "elaborate", exJa: "計画の要点について詳しく述べてもらえますか。", opts: ["elaborate","eliminate","estimate","evaluate"], col: ["elaborate","explain","expand","detail"] },
    { w: "inevitable", m: "避けられない", ex: "Some degree of change is ___ in a growing company.", answerForm: "inevitable", exJa: "成長する会社ではある程度の変化は避けられません。", opts: ["inevitable","incredible","independent","individual"], col: ["inevitable","unavoidable","certain","sure"] },
    { w: "perspective", m: "視点・見通し", ex: "Try to look at the problem from a different ___.", answerForm: "perspective", exJa: "その問題を別の視点から見てみてください。", opts: ["perspective","performance","permission","percentage"], col: ["perspective","viewpoint","angle","outlook"] },
    { w: "prominent", m: "著名な・目立つ", ex: "She is a ___ researcher in climate science.", answerForm: "prominent", exJa: "彼女は気候科学の分野で著名な研究者です。", opts: ["prominent","permanent","previous","practical"], col: ["prominent","notable","leading","distinguished"] },
    { w: "reluctant", m: "気が進まない", ex: "He was ___ to share his personal information online.", answerForm: "reluctant", exJa: "彼はオンラインで個人情報を共有することに気が進みませんでした。", opts: ["reluctant","relevant","regular","reliable"], col: ["reluctant","unwilling","hesitant","resistant"] },
    { w: "substantial", m: "相当な・実質的な", ex: "The project requires a ___ amount of funding.", answerForm: "substantial", exJa: "そのプロジェクトには相当な資金が必要です。", opts: ["substantial","successful","sufficient","suitable"], col: ["substantial","considerable","significant","large"] },
    { w: "vulnerable", m: "脆弱な", ex: "Young children are more ___ to infectious diseases.", answerForm: "vulnerable", exJa: "小さな子どもは感染症により弱いです。", opts: ["vulnerable","valuable","various","visible"], col: ["vulnerable","weak","exposed","at risk"] }
  ],
  "1": [
    { w: "alleviate", m: "軽減する", ex: "The new policy aims to ___ traffic congestion downtown.", answerForm: "alleviate", exJa: "新しい政策は都心の交通渋滞を軽減することを目指しています。", opts: ["alleviate","allocate","alter","analyze"], col: ["alleviate","ease","reduce","relieve"] },
    { w: "discrepancy", m: "不一致・食い違い", ex: "There is a clear ___ between the two sets of data.", answerForm: "discrepancy", exJa: "2つのデータセットの間には明らかな不一致があります。", opts: ["discrepancy","description","discussion","discovery"], col: ["discrepancy","difference","inconsistency","gap"] },
    { w: "exacerbate", m: "悪化させる", ex: "Harsh criticism can ___ an already tense situation.", answerForm: "exacerbate", exJa: "厳しい批判は、すでに緊迫した状況をさらに悪化させうる。", opts: ["exacerbate","examine","execute","exclude"], col: ["exacerbate","worsen","aggravate","intensify"] },
    { w: "meticulous", m: "細心の", ex: "She is ___ about checking every figure in the report.", answerForm: "meticulous", exJa: "彼女は報告書の数字を一つ一つ確認することに細心です。", opts: ["meticulous","mediocre","moderate","modern"], col: ["meticulous","careful","thorough","precise"] },
    { w: "pragmatic", m: "実用的な・現実的な", ex: "We need a ___ solution that works within our budget.", answerForm: "pragmatic", exJa: "予算内で機能する現実的な解決策が必要です。", opts: ["pragmatic","precious","previous","primary"], col: ["pragmatic","practical","realistic","sensible"] },
    { w: "scrutinize", m: "精査する", ex: "The committee will ___ every detail of the proposal.", answerForm: "scrutinize", exJa: "委員会は提案の細部をすべて精査します。", opts: ["scrutinize","schedule","secure","select"], col: ["scrutinize","examine","inspect","review"] },
    { w: "ubiquitous", m: "至る所にある", ex: "Smartphones have become almost ___ in modern life.", answerForm: "ubiquitous", exJa: "スマートフォンは現代生活のほぼ至る所に存在するようになりました。", opts: ["ubiquitous","unique","usual","urgent"], col: ["ubiquitous","omnipresent","widespread","common"] },
    { w: "ambiguous", m: "曖昧な", ex: "The contract uses ___ language that confuses both sides.", answerForm: "ambiguous", exJa: "その契約は双方を混乱させる曖昧な表現を使っています。", opts: ["ambiguous","ambitious","annual","ancient"], col: ["ambiguous","unclear","vague","uncertain"] },
    { w: "coherent", m: "一貫した・筋の通った", ex: "He presented a ___ argument supported by clear evidence.", answerForm: "coherent", exJa: "彼は明確な証拠に支えられた一貫した議論を提示しました。", opts: ["coherent","common","complex","concrete"], col: ["coherent","logical","consistent","clear"] },
    { w: "ephemeral", m: "はかない・短命の", ex: "Social media trends are often ___ and fade within weeks.", answerForm: "ephemeral", exJa: "ソーシャルメディアの流行はしばしばはかなく、数週間で消えます。", opts: ["ephemeral","essential","enormous","efficient"], col: ["ephemeral","fleeting","short-lived","temporary"] }
  ]
};


// ========== EXPANDED VOCABULARY ==========
/*
 * The original prototype contains 10 words per level.  To expand the actual
 * question pool without making this HTML file enormous, the app loads the
 * open MIT-licensed Kantan English-Japanese Dictionary at runtime and builds
 * five 1,500-word pools from its SVL level metadata.
 *
 * Mapping used here (approximate difficulty bands):
 *   3級   SVL 1-3
 *   準2級 SVL 4-5
 *   2級   SVL 6-7
 *   準1級 SVL 8-9
 *   1級   SVL 10-12
 *
 * The existing 50 curated entries remain as a fallback and are preserved
 * at the front of each pool.
 */
const VOCAB_SOURCE_URL =
  "https://raw.githubusercontent.com/gunyarakun/kantan-ej-dictionary/master/kantan-ej-dictionary.json";

let WORD_BANKS = null;
let vocabLoadPromise = null;

/**
 * Kantan EJ dictionary format:
 *   { "apple": { "ja": ["リンゴ", "りんご"], "rank": 2878, "freq": 676, "svl_level": 1 }, ... }
 * Also accepts array-of-objects or nested formats as a fallback.
 */
function flattenDictionaryEntries(node, out = []) {
  if (!node) return out;

  // Primary path: top-level word → entry map (kantan-ej-dictionary)
  if (typeof node === "object" && !Array.isArray(node)) {
    const keys = Object.keys(node);
    // Heuristic: if most keys look like English words and values have ja/svl_level, treat as map
    let mapHits = 0;
    const sample = keys.slice(0, 30);
    for (const k of sample) {
      const v = node[k];
      if (v && typeof v === "object" && !Array.isArray(v) &&
          (v.ja != null || v.svl_level != null || v.svl != null || v.meaning_ja != null)) {
        mapHits++;
      }
    }
    if (mapHits >= Math.min(5, sample.length) || (keys.length > 100 && mapHits >= 3)) {
      for (const [word, info] of Object.entries(node)) {
        if (!info || typeof info !== "object") continue;
        out.push({
          word,
          ja: info.ja,
          meaning_ja: info.meaning_ja,
          translation: info.translation,
          translations: info.translations,
          meanings: info.meanings,
          level: info.level,
          svl: info.svl,
          svl_level: info.svl_level,
          svlLevel: info.svlLevel,
          rank_level: info.rank_level,
          rank: info.rank,
          freq: info.freq,
          part_of_speech: info.part_of_speech ?? info.pos,
          example: info.example,
          examples: info.examples
        });
      }
      return out;
    }
  }

  if (Array.isArray(node)) {
    node.forEach(v => flattenDictionaryEntries(v, out));
    return out;
  }
  if (typeof node !== "object") return out;

  const word = node.word ?? node.w ?? node.headword ?? node.lemma ?? node.name;
  const level = node.level ?? node.svl ?? node.svl_level ?? node.svlLevel ?? node.rank_level;
  const meaning =
    node.meaning_ja ?? node.translation_ja ?? node.translation ??
    node.translations_ja ?? node.translations ?? node.ja ?? node.meanings;

  if (typeof word === "string" && word.trim() && meaning != null && level != null) {
    out.push(node);
  }

  Object.values(node).forEach(v => {
    if (v && typeof v === "object") flattenDictionaryEntries(v, out);
  });
  return out;
}

function normalizeMeaning(value) {
  const clean = (s) => String(s || "")
    .replace(/^\[.*?\]\s*/g, "")  // drop meta tags like [場面や文脈から特定できる]
    .replace(/^\(+|\)+$/g, "")
    .trim();

  if (Array.isArray(value)) {
    return value
      .map(v => typeof v === "string" ? v : (v?.ja ?? v?.translation ?? v?.meaning ?? ""))
      .map(clean)
      .filter(s => s && !/^\[.*\]$/.test(s))
      .slice(0, 3)
      .join(" / ");
  }
  if (typeof value === "object" && value) {
    return clean(value.ja ?? value.translation ?? value.meaning ?? "");
  }
  return clean(value);
}

function inferPartOfSpeech(word, meaning = "") {
  const m = meaning.toLowerCase();
  // Japanese meanings such as 「名誉ある」「必要ある」 can end in る even
  // though the English headword is an adjective. Prefer the adjective signal
  // before the broad verb-ending heuristic.
  if (/な$|的な$|らしい$|い$|ある$|ない$/.test(m)) return "adjective";
  if (/に$|く$/.test(m)) return "adverb";
  if (/する$|くする$|える$|む$|る$/.test(m)) return "verb";
  return "noun";
}

/**
 * Normalize dictionary POS labels and use strong English morphology as a
 * safety net. The sentence engine must never treat a clearly adjectival
 * headword such as honorable as a verb merely because dictionary metadata is
 * missing or inconsistent.
 */
function normalizePartOfSpeech(word, rawPos, meaning = "") {
  const w = String(word || "").trim().toLowerCase();
  const raw = String(rawPos || "").trim().toLowerCase();
  const map = [
    [/^(adj|adjective|形容詞|形容動詞|い形容詞|な形容詞)/, "adjective"],
    [/^(adv|adverb|副詞)/, "adverb"],
    [/^(v|verb|動詞)/, "verb"],
    [/^(n|noun|名詞)/, "noun"]
  ];
  let pos = null;
  for (const [re, value] of map) {
    if (re.test(raw)) { pos = value; break; }
  }
  if (!pos) pos = inferPartOfSpeech(w, meaning);

  // Strong adjective suffixes are more reliable than a weak/missing POS tag.
  // Keep a small exception list for common nouns/adverbs ending in -ly.
  const adjectiveSuffix = /(?:able|ible|ous|ful|less|ive|ish|ary|ory)$/i;
  const adverbSuffix = /ly$/i;
  const lyAdjectiveExceptions = /^(friendly|lively|lovely|lonely|likely|daily|early|only)$/i;
  if (adjectiveSuffix.test(w)) pos = "adjective";
  else if (adverbSuffix.test(w) && !lyAdjectiveExceptions.test(w)) pos = "adverb";

  return pos;
}

function pickContextSentence(w, m, pos) {
  const s = `${w} ${m}`.toLowerCase();

  if (pos === "verb") {
    if (/決め|選|判断|決定|確定/.test(m)) return `After comparing the two plans, the team decided to ___ one before Friday.`;
    if (/改善|向上|発展|進歩/.test(m)) return `After months of practice, her performance began to ___.`;
    if (/増加|増や|上げ|拡大/.test(m)) return `The company plans to ___ production before the holiday season.`;
    if (/減少|減ら|下げ|軽減|和らげ/.test(m)) return `The new policy is designed to ___ traffic congestion in the city center.`;
    if (/避け|防|阻止|妨/.test(m)) return `Wearing protective equipment can ___ serious injuries at work.`;
    if (/得|獲得|手に入|取得|購入|買/.test(m)) return `She saved money for months to ___ a new laptop.`;
    if (/調べ|検査|精査|分析|研究|調査/.test(m)) return `Before approving the report, the committee will ___ the data carefully.`;
    if (/支援|助け|援助|手伝|貢献/.test(m)) return `The charity was created to ___ families affected by the disaster.`;
    if (/要求|必要|求め/.test(m)) return `The position will ___ excellent communication skills and careful planning.`;
    if (/影響|作用/.test(m)) return `Social media can strongly ___ how teenagers communicate with one another.`;
    if (/維持|保つ|保存|守る/.test(m)) return `Regular exercise helps people ___ a healthy lifestyle as they get older.`;
    if (/提案|勧め|推薦/.test(m)) return `During the meeting, the manager ___ that the deadline be extended by one week.`;
    if (/続|継続/.test(m)) return `Even when the task became difficult, she chose to ___ working until it was finished.`;
    if (/変化|変わ|異なる/.test(m)) return `Prices may ___ depending on the season and the location.`;
    if (/説明|明らか|示|証明/.test(m)) return `The diagram helps ___ why the machine stopped working.`;
    return null;
  }

  if (pos === "adjective") {
    if (/必要|不可欠|重要/.test(m)) return `A reliable internet connection is ___ when you work from home.`;
    if (/人気|有名|著名/.test(m)) return `The restaurant became ___ after a famous chef recommended it online.`;
    if (/危険|安全/.test(m)) return `The road is especially ___ after heavy rain, so drivers should slow down.`;
    if (/難|困難/.test(m)) return `The final exam was so ___ that many students needed extra time.`;
    if (/可能|不可能/.test(m)) return `With the right equipment, the task is completely ___.`;
    if (/十分|充分/.test(m)) return `We do not have ___ evidence to make a final decision yet.`;
    if (/相当|大き|重要な|かなり/.test(m)) return `The project required a ___ amount of time and money.`;
    if (/避けられ|必然|確実/.test(m)) return `Given the severe weather warning, some delays were ___.`;
    if (/脆弱|弱|影響を受け/.test(m)) return `Young children are particularly ___ to sudden changes in temperature.`;
    if (/曖昧|不明確|明確/.test(m)) return `The instructions were so ___ that several employees interpreted them differently.`;
    return null;
  }

  if (pos === "adverb") {
    if (/急|突然/.test(m)) return `The lights went out ___, leaving everyone in the dark.`;
    if (/慎重|注意深/.test(m)) return `The scientist examined the sample ___ before recording the results.`;
    if (/完全|十分|大いに/.test(m)) return `The new system is ___ different from the one we used last year.`;
    return null;
  }

  // Nouns: use a concrete situation so that the surrounding words provide a real clue.
  if (/機会|好機|チャンス/.test(m)) return `The internship gave her an excellent ___ to work abroad for six months.`;
  if (/結果|影響|結末/.test(m)) return `The decision had an unexpected ___ for local businesses.`;
  if (/利益|恩恵|利点|長所/.test(m)) return `One major ___ of regular exercise is better sleep at night.`;
  if (/経験/.test(m)) return `Teaching abroad gave him valuable ___ that helped him later in his career.`;
  if (/環境/.test(m)) return `The factory was fined for releasing chemicals into the surrounding ___.`;
  if (/問題|課題|困難/.test(m)) return `The engineers met to discuss the main ___ with the new bridge design.`;
  if (/理由|原因/.test(m)) return `The police are still investigating the exact ___ for the sudden fire.`;
  if (/方法|手段|方式/.test(m)) return `We need to find a more efficient ___ of transporting the equipment.`;
  if (/意見|考え|見解/.test(m)) return `Everyone at the meeting was invited to share an ___ about the proposed changes.`;
  if (/証拠|証明/.test(m)) return `The lawyer presented new ___ that changed the direction of the trial.`;
  if (/責任/.test(m)) return `The manager accepted full ___ for the mistake in the report.`;
  if (/視点|観点/.test(m)) return `Try looking at the problem from a different ___.`;
  return null;
}


// ========== NATURAL EXAMPLES ==========
// Priority:
//  1) Seed/dictionary example tied to the word's Japanese meaning
//  2) Tatoeba sentence that matches the target sense (JP meaning overlap + idiom filters)
//  3) Free Dictionary API example (English only; Japanese translation is fetched on demand)
// Never show a natural-looking sentence that uses a different sense of the word
// (e.g. "vice versa" for the meaning 悪徳).
const TATOEBA_SENTENCE_API = "https://api.tatoeba.org/v1/sentences";
const FREE_DICT_API = "https://api.dictionaryapi.dev/api/v2/entries/en/";
const PHONETIC_CACHE_KEY = "wordGuardPhoneticCacheV3";
let PHONETIC_CACHE = {};
let phoneticCacheLoaded = false;
// Temporary fetch misses are NOT written as permanent empty strings.
const PHONETIC_MISS = Object.create(null);

function loadPhoneticCache() {
  if (phoneticCacheLoaded) return;
  phoneticCacheLoaded = true;
  try {
    const c = JSON.parse(localStorage.getItem(PHONETIC_CACHE_KEY) || "{}");
    if (c && typeof c === "object") {
      // Drop accidental empty values from older logic
      for (const [k, v] of Object.entries(c)) {
        if (!v) continue;
        // Skip legacy ARPAbet-looking cache (e.g. /S IY1 S/)
        if (/\b[A-Z]{1,2}\d\b/.test(String(v)) || /\/[A-Z]{1,2}\s/.test(String(v))) continue;
        PHONETIC_CACHE[k] = v;
      }
    }
  } catch (e) {}
}

function savePhoneticCache() {
  try {
    const clean = {};
    for (const [k, v] of Object.entries(PHONETIC_CACHE)) {
      if (v) clean[k] = v;
    }
    localStorage.setItem(PHONETIC_CACHE_KEY, JSON.stringify(clean));
  } catch (e) {}
}

function formatIpa(ipa) {
  let s = String(ipa || "").trim();
  if (!s) return "";
  s = s.replace(/^\[|\]$/g, "");
  if (!s.startsWith("/")) s = "/" + s;
  if (!s.endsWith("/")) s = s + "/";
  return s;
}

function extractIpaFromDictionaryEntry(entry) {
  if (!entry) return "";
  if (entry.phonetic) return formatIpa(entry.phonetic);
  if (Array.isArray(entry.phonetics)) {
    for (const p of entry.phonetics) {
      if (p && p.text) return formatIpa(p.text);
    }
  }
  return "";
}

async function fetchIpaFromFreeDict(key) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 1800);
  try {
    const res = await fetch(FREE_DICT_API + encodeURIComponent(key), { signal: controller.signal });
    if (!res.ok) return "";
    const json = await res.json();
    const entry = Array.isArray(json) ? json[0] : null;
    return extractIpaFromDictionaryEntry(entry);
  } catch (e) {
    return "";
  } finally {
    clearTimeout(timeout);
  }
}

/** ARPAbet (CMU/Datamuse) → IPA for learner-facing display. */
const ARPA_TO_IPA = {
  AA: "ɑ", AE: "æ", AH: "ʌ", AO: "ɔ", AW: "aʊ", AY: "aɪ",
  B: "b", CH: "tʃ", D: "d", DH: "ð", EH: "ɛ", ER: "ɝ",
  EY: "eɪ", F: "f", G: "ɡ", HH: "h", IH: "ɪ", IY: "iː",
  JH: "dʒ", K: "k", L: "l", M: "m", N: "n", NG: "ŋ",
  OW: "oʊ", OY: "ɔɪ", P: "p", R: "r", S: "s", SH: "ʃ",
  T: "t", TH: "θ", UH: "ʊ", UW: "uː", V: "v", W: "w",
  Y: "j", Z: "z", ZH: "ʒ"
};

function arpaToIpa(arpa) {
  const tokens = String(arpa || "").trim().split(/\s+/).filter(Boolean);
  if (!tokens.length) return "";
  let out = "";
  let primary = -1;
  const parts = [];
  tokens.forEach((tok, i) => {
    const stress = /(\d)$/.exec(tok);
    const stressNum = stress ? Number(stress[1]) : null;
    const base = tok.replace(/\d/g, "").toUpperCase();
    const ipa = ARPA_TO_IPA[base] || base.toLowerCase();
    if (stressNum === 1) primary = parts.length;
    parts.push({ ipa, stress: stressNum });
  });
  // Mark primary stress before the stressed vowel nucleus
  for (let i = 0; i < parts.length; i++) {
    if (i === primary) out += "ˈ";
    out += parts[i].ipa;
  }
  return formatIpa(out);
}

/** Datamuse pronunciation → IPA. */
async function fetchIpaFromDatamuse(key) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 1800);
  try {
    const url = "https://api.datamuse.com/words?sp=" + encodeURIComponent(key) + "&qe=sp&md=r&max=1";
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) return "";
    const json = await res.json();
    if (!Array.isArray(json) || !json[0]) return "";
    const tags = json[0].tags || [];
    const pron = tags.find(t => typeof t === "string" && t.startsWith("pron:"));
    if (!pron) return "";
    const arpa = pron.slice(5).trim();
    if (!arpa) return "";
    return arpaToIpa(arpa);
  } catch (e) {
    return "";
  } finally {
    clearTimeout(timeout);
  }
}

/** Fetch IPA; only successful results are cached permanently. */
async function ensurePhonetic(wordOrText) {
  loadPhoneticCache();
  const key = String(typeof wordOrText === "object" ? (wordOrText?.w || "") : wordOrText || "")
    .toLowerCase()
    .trim();
  if (!key) return "";
  if (typeof wordOrText === "object" && wordOrText.ipa) {
    PHONETIC_CACHE[key] = wordOrText.ipa;
    return wordOrText.ipa;
  }
  if (PHONETIC_CACHE[key]) {
    if (typeof wordOrText === "object") wordOrText.ipa = PHONETIC_CACHE[key];
    return PHONETIC_CACHE[key];
  }
  // Avoid hammering the same miss within one session for a few seconds
  const missAt = PHONETIC_MISS[key] || 0;
  if (Date.now() - missAt < 8000 && missAt > 0) return "";

  let ipa = await fetchIpaFromFreeDict(key);
  if (!ipa) ipa = await fetchIpaFromDatamuse(key);
  if (ipa) {
    PHONETIC_CACHE[key] = ipa;
    savePhoneticCache();
    if (typeof wordOrText === "object") wordOrText.ipa = ipa;
    return ipa;
  }
  PHONETIC_MISS[key] = Date.now();
  return "";
}

function ipaSpan(ipa) {
  const s = formatIpa(ipa);
  if (!s) return "";
  return `<span class="ipa-text">${escapeHtml(s)}</span>`;
}



const TATOEBA_CACHE_KEY = "wordGuardExampleCacheV5";
let TATOEBA_EXAMPLE_CACHE = {};
let tatoebaCacheLoaded = false;

/** Fixed phrases where the headword is not the vocabulary sense we teach. */
const IDIOM_TRAP_PATTERNS = [
  /\bvice\s+versa\b/i,
  /\bas\s+well\s+as\b/i,
  /\bin\s+order\s+to\b/i,
  /\bby\s+means\s+of\b/i,
  /\bin\s+terms\s+of\b/i,
  /\bon\s+behalf\s+of\b/i,
  /\bin\s+spite\s+of\b/i,
  /\bfor\s+the\s+sake\s+of\b/i,
  /\bin\s+case\s+of\b/i,
  /\bmake\s+sure\b/i,
  /\btake\s+place\b/i,
  /\bpay\s+attention\b/i,
  /\bget\s+rid\s+of\b/i,
  /\bin\s+charge\s+of\b/i,
  /\bout\s+of\s+order\b/i,
  /\bfigure\s+out\b/i,
  /\blook\s+forward\s+to\b/i,
  /\bput\s+up\s+with\b/i
];


// Fixed compounds that can technically contain the headword but teach a different sense.
// These are rejected before ranking/caching so an old or lucky API result cannot
// surface a misleading example (e.g. "hot tub" when the card teaches 浴槽/たらい).
const SENSE_TRAP_PATTERNS = {
  tub: [/\bhot\s+tub\b/i, /\bspa\s+tub\b/i, /\bjacuzzi\s+tub\b/i]
};

function isSenseTrapSentence(sentence, word) {
  const w = String(word || "").toLowerCase().trim();
  const text = String(sentence || "");
  const patterns = SENSE_TRAP_PATTERNS[w] || [];
  return patterns.some(re => re.test(text));
}

const LEVEL_ORDER = ["3", "pre2", "2", "pre1", "1"];

/** Always-allowed high-frequency function / elementary words (not only Eiken lists). */
const BASIC_ALWAYS_ALLOWED = new Set([
  "a","an","the","i","you","he","she","it","we","they","me","him","her","us","them",
  "my","your","his","its","our","their","this","that","these","those",
  "am","is","are","was","were","be","been","being","do","does","did","done","doing",
  "have","has","had","having","will","would","can","could","shall","should","may","might","must",
  "not","no","yes","and","or","but","if","because","so","than","as","of","in","on","at","to","for",
  "from","with","by","about","into","over","after","before","between","under","up","down","out","off",
  "there","here","when","where","what","who","which","why","how","all","each","every","some","any","many",
  "much","more","most","other","another","such","only","own","same","too","very","just","also","even",
  "one","two","three","four","five","six","seven","eight","nine","ten",
  "first","second","third","last","next","new","old","good","bad","big","small","long","short",
  "high","low","early","late","young","great","little","few","lot","lots",
  "get","got","go","goes","went","gone","come","came","make","made","take","took","taken",
  "see","saw","seen","know","knew","known","think","thought","say","said","tell","told",
  "give","gave","given","find","found","use","used","want","like","need","try","call",
  "work","works","worked","working","people","person","time","year","day","way","man","woman","child",
  "world","life","hand","part","place","case","week","company","system","program","question",
  "school","student","teacher","book","home","house","friend","family","father","mother",
  "english","japanese","japan","america","american","today","tomorrow","yesterday",
  "please","thank","thanks","hello","ok","okay","well","now","then","still","already","yet",
  "again","once","ever","never","always","often","sometimes","usually","really","quite",
  "thing","things","something","anything","everything","nothing","someone","anyone","everyone",
  "mr","mrs","ms","dr"
]);

let _allowedVocabCache = {};

function getLevelsAtOrBelow(level) {
  const idx = LEVEL_ORDER.indexOf(String(level || "3"));
  if (idx < 0) return ["3"];
  return LEVEL_ORDER.slice(0, idx + 1);
}

/** Union of all headwords in WORD_BANKS / SEED for this level and below. */
function getAllowedVocabSet(level) {
  const lv = String(level || (typeof state !== "undefined" && state.level) || "3");
  if (_allowedVocabCache[lv]) return _allowedVocabCache[lv];
  const set = new Set(BASIC_ALWAYS_ALLOWED);
  const banks = (typeof WORD_BANKS !== "undefined" && WORD_BANKS) ? WORD_BANKS : SEED_WORD_BANKS;
  for (const key of getLevelsAtOrBelow(lv)) {
    const list = (banks && banks[key]) || [];
    for (const item of list) {
      const w = String(item.w || item.word || "").toLowerCase().trim();
      if (w) set.add(w);
      // also allow simple inflections of the headword
      if (w.endsWith("y") && w.length > 3) set.add(w.slice(0, -1) + "ies");
      if (w.endsWith("e")) set.add(w + "d");
      else set.add(w + "ed");
      set.add(w + "ing");
      set.add(w + "s");
      if (w.endsWith("s")) set.add(w);
    }
  }
  _allowedVocabCache[lv] = set;
  return set;
}

function tokenizeEnglish(sentence) {
  return String(sentence || "")
    .toLowerCase()
    .replace(/[^a-z'’-]+/g, " ")
    .split(/\s+/)
    .map(t => t.replace(/^['’-]+|['’-]+$/g, ""))
    .filter(t => t && /[a-z]/.test(t));
}

/**
 * Returns list of content tokens not in allowed vocab (excluding the target word).
 * Used to keep example sentences within the exam level.
 */
function outOfLevelTokens(sentence, level, targetWord) {
  const allowed = getAllowedVocabSet(level);
  const target = String(targetWord || "").toLowerCase();
  const bad = [];
  for (const tok of tokenizeEnglish(sentence)) {
    if (tok === target) continue;
    if (allowed.has(tok)) continue;
    // soft-match common inflection stripped forms
    let ok = false;
    for (const suf of ["ing", "ed", "es", "s", "ly", "er", "est"]) {
      if (tok.length > suf.length + 2 && tok.endsWith(suf)) {
        const stem = tok.slice(0, -suf.length);
        if (allowed.has(stem) || allowed.has(stem + "e") || allowed.has(stem + "y")) { ok = true; break; }
      }
    }
    if (!ok) bad.push(tok);
  }
  return bad;
}

function isLevelAppropriateSentence(sentence, level, targetWord) {
  // Allow up to 1 rare proper-looking token; reject if 2+ OOV content words
  const bad = outOfLevelTokens(sentence, level, targetWord);
  // Capitalized proper nouns often missing from banks — tolerate 1 short OOV
  if (bad.length === 0) return true;
  if (bad.length === 1 && bad[0].length <= 3) return true;
  return false;
}

function loadTatoebaCache() {

  if (tatoebaCacheLoaded) return;
  tatoebaCacheLoaded = true;
  try {
    const cached = JSON.parse(localStorage.getItem(TATOEBA_CACHE_KEY) || "{}");
    if (cached && typeof cached === "object") TATOEBA_EXAMPLE_CACHE = cached;
  } catch (e) {}
}

function saveTatoebaCache() {
  try {
    localStorage.setItem(TATOEBA_CACHE_KEY, JSON.stringify(TATOEBA_EXAMPLE_CACHE));
  } catch (e) {}
}
// Purge known bad examples from the previous cache generation once.
function purgeKnownBadExampleCache() {
  loadTatoebaCache();
  let changed = false;
  for (const [k, v] of Object.entries(TATOEBA_EXAMPLE_CACHE || {})) {
    if (!v?.ex) continue;
    const word = String(k).split("::")[0];
    if (isSenseTrapSentence(v.ex, word)) { delete TATOEBA_EXAMPLE_CACHE[k]; changed = true; }
  }
  if (changed) saveTatoebaCache();
}
purgeKnownBadExampleCache();

function hasExactWord(sentence, word) {
  const escaped = String(word || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(^|[^A-Za-z])${escaped}(?=$|[^A-Za-z])`, "i").test(String(sentence || ""));
}

/** True if the target word only appears inside a known multi-word idiom trap. */
function isIdiomTrapSentence(sentence, word) {
  const text = String(sentence || "");
  const w = String(word || "").toLowerCase();
  for (const re of IDIOM_TRAP_PATTERNS) {
    if (!re.test(text)) continue;
    // If removing the idiom still leaves an independent occurrence of the word, allow it.
    const stripped = text.replace(re, " ");
    if (!hasExactWord(stripped, w)) return true;
  }
  return false;
}

/** Split Japanese meaning into comparable tokens. */
function meaningTokens(meaning) {
  return String(meaning || "")
    .split(/[\/・、,，\s\|]+/)
    .map(s => s.replace(/[のをにがはもでとへや]/g, "").trim())
    .filter(s => s.length >= 2);
}

function japaneseSenseScore(ja, meaning) {
  const tokens = meaningTokens(meaning);
  if (!tokens.length || !ja) return 0;
  let hit = 0;
  for (const t of tokens) {
    if (String(ja).includes(t)) hit += 1;
  }
  // Strong bonus when any meaning token appears in the Japanese translation
  if (hit > 0) return 40 + hit * 25;
  // Mild penalty when no overlap (likely different sense)
  return -35;
}

function sentenceQualityScore(sentence, word, meaning, ja, level) {
  const text = String(sentence || "").trim();
  const count = text.split(/\s+/).length;
  if (!text || count < 4 || count > 20) return -999;
  if (!hasExactWord(text, word)) return -999;
  if (isIdiomTrapSentence(text, word)) return -999;
  if (isSenseTrapSentence(text, word)) return -999;

  const lv = level || (typeof state !== "undefined" && state.level) || "3";
  const oov = outOfLevelTokens(text, lv, word);
  // OOV is a ranking signal, not a hard gate. The previous hard rejection
  // discarded many perfectly natural dictionary/Tatoeba sentences (especially
  // in WAVE 2+), because one sentence can naturally contain a few words outside
  // the learner's current level. Keep them but rank simpler sentences higher.

  let score = 100;
  // Prefer level-friendly sentences without making the vocabulary filter a
  // source of false negatives.
  score -= Math.min(30, oov.length * 8);
  if (/^[A-Z]/.test(text)) score += 8;
  if (/[.!?]$/.test(text)) score += 5;
  if (count >= 6 && count <= 14) score += 10;
  if (/[“”"'`]/.test(text)) score -= 3;
  // Prefer simpler classroom-style sentences
  if (count <= 12) score += 4;
  score += japaneseSenseScore(ja, meaning);
  // Prefer zero OOV
  if (oov.length === 0) score += 30;
  return score;
}

const MYMEMORY_TRANSLATION_API = "https://api.mymemory.translated.net/get";
const JA_TRANSLATION_CACHE_KEY = "wordGuardSentenceJaCacheV1";
let JA_TRANSLATION_CACHE = {};
let jaTranslationCacheLoaded = false;
const EXAMPLE_INFLIGHT = new Map();

function loadJaTranslationCache() {
  if (jaTranslationCacheLoaded) return;
  jaTranslationCacheLoaded = true;
  try {
    const c = JSON.parse(localStorage.getItem(JA_TRANSLATION_CACHE_KEY) || "{}");
    if (c && typeof c === "object") JA_TRANSLATION_CACHE = c;
  } catch (e) {}
}

function saveJaTranslationCache() {
  try { localStorage.setItem(JA_TRANSLATION_CACHE_KEY, JSON.stringify(JA_TRANSLATION_CACHE)); } catch (e) {}
}

function hasUsableJapaneseTranslation(value) {
  const s = String(value || "").trim();
  if (!s) return false;
  return !/(意味で使われる例文|英英辞典の例文|日本語訳は取得できませんでした|日本語訳はありません|取得中)/.test(s);
}

async function fetchJapaneseSentenceTranslation(sentence, opts = {}) {
  const text = String(sentence || "").trim();
  if (!text) return "";
  loadJaTranslationCache();
  if (JA_TRANSLATION_CACHE[text]) return JA_TRANSLATION_CACHE[text];

  // Keep this fallback on-demand. The battle preloader should not fire a
  // translation request for all 1,500 words; translation is needed when the
  // learner actually sees the explanation.
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), opts.timeoutMs || 4500);
  try {
    const params = new URLSearchParams({ q: text, langpair: "en|ja" });
    const res = await fetch(`${MYMEMORY_TRANSLATION_API}?${params.toString()}`, {
      cache: "force-cache",
      signal: controller.signal
    });
    if (!res.ok) return "";
    const data = await res.json();
    const translated = String(data?.responseData?.translatedText || "").trim();
    if (!translated || translated.toLowerCase() === text.toLowerCase()) return "";
    JA_TRANSLATION_CACHE[text] = translated;
    saveJaTranslationCache();
    return translated;
  } catch (e) {
    return "";
  } finally {
    clearTimeout(timeout);
  }
}

function getJapaneseTranslation(item) {
  const ts = Array.isArray(item?.translations) ? item.translations : [];
  const candidates = ts
    .filter(t => t && t.lang === "jpn" && t.text)
    .sort((a, b) => Number(b.is_direct) - Number(a.is_direct));
  return candidates[0]?.text || "";
}


// Hand-checked safe example patterns for high-frequency words
const SAFE_PATTERNS = {
  decide: { pattern: "We need to decide on a date for the meeting.", ja: "会議の日程を決める必要があります。" },
  improve: { pattern: "She is taking an online course to improve her English.", ja: "彼女は英語を上達させるためにオンライン講座を受けています。" },
  opportunity: { pattern: "This program gives students an opportunity to study abroad.", ja: "このプログラムは学生に留学の機会を与えます。" },
  benefit: { pattern: "Regular exercise has many benefits for your health.", ja: "定期的な運動は健康に多くの恩恵があります。", answerForm: "benefits" },
  suggest: { pattern: "I suggest that we take a short break now.", ja: "少し休憩をとることを提案します。" },
  continue: { pattern: "Please continue reading the next paragraph.", ja: "次の段落を読み続けてください。" },
  achieve: { pattern: "She worked hard to achieve her goal of becoming a nurse.", ja: "彼女は看護師になるという目標を達成するために努力しました。" },
  experience: { pattern: "Working abroad gave him valuable experience in business.", ja: "海外勤務は彼に貴重なビジネス経験を与えました。" },
  environment: { pattern: "We must protect the natural environment for future generations.", ja: "将来の世代のために自然環境を守らなければなりません。" },
  necessary: { pattern: "A good night's sleep is necessary for your health.", ja: "健康のためには十分な睡眠が必要です。" },
  responsible: { pattern: "You are responsible for locking the door before you leave.", ja: "出かける前に鍵をかける責任があります。" },
  influence: { pattern: "Parents strongly influence their children's habits.", ja: "親は子どもの習慣に強く影響を与えます。" },
  maintain: { pattern: "It is difficult to maintain a high level of fitness.", ja: "高いフィットネスレベルを維持するのは難しいです。" },
  significant: { pattern: "There has been a significant change in the company policy.", ja: "会社の方針に重要な変化がありました。" },
  contribute: { pattern: "Everyone should contribute ideas to the group discussion.", ja: "全員がグループ討論に意見を出すべきです。" },
  essential: { pattern: "Clean water is essential for a healthy life.", ja: "きれいな水は健康な生活に不可欠です。" },
  tend: { pattern: "People tend to check their phones too often.", ja: "人はスマートフォンを確認しすぎる傾向があります。" },
  vary: { pattern: "Prices vary depending on the season and location.", ja: "価格は季節や場所によって異なります。" },
  apple: { pattern: "I had an apple with my lunch today.", ja: "今日の昼食にりんごを食べました。" },
  study: { pattern: "I study English for thirty minutes every night.", ja: "毎晩30分英語を勉強します。" },
  tub: { pattern: "She filled the tub with warm water before taking a bath.", ja: "彼女はお風呂に入る前に、浴槽に温かいお湯をためました。" },
  illusion: { pattern: "The magician created the illusion that the woman had disappeared.", ja: "そのマジシャンは、女性が消えたように見える錯覚を生み出しました。" }
};

/** Escape a string for safe use inside RegExp. */
function escapeRegExp(s) {
  return String(s || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** Minimum naturalness checks before showing an example. */
function isNaturalExample(sentence, word) {
  const text = String(sentence || "").trim();
  const w = String(word || "").trim();
  if (!text || !w) return false;
  if (text.length < 15 || text.length > 180) return false;
  if (!/[.!?]$/.test(text)) return false;
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length < 5) return false;
  const bad = [
    /^they decided to .+ it carefully\.?$/i,
    /^it was a .+ day for the students\.?$/i,
    /^she answered the question .+\.?$/i,
    /^this .+ is useful in daily life\.?$/i,
    /^the word ".+" is important here\.?$/i,
    /^this word means /i,
    /^the ___ /i,
    /^the word /i
  ];
  if (bad.some(re => re.test(text))) return false;
  // Obvious grammatical poison pills. More detailed POS validation is performed
  // by SentenceAI when a full word object is available.
  if (/\bto\s+honorable\b/i.test(text)) return false;
  if (!hasExactWord(text, w)) {
    const stem = w.toLowerCase().replace(/(?:ing|ed|es|s)$/i, "");
    if (stem.length >= 3) {
      const re = new RegExp("(^|[^A-Za-z])" + escapeRegExp(stem) + "[a-z]*($|[^A-Za-z])", "i");
      if (!re.test(text)) return false;
    } else {
      return false;
    }
  }
  return true;
}

/**
 * Build a blank sentence while preserving the surface form used in the example
 * (e.g. benefits, decided, improving).
 */
function createBlankSentence(fullSentence, headword, answerForm) {
  const sentence = String(fullSentence || "").trim();
  const form = String(answerForm || headword || "").trim();
  const head = String(headword || "").trim();
  if (!sentence) return { blank: "", answerForm: form || head };
  const tryReplace = (target) => {
    if (!target) return null;
    const re = new RegExp("(^|[^A-Za-z])(" + escapeRegExp(target) + ")(?=$|[^A-Za-z])", "i");
    if (!re.test(sentence)) return null;
    let used = form;
    const blank = sentence.replace(re, (m, pre, matched) => {
      used = matched;
      return pre + "___";
    });
    return { blank, answerForm: used };
  };
  return tryReplace(form) || tryReplace(head) || {
    blank: sentence.replace(new RegExp(escapeRegExp(head), "i"), "___"),
    answerForm: form || head
  };
}

/** Curated seed example aligned with the taught meaning. */
function exampleFromSeed(word) {
  const raw = String(word?.ex || "").trim();
  const w = String(word?.w || "").trim();
  if (!w || !raw) return null;
  const form = String(word?.answerForm || w).trim();
  let sentence = raw.includes("___") ? raw.replace(/___/g, form) : raw;
  if (isIdiomTrapSentence(sentence, w) || isSenseTrapSentence(sentence, w)) return null;
  if (!isNaturalExample(sentence, w) && !isNaturalExample(sentence, form)) return null;
  const ja = hasUsableJapaneseTranslation(word.exJa) ? String(word.exJa).trim() : "";
  return { ex: sentence, ja, source: "seed", answerForm: form };
}



async function fetchFromTatoeba(word) {
  const key = String(word?.w || "").toLowerCase();
  const meaning = word?.m || "";
  if (!key) return null;

  // Tatoeba is used as a sentence source, not as the sole gatekeeper.
  // Requiring a Japanese translation/direct translation/native flag made the
  // hit rate unnecessarily low for many Eiken words.
  const search = async (exactOnly) => {
    const params = new URLSearchParams({
      lang: "eng",
      q: exactOnly ? `=${key}` : key,
      word_count: "5-18",
      sort: "relevance",
      limit: "50",
      "is_unapproved": "no",
      // Do not require Japanese at search time. Tatoeba v1 otherwise
      // hides many valid English examples. We can translate on demand.
      "showtrans": "all"
    });
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2200);
    try {
      const res = await fetch(`${TATOEBA_SENTENCE_API}?${params.toString()}`, {
        cache: "force-cache",
        signal: controller.signal
      });
      if (!res.ok) return [];
      const json = await res.json();
      return Array.isArray(json?.data) ? json.data : [];
    } catch (e) {
      return [];
    } finally {
      clearTimeout(timeout);
    }
  };

  const level = (typeof state !== "undefined" && state.level) || "3";
  const rank = (results) => results
    .map(item => {
      const ja = getJapaneseTranslation(item);
      const t = String(item?.text || "").trim();
      let score = sentenceQualityScore(t, key, meaning, ja, level);
      // When Tatoeba provides a Japanese translation, use it as a strong sense
      // signal. A fluent sentence in the wrong sense is worse than no hit.
      if (ja && japaneseSenseScore(ja, meaning) < 0) score = -999;

      // Do not require a Japanese translation. If the English sentence itself
      // is clean and contains the target word, it is still a useful source.
      if (score < 0 && hasExactWord(t, key) && !isIdiomTrapSentence(t, key) && !isSenseTrapSentence(t, key) && !(ja && japaneseSenseScore(ja, meaning) < 0)) {
        const count = t.split(/\s+/).length;
        if (count >= 5 && count <= 18) {
          score = 80 + (count >= 6 && count <= 14 ? 10 : 0);
          if (ja) score += Math.max(0, japaneseSenseScore(ja, meaning));
        }
      }
      return { item, ja, score };
    })
    .filter(x => x.score >= 50)
    .sort((a, b) => b.score - a.score);

  try {
    const [exactResults, fuzzyResults] = await Promise.all([
      search(true),
      search(false)
    ]);
    const best = rank(exactResults)[0] || rank(fuzzyResults)[0];
    if (!best) return null;

    // Japanese is optional for the sentence. The explanation layer translates
    // it when necessary, so absence of a JP link must not discard the example.
    return {
      ex: String(best.item.text).trim(),
      ja: best.ja ? String(best.ja).trim() : "",
      source: "Tatoeba",
      sentenceId: best.item.id || null
    };
  } catch (e) {
    return null;
  }
}

async function fetchFromFreeDictionary(word, opts = {}) {
  const key = String(word?.w || "").toLowerCase();
  if (!key) return null;
  const strictLevel = opts.strictLevel !== false;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 2200);
  try {
    const res = await fetch(FREE_DICT_API + encodeURIComponent(key), { signal: controller.signal });
    if (!res.ok) return null;
    const json = await res.json();
    const entry = Array.isArray(json) ? json[0] : null;
    if (!entry) return null;

    // Side-benefit: store IPA if present
    const ipa = extractIpaFromDictionaryEntry(entry);
    if (ipa) {
      loadPhoneticCache();
      PHONETIC_CACHE[key] = ipa;
      word.ipa = ipa;
      savePhoneticCache();
    }

    const meanings = Array.isArray(entry.meanings) ? entry.meanings : [];
    const level = (typeof state !== "undefined" && state.level) || "3";
    const collect = (requireLevel) => {
      const candidates = [];
      for (const m of meanings) {
        const defs = Array.isArray(m.definitions) ? m.definitions : [];
        for (const d of defs) {
          const ex = d.example && String(d.example).trim();
          if (!ex) continue;
          if (!hasExactWord(ex, key) || isIdiomTrapSentence(ex, key)) continue;
          if (requireLevel && !isLevelAppropriateSentence(ex, level, key)) continue;
          candidates.push(ex);
        }
      }
      candidates.sort((a, b) => a.split(/\s+/).length - b.split(/\s+/).length);
      return candidates;
    };
    // 取得率優先: 級フィルターなしを先に採用
    let candidates = collect(false);
    if (!candidates.length && strictLevel) candidates = collect(true);
    if (!candidates.length) return null;
    const ex = candidates[0];
    return {
      ex,
      ja: "",
      source: "FreeDictionary"
    };
  } catch (e) {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}


// ---------------------------------------------------------------------------
// AI-STYLE OFFLINE SENTENCE ENGINE
// ---------------------------------------------------------------------------
// The app cannot assume that an external LLM/API is reachable (especially on
// mobile networks).  This engine therefore creates a meaning-aware sentence
// immediately, using Eiken-friendly semantic frames.  Network sources are
// treated only as optional quality upgrades; they are never required for a
// question to exist.
const AI_STYLE_OVERRIDES = {
  tub: { ex: "She filled the tub with warm water before taking a bath.", ja: "彼女はお風呂に入る前に、浴槽に温かいお湯をためました。" },
  illusion: { ex: "The magician created an illusion that made the audience think the woman had disappeared.", ja: "そのマジシャンは、女性が消えたと思わせる錯覚を観客に見せました。" },
  policy: { ex: "The new policy will make it easier for employees to work from home.", ja: "新しい方針によって、従業員は在宅勤務をしやすくなります。" },
  approach: { ex: "We need a different approach to solving this problem.", ja: "この問題を解決するには、別の方法で取り組む必要があります。" },
  issue: { ex: "The committee discussed the issue at the meeting and agreed to take action.", ja: "委員会は会議でその問題について話し合い、対策を取ることに同意しました。" },
  advantage: { ex: "One advantage of working from home is that you can avoid a long commute.", ja: "在宅勤務の利点の一つは、長い通勤を避けられることです。" },
  disadvantage: { ex: "The main disadvantage of the plan is its high cost.", ja: "その計画の主な欠点は、費用が高いことです。" },
  evidence: { ex: "The police found new evidence that helped explain what had happened.", ja: "警察は、何が起きたのかを説明するのに役立つ新たな証拠を見つけました。" },
  consequence: { ex: "You should think carefully about the consequences of your decision.", ja: "自分の決断がもたらす結果について、よく考えるべきです。" },
  perspective: { ex: "Talking to people from different backgrounds can give you a new perspective.", ja: "異なる背景を持つ人と話すことで、新しい視点を得ることができます。" },
  honorable: { ex: "His decision to help the injured stranger was truly honorable.", ja: "けがをした見知らぬ人を助けるという彼の決断は、本当に立派なものでした。" }
};

const AI_STYLE_FRAMES = [
  // Verbs — specific semantic situations first.
  { pos:"verb", re:/決め|選ぶ|選択|判断|決定|確定/, t:[
    "After discussing the options, we decided to ___ before the end of the day.",
    "She took some time to ___ which plan would work best for her family."
  ]},
  { pos:"verb", re:/改善|向上|改良|発展|進歩/, t:[
    "The school introduced a new program to ___ students' reading skills.",
    "With regular practice, he was able to ___ his performance considerably."
  ]},
  { pos:"verb", re:/增加|増加|増や|上げ|拡大|伸ば/, t:[
    "The company plans to ___ production to meet growing demand.",
    "The city is trying to ___ the number of buses during busy hours."
  ]},
  { pos:"verb", re:/減少|減ら|下げ|軽減|和らげ|縮小/, t:[
    "The new measure is designed to ___ traffic in the city center.",
    "Regular exercise can help ___ stress and improve your mood."
  ]},
  { pos:"verb", re:/避け|防ぐ|阻止|妨げ|回避/, t:[
    "Wearing a seat belt can help ___ serious injuries in an accident.",
    "She left early to ___ the heavy traffic on the highway."
  ]},
  { pos:"verb", re:/得る|獲得|手に入|取得|購入|買う|入手/, t:[
    "He saved money for months to ___ a new computer.",
    "Students can ___ useful information from the library."
  ]},
  { pos:"verb", re:/調べ|検査|精査|分析|研究|調査|確認/, t:[
    "Before making a decision, the team will ___ the data carefully.",
    "The researchers will ___ the effects of the new treatment in detail."
  ]},
  { pos:"verb", re:/支援|助け|援助|手伝|貢献|寄付/, t:[
    "Many volunteers came to ___ families affected by the disaster.",
    "Everyone can ___ to the community by helping others."
  ]},
  { pos:"verb", re:/要求|求め|必要と|必要/, t:[
    "The job will ___ good communication skills and careful planning.",
    "The new system does not ___ any special equipment."
  ]},
  { pos:"verb", re:/影響|作用/, t:[
    "The weather can strongly ___ how people spend their free time.",
    "Social media continues to ___ the way young people communicate."
  ]},
  { pos:"verb", re:/維持|保つ|保存|守る|確保/, t:[
    "Regular exercise helps people ___ a healthy lifestyle.",
    "It is important to ___ a safe distance from the fire."
  ]},
  { pos:"verb", re:/提案|勧め|推薦/, t:[
    "The doctor will ___ that she get more sleep and exercise regularly.",
    "I would ___ taking the train because it is faster."
  ]},
  { pos:"verb", re:/続け|継続/, t:[
    "Even when the work became difficult, she chose to ___ until it was finished.",
    "If you ___ practicing every day, you will gradually improve."
  ]},
  { pos:"verb", re:/変化|変わ|異なる|違/, t:[
    "The price may ___ depending on the season.",
    "People's needs ___ as they get older."
  ]},
  { pos:"verb", re:/説明|明らか|示す|証明/, t:[
    "The diagram helps ___ why the machine stopped working.",
    "The report clearly ___ how the problem developed."
  ]},
  { pos:"verb", re:/作る|創造|生み出|建設|設立/, t:[
    "The project aims to ___ more opportunities for young people.",
    "The company plans to ___ a new product for the overseas market."
  ]},
  { pos:"verb", re:/含む|構成|包含/, t:[
    "The price ___ breakfast and free use of the hotel gym.",
    "The report ___ several useful examples from recent studies."
  ]},
  { pos:"verb", re:/参加|出席|加わ/, t:[
    "More than one hundred students ___ the event last weekend.",
    "Anyone can ___ the discussion if they have an idea to share."
  ]},
  { pos:"verb", re:/提供|供給|与え|届け/, t:[
    "The program ___ free meals to children during the summer.",
    "The website ___ useful information for people planning a trip."
  ]},
  { pos:"verb", re:/許可|認め|承認/, t:[
    "The manager ___ employees to work flexible hours.",
    "The school does not ___ students to use their phones during tests."
  ]},
  { pos:"verb", re:/拒否|断|否定|却下/, t:[
    "He politely ___ the offer because he had already made other plans.",
    "The company ___ the request after reviewing the details."
  ]},
  { pos:"verb", re:/発見|見つけ|気づ|認識/, t:[
    "She ___ an interesting fact while reading the article.",
    "The researchers ___ a possible cause of the problem."
  ]},
  { pos:"verb", re:/覚え|記憶|思い出/, t:[
    "I still ___ the first time I visited the city.",
    "She tried to ___ the names of everyone in the class."
  ]},
  { pos:"verb", re:/忘れ/, t:[
    "Please don't ___ to lock the door when you leave.",
    "People sometimes ___ to check the weather before leaving home."
  ]},
  { pos:"verb", re:/信じ|疑|期待|予想/, t:[
    "Many people ___ that the new plan will improve the situation.",
    "We did not ___ the meeting to last so long."
  ]},
  { pos:"verb", re:/比較|対比/, t:[
    "The study ___ the results from two different groups.",
    "Before buying a car, she ___ several models carefully."
  ]},
  { pos:"verb", re:/解決|対処|処理/, t:[
    "The team met to ___ the problem before it became more serious.",
    "We need to find a practical way to ___ this issue."
  ]},
  { pos:"verb", re:/準備|用意|備え/, t:[
    "The staff worked late to ___ for the busy season.",
    "She will ___ carefully for her final exam."
  ]},
  { pos:"verb", re:/移動|運ぶ|輸送|運搬/, t:[
    "The company uses trucks to ___ goods across the country.",
    "It is difficult to ___ such heavy equipment by hand."
  ]},
  { pos:"verb", re:/増|減|成長|発達|悪化|回復/, t:[
    "The situation began to ___ after the government changed its policy.",
    "Her condition continued to ___ over the next few weeks."
  ]},

  { pos:"verb", re:/話|述べ|伝え|報告|通知|知らせ|説明|連絡/, t:[
    "She will ___ the results to the team tomorrow.",
    "Please ___ the manager if you notice any problems."
  ]},
  { pos:"verb", re:/理解|分か|意味|認識/, t:[
    "It took me a while to ___ what the speaker meant.",
    "Children learn to ___ the difference as they gain more experience."
  ]},
  { pos:"verb", re:/考え|検討|思考|想像|推測/, t:[
    "We need to ___ carefully before making a final decision.",
    "She tried to ___ of a simple way to solve the problem."
  ]},
  { pos:"verb", re:/信頼|信じ|信用/, t:[
    "You should ___ people who have earned your trust.",
    "Many customers ___ the company because of its good reputation."
  ]},
  { pos:"verb", re:/希望|望|願|期待/, t:[
    "We ___ to finish the project by the end of the month.",
    "She ___ that her parents will be proud of her."
  ]},
  { pos:"verb", re:/移動|行く|来る|到着|出発|戻|歩|走|飛/, t:[
    "We will ___ early in the morning to avoid traffic.",
    "The train will ___ at the station in about ten minutes."
  ]},
  { pos:"verb", re:/使う|利用|活用/, t:[
    "You can ___ this app to practice English every day.",
    "The school will ___ the room for after-school activities."
  ]},
  { pos:"verb", re:/選|採用|雇|招|招待/, t:[
    "The company plans to ___ several new employees this year.",
    "She decided to ___ the blue dress for the ceremony."
  ]},
  { pos:"verb", re:/壊|修理|直|交換|取り替/, t:[
    "The mechanic will ___ the car before the weekend.",
    "We need to ___ the broken part as soon as possible."
  ]},
  { pos:"verb", re:/保護|守|救|助/, t:[
    "The new law is designed to ___ children from online abuse.",
    "Volunteers worked together to ___ people trapped by the flood."
  ]},
  { pos:"verb", re:/開始|始め|終|完了|停止|中止/, t:[
    "The meeting will ___ at nine and end before noon.",
    "The workers had to ___ the machine because of a safety problem."
  ]},
  { pos:"verb", re:/許|可能|禁止/, t:[
    "The new rules will ___ visitors to enter the building earlier.",
    "The sign does not ___ people to park here."
  ]},
  { pos:"verb", re:/似|含|持|所有|属/, t:[
    "The new model ___ several features that the older one did not have.",
    "This bag ___ enough space for everything I need."
  ]},

  // Adjectives.
  { pos:"adjective", re:/名誉|立派|尊敬|称賛|光栄|誇/, t:[
    "His decision to help the injured stranger was truly ___.",
    "Everyone agreed that returning the lost wallet was the ___ thing to do."
  ]},
  { pos:"adjective", re:/必要|不可欠|重要/, t:[
    "A reliable internet connection is ___ when you work from home.",
    "It is ___ to check the information before sharing it online."
  ]},
  { pos:"adjective", re:/人気|有名|著名/, t:[
    "The restaurant became ___ after a famous chef recommended it.",
    "This park is especially ___ with families during the summer."
  ]},
  { pos:"adjective", re:/危険|安全/, t:[
    "The road can be ___ after heavy rain, so drivers should slow down.",
    "The children were told that it was not ___ to swim there."
  ]},
  { pos:"adjective", re:/難|困難|簡単|容易/, t:[
    "The final question was so ___ that many students needed extra time.",
    "It was not ___ to find a solution that everyone could accept."
  ]},
  { pos:"adjective", re:/可能|不可能|実現/, t:[
    "With the right equipment, the task is completely ___.",
    "It may be ___ to finish the project by Friday."
  ]},
  { pos:"adjective", re:/十分|充分|足り/, t:[
    "We do not have ___ evidence to make a final decision yet.",
    "Make sure you have ___ time to complete the application."
  ]},
  { pos:"adjective", re:/相当|大き|かなり|莫大|膨大/, t:[
    "The project required a ___ amount of time and money.",
    "The company made a ___ investment in new technology."
  ]},
  { pos:"adjective", re:/避けられ|必然|確実/, t:[
    "Given the weather forecast, some delays were ___.",
    "Some degree of change is ___ as the company grows."
  ]},
  { pos:"adjective", re:/脆弱|弱|影響を受け|敏感/, t:[
    "Young children are particularly ___ to sudden changes in temperature.",
    "Older computers can be more ___ to security problems."
  ]},
  { pos:"adjective", re:/曖昧|不明確|明確|具体的/, t:[
    "The instructions were so ___ that several employees understood them differently.",
    "The manager gave us a ___ explanation of what we needed to do."
  ]},
  { pos:"adjective", re:/責任|責任感|信頼|頼り/, t:[
    "She is highly ___ and always finishes her work on time.",
    "We need someone ___ to look after the children."
  ]},
  { pos:"adjective", re:/便利|実用|効果|有効/, t:[
    "This app is especially ___ for people who travel frequently.",
    "We need a more ___ way to organize the information."
  ]},
  { pos:"adjective", re:/感情|幸せ|嬉|悲|怒|不安|心配|興奮/, t:[
    "She felt ___ after hearing the good news.",
    "He was ___ about starting his new job in another city."
  ]},
  { pos:"adjective", re:/一般的|普通|典型|特別|独特|珍/, t:[
    "It is ___ for the temperature to fall this low in winter.",
    "The museum has a ___ collection of local artwork."
  ]},
  { pos:"adjective", re:/高価|安価|費用|無料|経済/, t:[
    "The product is relatively ___ compared with similar models.",
    "They were looking for an ___ way to travel around the city."
  ]},

  { pos:"adjective", re:/予想外|意外|驚|突然/, t:[
    "The result was completely ___ and surprised everyone.",
    "The news was ___, but we soon understood what had happened."
  ]},
  { pos:"adjective", re:/複雑|単純|簡単/, t:[
    "The problem looked ___ at first, but it turned out to be more difficult.",
    "We need a ___ explanation that everyone can understand."
  ]},
  { pos:"adjective", re:/深刻|重大|深刻な/, t:[
    "The government needs to take action before the problem becomes more ___.",
    "The report warned of a ___ shortage of clean water."
  ]},
  { pos:"adjective", re:/新しい|古い|最近|現在|過去|将来/, t:[
    "The museum has an ___ exhibition that opened last week.",
    "The company is looking for a ___ way to reduce costs."
  ]},
  { pos:"adjective", re:/同じ|異なる|別|様々|多数|少数/, t:[
    "People from ___ backgrounds joined the discussion.",
    "The two products look similar, but they have ___ features."
  ]},
  { pos:"adjective", re:/必要|不可欠|重要/, t:[
    "A reliable internet connection is ___ when you work from home.",
    "It is ___ to check the information before sharing it online."
  ]},
  { pos:"adjective", re:/美しい|醜い|魅力|素敵|美味|新鮮/, t:[
    "The town is known for its ___ scenery and quiet streets.",
    "The restaurant is famous for its ___ local dishes."
  ]},
  { pos:"adjective", re:/広い|狭い|高い|低い|長い|短い|大きい|小さい/, t:[
    "The room is large enough to hold a ___ table and several chairs.",
    "They moved to a ___ apartment closer to the station."
  ]},
  // Nouns — high precision semantic frames.
  { pos:"noun", re:/理由|原因/, t:[
    "We still do not know the exact ___ for the sudden change.",
    "The report explains the main ___ why the project was delayed."
  ]},
  { pos:"noun", re:/結果|結末|影響/, t:[
    "The decision had an unexpected ___ for local businesses.",
    "We will discuss the possible ___ of the new policy tomorrow."
  ]},
  { pos:"noun", re:/利益|恩恵|利点|長所|メリット/, t:[
    "One major ___ of regular exercise is better sleep.",
    "The plan has several important ___ for local residents."
  ]},
  { pos:"noun", re:/欠点|短所|デメリット|不利/, t:[
    "The main ___ of the plan is its high cost.",
    "One ___ of living in the city is the amount of traffic."
  ]},
  { pos:"noun", re:/経験/, t:[
    "Working abroad gave him valuable ___ that helped him later in his career.",
    "The trip was an unforgettable ___ for the whole family."
  ]},
  { pos:"noun", re:/環境|自然/, t:[
    "The factory was fined for harming the surrounding ___.",
    "We need to protect the natural ___ for future generations."
  ]},
  { pos:"noun", re:/問題|課題|困難|トラブル/, t:[
    "The engineers met to discuss the main ___ with the new system.",
    "We need to solve this ___ before it affects more people."
  ]},
  { pos:"noun", re:/方法|手段|方式|アプローチ/, t:[
    "We need to find a more efficient ___ of transporting the equipment.",
    "The teacher introduced a new ___ for studying vocabulary."
  ]},
  { pos:"noun", re:/意見|考え|見解|主張/, t:[
    "Everyone at the meeting was invited to share an ___.",
    "She expressed her ___ during the discussion."
  ]},
  { pos:"noun", re:/証拠|証明/, t:[
    "The lawyer presented new ___ that changed the direction of the case.",
    "There was not enough ___ to support the claim."
  ]},
  { pos:"noun", re:/責任/, t:[
    "The manager accepted full ___ for the mistake in the report.",
    "Parents have a responsibility to provide a safe ___ for their children."
  ]},
  { pos:"noun", re:/視点|観点|見方/, t:[
    "Talking to others can give you a different ___.",
    "Try looking at the problem from another ___."
  ]},
  { pos:"noun", re:/機会|好機|チャンス/, t:[
    "The internship gave her an excellent ___ to work abroad.",
    "This event is a great ___ to meet people from different countries."
  ]},
  { pos:"noun", re:/選択|選択肢|オプション/, t:[
    "We have several ___, so let's compare them carefully.",
    "Taking the train is a good ___ if you want to avoid traffic."
  ]},
  { pos:"noun", re:/計画|予定|企画|プラン/, t:[
    "The team changed its ___ after receiving feedback from customers.",
    "We need a clear ___ before we begin the project."
  ]},
  { pos:"noun", re:/目的|目標|狙い/, t:[
    "The main ___ of the program is to help young people find jobs.",
    "She set a clear ___ for herself at the beginning of the year."
  ]},
  { pos:"noun", re:/成功|失敗/, t:[
    "The project was a ___ because everyone worked together.",
    "The team learned an important lesson from the ___."
  ]},
  { pos:"noun", re:/変化|変更|違い|差/, t:[
    "There has been a noticeable ___ in the way people shop.",
    "The study found a significant ___ between the two groups."
  ]},
  { pos:"noun", re:/情報|データ|知識/, t:[
    "The website provides useful ___ about local events.",
    "We need more ___ before making a final decision."
  ]},
  { pos:"noun", re:/連絡|通信|メッセージ|会話|議論/, t:[
    "Good ___ is essential when people work as a team.",
    "She sent a short ___ to let him know that she had arrived."
  ]},
  { pos:"noun", re:/法律|規則|ルール|制度|政策/, t:[
    "The new ___ will take effect next month.",
    "Everyone must follow the ___ when using the facility."
  ]},
  { pos:"noun", re:/研究|調査|実験/, t:[
    "The researchers published the results of their latest ___.",
    "The ___ showed that regular exercise can improve sleep."
  ]},
  { pos:"noun", re:/会議|集会|イベント|行事|式/, t:[
    "The ___ will be held at the community center next Saturday.",
    "More than two hundred people attended the ___."
  ]},
  { pos:"noun", re:/事故|事件|災害|火事|犯罪/, t:[
    "The police are investigating the ___ that happened last night.",
    "Several people were injured in the ___."
  ]},
  { pos:"noun", re:/会社|企業|組織|団体/, t:[
    "The ___ plans to open a new office next year.",
    "The organization helps small ___ develop their businesses."
  ]},
  { pos:"noun", re:/人|者|男性|女性|学生|教師|先生|医師|研究者|専門家|従業員|客|顧客|住民|市民|隣人|友人|家族|子ども/, t:[
    "The ___ spoke to reporters after the event.",
    "Several ___ joined the project and shared their ideas."
  ]},
  { pos:"noun", re:/場所|地域|地区|都市|町|国|施設|建物|店|公園|学校|病院|駅|空港|ホテル|家|部屋/, t:[
    "Many people visit the ___ during the summer.",
    "The ___ is located near the center of the city."
  ]},
  { pos:"noun", re:/食|料理|飲み物|食品|野菜|果物|肉|魚|米|パン|菓子/, t:[
    "The ___ is popular with visitors to the area.",
    "She bought some ___ at the market on her way home."
  ]},
  { pos:"noun", re:/道具|機械|製品|商品|装置|機器|車|自転車|コンピューター|電話|服|靴|かばん|本|雑誌|写真|絵/, t:[
    "The ___ was designed to make everyday tasks easier.",
    "She bought a new ___ because her old one was broken."
  ]},
  { pos:"noun", re:/時間|期間|時期|日|週|月|年|朝|夜|季節/, t:[
    "During this ___, many people travel to the area.",
    "The ___ lasted longer than we had expected."
  ]},
  { pos:"noun", re:/感情|気持ち|希望|不安|恐怖|怒り|喜び|悲しみ|愛/, t:[
    "She could not hide her ___ when she heard the news.",
    "Talking to a friend helped him deal with his ___."
  ]},
  { pos:"noun", re:/費用|価格|金|お金|予算|収入|利益|税/, t:[
    "The ___ was higher than we had expected.",
    "We need to consider the ___ before making a decision."
  ]},
  { pos:"noun", re:/健康|病気|症状|治療|薬|運動|睡眠/, t:[
    "Regular exercise can have a positive effect on your ___.",
    "The doctor explained the best treatment for the ___."
  ]},
  { pos:"noun", re:/自然|天気|気候|空気|水|海|川|山|動物|植物|森林/, t:[
    "The area is known for its beautiful ___.",
    "Scientists are studying how changes in the ___ affect local wildlife."
  ]}
];

function aiStyleFrameFor(word, meaning, pos) {
  const p = String(pos || "noun").toLowerCase();
  const candidates = AI_STYLE_FRAMES.filter(f => f.pos === p && f.re && f.re.test(String(meaning || "")));
  if (!candidates.length) return null;
  // Prefer the most specific match (more Japanese meaning terms matched).
  candidates.sort((a,b) => String(b.re).length - String(a.re).length);
  return candidates[0];
}

function buildAIStyleExample(word) {
  const w = String(word?.w || "").trim();
  const meaning = String(word?.m || "").trim();
  const pos = normalizePartOfSpeech(w, word?.pos, meaning);
  const form = String(word?.answerForm || w).trim();
  if (!w || !form) return null;

  const override = AI_STYLE_OVERRIDES[w.toLowerCase()];
  if (override) return { ex: override.ex, ja: override.ja || "", source: "ai-style-curated", answerForm: form };

  const frame = aiStyleFrameFor(w, meaning, pos);
  let templates = frame?.t || [];

  // Broad but still natural fallbacks. They are used only when the Japanese
  // meaning does not expose a more precise semantic category.
  if (!templates.length && pos === "verb") templates = [
    "The team decided to ___ the problem before the meeting.",
    "She plans to ___ the task carefully before the end of the day."
  ];
  if (!templates.length && pos === "adjective") templates = [
    "The situation was more ___ than we had expected.",
    "The result was surprisingly ___, even to the people who planned the project."
  ];
  if (!templates.length && pos === "adverb") templates = [
    "The team responded ___ to the unexpected problem.",
    "She spoke ___ so that everyone in the room could understand her."
  ];
  if (!templates.length && pos === "noun") {
    if (/物|もの|品|物質|材料|道具|機械|製品|商品|装置|設備|家具|衣類|食|飲|乗り物|車|本|写真|絵/.test(meaning)) templates = [
      "She bought the ___ because she needed it for her daily work.",
      "The ___ was carefully designed to make the task easier."
    ];
    else if (/人|者|男性|女性|学生|教師|先生|医師|研究者|専門家|従業員|客|顧客|住民|市民|友人|家族|子ども/.test(meaning)) templates = [
      "The ___ spoke with the manager after the meeting.",
      "Several ___ took part in the project this year."
    ];
    else if (/場所|地域|地区|都市|町|国|施設|建物|店|公園|学校|病院|駅|空港|ホテル|家|部屋/.test(meaning)) templates = [
      "Many people visit the ___ during the summer.",
      "The ___ is easy to reach by public transportation."
    ];
  }
  if (!templates.length) templates = [
    "I learned about the ___ in class today, and it was more interesting than I expected.",
    "The ___ was mentioned in the article I read this morning."
  ];

  const index = Math.abs([...w].reduce((n,ch) => n + ch.charCodeAt(0), 0)) % templates.length;
  const sentence = String(templates[index]).replace(/___/g, form).trim();

  // Grammar guardrails for generated examples. These catch the exact class of
  // failure where an adjective is inserted into a verb frame (e.g.
  // "decided to honorable the problem"). A sentence that fails these checks
  // is discarded instead of being shown to the learner.
  if (pos === "adjective" && new RegExp("\\bto\\s+" + escapeRegExp(form) + "\\b", "i").test(sentence)) return null;
  if (pos === "adverb" && new RegExp("\\bto\\s+" + escapeRegExp(form) + "\\b", "i").test(sentence)) return null;
  if (pos === "noun" && new RegExp("\\bto\\s+" + escapeRegExp(form) + "\\b", "i").test(sentence)) return null;

  if (!isNaturalExample(sentence, w) && !isNaturalExample(sentence, form)) return null;
  return { ex: sentence, ja: "", source: "ai-style-local", answerForm: form };
}

function buildLocalContextExample(word) {
  const w = String(word?.w || "").trim();
  const meaning = String(word?.m || "").trim();
  const pos = normalizePartOfSpeech(w, word?.pos, meaning);
  const form = String(word?.answerForm || w).trim();
  if (!w || !meaning || !form) return null;

  // Reuse the app's meaning-aware sentence library. This function had been
  // defined but was never actually connected to the retrieval pipeline.
  let template = "";
  try {
    template = pickContextSentence(w, meaning, pos) || "";
  } catch (e) {}

  // No semantic template = no locally invented sentence.
  // A generic POS template can be grammatically correct but teach the wrong sense,
  // which is worse than falling back to a meaning question.
  if (!template || !template.includes("___")) return null;

  const sentence = template.replace(/___/g, form).trim();
  if (!isNaturalExample(sentence, w) && !isNaturalExample(sentence, form)) return null;

  return {
    ex: sentence,
    ja: "",
    source: "local-context",
    answerForm: form
  };
}

async function fetchNaturalExampleUncached(word, opts = {}) {
  loadTatoebaCache();
  const key = String(word?.w || word || "").toLowerCase();
  if (!key) return null;
  const meaningKey = String(word?.m || "").slice(0, 40);
  const levelKey = (typeof state !== "undefined" && state.level) || "3";
  const cacheKey = key + "::" + levelKey + "::" + meaningKey;
  if (TATOEBA_EXAMPLE_CACHE[cacheKey]?.ex && isNaturalExample(TATOEBA_EXAMPLE_CACHE[cacheKey].ex, key)) {
    const cached = TATOEBA_EXAMPLE_CACHE[cacheKey];
    if (!cached.ja || hasUsableJapaneseTranslation(cached.ja)) return cached;
    // 旧バージョンの仮訳は捨て、必要になった時点で本物の訳を取得する。
    cached.ja = "";
  }

  const remember = (result) => {
    const posSafe = !(result?.ex && window.SentenceAI && word &&
      !window.SentenceAI.grammarCompatible(String(result.ex), word));
    if (result?.ex && posSafe && isNaturalExample(result.ex, key) && !isSenseTrapSentence(result.ex, key)) {
      const clean = { ...result };
      if (!hasUsableJapaneseTranslation(clean.ja)) clean.ja = "";
      TATOEBA_EXAMPLE_CACHE[cacheKey] = clean;
      setTimeout(() => { try { saveTatoebaCache(); } catch (e) {} }, 0);
      return clean;
    }
    // Unnatural → do not cache as success
    return null;
  };

  // 1) Hand-checked examples first.
  const safe = SAFE_PATTERNS[key];
  if (safe?.pattern) {
    const form = safe.answerForm || word.answerForm || word.w;
    const hit = remember({
      ex: safe.pattern,
      ja: safe.ja || "",
      source: "safe",
      answerForm: form
    });
    if (hit) return hit;
  }

  // 2) Curated seed examples already bundled with the vocabulary.
  const seed = exampleFromSeed(word);
  if (seed) {
    const hit = remember(seed);
    if (hit) return hit;
  }

  // 3) Real AI generation through the secure serverless endpoint.
  // The API key never reaches the iPhone/browser. A short timeout keeps the
  // first question responsive; successful generations are stored in IndexedDB.
  if (window.SentenceAI) {
    try {
      const ai = await window.SentenceAI.generate(word, { timeoutMs: opts.aiTimeoutMs || 1800 });
      if (ai?.ex) {
        const hit = remember({ ...ai, source: "ai-server" });
        if (hit) return hit;
      }
    } catch (e) {}
  }

  // 4) AI-style offline generation. This is the zero-network fallback, so the
  // game still works immediately when the AI endpoint is unavailable.
  const aiLocal = buildAIStyleExample(word);
  if (aiLocal) {
    const hit = remember(aiLocal);
    if (hit) return hit;
  }

  // 5) Network corpus: Tatoeba + Free Dictionary (fallback only).
  const networkTimeoutMs = opts.timeoutMs || (typeof WAVE_API_TIMEOUT_MS === "number" ? WAVE_API_TIMEOUT_MS : 4000);
  const withTimeout = (p, ms) => Promise.race([
    p,
    new Promise(resolve => setTimeout(() => resolve(null), ms))
  ]);
  try {
    const [tatoeba, free] = await Promise.all([
      withTimeout(fetchFromTatoeba(word), networkTimeoutMs),
      withTimeout(fetchFromFreeDictionary(word, { strictLevel: false }), networkTimeoutMs)
    ]);
    if (tatoeba?.ex) {
      const hit = remember({ ...tatoeba, answerForm: word.answerForm || word.w });
      if (hit) return hit;
    }
    if (free?.ex) {
      const hit = remember({ ...free, answerForm: word.answerForm || word.w });
      if (hit) return hit;
    }
  } catch (e) {}

  // 5) Legacy semantic local fallback (kept for compatibility with the
  // previous sentence engine).
  // This is deliberately last: real dictionary/Tatoeba examples always win.
  // It guarantees that a transient network failure cannot turn into a
  // "problem retrieval failed" state.
  const local = buildLocalContextExample(word);
  if (local) {
    const hit = remember(local);
    if (hit) return hit;
  }

  return null;
}

// Single-flight wrapper: preload and quiz preparation share the same request.
// This prevents WAVE 2+ from multiplying identical API calls.
async function fetchNaturalExample(word, opts = {}) {
  const key = String(word?.w || word || "").toLowerCase();
  if (!key) return null;
  const meaningKey = String(word?.m || "").slice(0, 40);
  const levelKey = (typeof state !== "undefined" && state.level) || "3";
  const inflightKey = `${key}::${levelKey}::${meaningKey}`;
  if (EXAMPLE_INFLIGHT.has(inflightKey)) return EXAMPLE_INFLIGHT.get(inflightKey);
  const promise = fetchNaturalExampleUncached(word, opts).finally(() => EXAMPLE_INFLIGHT.delete(inflightKey));
  EXAMPLE_INFLIGHT.set(inflightKey, promise);
  return promise;
}

// WAVE1のみフル読み込みUI。2WAVE目以降は前WAVE中にバックグラウンド先読み.
const WAVE_PRELOAD_MAX_MS = 3500;
const WAVE_PRELOAD_MIN_MS = 0; // 人為的な待ち時間は入れない
const WAVE_API_TIMEOUT_MS = 2200;
// 先読みが間に合わなかったときだけ短く待つ上限
const WAVE_SOFT_WAIT_MS = 1200;

function getWaveWordSlice(waveNo) {
  if (!battle || !Array.isArray(battle.waveWords)) return [];
  const size = battle.waveSize || 5;
  const start = (Math.max(1, waveNo) - 1) * size;
  return battle.waveWords.slice(start, start + size).filter(Boolean);
}

function getCurrentWaveWordSlice() {
  return getWaveWordSlice(battle?.wave || 1);
}

function removeWaveLoadLayer() {
  document.querySelectorAll(".wave-load-layer").forEach(el => el.remove());
}

function hasExampleSentence(word) {
  if (!word || !word.exSentence || !String(word.exSentence).trim()) return false;
  const sentence = String(word.exSentence).trim();
  const target = String(word.w || "").trim();
  const form = String(word.answerForm || target).trim();
  return (isNaturalExample(sentence, target) || (form && isNaturalExample(sentence, form)))
    && !isSenseTrapSentence(sentence, target);
}

/** 出題可能な状態（例文あり、またはこの場で取得失敗確定） */
function exampleReady(word) {
  if (!word) return false;
  if (hasExampleSentence(word)) return true;
  // none は「出題直前に最終試行した」場合のみ。先読み失敗の none は未準備扱い
  if (word.exSource === "none" && word._exampleFinalized) return true;
  return false;
}

function isWaveContentReady(waveNo) {
  const words = getWaveWordSlice(waveNo);
  if (!words.length) return true;
  return words.every(hasExampleSentence);
}

function clearExampleFailure(word) {
  if (!word) return;
  if (word.exSource === "none" && !word._exampleFinalized) {
    word.exSource = "";
    word.exSentence = "";
    word.ex = "";
    word.exJa = "";
  }
}

/** 指定WAVEの例文・発音を並列取得（UIなし）。 */
async function fetchWaveContent(waveNo, opts = {}) {
  if (!battle || battle.over) return;
  const words = getWaveWordSlice(waveNo);
  if (!words.length) return;
  const timeoutMs = opts.timeoutMs || WAVE_API_TIMEOUT_MS;
  await Promise.all(words.map(async (w) => {
    try {
      await ensureNaturalExample(w);
      ensurePhonetic(w).catch(() => {});
    } catch (e) {}
  }));
  if (battle) {
    if (!battle.prefetchedWaves) battle.prefetchedWaves = {};
    // A WAVE is considered prefetched only when every word has an example.
    // Partial failures remain retryable instead of being permanently marked done.
    if (words.every(hasExampleSentence)) battle.prefetchedWaves[waveNo] = true;
  }
}

/** 次WAVEを裏で先読み（非ブロッキング） */
function prefetchNextWaveInBackground() {
  if (!battle || battle.over) return;
  const next = (battle.wave || 1) + 1;
  const maxWave = Math.ceil((battle.totalWords || 1500) / (battle.waveSize || 5));
  if (next > maxWave) return;
  if (battle.prefetchedWaves && battle.prefetchedWaves[next]) return;
  if (battle._prefetchingWave === next) return;
  // Do not start another 5-word network burst while the current stocker is
  // already filling the same battle. It caused request storms and made later
  // WAVEs look like they had "no examples" when the real problem was timing.
  if (battle._prefetchingRemaining) return;
  battle._prefetchingWave = next;
  fetchWaveContent(next).finally(() => {
    if (battle && battle._prefetchingWave === next) battle._prefetchingWave = 0;
  });
}

function prefetchUpcomingBattleContent(count = 4) {
  // 互換: 次WAVE先読みに寄せる
  prefetchNextWaveInBackground();
}

/**
 * これから先の問題文をストックする。
 * - 例文がまだ無い語は前問の解答中に取得を続ける（取得不可で打ち切らない）
 * - 取れた分はストックし、さらに先の語も順に読む
 */
function prefetchAheadStock(fromIndex, count = 8) {
  if (!battle || battle.over || !Array.isArray(battle.waveWords)) return;
  const start = Math.max(0, fromIndex | 0);
  const end = Math.min(battle.waveWords.length, start + count);
  const targets = [];
  for (let i = start; i < end; i++) {
    const w = battle.waveWords[i];
    if (!w) continue;
    if (hasExampleSentence(w)) continue;
    clearExampleFailure(w);
    targets.push(w);
  }
  if (!targets.length) {
    // 先が揃っていれば次WAVEも温める
    prefetchNextWaveInBackground();
    return;
  }
  // 同時に走らせすぎない（直列に近い並列2）
  if (battle._prefetchingRemaining) return;
  battle._prefetchingRemaining = true;
  (async () => {
    try {
      // 近い問題から、最大3件ずつ並列取得。5件同時の波状アクセスは避けつつ、
      // 直列取得より大幅に先読みを速くする。single-flight で重複要求も抑止。
      for (let i = 0; i < targets.length; i += 3) {
        if (!battle || battle.over) break;
        const batch = targets.slice(i, i + 3);
        await Promise.all(batch.map(async w => {
          if (!w || hasExampleSentence(w)) return;
          clearExampleFailure(w);
          try {
            await ensureNaturalExample(w);
            ensurePhonetic(w).catch(() => {});
          } catch (e) {}
        }));
      }
      // さらに先をストック
      if (battle && !battle.over) {
        battle._prefetchingRemaining = false;
        const nextStart = (battle.wordIndex || 0) + 1;
        // 再帰的にストック（既に揃っている分はスキップされる）
        prefetchAheadStock(nextStart, 8);
      }
    } finally {
      if (battle) battle._prefetchingRemaining = false;
    }
  })();
}

/** 現WAVEの未取得 + 先読みストック */
function prefetchRemainingCurrentWave() {
  if (!battle) return;
  prefetchAheadStock((battle.wordIndex || 0) + 1, 10);
}

/**
 * WAVE1専用: 読み込みUI付きで現在WAVEの問題を取得。
 */
async function prepareCurrentWave(options = {}) {
  if (!battle || battle.over) return;
  const waveNo = battle.wave || 1;
  const words = getCurrentWaveWordSlice();
  const total = words.length || (battle.waveSize || 5);

  battle.wavePreparing = true;
  battle.pausedForQuizPrep = true;
  removeWaveLoadLayer();

  // 原因: seed即時ヒットやAPI即失敗で取得処理が1秒以内に終わり、最低2秒表示だけで終了していた。
  // WAVE1は約5秒の枠を使い切り、その間ネットワークで例文を探す。
  // 全キャラのフルスクリーン・スライドショー（2.5秒ごと）
  const allChars = (typeof CHARACTERS !== "undefined" ? CHARACTERS : []).filter(c => c && c.img);
  const slides = allChars.length ? allChars.slice() : [];
  for (let i = slides.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [slides[i], slides[j]] = [slides[j], slides[i]];
  }
  const slideHtml = slides.map((c, i) =>
    `<div class="wl-slide${i === 0 ? " active" : ""}" data-name="${String(c.name || "").replace(/"/g, "")}" style="background-image:url('${c.img}')"></div>`
  ).join("");

  const layer = document.createElement("div");
  layer.className = "wave-load-layer";
  layer.innerHTML = `
    <div class="wl-slideshow">${slideHtml || ""}</div>
    <div class="wl-slide-dim"></div>
    <div class="wl-ui">
      <div class="wl-char-name" id="waveLoadCharName">${slides[0] ? String(slides[0].name || "") : ""}</div>
      <div class="wl-title">WAVE ${waveNo} 準備中</div>
      <div class="wl-sub">このWAVEの例文を準備しています…<br>
        <span style="font-size:.8rem;opacity:.85;">自然な例文を先に即時生成。2WAVE目以降はバトル中に先読みします</span>
      </div>
      <div class="wave-load-bar"><i id="waveLoadFill" style="width:2%"></i></div>
      <div class="wl-count" id="waveLoadCount">0 / ${total} 問　取得済み</div>
    </div>
  `;
  document.body.appendChild(layer);

  let slideIdx = 0;
  const slideTimer = slides.length > 1 ? setInterval(() => {
    const nodes = layer.querySelectorAll(".wl-slide");
    if (!nodes.length) return;
    nodes[slideIdx]?.classList.remove("active");
    slideIdx = (slideIdx + 1) % nodes.length;
    nodes[slideIdx]?.classList.add("active");
    const nameEl = document.getElementById("waveLoadCharName");
    if (nameEl) nameEl.textContent = nodes[slideIdx]?.getAttribute("data-name") || "";
  }, 2500) : null;

  const t0 = Date.now();
  const deadline = t0 + WAVE_PRELOAD_MAX_MS;

  const updateUi = (forceDone) => {
    const got = words.filter(w => w && w.exSentence && String(w.exSentence).trim()).length;
    const f = document.getElementById("waveLoadFill");
    const c = document.getElementById("waveLoadCount");
    const elapsed = Date.now() - t0;
    const timePct = Math.min(100, Math.round((elapsed / WAVE_PRELOAD_MAX_MS) * 100));
    const dataPct = Math.round((got / Math.max(1, total)) * 100);
    const pct = Math.max(2, Math.min(100, Math.round(timePct * 0.55 + dataPct * 0.45)));
    if (f) f.style.width = (forceDone ? 100 : pct) + "%";
    if (c) c.textContent = `${got} / ${total} 問　取得済み`;
  };

  updateUi();
  const uiTimer = setInterval(() => updateUi(), 200);

  const applyExample = (w, cached) => {
    if (!w || !cached || !cached.ex) return;
    w.exSentence = cached.ex;
    w.exJa = cached.ja || "";
    w.exSource = cached.source || "net";
    try {
      w.ex = cached.ex.replace(new RegExp(String(w.w || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"), "___");
    } catch (e) {
      w.ex = String(cached.ex).replace(String(w.w || ""), "___");
    }
  };

  const loadOne = async (w) => {
    if (!w) return;
    if (hasExampleSentence(w)) return;
    // Remove stale/semantically wrong examples before trying a fresh source.
    w.exSentence = ""; w.ex = ""; w.exJa = ""; w.exSource = "";
    try {
      // 手作業で確認した安全例文はネットワーク結果で上書きしない。
      // これにより「hot tub」のような別義の偶然のヒットを防ぐ。
      const safe = SAFE_PATTERNS[String(w.w || "").toLowerCase()];
      if (safe?.pattern) {
        applyExample(w, { ex: safe.pattern, ja: safe.ja || "", source: "safe", answerForm: safe.answerForm || w.answerForm || w.w });
        return;
      }
      // まずシードを即セット（あれば）、その後ネットワークで上書き改善
      const seed = exampleFromSeed(w);
      if (seed && seed.ex && !hasExampleSentence(w)) applyExample(w, seed);
      const cached = await fetchNaturalExample(w, {
        preferNetwork: true,
        timeoutMs: WAVE_API_TIMEOUT_MS,
        allowSoftSeed: true
      });
      if (cached && cached.ex && cached.source !== "template") {
        applyExample(w, cached);
      } else if (cached && cached.ex && !hasExampleSentence(w)) {
        applyExample(w, cached);
      }
    } catch (e) {}
  };

  let lastPending = Infinity;
  let attempts = 0;
  while (Date.now() < deadline) {
    const pending = words.filter(w => !(w && w.exSentence && String(w.exSentence).trim()));
    if (!pending.length) break;
    const remaining = deadline - Date.now();
    if (remaining < 150) break;
    attempts++;
    await Promise.all(pending.map(loadOne));
    updateUi();
    const stillPending = words.filter(w => !(w && w.exSentence && String(w.exSentence).trim())).length;
    if (!stillPending) break;
    // Retry only when the previous pass made no progress. This handles transient
    // mobile-network failures without hammering the APIs.
    if (stillPending >= lastPending && attempts < 3) {
      await new Promise(r => setTimeout(r, 180));
    }
    lastPending = stillPending;
    if (attempts >= 3) break;
  }

  // 最終フォールバック。ネットワークが失敗しても、既存の安全な seed /
  // 意味連動テンプレートがあれば即座に採用し、人工的な待ち時間は入れない。
  for (const w of words) {
    if (w && w.exSentence && String(w.exSentence).trim()) {
      ensurePhonetic(w).catch(() => {});
      continue;
    }
    try {
      const seed = await fetchNaturalExample(w, { preferNetwork: false, allowSoftSeed: true, timeoutMs: 500 });
      if (seed && seed.ex) applyExample(w, seed);
    } catch (e) {}
    ensurePhonetic(w).catch(() => {});
  }

  clearInterval(uiTimer);
  if (slideTimer) clearInterval(slideTimer);
  updateUi(true);
  // No artificial post-load delay: close the screen as soon as the first wave is ready.
  removeWaveLoadLayer();
  if (battle) {
    battle.wavePreparing = false;
    battle.pausedForQuizPrep = false;
    if (!battle.prefetchedWaves) battle.prefetchedWaves = {};
    battle.prefetchedWaves[waveNo] = true;
    // 読み込み時間内に取り切れなかった問題を、1問目の解答中に裏読み
    prefetchRemainingCurrentWave();
    prefetchNextWaveInBackground();
  }
}

async function ensureNaturalExample(word) {
  if (word && word.exSource === "none" && word._exampleFinalized) {
    return null;
  }
  if (word && hasExampleSentence(word)) {
    return {
      ex: word.exSentence,
      ja: word.exJa || "",
      source: word.exSource || "cache",
      answerForm: word.answerForm || word.w
    };
  }

  const cached = await fetchNaturalExample(word);
  if (cached && cached.ex && isNaturalExample(cached.ex, word.w)) {
    const form = cached.answerForm || word.answerForm || word.w;
    const built = createBlankSentence(cached.ex, word.w, form);
    word.exSentence = cached.ex;
    word.exJa = cached.ja || "";
    word.exSource = cached.source || "net";
    word.answerForm = built.answerForm || form;
    word.ex = built.blank || cached.ex;
    return { ...cached, answerForm: word.answerForm };
  }

  // Natural example unavailable → meaning-only question
  word.ex = "";
  word.exSentence = "";
  word.exJa = "";
  word.exSource = "none";
  if (word._finalAttempt) word._exampleFinalized = true;
  else word._exampleFinalized = false;
  return null;
}

function normalizeWord(entry) {
  const w = String(entry.word ?? entry.w ?? entry.headword ?? entry.lemma ?? entry.name ?? "").trim();
  const m = normalizeMeaning(
    entry.meaning_ja ?? entry.translation_ja ?? entry.translation ??
    entry.translations_ja ?? entry.translations ?? entry.ja ?? entry.meanings
  ).trim();

  if (!w || !m || w.length > 40 || !/^[A-Za-z][A-Za-z' -]*$/.test(w)) return null;

  // If a future dictionary source supplies examples, prefer them.
  const suppliedExample =
    entry.example ?? entry.example_sentence ?? entry.exampleSentence ??
    (Array.isArray(entry.examples) ? (entry.examples[0]?.en ?? entry.examples[0]?.english ?? entry.examples[0]) : null);

  const pos = normalizePartOfSpeech(w, entry.part_of_speech ?? entry.pos ?? entry.partOfSpeech, m);
  // Never invent a generic sentence here. A battle sentence must come from a
  // trusted example source or an explicit AI-generation step; otherwise the
  // word is presented as a meaning question rather than showing unnatural English.
  const ex = typeof suppliedExample === "string" && suppliedExample.includes(w)
    ? suppliedExample.replace(new RegExp(w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"), "___")
    : "";

  return {
    w,
    m,
    ex,
    exJa: "",
    exSource: suppliedExample ? "dictionary" : "none",
    exSentence: ex.replace("___", w),
    pos,
    opts: [w],
    col: [w]
  };
}

function numericLevel(entry) {
  const raw = entry.level ?? entry.svl ?? entry.svl_level ?? entry.svlLevel ?? entry.rank_level;
  const n = Number.parseFloat(String(raw).replace(/[^\d.]/g, ""));
  return Number.isFinite(n) ? n : null;
}

function addUnique(target, item, seen) {
  if (!item || seen.has(item.w.toLowerCase())) return;
  seen.add(item.w.toLowerCase());
  target.push(item);
}

function buildExpandedBanks(entries) {
  const ranges = {
    "3": [1, 3],
    pre2: [4, 5],
    "2": [6, 7],
    pre1: [8, 9],
    "1": [10, 12]
  };

  const banks = {};
  const byLevel = Object.keys(ranges).reduce((o, k) => (o[k] = [], o), {});

  for (const raw of entries) {
    const lvl = numericLevel(raw);
    if (lvl == null) continue;
    const item = normalizeWord(raw);
    if (!item) continue;
    // Prefer higher-frequency words within the same band (lower rank = more common)
    item._rank = Number(raw.rank) || 999999;

    for (const [key, [min, max]] of Object.entries(ranges)) {
      if (lvl >= min && lvl <= max) byLevel[key].push(item);
    }
  }

  // Sort each band by frequency rank so the first 1,500 are the most common
  for (const key of Object.keys(byLevel)) {
    byLevel[key].sort((a, b) => a._rank - b._rank);
  }

  const levelKeys = Object.keys(ranges);
  for (const key of levelKeys) {
    const seen = new Set();
    const result = [];

    // Preserve the hand-curated words first.
    for (const item of (SEED_WORD_BANKS[key] || [])) {
      const copy = { ...item, pos: item.pos || inferPartOfSpeech(item.w, item.m) };
      addUnique(result, copy, seen);
    }

    // Then use the dictionary's frequency ordering.
    for (const item of byLevel[key]) {
      if (result.length >= 1500) break;
      addUnique(result, item, seen);
    }

    /*
     * If a strict SVL band ever has fewer than 1,500 entries in a future
     * dictionary revision, fill from adjacent levels rather than silently
     * reducing the advertised pool size.
     */
    if (result.length < 1500) {
      const allCandidates = [];
      for (const other of levelKeys) {
        for (const item of byLevel[other]) {
          if (!seen.has(item.w.toLowerCase())) allCandidates.push(item);
        }
      }
      allCandidates.sort((a, b) => a._rank - b._rank);
      for (const item of allCandidates) {
        if (result.length >= 1500) break;
        addUnique(result, item, seen);
      }
    }

    // Strip internal rank helper before storing
    banks[key] = result.slice(0, 1500).map(({ _rank, ...rest }) => rest);
  }

  return banks;
}

async function ensureWordBanks() {
  if (WORD_BANKS) return WORD_BANKS;
  if (vocabLoadPromise) return vocabLoadPromise;

  vocabLoadPromise = (async () => {
    try {
      const response = await fetch(VOCAB_SOURCE_URL, { cache: "force-cache" });
      if (!response.ok) throw new Error(`Vocabulary fetch failed: ${response.status}`);
      const data = await response.json();
      const entries = flattenDictionaryEntries(data);
      const expanded = buildExpandedBanks(entries);

      const complete = ["3", "pre2", "2", "pre1", "1"].every(
        key => expanded[key] && expanded[key].length >= 1500
      );

      if (!complete) throw new Error("The downloaded dictionary did not provide enough words.");
      WORD_BANKS = expanded;
      _allowedVocabCache = {};
      try {
        localStorage.setItem("wordGuardVocabCacheV2", JSON.stringify(WORD_BANKS));
      } catch (e) {}
    } catch (e) {
      console.warn("Word bank load failed:", e);
      // Use a previously cached expanded bank if available.
      try {
        const cached = JSON.parse(localStorage.getItem("wordGuardVocabCacheV2") || localStorage.getItem("wordGuardVocabCacheV1") || "null");
        if (cached && ["3", "pre2", "2", "pre1", "1"].every(k => Array.isArray(cached[k]) && cached[k].length >= 1500)) {
          WORD_BANKS = cached;
          return WORD_BANKS;
        }
      } catch (ignore) {}

      // Last-resort fallback: keep the original app usable.
      WORD_BANKS = SEED_WORD_BANKS;
    }
    return WORD_BANKS;
  })();

  return vocabLoadPromise;
}


/* AI-generated raster character portraits. c1/c2 retain their existing portraits; c3-c8 are replaced below. */
const PORTRAIT_DATA = {
  "c1": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIjJSUlFhwpLCgkKyEkJST/2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCT/wAARCAGAAYADASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAABQECAwQGBwAI/8QARBAAAQMCBAMFBQcCBAQHAQEAAQACAwQRBRIhMQZBURMiYXGBFDKRobEHI0JSwdHwYuEVM3LxFiRDUwglNIKSorJEY//EABoBAAMBAQEBAAAAAAAAAAAAAAABAgMEBQb/xAAkEQEBAAIDAQEBAAICAwAAAAAAAQIRAyExEkEEUWETMiJCcf/aAAwDAQACEQMRAD8A+dA0qQCyRoTgFomFsnCx5JG6pwFkGW1l6y8BfmngBAMsnBODAeqXJ4WQRtivWT7JQ2/RBI8l0oYphHZSRU8lRI2KKN8j3aBrAST5BANoqCWunbBC27ndTYAdSei6lwX9g2K8Qxx1VXL7LTSd4EtIJHlutD9lH2H4nUup8SxmM0tI49q+J3vuIPdZbpzK+iIqeGiiDWM0HLoq8TrbCcIfYzwxws0SCibWVPOSYZtfJbXNBQMsyCGJoGmgFvQKGtxPsGk5gwfBZytxZkryC8u8jdVN3070M1GPRPDg1zOlwEIlxComkDIpWk8hbkqlLTDFJuzDbdXXymy1FDQUtBGGxQ3I/E45inbJ4nW1Giw98wD6uRx6NGl/NE2OjgbaOICyWR1xubfBVJJcut3eimX/ACejqisqR7vZ28AhdTW1TtAI3HfdWJJWn8bh5lU5pHG+jZW9CNVpKiqE9fNHfPGR48lQmxB+/ctbmSr0ssD3ZWh0Z2y5t0OqYX97s35j+Uix+q0lRVKoxGXXK6HyuULnxapBI7SAfFWamcNJbI58bv6hdDqmzwc0UcrerTYq91Jj8bmGpmjHk0pn+Pyg61DR/wC1D5aankBMMronD8LtfmEPqI6mC5LMzerdb/BK55FqNRDj8ulqpl/EIlTcQ1bNc7JAOgXO/a7HvRgKWPEQw3u5p8Cp+7fT+XWsP4wyuDXhwPxHzWoosehqGguc03G5FiuJUfEDmgNe8SNHJ4utPhGLxSkZQ6I/0EkfBTdUS2NpxZwVhPFtE+KeCLO4HLIBsV8ucefZ9X8H4hJG6J5guSHHbL1B5j+FfUWF4kXAN7Vrr+YPwXuKOHaPijCpKOpAJIux5HeY7qEr/iql/XxaWHnooyxa/jPg2r4XxOanmjLWtJO2luRB6fRZh8ZBIO+yzyjaXpWISWUrmpllCoSySxTl5IGEHbqmFp23UyblQEdja6VOLRzSEWQDSEifbxTSEB47JpAPJOSXv5pKOAslC9volGiqlC7Jw1HJIAnjW+mqRvNbpqpG26WSAJ9tEE9bRJZPShv8KZGBvW6eGDonBifG0DdODaxh9A+vqWwsOUalzj+Fo3K+lvsc+yWKip4sar6UxRObmha8feTg/id0HQCyxX/h/wDs6lxrE3Y7Xw/+W0/ds9txO/8AIPAbn4c19OuksA1oAGw6BLevBrZrxHEwXs1o0A6ITiGIOY0ljbDq47q3WzCNpNszuRWSxarzuJlkDR0BuU5NhTxPFe1JBu7yVGji9tlDNWsJ1KicG1UwjiBNzYGy0+FYc2GJuRxDt7OF7qtpXKGiipogI4WFvU7lWyW20YGu6c1E1xAuAWuG4H1SSSteAJNL7O5f2S9M2WUg2uPXRU6iTXvXB8VJO9zdDy0Djy8Ch1RUujBFszRqW/l8lUidmTTaa6eIVGoqHNbmc3MBs5u48wnSzMeLtdYHrsUNqpnMN725anQ+auRFemqi9tiRK07a6qjJVvF+ycJW82OHfaoKibMXFpyv5tOxQ6aqvq4lrxs7p4LTxmvTVonaWkZ2ge67cIRUwOAMlI8gjeMlJLVFz7O7snIjS/qq8lSdXO5GziN/h1RsaUZqpsri2oY6OQfjG4UL6iaH3rPZ/wBxn6qeryT27RwudWSgbjohb3y0byHizTzGzktjSaRxkFw1knPXQqq8xk2yvjPndSOcCM0fq1MMjJNH7+PVRauQ0Zb3zetldo6x0DwWyWsqEjXx6g5h4hOinDT3mDzCg7G7wfHHgtD3hwW7wfGWyxhrnFzRrqdVyHD6yEPGYA+tlsMGqYLgxzvYbbP2WkZ3oZ+0Hg6m4rwsvYB7VG0ljwNfJfMGOYPNhNW+F8bgGkjUbeC+t6CeTJlf32HS41B/Zc3+1ng9lVE7EqWMF/8A1Gge90Pn9UsorG9vnohROCIVdN7PM9mvdPMKo9vRYt5ekC8nOCTnslTIvW1vfZLaw02XikDcvJNLSn2KR22yAaNkhGiXbQpOl9UHDU0p3okOgSM9upT2hMb4ap4VEUeCePJNapG6IBQNE8aJoT7IK0oSgG68E8J6Gy2Wx+zfgKo43xuClJfFS3u+Qblo3t0AG58QN1kqeF1RMyIXBcdwvqj7D+GWYVgAxIxBs1YAIx+WIHQeRNz4pydbT+6dKwbC6PBMNp8PoYWw09OwMjaNLAfzdW817uvYdfBejb3cuwVWunJaWM93mT9PHyUL2E45iBa0iJwjbb3rXLvJYuukzEu+Be7mtBi8sNO4vlcZJDs0lAWQSV1Yxrm5A87c1fhCvDmGFxFU8A30Gi0eQDQ8z8SmUEXZ0zYwLEA29NlYeM7L7EjRLRInHMN+8DofHxVKZ+UkW03LSpJqkMOYeRCoVdQ17SOY1B6hXjCpstVbQnunRp/RDqqYHS9iFFPWNyuB0voR0Qqsrg67SbObv4+K0ia9VTuiu8e7+JqpSYi13dLrtOrTvoq89fmaRm1+vgg9RMWEuae6TcjoVURpeq5dTlN7a26DwQ2SqDrgjbcHkq7q65sXeR6FRSyNl20frb9k9p0ke8Hualp908/JUqx82XPGbvaLgcnt6eiR1RY5X6A9OR6+YTXT3OV/Xfof2U2np6CuiqYbgdxxs5rvwO5pkzxD3JO9EdieSo1jHUFQ6qZpDJpM0a26PHkrEVSypY6OQAPb3TY79D/f9lO1aRSQ9m7NEbjeyS4ePHokc11O6xN49gen9kjx3gQbW1UWmfHIR3XbbC6e6EHVuiguHC9vMKaGTJo7Vp0BSB0bSDc6I3hlTJHa5v8AohwdEBmcCQeY5K7Ry0pcDme302VxFbzAsWsWsL7E8jstBWUsdfSPic0FsjS0jkbrH4S1sgaI5I3dL6FbHDs4bkfz68lf4h88cccMGGvqI2MIq4BmDbf50fXzCwDxbdfRn2q4C59E3F6UZamkddxA3Yd1wrHII3ymsiAAe4iRo2a7r6rPONOPL8AntUZbzVh7dNlERYrJubl03Xk5IRzSBiQp5TSgGO21KROdsk9CgQw6JpITyAmOSUkaAngXTQPingaDqqSc0adE8C2ya1oTwLHRAObonDQ3K8AlCCOa2+5UjW3TWjRStThX0e4IwQ45xDS0JJbHI8CV3Rl7n1Ow819p4PhzaCkihaxrGsaGhoGjQNAAuA/+Hjg81eKOxOeMdjSBsjyRu83yM9PePovouSRsTCeZ+qMrvo5P0krrDs26W3P6ILidbkJig1edL9P51VmurxTwkN1kdoEBrKgUkFyQZ5TYH6pYr9DqtlpTls9/N7vwpcFgDql0ty4DY9SUIxPFY6eAvGrM2Rn/APo/x8BqiHDNQ19HmMmZz3ONz1snstVq45LMhJ56G3X+BNfMGZ231b3x5KiKwOpbgjl6HkoKqtzNZO3W2hHUFVCs0hxGp7OQkHunvW6fz9UFqsQ7B17gtP0TsQqy2M63MZv5tssxX4hkY5jrkN1/9vNWWhCurLXe3XqOoQioqu0bmDu809dwqkeJhzuxkdqNA7r0VKrmfC8kEDkR/OSrY0Wpqi0790636FVH1biDa2YcuTlHLOHi2mVw0KovkeLjmzU+SNp0dNL3sw0BGo6pjah25cbj5jqvEtkbcc9QonCxvvb5pWp0sSO7YXvYn6qG5d3fxDbxXmDkDodl6QF3mFOx4khlbODFIbkDY8wh1Sx9HKJIwXdmDlb+ZnMHxG4VibM0tqI752Gzh9VLUNZWwNfHbXbwKLQg/wARZIwe5Ix7czG/itzHiqwqG37O5y7NvuPC/wCiFT004bJCx3ZvYe2gcOX5mpIK+bs71cWdm3axtu0+aRa7GG1GR1pNHDS/VWGHnu07qlC6GWMObI0sO19R8eSsthfDqxwLR0N0jX6eTI7s36xP0v08VaiiySZSbHl5KnBBUTAnKy3Uq9CJXBjXAFw0Dg4X8rKoVFKCUxzNBuLHa+63WE1ruzBzZg3Y8wuetqcknZSN+8bYgE7ojQ8TCmmZTBgjLtC52tlp4ys232NUzcYwqph0tNC5jrctN184cR4LUYNXzUEwJbPFma7+pq+hMLrjKzJG/tWvGjgLA+qyP2lcOsqsMbWRtaJaZ7X35luzksp0Md7fPrmclG5uqv1UIZUyRs1aHEDyUMjMrbbn6LDTq2qEJE9wTUj2YQmkdVIU06pBGRyTSpSEx40QDDsmlO3CaUKSN0TxumDfZStA3tqmk4a+ac0C6QDwTwLi6AcLEJRYb6rw0snBAObsVcw2Ht6uNhbmF8xHlr/b1VVoyjVbz7JuHm43xLStkZdhl7w6tb3nfoPVVim+vpn7LuHf+GeDqKmeLVUw9oqDzL3a29Bp6I3V1PaSEA9xninS1Ap6c5d7WCDYnVdhRhoNnP5+CP8Aaop1VeJqz3rW28B/Oax2JY1JimIGOmPdkIhitybfU+tr+QCix3F3RwyiMkPqCY2kcmDT91BgNOY2yVjx/lCzf9R/YBZZZTx0TDpHiV62uMMV/Z6cdkwX3P4itNhUDqWliZaxbr9dfmqOHUDWtBcLk7+ZR5rQ1o8Al9K+VdspaCw6NcLHwI0VdlQXMMbtCe6fP+WUtQNHWGt8w/VD532eS0794ea0mSbgr1coYRmIDR3HLJ42x8Yfa5MZv5t2Wlrvv2h1j3xY+B/2QOptLE3tPebeGTyPP5BO0scf8snJM+9jq5nzarkFaKqHJKbvAyk8yP3VOqhdDIWG4cw29FXzmKQSN06gdFnOTtd4+ksgfDMYXnR3unl/Cml5c0Ot3m91wTp7VEJaTctGZrudlXZKXaute+V469CtfpjcEjXZTYbHVvn0XjuD8Cob3JZfUjTzT2uEsZ1s4ck7WdxPiOhadOY8FOLPAd10PgqZedCNxqp2PF7DY6p7RYdYNflPuu7p1UMJ9lmdG73Haeqkc7MLddj4qOdvasDvxDT1T2SOvgBImaAXNN7+HNDZqlzGFjJTGGCxDmgjwICLRuzssR6FB8Vw1tWOzGYFpuC38TeYUWjWwuWvp2zZBAJiRdxpzlLfO+nor9HBO8ulgqi9lrhjzlc39E2NsVM3sYKfMd7NaCSpA4NIzMFO4nZzsp+GqNixYhFS5xa+R0Dj+Nh2+alfRl0PZ1WO1k8bDdrLaA+e6YJSd6aB/wDWXa/AKzHT3b94JCz8rY7J7T4Y5+HQU0YpJJvaWkWebkSeJv8AopoabEqhxrjDKKce9I0d0W8VPBAI3AU9CHE/ikKutjxHE3Np6ioLoY9cjXWY0fT1VROXbW8JVTcYnjjklyQxN7rGmwNuZKu8Qg4uybDsNFNDE9pzSysLnyAbkflHisyyrMbW4bg0RLnEMqKoaEN5tb0Hjut5w3gfs8UJlsXTva0uPMftoqpR8941hgoKmeJzHCeORwkzbC373Wfqe4crgcx18l1X7V6NsXFuJSBgERLXkjwaCf0XKJiZJHPO7jcrOtsfFciwTDopXNUZChRiROtZeskZh3SEJ+W5SEICEgAqMj4KVzTfZRu6JHErRcqQDRNA8FIFRHDkE8Ack0BPbugFAT2hNCeNkA4Fd5/8P+FhtbVVJj/9JAyO/wDW85j8gFwujjE1VFG7RpcL+XNfTP2G0Jp+E31jgQ+tnfKfK9h8gtMfNot7dErH5ixnxCzHFNdliflPLKP5/N0cnlvJI87Nvb+eqw/E1UXTMYD0+YKjK9NuPHdZ+tcJcQfzZA0NA8dFoKOAxYXTwHQvdnd8v7oDhkZqZXuOvaSk/NapzLPDeTWLnlduU10tU7ALDoArT323VaI2ACWWS48Ey0ineb+SHVLrat2BuFZnfdD5n7g6Df0TlP5VZ5ezzHle9kMq2BsziNY5m5fXkVdmOtnctCh77SNdC4jM33T1CraLiBYnGXAS/iacrx9Cgzxpl6HRaGtBPfP4+64eP8+qA1DCxxsD4XWeU7aY+I6eUxkM/Lq39QmVDWxSiYA5D3XDw/svSNvZzTqNVJHIKiMgi52ITxyRlgglu3Vp7zefUck/tOzkbMPddof1TLFrS12pjNiereSSO3eiPuuNweh/hWsyc+WKaVuV3dII3BTYn7gX01HkmxPLmdk73mjT9kzPkkBG1/8AdVtlliu6PBUYfldbkd15ptp0TJPzba2PkU2ejpAWntG633UUjg5p0vzt9QpI35g6M7qLJZ3ddv3m+fNSYbUMpYHF7Wysza9o1w/a4SPgbUHM5xkvtmfmKuz098zmt1cNWnYfz5XQh9FkBfTydjnP4uqKel2KakhOaWJzHtVn/iCip7O9mkI2Dn6XPkhbZpmRZZRci5z5Q6/omNZ22oZDT3PvN1cfK+gVTaLP8tVR4qKtodL2dKw7NaAXOCIwzuqssTY3xQH8P4neZWDgqXYa53ZCoF/ffmDnO+I28Fo8JxmVzQYXR1b+jnGOT05FaT/bKx1LhnD6eOJt4WkWFrDZah0oMkcdjladxqT5Ln3DmLvlIBkLHA6xuGVzT+q3FDT1dU3OHCniOma+Z5T8Jyn7WKiOOq9ifM1tXVOL537iJpNw025mwGmwC5PV0slJIWygeBBuHDqCut/ahgsb56mWncJTE0S3J1c07krlIqQxro3jtIvy9PEHkVFjTG6UTzUbm33VqWBoGeE54/mPA/uq5UWNJUZFjukKeQmlTVSmjZIbBOSO2QEbhYqJ7bKZ3ko3bWSOJWjVPCQJQSFRHjQpwTQnA62QKeE66YE8IJZohldI48ozbzNgPqvrT7PqcUHBmFRgAEUzXGw5kX/VfKNBEZYpg0XJMYA9T+wX15hbBTYRSQgW7OGNvwaFrOsUz0tZLaKw5glc9x6r7Ss3Pvu+QsPotriEuWJxvs1c3q5jNVNN79wn4uK5uTJ28GPYtw9H/l/HVaWUfevv0AQfAoMrWm21kamH3jj1AWcdGfp4OllHI4p40F1XlJRSVp3qjM7dWptbqlNzRtWPqpMbi55aHxQ+qBaRIN+qvyaO69VVls4Fp2KJRYG1Y7RgkABzb25H+XQWqiBBG4O3nyRr/Kc5jvdNwfPqqFXCcxbtm939FXpToFuLWN78/BQBxp5wdgTqrVTEb5rb6OUD4+1ZY7t+iztVpJJbMH2uCMrh4clXkbZ5AO7czT/PVSwEvjfE43cAbeKjffISPejdf0K0lc9hzjqJW/6vRJPGCfA7eS9B3Q9hNwNR4gp5F4yObPorlY5Y7PhdmjaT/pPonWDgQdbi1vBQQOtI9l9xmHjb+ysdDy5/z1WsrG9K+YteHX13P6p0mxcL6apkgs4eJt8k5p2JF+Xokkgu9mhtzB/RV6mAXJ2B022KmYRHKYnHuv8AcN+an7MTMcx1sw38uqNGHxUJYA6JxI6dVfhjgnHZzQMzbXAsVXizU7iCLtJ26FXA5jmg79CqRUM+Awv1hcQehChp+HAJQXSmJ4trrZF45XxgfibyurVHVRT93UHYtPIqto0N4FQkMY2qrIZ2tAylwsW+oK3GGVlNS2jikdIOY/CFicOZFo8NH11W0wprQAcoNwn2QVxlhVLVu7aJgjllY5jWkd19x7l+R6XXzti+HyUFVNG5rm5XEZXbgXX0/wAVua7C3OMF3sYXWDrCQDXKfh9Fwfi2rp8TqTJM0PZJrHMAGyAdHjYkddLp04wwkdG4OaSCnjs6g6OEbzpY7FSVVC6O7o3CVnVu/qOSp662WdWmmpp4BeSNwB2NtD6qK4PNT09dUUwtHK4NO7Tq0+hUrqynn/z6RgPN0Xdv6bKeldqJGl02ymkDC49mTl5Zt1E7Q2Sqt7NcFGVI7QXUbvBKiJgAE4b6pANbp1rplDrLwXhfqlGwQCt3Ug38EwJ4QBnBGtJY197OnZe39Ov6r6ygcPZowNso+i+T8HIjdRm+rpHu+bR+/wAV9V0z70bD/QPotv8A1RPQrG5iyindfYFYGMGSpH+hg/VbLiSQtw2c30I/VZLDRnrCOYyj5BcnI9D+f1rsLZlaOht9USlabg9W/qqNE3I0AhX5D3b72/hURtmZ+HeyrSkXKe+TKbHloq0so1QIhk1VOUKeSTdVpH7pbXpVl38FVktchWJpBbbVUZpOeqWz0gqm3GbpoVRkZ2jHM3LdWlXpHh7dxfY2VCZ/YuD9bDfwTibA+pjzXcPx3Hk5D3Mym4vcHZFqssaTrZj9R4FC5ntBOouNxffxRYUyRO7rmytGx1SyZQ8PGrXNIsPFR+0MF7m7Tp5LzHD/ACye673XIxqMjHXjNx/0z8ipoyA+24dp6KuXfmGxyOC9HIWOyndm3ktGVh7rxvDh+B3yVrw5bed9lBK0E+BCfETJE3qRlP8APgtMa584SbVpPhf1G6aCbubsDr5KaUXIPUZv3+qrO7tidbEeqpD2ZswdE495umm6mY97bO0zM1v1H+yH1ccomEsRs9v/ANvBTU1c2TR4DHN3DtMp6+SMSXKlrbdo3WM2uByH9kkLbcwWnTwB6pY5Aw9jJ7jtieX9lG1pppDC8nK73Tf5JpE6NglhdG4d5unoo4B2GItabWebb80+hk+9a7TvaFPr48krZByOYK4lo8MaWuez/wBw06rZYI67G667LI4bZ0kTwdJGkFarBiWyll+eipA1itJ7XQPYPfAzN81838XYacPxOppLZQHF8d/ynUfqF9Ng3iDrXC4/9snD9mRYpCLFhLX2G43BRfBOnGJmk3v8VXc3qSfFXJR3lWeNVjW0Q7GyUhK7cpvokZLlMdunHdIUjNKY5OtdNO9kBONQnA2SAJwATKPc0oXrDxTw3ZI9kFzZPASajknNTIUonFkuHgkWyE//AH/svqqheHYdCb/gy/AL5QLuzFC4D/pEf/dy+psKnEmDUkn5mNPxatpekz0I4pP/AJe8X3H6rFU+JNoqiR5DT3ralbfiZv8AyL78v3WLoaakq6eR0jWOka9zDcba3/VcvLdO7g78Eo+NhDo6NrTe2psjuH8UUteywe27hpYrnOM4bTua4iUsd1BQOm9rw6Zs8M5cAdRfVRMp+NvnKOwyYmx5uHC/mq764O5hc3nx2qjqBUseTFIAXD8pRrDsaNU0AnXxKi1eDTuq781BJUjXXdDnVB68lXmq7XsVO2vyuz1Q113Q6prmN1JQ2ur3sGhWZr6+onu1riNbWCUpZXTSz41FA4h0gF+SFVnEIfG58PfczRzeo6rPCmmndd5PdPMp8NH2ZDnv13sFUyZ91eixp84dTm9nXLTbb+aqrPUVL9MhzjQ9HeScIoGvBtYZr3BVp00L2C1myAW0O4T+0fAQIa/Po17Wk3sSr0LKsAtIsNxrspmVLb30aCpm1DLeu6W6r4nivVGUtE1iCdHjolbI57Y5undd5Kz20e5sQRZw525HzUNK5sczoXe67S9/gfgtJdsssdL7Bmh01LdfQpKbuve3kTmC9THIezcdu6Utuznb/wDFVixyict+7HRpIt6qs9vdLdyDY/BXGjOXtte4uq726nqW3+C12x0H17M8DSPDnbVDm1DmEdoC4bB439UXe3tI5I9QdxqgNU8ROLnBwAFjl2PmETLRSL7Kwtb929ssZ7xZzb4jwVluIQzR5Hyacr7tKzURmneBFGNToR1Rahw65DqmZ7rHmbAKMuaRphwZZjdBWhz8rjrffldHKu0sDJBsbj6IDBhcQOemna5xGrM26NUzzJRviO7ddRqOS04+XHLxnzfz5cfdHcDlzUULtPu35VsaAhtW0jZwusJw3Jnp54ubSHBbmgIMdPKPAFbxzWaaqEXiIttcrK4vSxY7T1uEzAGQgsbfnpcfLRa2ls5pB2K5dxzik2A8aUjg7LHWRlgN9pGm4+I09UY/7TfHFMZoJcNr5aWUWfG8tKGPXUftQwqHEYabiKkt2dSMsth7rwuXvBa6xFlnnjqtsMtxC+2uqZaykcNPJMss1mnrZJonFIQinDCNNEhF0/YJtgNzZLQSDdPAKQBO2CZPC6ekGuic0IBbJwb4gL26UaaJwVakeHU1G4D3M8Z/+Vx8ivpjhef2jhfD3jlGy/wAXzNCQ+lnZzYWzDrpofkfkvoP7Oa0VPC0Md7uZHb4K54UmqJcTaYe87C65IzF30GKz0znZY6lvcc7bOP3uuucRNMmHSADdt1wvjGDM97TMY4/eIDLkeIKy5J1qurhuu4p1fFNS+oma6pp+zBsc2p8dlUlx8Pk7tW05diGkINFhLq2oha1svZvsS99gXDwHRH+IeGqfC3UvZRktfGDr+I89etllMJWuXPlD6biOJoLZntcHaEhaTDq2EOZJG8FrrLmeJ0rqfEP+XjLKeU3Y0m9h0uiWE11RRTmElxhJsHcrqOTj1Ol8X9Et1XYYyJYg9tiLKhWEsvZR8H1bqkup36m1wieMUXZMJI0WO9uyRlqqa990MlLWuJAV+qOUlB53d6yE5aSul0KG1uIiN3ZtF3dFNJJljvqglRBJNL7ODZztZTfl0TxnbPK6nRtRjLWXzTOld0b7oVV2PuBzNjLT6lGJuHqembTPczPCT30Mr8LlirX08Ba2CTRp/CGnqet1148Us28/k/oyxy0rNx6QOLmOIvqrMXEEgNnG3iEn/Dg7CN4lA7vfPJVJ8NjaxxZm8DzIRycUg4/6Msr0PUuNNktd9+qvtmLxHIHX5X8tljoMPkdYhx18FqMLik9nMT/AHgMw9FhrTqxytnbSwydtCyUe9sVNMc7RIPAqhhj7F0etiMw/VX2gGMi2g0WmN2xzizE771p5FRSNtK0eJb8f9l6I6NudtE+q0aXjwd81pKx0qFuVzDfwQ2spgJnXYHNfrYotKASRyvf0TKqESRB4HunXwSyPGA7I20cJOWxGuiGGofUuOdxDAe60Hkr2I18cILXg2d3TY7KCkpoHuztIdmK5cu69Hi6iAOlpJWyRucB57LX4Bipqn5JdXW366IBWU7XQ3Y2ym4ecW1DXa7Jcdszi+aTLju26wA9liUkROj+S3mEHNS9mfeYTZc8oJcldHJzBsugYZJknFtpBdephXg5zTXUJLo2m65j9ueHumpYKqM5XxETNI3GXQ/Ij4LpeHEhhb0WU+1Wi9qwJpAvZ5jPk9pH1snpDmXDXEVLiNLPgeJkNpMQaMrj/wBOQ7OHrusBjuFT4Nic9DUC0kTi2/IjkU+J8kcNmH7yI52jqOYRrFalnFWCtqu6cSw9gbLYayw8neNtkZd9nj/41kConbKdw5qNwv5LBsj3C8lI5fBeRTMJFtkh69E4iyQix0SCYAJUlvgntamTwFwnD1Tg3/dO8OiAQJQPFeCWxQEtNIIJ2SEZm3s4dQdD8l2T7Ja3JBLRF+YRXA8W7t+IPyXGRouj/ZPiDRiD6ZzrOy79W/wn4rTAb7daxNmelIv+Ehcmx6jDnShzRv8ARddqhnhI5EZgPQLneP0oDpDb0WXPOunX/P7pnpsGcygp6mBgBbHbb1TcQNDi2GRQ1T3Q1LLFrwCQHBdAwzB2z4FBduvZj6LK4pgslJLI2OAOzHfoubDKx2ZcOOfTD1FA9zADHSuLNnuOp+WipyYXWVTWsbLGQBoBoAQtecFlcRnad91co+Hi+Roaw3v0TvJlkWP8eGPazwDhUpro3PHeDbG31W34vwz2elDnN1ICI8EcOCkex72949RsNFL9o8rGWjBAyhR8ab27uo4tiDLOI1QmWLdHa9odIRyuqL4AU9IzlUG02ZjyGgut3QdroZHhM9PIZDMLk3Nhz8Vom05G2iY+jzHUBCJ/tQkDpITDIQ5p0O2qqz9pDpGI5SOT2lFTQm1hb1UT6CRxvlHpzRjnlj4WfDhn7ASZlZUBoe5jWE+4wWAULaUk/eNOt7eKPjDnuIOUtsp4sNaACW3I11ReTK+icWOP/UIoMKaAO7pyui7KZsJDg3RXGQCOwCe5mmwUbXMA1rDTS/6HaeIRKMgv8CNFVqGXs+2vun+eSkp5Pu2ON7tNj6LTjv45+XH9TsuHub/7lOR2kLgdwCPkq0hEVS08r2Vhg+8cy52+n9lrtz1XlHdYTzZqkglY4AOtlf3D4FOl/wAuP/QQhTZi2olhv77c7fMI2JAvFKFzKySN4Ja8Et15hDaWaSklyEnLfTwK0mMvzwwVNtToT4jRZyuAZMLkLLOadXFeh+nl7eAgeSs4FCWuJ/rIQ7CCXBzjsNbI3hbMsDZeRk/VLix3k0/py+eMXhl7Odp6EFdBwyTPTQSg+73Suc1JMc++y3XDc3aULmHWwuF3YevHz7dAw03PmFV4rofb8Dq4N3GIub5jvD6KXCXgtjN1drWB0ZHIg2Wu2H+3yTijXUOK1AA92Rxt1B1t8CoqOrfhWICeAi8bjYO2ewj3T4EFaH7QMMMGLSzMaQHXa9ttnNNvpZZWQXjikHNuQ+YOnyKi+r/EuM0cEU7aikuaWoGeO+7OrT4g/oUNIPREoZmGF9LMbRPOYO/7buvl1/sqMsL4pXRvFnNOqjJcqI9Cm2UjhYdE12ylRpAPNNI12TkhGl9wkaZo11UjRZMaFI3dMigdE49V4bpbXNkAgHRLa6XKlAtvsgPNFytDwXXHDuI6KUGzHP7N3iD/AHsgA62OqtUTyypicDYhwKc6uw+mGODmttz09FkOIqa4ecvUFaPDpxPQQyg+8xj/AEIQ/HIswcbe9v5p8nc06OLLVlEMDY0YZA3+gD5KHEaJsgNgMx8EmAz/APIwj8rbfDRFHMEm4sVwy66evJtmBgrpH2t8kewfAIaciR7QSNRdXIoW3vZX4LCyraMtimFMbG4yEANaP0XNuP8AETPVSWPMhdJdJ7Phckh3IIXGuKpnS1Dtt0ZDhjLzOzvJKhAF0sjrE6pocLqNqyTsaL3AU/s4cNRuoYirjLEeCe0THat7LbZN7ADkr2W6aWjoja/+NTEC92QCneQFE5w8VFqpx/5RloGyY6wTnOUbjfQJH86QTC7SLnUXt5KGA98tOz9fVTv3FgqjTldYbtOivG9sOXDpek78bHncWF1YZftQfBV2nMx7R/qHkVZhNww+AuuiR59mkEpsGA8mFBKp4ZVRvzbG1upRqo0t5O+N1m8RpZJ6kylxDYrOaBpr1Kzyuq1xx3F6rZ22HTBmuUh4/VBI6KWtkBI0sFoaG8kT2k+8zXVQTSigiLhcvIsB4qc+2vDZjvaEltJG2mabvfoj8DAzDWgcnBZaIO/xFmbU2utbH/6AgcrFdPDx/McX9HN/yZdeJ69t8rralgK1XB812tbe42KzNQ3NDC7q2yMcIyZJi3xW+LlydPwd/cDSdkYqGGWnIG4Giz+Fv+8I8Vo47uiCqso4P9rFIKTFm1OX7mo1cOjrWP6H0XNp6cxRSNGoY7MPI6LuH2u4WJqEEtHvXHgbft9FxQBz2yU7h3gC0X36j6Kb60ngb5JxcJGhktzYaO5gePgvbprt7qbThj4iNR3h1GyjOiluQdCmKdnOkRGiTWykOuulkwiyle0zQU8BNG+m6e3dNMOCUL1tbJQ0pm9lSgHqlXgEAoCmpjaeMn8w+qiG6e24II3vdEK13nhGr7fA6K5H+TlPmLhEcRaJYjYakLK8DVt8DpTf3ZHDy1K1bjmYQdrKso1xofgE4vNATYsdf0K0LHfJZOF5osbYToyUlh9dlqWHTfkuPkmq9b+fk+sVhr9uas0TjNO2Ju7jZDZJS3ZS4ZiUdDJPUPOrWgNv5qf/AK3ym500HEdQyjw0xZtSNVx3H5A+R5C0HEvFMlTcF2g8Vg8QxB0l+hU3OWjDD5xDqnQm2tlX7QtN1K6TOddLqOUDKdkvqJuNXKaXNbVEIjcboBQylshab2B0RuF/d8kZFhO1nmmPK9fxUT3qdt4ZI6yge7VOkeVA439EHt4m7k09L2XiUhQjLIxypyd2XwN7q6QqlQ0ZgfFG2OXa9T94C/Ngv42Ksx/5Q8LBVaE+7z7tlbtaEnof1XXjennck1VKsdYnXmQqDmhxd4jVQcUVz6KlkkjNnBxAQjDsWqKl7Q6xu0FTlju7GOcxg3TzCNxAOoYe6qfamtpu3dfMHGw8Nf2Xon9niFMTrmZY+N0uGMvTVEfJrz+qvGMss69ky4kw9QFqac5qJw/pWcnblq4Hf0j9VoqU/wDLEf0reOerpGahYfykq3w9J2VYL81Wg71HI3obpcPJjqWkaapotdSwyT71u+oWpp3dzw3WLwmXMIneC19K+7WHkRYq0APH+F+34FPkbeSIdo23UL5uxBhgrDIBY3zf2X1fiLAac3FwRYjqvnX7QsB/wnFHmP8AyJbvjcNtT+6mxWNYipZkmdb3TqPL+XURF1akb2kObnHp6fz6quRooq4jcLaJh08lK5qjLQpOIzvtZNIT3aJp2SNK3e5UgHgmgap4GmyZHAHoU4BeAPPVOTgIAvWTgM2iQgXQTwGqkaAdNU1oN9NlI0WThOj8BzE4IWNPuTkeVwFu2OvboR/PoubfZ9NdtVTk7kPA8bH+y6HA/PFG7wVZNeNSxWHtWCRps4c+hRnCK32+hjm0DgLOHQjdUamIPzsOzgh/D1b7Fi0tFKbMn1b/AKh/ZYZ47jr4OTWWmmlaVXfTduHNIuHaFXyy56KaGEDouWvQ+unOuI8HraB2d7XSQO2kA28D0WQrS6NpMcYkN9BfRd5qaWOop3RvYHNcLELlHFWBjD6h2RtoyTYDkss5qtOPl+pphJKrE23LG0ot+FwOvhdWW1ZfCHStyO5ga2V2egzMDhdV2Ugzd7W3VOTZXP59Nw9rnyOkIsHHQHojkXdAVOFmW1tFZYdFdZ41YcdlFI7dNLkxxvopbTIx512uo3a80938CjKBciX133XrX6rycE2dqNwUEwzfFWiBZQlt/ijTK1NRbt8ArczgIXjbvD6qrR7iydWyZY5P6TddGPji5P8AsyXFc5lpJtrCWw8hZVOHYvvW87BqlxxueieL6ulcb/BS4CzLKRfk07K52xyqeqaY62mINrE3v5lWsLZcVdti+4+arcQtczsS24OZzdOhIV3BhmimPUA/JaRnTK4ESwv6D90eo3fcj/TZBcSbq3wNkWw914W+LVUrO+DFC3NHI3TVoSQDLMD4r2GOvJbq39ErRlf62+auJre4FMDFFqtlh7iYsvNpuuf4JMezZv1W7wx9xG78zbFUzojVRmWnIHvbhcf4spIauqq8Hqe6157akefw5t2/FdlA+7Oy5V9puFuaYqht297sHOH4c2rT6OHzRDcYraKbDKySnqWFp2Om46ofIwscWla6qq4sTjFJijhG+x7Gqt7p2LXeF+fJZyvopqSV0EzLSR6jnceHXwUWLlUd1G4KTlomHdQuVGRbVRka2UrueijcLnQKTWALndPCaPonDVVpMPATuSROAukZWtTsgXgLJ1tFRaJZOaE0XTxsgmr4BmEeLFlx3mH9F0ijfZ5iPU29CuVcIzdjirH32FvmF04P7KtaSdO0ynwDh/ZVrpeF0v1OmSyzePxyU8sdXEcr2m4I5ELUVLc0INtkHxiHtaZ7dyO8obb/AGNHgmJx4vh0dUwgFws8flcNwiTJA3UrmvC2M/4ViRgldaCos032a7kVssUrXU9OXs5C65OTH5ru4cvuaH2vzsNuSyfF1EKtmWPLmvz/AHQKs48dJQPpo3OjkFxmBsViqjiusLTCaiR2pNy6658srXocf819GasRUsJje9pdbYFCHW3BBAQaXEpHkuLnG/UqEYy+D3hcX6oxyVyfzVoA4dVIJEGhxmCS2Z2UnqVYOIQtF+1b8VUu3NeOyiXaXXs11SgrI5xdjw4dQVZabhFBxN9E09PolvZeQm0gCVeCQmyabSO/RQPcACpJHgDU8kIxDEBGCxhBeeXQJoo1hzw8PItZrg2/881BiMvdksfeeGr2ENMGHxgk5nHMb+Lgq2JSWfGN7yXOvmtsa5cvQTEGh9KbC/3jv0UmCi1QPK/0UkrR7PY8pDZLhsZY9jv6VeLHNa4ga9tH2jALtLnX6bJeHNaSztyAFcxSLtsOkAG8ZddU8B7sUberlqy/E+JN0dzsT6aBW8KkvBC7wso6xmZzhvcn6JuDn7pzDu03VyI/B/DSRUZehIVqRtp5Om4+Sp0hy1TDbR1kQnbaZvK7bLSIo7gklo2eBst7hEoMI2uLH0XOsGfoWnz+C3eBS+60nQiyaGniN2+W6zfGuDjF8MqKXZ0zCGHo8atPxAWhpSSNdxoVTxvSNp1teyIHzHi7HvMwkZkeD2tratds4fEFU6bEI5IW0te0vgHuPb78Xl4eG3ktv9peEew4wK1jfuKokvH5XHcfHVc5kYY3lhvcGyiribEsImoWidjm1FJJrHPH7rvA9D4FDjor9HiVTh7ndi4FjxZ8bxdkg8Rz81K+locS79I8Uk7t4JXdxx/pd+hU2bVKDuO6YdQrFTSzUspjmjdG7oQoDqo0vawBpsn2SAapwTI4A+aeEjRp6pwCAUaJ3JJZOAtugjUt9k6w00XrX1RBRHBZOymc8aEZf/0F1OsNnNlB0c1r/UWK5PQOy9oP9P1XVqcCqwKnmAuWNaCTzFlpAPC0tO7xGZD6lt2i+1rWVzDH9pRRE/lyn00UFSwtaeViosaysPi9P2crwBYBxH6haHAcZGMYYaedwdUQjK7+ocihmNxEzkD8Y0P9Q2Wepq6XDa9lTDa4t3Ts4cwo5MNxtxcnxk0//AlDW1Lp5mu7xGlyAfFVMY+zXBmxTOiu14194rXYPXQYpRNqKdwII1voWnoVn+IaippHv7xLToQuDKfNfQfycsz9c+qeCGiRwjmfptZxQyp4VZASHF9/FxWjqcQmudL3uNFQlllmOzz5pTKOrOYs8cDY3QEhOhwJkj7OBdfqUdZRFxu+w8FcjgZFawBKdy04uTLHyKlDhzKNobGA0dAiLDYeKaDqvZrKd7ciS6UlR5l4vCuJSF3kopJQwan4KKaoa0bgWQWtxR0pMcG2xd+yZWp8QxQBxih1dzN9B/dUYInTTtbclznAXKjjZYab87olhTBG99U73YW6X/MdgiVnRd7gzsomnQSNaB5IbiTszg7+u6sCS8lMXbuOb5qtW6xt5kkfqtdslaodpbS2YH4gq3TQ2jaejLIRPVh2I+zD8DQ4+dlo4IwYNR+H91rhHNyLQYJqbKRe8aFYWzspmx2OjiLItQHNAP8AQqbIuyxO2gBddasU1QM01r7ud9FBQO7Orc03AcrE5HbMA/N+iqu7k4eNCHW9FUSPt7pjcOSK1FnRQyW2NkIa7PStf+XdFofvcPdYat1WkjOr2FnJK7yutrg0lo2OvexsViMNcDPYW7wt8lrcClu10Z33V6S29O7vHo4XCTFoTNSPHPdV6KXNC031abFEZR2kJAO40UaNzPjLC24xg4YR3pBZrrbPG36rhWIQPhlyvbZw7p9F9F1UBmFdRaB7HdtF4X/uFyDj/CRHUyVLGZdnuFvwu3+f1Rr9ErDPHd3sRomA7/y6my3Jv0UOxIWdaRYZXysiET7TRf8AbkFwPLoq8gp5LuY10RPI6hIQmlTaciUBOaEjd1I1MFan2SDVOG6DeCcGr1r6Jwv5IIlh1S2vqlsltYoJPRjvPHPLf4LqHCU3tGGPhJBtGDb1K5hSXDn6D3Cug8AvzOfGTvEf/wBXWmJxq8GuIZoj+CQ28in1DdZB4p9CzLU1TfzNDrJJ2jO/mLXU31pKy+NxFsbZBux1/RZPE4uzldba9x5LcYtGJI5WfmbmHosdiTM/ZOPNuU+iWhUnDeOvwKsbKXF1PIcsrPDr6Le4vhUeL0rJoHB8b25mluoIXLAPuiDqVuPs44iGd2CVUlxq6Au+bVz83Hubjq/m5bLoBxDhapiJLWGw8EFlopoXWc0hdqxVkLIHEtFz4LAYs2NzjYBclxj0ZllfWWZGQNQU/L8VZliDTcKEiynUL9RkW3SF26cT6KCSVrddU4VK59gq1RWMhaXOIHQdVVqsRAOSPvO68gh780hzPcS4+KraKWpq5at1jdrOiYyPlY2UgaAE8aqQ81oAtqr0pENLFADq4GR3rt8lWgj7WZkY5mx8AkqKpkk0khNm7C55K8Izyyi/nArGDkxgv8FTrKlrImXdpa/zP7qt/isclZMYwX2jc4HloEIxKokmZT5XZSGnS/j/AHW0xc9zkew97psVklINjcg9QCAt5RDuZT0P1sshhDWdmw6ZhGb/APzWwgOUg/1OHzW2Mc+V3UtCLMA/K4tTZmZa6J9tC6ylpQA+Ua2vmCWrbaSN2mj/ANFoyUq12R7L/mCiqRZzulgf0T8a7lvB37JjxniY7mW2+I/snBRbCpBLEWEjUIzhbrNfC5ZnB5i2QNzdFoY3dnOx4/FutYxq5SuMcrDza6xWqwqTs6i+wJv6FZUC0zh17y0GHyXET7n8pVE3VDJdhH5hf1CMU7w5gBKzWGTFpIOtjdG6d5afI2SpxnuJG/4diUFb+C/Zyf6Tz+NliuLcPjqmTMLe/BdrvGJ43HkfqukcU0IrcPkbbQtseoXOsdnkbhtLijG53wXhnZf3su4PmFMDjVbSvo6p8L92u0PUciqzmgFbXi/CGANq6fvsLczHfmjP6jmsdIy2vooyi8VZya4aKUi26jeL/BRfGkShtk9ptyTW+WyksmmFHVOaNR5JE5vVAOAJTgOqQJ3yQT3qlYOZ1Sbeac3QICelBPaW17pW14DlyYixvUH6rGUgtnPLKdbrUcFvLcUaTybf/wCwVynHT4WCOsDhsRY+Shnb956WVgb5vJRVHvE9CnVwCxHuvjcdr5fQrK18WjmjdrytZirLwn/5IBXxXndpoQEqpmnM99pGyrMlkpqgTQvLJY3BzHDkeqJTR5ZpB1Q+Rn3p81F80XcvTdt4sbi+HhzjkmYLSN6eIQCqqs7is/2j4nkxuLXjmEz/ABWZxIc1jvHZcnJw5b6ehx/1Y61kKSSi5N1A5/NBcWx2ow/Dm4h7D2kDpDET2lsrvHTzQCm44mnrYmzU8UdOXjMASTbzWV4sp61n9GF8a+epawHmeg1Q2oklmJubNvsFpfYKWaBskAaWOFwRzQ2qowy9m6LLf+WtgLkA02SZQFNUZYgXOIAHMoLW45FT3DSL+J/RXjjb4xyzmPone2yjlqY4Rd8jW+ZWddjFVVnLCyV4/pFgoJhM1uapkZDfle5K1x4cv1z5f0yeNJDirGx1MjL6RloNtr7n4XQR1TLUgl7iG6WASmZlNhTGi/3ribk6kaa/JUh203dhY9w5WHNazGYscuS5ejWFsdmnOU2bA+5Cc6lvSQzSCxjcb3+Kio6WZ9NOLGN2Sxu7ZW6SHNh7WSa98nXXyVItLhGXM8tcCNrg35j9itdCSQ4X3eR8ljcMkY2rkgaNcpv53uthEdDbm2/nYhaYoq/SuzSh3J2h+qkrG2jb1BCq0L++W/D0/wB0QqW54r+CtAVxBH9z2ltLbqnRSdrRNO5bofRFMUHaUpadbtuPNAsGeQyaF24OnkUQqt07uwqNNgVp6eTtoRbUhZWR1ntdbf8ARHMKqRlAJV41OUH2uzMa/poUYw1+zDsdfVBIHA3bfQjREaB5ygcwrqNNnh83unmBb0R6mmuBrt3SsrRTXAcOe48CjlLNp/q0SGhuYCeAs5ELAVlE2CvqaCYfc1ouwH/uN/cLdU8hezYIBxVhbqqmMsItLH32Ho4fyymXRuU0lO/tKrhypJEkTi6lzHqL5fIjl4LE4pRmlnc1zSAfkeYXReMqN1dS0uP0d452dyQDdjxqL+qA4vCziLDRicDGtkvaoiH/AE5OfxTym+xKwrhrqoXhWZmOY4tI1UDwCFjWu0oCcE26eE0nNCcEmwTgPkiA5oTtxoUjRbdPA1TBuvkngC2y8B4KRjRuUBLCLMeLa5StDwe62KN13Yf0WfZctcdwdEf4S0xZn+l30Tgl06xbNCD1VaV3veNlPCb0bT4H6qs83v5IaQOrm5ovVBa6PVp5kI/VAOjKEVre63TZKqZmpjtUEdUNcy0pRmsZaUlC3Czi47IKqMjfeUPsrmxB9tTdFaPD5a+dsETC5zjrbkFt6XgB08TBI8NAGoRpNrldK6nraXEOHq0iNtY5roJSdI5OV/AkWXPMUwmswLEX0VbEWSs+Dm/mHUHquu/aRwnBw9i2HASOdHVxSMkF9RYjXwNzosvXdlieF1eFYw8Oq6KMz0VVbvPA/Cet7AKcptUy12l4J4gcab2OZ18vu36I9Xzs7Mu5LlmE1vstU1wNuS1s2LA0xc9/dAuT4Lhzw7ejx8m8ewniHFH5xG29zsBuqP8AhsVAO1rx2k5F+x5M/wBXj4K9TRewgYrWgGrmF6WJ2oib/wBwjmeg9UHcyoxCr7Nl3OcS5znchzc4rqxwmEcPJnc8v9PT4nNKRHESwbBsYSxYNV1BzPtCD+KQ6+dkWpMPgpI7MBcTu47n9vJT3y+42xGtiTqnu1Emiw0DXRRRgRSPjZYGQa262TiySId5gaAbAtOnwUhhDwyRws7LqQbalNdnyGP3i/Qaa/FIzu1tRyuJtd5BLdDqPom0kofTvyvzWJ16eC86nkfRtafxOLjY6EBQ08gEb42sDS11vApbCKT/AJarZK0kGRxueQFgFsKOUSU8bwdPdPw/ssfMz258kYOXsQHX8f8AdaHh+cy08sTveFnWV4lRqF3ZSB4v3Xa/zyRu2eFwHPb4LOxPGexsb90/UI3hM2dmQ7t0K0Qq1l30126lh0+CzjD2FdmHuSCw8itJWPdBP2drMkcWnnbos7iUJhmJv3XG7f6TzRCWJdQeoNwrmGT2I8NUPMoLGSa2I1/VPp3ZJLt2T2GzopwbXRSndlkvfRyzGHVIflF9dkfp5MzRa1wqlQ02GzjRt/A+KP0kpsWnzWOpKjs3t8VoqSp90jyTDT0kvLqFLO3tGm+x0N0KpZ+6BfbX0RVrxIzzCVDFYphjKWtnpni1HiAI8GSciuXzTT8KY68ytLqeU9lUR8j/ADcFdzxfD2YjSPgcO+NWnoVzTjPCvbaN1ZMy00X3VSLdNnpylYxvF+Bx0+TEaT7yhqe8xzfwnoso9pbvqtrw9ijIJJMBxQZ6Wb3Sfw35oFxFgM2A17oHd6J3ejfyc3ks8orG/gSBqpWhRsUrQSkZQLp7V5jFKyOxvpayYNaL2UnZ21GqeIz0WiwTgfE8Xa2YsFNTOsBLILX8hzVTG1OWUnrONHmUYwXhfFsfnEVBRSzOOpsNAPNdJwP7M6KhyzSwuqaguDImS7vd1tyHn58kR+0fiZn2b4TBgmE9mzEqsZ55wBdg/mwV/Op2mcm/HMavhOtw2R0E5gMrfeax4OXzV7hnDpqfFWPczQAt3WGq5qqWsL/aZy+U3Ls51HitNwhPUjF4A+olLnObY303spV261TgiibcEHvfVVzp6j91cAywBpNz3tvNVJe6B5Ka3irMO76obWMuCikurLdEGxmvjoW3k52AspPQJiIIJNuRQWpqI6exeSb8gN1PiWOizjkBAaSD4LO1mNNkIJaAgr60VFxscIYRh+Gx9od5ZXZj8BsqeJ/aJxHUtOfEDTx/lhGVZCrxwtJy8kJqK5xaZ53d0aht91P0NC8uKVFdWl9RPJK5gBDpHEndX6nD317TJCQJYCXxnqDrlPgsxhEz5WVVRJubW8r/ANlq6CqJMFxZrm2PiUbHjD4zhzKSXtaYPMZY2S5GgB/Y3HormF1La50TZQDHE3PI08zyHxRavjELq2ncATmDYWu2yO1I+IQjDqYU7ahhdYF+Uk8m+Pop13tX1ZNQmITTVEpneDJNO7JEzw/bmiNHQtw+mLRZ879ZHHmf0C9hFKKtz8Skbo67adv5WdfMp9U6OWd0RIOXdoO6L3dlOkLALXDy+S+uR1wpb3IBvcnWxTQWxCzWgf6QvNmY2pYwuyuPutO7z4I8CcyNabWOpsADqvPZZuZhzPuCPBMDnNkFnNDvK4t0/uklJ3MZudnNOnklrYWZO7HCT3W5M2+wJP7IWKiEzShjs2UZr8vJFqilc6dtHcDuMbc67NF/mT8EJ7FuHVEjbsJHd7w0J6keqNBboqbs4LvAzzEvIHTkpcAqBTYkI7gMk7unI/7pKcFrHyZi7KMrSRvbc+pQmKSalqInEENcczjzvvoqidt1O3s5A4DR3y6fqFfoqkRTMkBGV9syoCRtbh7XsILm8x0TaWQvicy9nNWkSN4o0PsQ4AP0v48kCrY3PYYyL32B5HqEXa/2/Di29ntFvVZuWtmp5DHM0loPmQUUojgLmXikNjclvip4ZbGx0soJnNqSJI3tEjdb9U10rX5XtPeI+Kk5BqlqDGQ5p0Wkw+tD2gtNweqxVPWBhFwQUZoqgxuDmEa8uquJ03EEgkA11/VF8NqSRkcdeSylBXMkAN8p5go7RZp3jsQXu/pBP0Wk7R41dJNZwJRqllvdp05hA6ShqOzBdFITpoI3G3yV9lSyCzZX9m4fnaW/VFhwQk3vzG4QXF8MZUB8mTMHtyyNto5v7hEhXQSNzCVrtL6G6a6RsjDlNwOQUm4BxNg0mH1ssADg+nPaQu/Mzp5hFaGtg4qwhuF1Za2sYCad55kfh9VuONeHm4hTNqom/fQnMLDlzC5PVU5pah2Qujc12ZtjsOSij9BYxdTxsva4UbBba6NYHgNbjdR2NJFcA96Q+6zzTmO/D3J6otYtFw7wTivELx2EBjhvYyvFh6dV0bhT7JqKN0c9W2SpINyZBYE+DeQ8Sus4Xw62NjWQQNYxugAFgAtZhMe8mNzuXWLl+A/ZZQUL2yOj9rqIzmc6TUA+A2B81u6Ph9z3ZXZM5b7g/wCmOp8fBamKhdSyCBrWDtNS617BLWUUOF4fPJAwCRwuXfic49T11SvLN6iZx2+g+E0VPQxVOLVIb2NIxzYnHk0e87zOy+UuO+IKrjDiitrblzXPs0DkwGwX0Z9tWLjhr7OnUEL8k1VlgBHxcV8vYXVdlISynfI6+pGyiXfbWY66Nlidh0LZagucdSfBGeDcRbXY9QRQ2Ic8E25AG6GYzLFiEjaR0nZh3vXHurTfZlgsFJjMYiaZmjM7tSLAWGw+SVXJt1gm7QD+W/xVKoNmk35BXZTZrze4sAEJxGpbCxuY2uQ1S2hHyHK7XmsbxvWCOKnNycztLeSN0uJirpaqQ2AZIWjXoFjuKJfa8IjcHaxvdb0uUGzOMVPckAOxDfgEAqKkgHU3sr2KSd1rXe9cudp4/wCyDiN9Q+57rSbqLU6QlwcC+R1mAX1O6HPlfXza6RtOg6q1ilQLCmhILD71ufgn4dTaC7b9NN/FT6dF8Jjp4adzZyAwgk+drj5rTYHAyehEzwNGgj+nVBaOlilzwENeXM+BRrAWPFJHACbyHKVUhbUOIgxtXUPPvBtmnoQGn+eazUAkqaZ0DXfeVVQ1gdzFxr+q13GAY2lfUNsA+WexPQZR+iAcNQE1kcjv/wCaMyW6ucbBE7o/BTEi3D4GU1M3Vto2NHM7D91DBhraemyyWe5xzvf1d4K3HC6txhx3jpGWJv8A9R39la9iqcTqWwUrW3f7hcbNA5uPgLJyFsIMbQ1xAsGbk9FHE+RsvakWIuGNOuXx80Uq6KmppXRwzuqGt3cfdLgLG3gq1RRyNhFQIC5hOxNtOqVgih2hEjhYuJ1t4KWn+8e8NcCWgn1TZoKiIETROia4XygW/wB1ewClNXXRRMaBm7u2nj8kQVbc1sUOE1JIc/sT2vU3e7X4ILiscUlS8AZXB19RyRCvif7XNkc98F+5lF2hvLVBamqY8yujOZ0Qs8tNwfJMoINcGwsA2awAXVOWNtRIY26BuVl7ciVVOJt7ESR5nSZchB91v7myMQtEoE7RrltbzTgq5gNSYCaaRwAvl8hy+CtVBdRz9oBpfUdQqL47yuy6Zxmb4OCv5vbKMOItINCDyKqULlNUCnma8G8Uo+P91VxyEEZ2a3GYW5odR1oif7LK6zXHuu/I5EyXSQvhkbdzBmYR9B80r34nTN5s5Lm2DgbWUjJQQWON3NPdv9Elcwxu7Rg318vNV5CGMEh0sSQOZU6XKuxzuG5cD0IRfCnwOlaJpuzaTrYXusy189Qb3sBz5AJBiUsJLKEd/wD7p39E5U10+eqwrD4G2qY6ew1c8Z5Hny/CEc4e+2T2Ex0WF4d7ZKLAGFurvQCwXE4mwulz1z5KqS9+zBNh5lafCeOcTwwinweGjos9gHCMZhy3KuZVFxd6HHn2k4nTB9Dw7SUDSf8ANrJADbra6zOM47x9OXMxDivh6DqwPZ9LILhPDPEHGsUb67iiWQPBb2TnENa/8tgba9UuJfZqcHoW1b6Suri5xaI4Y2tBsLm99QPFVSmpAirxDH4Jc7eIsGlcNyz+zVfw37R8ZorMq2UFc0bmGXI4/FZCvxTAqeZ0FXw5WQZfeLKshw9Doi+AcO8L8WkRYZXYnSznQxT6tB8Hbel0t7Pt0vC+OsGxZjIp5jQzOFslULNJ8H7IFxtwS8s9voWhzSLhrTcEdQRofRZqf7LsXgjdLheItmAOrSSPTW4KqUuLcV8HP7zZo2g94M1YfNn+yVgWeBuBavi7ERGAYqSPWaYjQDoOpXcuGeFaOkd7NT0zWUkDrMI3kdzceuqHYC2HCqOPDqNoY4tzSOGmT+62OG4hHSQloa0W93TULqk+J05rfq9tFheDtyh0g0vtzRtrWxts0AALPRY9HEyxdfKLH90ys4rZC2wy/HdcmeGeVdWOWOM6F+1a6ukzEWYAEIxzFI3YhQYe1wPaTB0hvsG6rPVHFIAnk7QNDXXOmv8ANlgq/ieZ+NzTMmBbDTlzTe1nOcAPkCn8aR9bAf8AxE8UtxHGKXDo33jgY6QjxOg+i5dhVU11KHRgMsN1DxzjD8Txyqlc+5JDbnoAhlFUCCAsDgb/ACR9a6XJ1tde6N+KmaWN0kbCAWtF8y6j9mcL5pKqtdTup42NyxNcNTfUn5BYDA4xTOje9naSS6xtB+dl2rBaH/DMFYH2Ej+84eJQcixUODe7yFifNYri7EexGUOyhoJ9drfNa2qkDCSTawuVybizFPaq1kYNy5xe7y2H6KWsGcAl/wDIqh19TK69+Ztr9VnawulifTgk98HyBH+6OUMgh4eDNbklvmSTf5KiaMCKWpcL37jR1PJKFthq6Mz1DjY9kCST11SiG0bpuyLooxmyt6Dr4dVoafA5a6bO5uSK+UDlfy6r3FcEOB4VNShx9oqYizQbagkeA68+SVn6NueMiNZVvle0NaXE2A5X2R6jjbSwSVLwBkF23Gg5BJg+HvqXw07GOcHEe6NT/Ctdx9w1S8M4Jh9PPI51bVHtnwt/6bBtfxN9kpP0WgOFxup8OirZQJDJJYP5uvofitNhVGyGA1mb/wBL37HZzuQ+iz/DxOKTwUzoSKeA52tbs0f7rodVSQYfi+CYNExjqipmbUTQucG5tbtYSdr9eic82VnbGfaZh78JbhuDSWE7aVj5ADexkObU+O6C4G1kNFV1br5DMGg/0tF9Ec+1SoqH/aBi/t7qaeoj+7/5d5cxr8ndbfnl+F7q5wXgdJ/gNNjGMRTvwakqM0wi96eZ3usB6AAEnxTguzqDCH0uFwCRlqqsJnkvyLthfwCHwuqKip/wXB4pq2omeWHs23Mp3yjo3678kX4rx2oxWd8lHTxwU0jRefMAAzk0Dlb52QWg4vk4apJ48FAZPMzLUYge7IW/kjv7g8dz4J2/4TFnE+Fa7B8RbTVlRTSztZmmELg5sB5svsSOdkCxPH2xy5WPbL2ZsCRp6dUNruKq2oZk7Ps4nC9iTd3mgzq2QuJAa2/MC5+JU2nINy49UOjex7bxOFryd5wHgT5KEcRex0sjKMn2iVpYX/8Abb4HqfkhdFSy4lXU9K0kvnlbE0u1sSQL/NaLjng6t4cxc4Y5kb46VobHMxgZ2zdw/wAeam1emafiFU+LsXTyujGzS42+CkwuojhqXCY2a9hb4a9fBQmkmGhb/wDYJz8OmbTseYyHOcbEkWIsP7olAo+jZThscZMkZOYWPNFMPkBf2RPvR3t4hZeKGqj/AMtzm6W0KP04dRmnz3MkYaXknUkm5+qqVNg2GEsa7exOqlB9nlzD3JRY9LpYwLOA63CbOA+K2luXmqIIxSLsXmSzjGfeA0V3CcSFRGIJXi40Y/nZQVEwyWkufwm/I9UMdTyUpEzX31v0uCkehKuzU8zo5G5w4kgfVDo4TUuMj7NZa56AdEXjBxSiyFt5GgEEmxPUIfXvaLRNF42G1h+J3TyCKSnPMJiIYhljGwO7vE/soxEWNuXFjT0953l4K6ylEERkm1JN7Ddx6KtI4Sd6VrzIToL2bb9ktmSFwaLRsDW+Bv8AFanAK+njDmy00UjHCxyCzmn8wWWYwyEXblYTYDmT0CuQSSQSNEhc1txYWubKpU2O38EY1Qw0rrdmG3ADwbdmWm4Njr6LrmDYvU4nndBhtLVM/DVvlaCL9QRy5WXyvhWNSQzh1PWxxEC2eUWDPIWJJ8lv+GuLK/2pvtIxCtgOjnMf2Zk8tdB63Wk7Z3qOsV/DuBUuZ9bV4PSVM2p7QF2YeNyC7z+SEy4DwphhFYKfB7g3FRBRz3B+l/VF+HY58YHaYdgeHYU0b1FSWyy36gD6krVP4Qgr6Z0eLVtRXk/mIYxunJrdPqlbr052w8NHTYq11Xhbv8SewWd2faRkDobut62VGowsyEGtwfFY7mxzS5x5E2N0uHVWJ/Zvjtbg+HYUMUnq3Ds3kWyjlcjlZaeXgbHOIYzPjvFeJUz5Dc0lARHFGOQ6lK5HHO6HEJGDtHPDZpjmNuX7cleZxIKVgs8uN73J0B3JXOGcQSR3JcSdRvsreEVEOIzPfiFZ7NRwgOlf+I9GtHMldVzjmnHW7/4sqa1/s8DXSz7BkYub+SbieKTUOT22aJ1RpaBr7kEkDUjz2WHxjjiW7qbh+FtBSWyuc3WaXldzt7eA8UEwqaonxKGWR7i2JxndcnK3Lrfz2Wd5GkwsjbY5i/YVFVEyWRt5O9Y6EgbBZasxSRlPWVJvlc+OHMOYDST8LqjU1755iXk3eb73tc3JUHEVayk4ZpYHC0sxfUPPMA6AfALPLNpjiwFdVNqa2cXNydB4D9U2ijlqKqOKLMXXDbc3KhG19TUGRrm3c42BOq2vCWBVdRWRtY9pldp3RcDzKxl3WmtN9wJwuw1cT5u+YgHO52PIea3+J1A7dkANmxjM5V8Do4cGoiLjuNu53U8z/NuSCYpjAjidLmBkndlYL/NWEfFOMigw2WTMA5w0J8VySjlfidY+seDlc4ZfFo2HzC0f2g4g+t7CgpruLjl052/nyS8N8PmR8TGjNFERcjZ5H6A3U3tUFvYpHw0dIwd4NzPPIXFyfmoq1va1FPR01gyOx16DmVoKiJtNE62rnb6ano35K1w7w62WozzNOcjM4nqeXoq0W1vhbA6auiZLO6OMMBFncupWPxzhmDjTHKqoo4w3DKEOp6d5BzVEg1fIfAdV0bH8Piw/hnEKyeR1OGRHsywai+gPnqvcP4TS4BwPVVhcTekOXNrkbqTrzJOpTsR9OV/ZhT0UGKTmdtOTG97oe2dYkt0GUczzScUcPvxLH5a/iPFn08bmMbCxre0lkOS+jeQuQPVXsB4CxKSDAsXmi7OnrMQbTx5jZz8wzZvKx3RsspMX+0z28kew4dO+pkdfMGQxnT/8hTbNHGV+z+nw2ipa7FamZsfsUguyT3pDya0dUDxLEqkVmJY5W39ske5lPZ3+WdvlsjuH4U/jLjLE6vC6cMw19Q9/bO7raaMk/ea7u02PVZjimOjdis1Ph4IoqeTLFmNy+27r+JJ1S+ehvsDYBJVhsjjqSXPcb2NjqepufVajC+NJ6LhOq4XmhYaOeaOeOR2joXNNz5gi3krM2CYbw5wu2vxWNtTjWKsLqSlJ7tJET/nPtu4/hHqs5h+FV/EOJU+GUUL6iqqHZI2A3JNt78gN7ok6VUVdjFM4GNrZJ2g6MByMv9Sp+EqN2OYqaittHhdEO2qQxoALb6Rj+p5sPieSuY1hGEYFisGH4ef8Zq4HEVUl/wDl3yad1nVjTu4nXXSwRPEcTbHSR0sbYo2MIdJ2TA1r5LWvYcgNAOXmSlq0eM/xbHJite6pDY2vkJc5rbNa3oAOg2A8Fnv8MlvbNGPW/wBFpagjMXz5GOcASH6EDkh8lXTsJDXF5HJg/VPSZaHNwvKLmdo8gV4wOv3nl3i/+6N0cTqzDKmrz2MMrGFjSCQCDYn1CpGljL8zsxN9zqp0vapHGwkNAzkm1gFZr4YmvbExzLRsymx/Fzt6n5KxDE1mdwB7o0/1HYJk9KIQ1ji7tLd69rD+6X6avh9C2SrZnt2TSXPsdgNSppn9rK95Ns1zopoGiGmlkGj5O5/7Rqf0VVwy+aqRLQYfKZKZpvq2zfl/ZPftIzl7w8lQwmdrH9m86Pbt6/7olKw3adA9rsh/T6q9JCpnNeS13vN0Pp1UUVKZZGRlxA3bcbBX24bLU1cbYmOuSMptq4FFhhwgje9rczYe40299/O3gP1RMRaEzgRsbFH3C0FziN2j9yq1PRtlPbv91oswdfFWa6iqGVDqJ+Zk7u/PfXIDs3zSyRTwRmFwY9mXUZSCPIosG1Ej2lshc/IQ6wAF8rR+qiMETiHtY98Y1vJoXeQ5IjG2n7JsYD4Da2hzB3nzCfGHR27jDbUF26nQ2pwtc+d7Q0RNiAMknJo3PqqtQXyVDjC0sB3lfufAdFe7IBrmtuGl2Yi+7lBJEXAcgq0VQ0uSB4Iu5zdi7Wy1eF8RVDHNu+/id1lnRFnifEKSCV0elzdaY5/KMsdu+cIfaWaSJsLndo4WAG9l0nDvtGo6gMha1zpjrYA6eK+TaHGJac2jblA3fzWowTiuSmlBjlfvrrq5VvHK9o1cZ0+sMLkp5IWynK6V34z7xVt8jc1gQfVcMwf7SpIgwySkN90C+55LVUH2hsq5o6aV7Q86AgblZZcVta48sfOTJ9Cb+XgonTyyvDIySCdlSa59yCSjvC8eFS17GYoalkD+7mgy3aTpck8huRztZK05iN8MTw0sE9JO2Fzp4XMcHNuWi2hHig1NVSUlHO917yv7Ju2obqfibL2JU76DFXwh4kjp3F4qGbPa38Q89NFRkqe3jp4suUsYcxvpdxJv4IkFieip319THF7vaGxdfZo1cfQX+KzfGWLCpmnLHWiaOzjF9mjQfJHX4izDsFrK5rgJJv8AlofDm4rn2JSGR0cQJJPePioyq5EmD0jqqpja3WRxFvAdV3PhPCGcP0kTGMMlfUN0ad2jxWH4DwUU/ZvjibNVu1AI0jHUrpZng4fo3TySiorJhfM7X+D62VY4/qbe0uMV5jiZhscuZ5GaR42A/usrLNJiuKXY7LT0rS0OOzep9NVO2OprGvmc4sbNq6WQ6efj4LzKV8zRQ4fGS12hJGp1953h4c1W1QIioXYzjD2wMLWAWc87tYN/UrfUtDDhOHsIa1r3CzGjkOqlwPAKWgpcgFwDmlkcffKhmxvCqnEnsqJzeNwY2GNpc7zICWMFulqmoGCI19UR2UdiL/if+yO8IzUU8FRUyzxMHaOa4yPDba7a+FkKoOJMPxrHIMAosNkrHgF+eWZsMbAN733t0C599pVDE3jaenpnQ2myBrTJmbI4ixe22wvp6K5eumf6639o+LYZR8OQS5Y62KSrhjk7NwcA3MDYa7laHimhhxHgSujpaaSJ1TS5YYmjVrSO6COu651xVwRTcIfZpg+BufBHV1WJNnqpQ/M0Gx1uOQC6JhWMVuOvpcDwuhccPbG2OrxJ7XMY5gFssYOrr9dkvwrrYbWcM4piWAYJQ4fT00b8OaezlfKQc5aWXAHTqeiAYV9lddhmE1OEtqad01a3squrBJc2O/utFtPMruFLhsFHCyGmjbE1u1hugfFON0uB0MjmhgdzdoMh6lRjd3UVk+eOL24ngNPNwvwzgtVTUEOk1Y9thKbblx/VYeswaPAo4J6pzMRryWu9ihBcwDfvv205geS3XHfG0uLVb6c1IfTt1bGSdTbcjzXOp8YkMUpaxzmxEAuBsNei2vFZ6zmc/EOM4lVY1iT8QxLD5IpJCAQ2+UNAsG25CyJ4BjsWBUGKf4bG7/Eqxgp4JwDenjI74HidEA9vne68cjmX1uL6qGodWVkjZoarJUR6tOjb+BUfOmn0PYfRUtAwRdnIZ3AAhrSS4k2FzyF9fHRQYpQPpZYrhhc5pJY5uYN9efn9VXw3H5pGVU9dWRx1MYdC2kZEcznFv+YDsQCNvUKvR4rA6ra3Ep5omO9+fJ2j/PLfX4qf1Su7D4WklzQ935nauPiSVHJTNItkFkUkfE8kxOL4ye6SLEjkbcvL6qrLqdgEEpRtdTlxiOXMMr28njoU81TNi0sPPW9k54AJ1sFE61uSk15ro3U0b4To25e4mwYTsLczb6qrLJ20ndbvoAAoH5bfsn00U8k8cTHBrnG1zy8fkkaxUuZGWxMsQwWv1PNU3nW116aeRrcrrAA3tzKiY83BsCSeewT0S7Tlt45C7IR7o/N4+XitMGe0U7KhmocwXtycNreh+Sy8DTI67tQTck6lxXQeEqeOsjazI20TQ8nmMupPgb2HTRXE5XR2DYXNNVx0dLC99ZPIII2DYOduPQa38F0TDeC4qCirsXn78GGB0ETS24mnH5RzOb08ztb+zXAahnZVrWgV9WXw0TiNIQf82oPkO6PIdV0ampqXEOJKfBacMGFYAxjpGm33tQ4dxp8h3j4lGWWk4zccjwb7Jq+XCTi1eXGabNLaNty8k9Tv6dFlOI+EJqbO4sLQPzHUr6KgxNmH4lLwrXSezSua51BK0/50RJ010Dm6jyXPPtMoOGsJbNJWYridVX5MzaeGVhA/1G3dCeOQsrgVZCIXlpBa5qc2RkUTXVTHsd1LNHW/VWarHO2qCKOlZTja7Wl0nqTz8rBE8O4dq6ke11Jha0jMBM/cb6/sot7X+M/JPC13dDzfbQNB+KhfJG/UGzeliStO6HJI5vZR5QdHBgDf3VKSKxJBHjYWF1USz7gHA9yZ3SwsE0RSX0gyk/mejMgdycLFVZIMxN32HQ7I2FQU04F2sa+4JPZvzGw30Gqa2qkj7zCw26O+SdHLNh1SyeB4D2G5uNCOniDzCbU1grXkzCGKV7rXijygeg80bHyt03EUlNKCToOXO60NFxuKYAvgbNKBYOz2t5Fc/qRkdZp1HX9FAKxze66y0mbO4Sv/2Q==",
  "c2": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIjJSUlFhwpLCgkKyEkJST/2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCT/wAARCAGAAYADASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAABQECAwQGAAcI/8QAPhAAAQMDAwIFAgQEBQQBBQEAAQACAwQRIQUSMUFRBhMiYXEygRRCkaEjUrHBBzNi0eEVJEPwchYXJYLxY//EABkBAAMBAQEAAAAAAAAAAAAAAAECAwAEBf/EACURAAICAgICAQUBAQAAAAAAAAABAhEDIRIxBEFRBRMiMmFCFP/aAAwDAQACEQMRAD8A8cAsU4DCUtScKBIVclsuaFmEQJbLrX9ktkDCbcrrfCdbC4C/ysAQBSBvwuaDdSAC6xhA3CcG/H6JQLJfkrGE2rtqeAl2rBIvL+F2xS7QlsFgEIj7Bd5Z7Ka3skNm5JWMR7LJQ3CjnrYKdt5XNYLdSg9X4sp4bthBkI+wWqzcQ+G9rJS4NuXED7rD1Pimvmwx2wf6QqEuoVU9y+WQ/wD7I8GH7Z6Aa6mY7NRE0ju4JrtXow4g1UNh/qC878sv4cSflPjpnSHAyjwGUEeiR19LKQGVEbj7OUz5Y4xcvBxwvPo6R8DPOfcN6W7roqyqY/0Suz0vgJHEbgbwbpzbDWW4TnfwgGtF84WUpterqYhrtsgvwUXo/EdLO+0wMbjbnj9UGgcAo2EkeY857qpU1scdwXhjVR1TxDEwbYXA9EDbJLXOLnk27LKIYYwrNrbGny6Zhce54UUbqmpdeR4+OypmPycXynRVogddxLig/wCHRxSD1PRvIGR91abQSWFi3KEUutPcQGsuj1BWySgFzB+qm+SHWOLK7qaaO5LbgdkyxPIstDExsjfVGLqCr01ti5gv7Jo5LI5PHpWgIAnfZTGAXs1wv2KY5pbgix7Kpy0Msl2pbWS2sEAjC1NLVJa/CaW36rGI7JLKQtTdvVYw0hdbKckRMMIv0SFtrp9uyRxusAkISWSu5SIhOXLlyzMOSgJEobcIGOwcJzRbg39lwCcG2WMKE4LrJwCwBQE4C3RdZLZYJwBXAZT+q61kLMNHZcbBI+RrcWu5CdU1uKiFmkPk7A4CKNRfqquKnYXSyNY0Z9ys3qHidxvHRt29N5yUHrtSmrZC6R9x26BVhucegHcpkiih8jp6maocXTSveT3KjvYYB/RP2t4F3H9FLFBNJ9EZ+wRtDJETbHDmu+QpI4A8+l5B9wr0OnVLiLi3yVdj01zG/wAWRlh3N0OQ1A1mmz2Dg3d7tRCjpQ8bXNLZhkXHKtRvihFvMuOMNU8lbC8AENuOHWsQtbCkQujY+jlBAbtNyOyigoYbsY0Xu25UVXUOs8AjI/VVqWseyYOJwMIIzL0+m+c+QxNuQbKjPSGAjN3dfZGqaUyRiKNzQ7l7r8X/AKqaWkilb5UcdyBcucOqxkZWSDcMg37hdC+amN2jcOyKVdP+HPV2T0t+iokE2u0j2Q5DDnVTaltvpcMEKC0QNyV0sIe4kYPsqMrJWus4khFKzNhWKuih4c1qK0OpmQgMnbfsVlW073HF1K2nlj9Tbj4QcAKTTPSaDVJWENnZjutBG5szLixuvNdD198LhDUethxc8hb7TntkiaY3bmEen2UJxo6YSvTIdV047TNEPdwCEh4PpkPsD1WnlLmsuMgoFX0gYfOiB2O5H8pTQlemcnkYqdoqFhabX+D0SFOjeHDY7g/suc0sdY9FQ50M4CQ8J/PASFqxiM8pCnkYTVjDcJE5NRMNP6pCE4pvBQsxIeUiftScJgCWXAgcXSrhyszCj2wnBdbHVKEDCgJwC63RLayxhQPZObdcOyeAAgYWycBbhIBcJ4H/AAsEQDsmPktgcqR/YIVrWpx6bT2aQZXDA7e6NBSKmtaq2kYY2O9bv1WRnmkmeTk3KfNK+d5klcTfuoCdxtkDoB1TpFEqFDR1u89grEdKXEeY4js1uSU2GP1BtruP5R/dHKOkZAAXgOf2HCzYyRBSaeLXEbWju7JVsiCIepznntwuqKkAc3t0HAVMSy1LtsUd/gJWhrLf4lziRHCB7kJ0UU1Q6123PbP9EtLpbneqolNuwKMUzGwR2i8uFlvqJskeuhitHovpDpTJ8cXXS0dLEMRNv3c5PlraXcQJJZ3ddg/uqc1UeWxsj7XyUqtjFaqZGb7Yhb/QUJma1jrgEexRN9TcW3uJ7BuFSnfvFrG3wqRFezqSodG4AnBOfdaSmrGysEcbdxHNzbKyjm7GAi5VvTtRkglAwB/RN2LRoamjc4bnWc49ejUHnpmxk2ybZKNwP/FMAfK0NHAHKZWUsYZgA37ngJBkZlzBuuFHNDcEWFj1Rc0ewOeb/fqqhj9W2xtZa6CCY53U0gD2+noi8cpLBL5bZIzjc1Uamk3tII9wUmk1v4GcwzeqJ2C09PdOtoXoMN0ql1FpfA7ZIOiM6BU1Gnv8iYEgIVU0D6a1XRvxyQEW0iuj1HaH2bKBx/ZTktFIM18EjJmCxBDgh1YwwSlvLHDr/ROp7wY/If2UtWzz4SBlwyFzrTK5I3EAVEIifj6Tx7Jb+ZEM3c3H2U8zd7bHAcP0Kqxel9ndyCuhbR5rVCApQutYkHFlyIBC0FNIsnppF1jDLYTSnkWTSFrMNIsmFPKYVjE5CSxvynlpSWTAEtlOA+FwbhKAgY4BLY3CUD3TgLLBOA6JwGFwFspzUACgWTgMrgMp4FisY4NvhO4BKUBMlIAF+BysZEFZVsooHSyHAF/k9lha6pfXTvnlJIJRTXa51bOY2uPlsuEBmc5x2tTpFUq2QyOLjYC57dl0TXF21v1Hl3ZKGFx2t68lTxuEZ2Rj1cF3ZNYyL9JCymtf6j9R6/Hsrb5SWfysOMclU6cta0uJJt9RViN+47nuAAHX8o7JbGHMpTPYyCzRkM/3VuOzfTGMDoOFBG8yjHpiH7qwy5OBcdB2HcoMNE7HP9LWtLnH6Wg4/VTii8z1VD/MPRg4B/uo4b32scB3d0V+JxIDY2//ACJ6pRihLRuAs94gZ0YwDeUwaY9zfMbGIIx/5JuflX6mspaBrnG003JN8A/KESU+payTJM/yKcZBccW+FjWVqqSjh9LHOnfxuPH2CoOie525wDB7ov8Ag6ekYfKBcbZkd9R+B0CGHdNMBbB4HdFaNYk0e+luwE7TY+6qMNiNwRWsZF5IjB27bC4PVDNpFuoWQWFKNwaAWutbsUZp6xpaGeW036oFQMdua5lw7tfkdlo6aibLF5kZ/wDk08t/4SyYUhHQCe7zm3F1QqKYMeBb1cn2CNxRBjSA0brfoqNZEPUGm5PJ/sktjJAMw+Yx4sLtOPhCNQpS31C92rRxxhsrxa4VSup7scQMsKeLpiyjaJvDeo+dTmnkNy3I+FJVQ/8AT6htXTk7CcgdFnaGc0OoNzZt/wBlq8SROacscmloEdo0WmVwraVrr5tkK0JCyxPwVmtFmdTHYTgGy0Dnh7bjghc2RHTB2ivWxhocW4zuCoTC7g8Y3C/3RKV3mwZ5bcIfa8bm/wApuFSDtHBljUhls/ZKEpGQuAPCckxCLcJlr9bqWyYW2ysAaQmHlS2smOaiYjKa7hPITXBYxP1XdUp5XDOUwDrJQAkTggE6yeOUgTgD7LAFanLgCngIGFA/qnDPK4BOCxjjgcITrFYYo3MafURtH+6IzybGX5ccALMalPd7nHO3HyUyGigRWO2egG7jkqjIC07G5c5WZHEEuJ/5UQaI2mU/UcAdk5TsjI8sCJmXHDj2To3C4Yy+cFyicbXbfJy4p3+UzkBxH7LDFkT7SLfS3v1Knp3Gc3cdkbefdD4x5rrYDRyewVyOYPO0AiJv0jv7lBhoJscZi0NFmA+lvcq1G4bSAQBy5yoRVAY0Zy7A/wDeyd5+7h21gyT3SjBRr2ts78o4aevyufVzVB8qG7i7sqUTnVBAB2sCuQ1WxxgpG3d+aTsgEIUWlxUpD6n+PUHIZfDff/lWZITLGZ6hwELeGjglV6dzd/lNe57v/K/uewV923Y18ttmC2PuUg1JgKrilnG50ZZET6Ixy/3KHlgikLW2MhOSOG/C008MtQSABuI9TujR2CHO0SWMb9jgHG1z27opm4/AFqYv4Db8m5yqcUTt925GMIxVsDmi4sN1gPYKtR0rhINtxe9j79lk9Ga9F7TqRrXNcBdjufZaWKldS2eyxFs/6gqmmU3p3WtfkW/cIwxobGYzct6HsEkiiRSqImSM3MuLchB65whB7nNvdEqx7oXuF7fze47/AO6CVBM0pGSAcox+QSZ1PEdpOSS79gmTtAqCDazhYohBF5cQJFienZUJs1XsHALXsHozmrUnlO3jocozodUKqmDXH1AWKi1iDex2OW3QrQKkw1nlk2BVO4k1qRpoz5NTtOA7+qOU8hdHY8hBK5n0St6ZRKlmvsdwHC6jJWWWi5G71WPDsfdVJW7JC35+6sbdpI68hMn/AIjQ8c8FLB0yOZWQdVwF076koCrZzMakIxxdPAXdeEUKRkGyaR91KR7BNcETEJCY4cqZzcKNwwsAlslA6LhyuHKYJ23pdO4C62Vw5QMc0FSAJALcBPaEDHAWUgCa1SAIgFATjYAkmwGbpBbuumFwGZzkrGKNS8NifO7ixDB2WTrpg47c4/qtJrtRtaIgbDlZOU7nOJKZFIr2QW8x9j9I5UNQ/N8G3AVgDbHuP1OyqkrgM89vf3TDoZGM3NsZPymEmWTGellI8eXEBwevymx/w2bvzHA/3WCPLtoETOB9R7n/AGU0YAbc8BQxtzc/dOfJuI9sJX0MifzyTvdi2APZTRPLxd5s2/HsqjReznGw6BSh26270t7d0AhBkrpm+WxxZEMF3dXKd5faCmBa2/qcOSqdJSy1NgBZgReGNkQ8mDJ4c9LyGUS7TbKazGt3O6NCIwwvlkDnG7+c8NHUqjSxuMgihYZZSM5/clbXw54ZMpElRll7nGHHt8dlOU6WysYNkWm6L+KYHuBbC3OeXnufZT6xpRbFmPaBcRs/3+2VuqfTWxBrWRh0gyOzB3PuhGvQD8Q2nsXyPFrNydt8/clT5NluNHk2r6RI1rA1pFhut1t/7/VU6SlLX3tYXBP+k917VrXgGSGia+VrTU23y2yGk/lHxgfZedVmlmknPpI6EHv2RjP0CeP2LSN9OLA8hPnl8lt25H1D+6rxzCMC3yF007ZWmMi3UJmIkVa57Zot7cgf06hCoWATEOdgfTfqFOZDC90Tjdp4KqTuyCOQihWtl50rWxkk5QsO3zi2ef1XVNYZGsa30i3/APV1ILXf24TULY6tj3x5/lwskw/hdQ7WctjO4bW3wslqrDHV7+5TQfoSa6Zrg8T0jXWvhT0rrwWP5ChuizedRObi9kQo3eq38zbKb1oqnYWY4SRNk7YTQBvLDgOym0h/huYfkJ0jbWd1CQnkVERbtcWlcMKWZtyHd1GRdyojlaOAsuslC4pkINKQiyfbumuCJiJzVG9uOVMQmOb7YWAPsu+yW1iuTGOAxlOthIBZPDcoBFShdt904BYw5oueicAm2sb3Tw1YA9vRNdYvJuAGtTgq9ZIWM9OHOwFjGd1yfdO8i+LBApAdob/MbfCJakfWWg9TlDn5n23yE6LIjmzZvTkqkD5s3s3JVqpcGRucevCqwjbCXHkopDWJKfNm2XsOT8JfrfxcDomxfS55/NgfClBEUZJzn9UGxkJI4MBb+vymtb1PPQJrQXuuTjqpWu3mzf1Q9GXYreb8uR3SdEdUATVAO3+XqfZSaDoXmkTzizeRdW9W1ZkX/aUZu/h7h09gouVukWUaVsSsqY43fhqYNaG/UWqTTKeevk8ijbccvkP0hO0Tw3NqFn1G5kJ/KOXL0bRtDip4mtbG2OMflb1U5TrSKRxuW2QeHfDsdNGGtBd1fI4ZcVt9PgttjibtDeXHoqtNC1oDWtACLUrWsZkhrW5J7KO29nTSS0X2SwUFLI95tFG0ve89e/z/AMp/gzRv+o1b9droxcPPksdwD3HsOP17LMV9TPr9XFQUP+SHA7jw+3Lz/pb07my9J01jKOkipohtjiaGAew/9v8AdU9EqtkupUzJon3ze/ReR+LtGDah7mtABK9ik9Y+Vj/E+mec1xDUtVsqnaPCq1joJHDuePdDpKkhxaT8FajxJp5jc70kG9vusXW54OU8ZWRlGiSof5zA8fUMH5/5VV7w4YxcX+6jZU2dZxsH4Pse6jmLoyHjhOibI5MOwTYhWaVxcAwYAyVXcQcAel2QubOI2lrTnqU/aEaLM8u6QNvgGyBa0xvmZ68FFGOGL8koXreR8FGHYs+i94alsdh4IRiJ3kzEW+l37LM6FMWSsJ6HK0tX6ZA8fnbyhJbDB6C8J2SexU0jbKrC7fAx4PRXLeZCHBSRsy1Ywi7W8YUZGR7KRtuE0hP0zlltDbJcBLt911rlOiY1IUpSEImGEXTHBSlRvWMO691wTvskATGHAXShJZOsVmYUZNk4ZSAJ46IAYtk9qaAb8YTxjkLBHDhUas3c49G4Cvk7GlxHAQ2ruymdftf7/wDpWRvZlal25znEcXVGAmSWV3uQD9lbrnbQ/wBuFUo27YC/uCU5VIpV7zYNGeibKNsbWDoEkl5KoA5ASyXdJ8YCb0Ee1lgG9AP3Ucx3yBreALKR7tjT+v3UDTtH+opUO9dD2t3Ha2+0co1oumCd4fJYRsznqqNBTB1nSEBv9UW8ySa1PTiw4JU5yvRXHH2W9S1Z0pFDp7SSRZzmhE/Dvhj6ZZ497ib+pTeH9CjhAe8XceT1K2NLEyMAAAAdLLncqVI6FG3bJdPoGxAEjPUo1CA0BUYn2VyN11Jli7HIAL2+6WeSSpjs4lsQxtHLlXDm43OLvZEaKxeHPAxxjhFGfQT8P6f+DYZJLefKQXAfkaBho+MrV0v0+yz1LMCRke6P0T2nJKaNCNF4Mx1VDUYPMY4EXwirA0tFioKtlwQR+yMgJ7PJPGWkD1vDbX5/3XkWswGCY468e6+ivEdAKiF+PZeJ+MNKMMrzbDv2KnB06KTjaswlQNhuOHZCfFM2Ru1xw4JKhp8pwOSw2+yptdtNr+4XVWjj6dEzXbX+WTkHCjdzYm2cp8wMjGzNw4YcEjvW5rwMOt+qZAJ6cWI/0i6H6n6/Mt0KIxuDbtHTkodPZ3mNP5kY92CXRV0qTbNY+xWvcRNRseOWlYqlOyf7rY6a4SUjoj2Wn2DH0EtMdvpSD+X91ep3fwz7IbpDtu9h7ohB6Xub0Kh7KZFcRXja6655vY9092Rbsmjgt7G6p/TifwNC6wTiAkTExpaksnppRMMIybqJ2VKcJjh8rGHHHAylsuXJgWKBdOSNTwO6zCcE9vZIBfqnAIGHAJ7QkaPhOssAbJ/lO97BUtVG2AD3V6Uej4IQ/WngU7Tcc/2WQV2YrUpLueB1P90jwIqSxHRR1YL5x7uT642ZYdB+6f2WQNhuS+S3t/unxC5Lzw0YTXAgNjbz1UslmMDb2HJRYYohkN/i6dFCT63JIyxztzz6Qr0M0WHPwOgCVjkDXyR5Nx2siWl6x+Dfd7A4E5vykE9M/k/qE/8ADU8mb27WKmyifwbHSdegqbBpsVoYKsOAsV5lS07qeQPY7qtXp9cXNbnopyiuysJM2UEwIVkVQYLkoJS1BeAQpql7vKNiQVFo6Ag7WIITukeGqCXx/Q0hsC559gsZqEs00lruIyPuhMlFM82uAqRghHJnoL/8WvLNoKb4Lim//d7VHf5XlsHCwUWkD/yy2+EWoINLpXDzC15HcotpdASb7Nvp3+JPiGqeBHO9xPYdVqtP8f6zEGtrqQzs6kNsbLG6NrGnxFojZF8C11stP1KmmABEZ/RScinAMM8UabqkewPdFI7BZILfusJ4voGzNmFr43NWwmpaSZhcY2Ekc2QXV6NpprC9hcKLVOysejw2vg8mqc1wsHoPKA19rey13iWl8modcfSf2WWro7SG3VdkHaOLIqZHBLseWuvbgqYN8u4bwctKpNcXi3Dh+6uU7t7LZ/2VGvZMkt5UOeXYKFVMhZUMBP2RKbc1jnOsLcIBM9zpi4m5v+qMFYknRM9uypNuowtJpMtnNz9QWfmbfyn9CLIppku3y88GyMjR7NHRDy53ImMPDkNi/wAwdiEQYdzWrml3Z0VaolPPykcPUD9il5aFzxdp7hUXR58tOjtq4BKCee6VERke1IQpE22U4CMhRvCmKjesYVcB0S2XDCYwounAFIE8eyBhWp45TQLlOAWMOanhNaLfCeAgChsgu23ugutvtE1vyf2R0tuAEBrx50s55bEz9ymGSMtPHumhdnuoaw3cb35V5wG+POAxUpWB7nFxs0ZJTFUVGMDQZH8cfKrTSGQ3ypKmbzn2GGjAHZRFpc/ba6LChhdZoaLq9pWj1equd5RAa3l7uExtFdm7aUd8PVzaVvkyN2A+2Cg5DJAKpo5aOd0TpCNhsXWwnQTytNg4Pa3noVoNSpG1E5J2lkha73NuigZoEjuAGhx3OPcdgkcvkdR+CvS1Ti0G52nujen1PrAvhC6XTJhVPYYntiuQCRx2V+mgMcgGbgpHTHSaNxo0Tpw0Aco7LpbvJJcDayh8DUJrNoAvwt3quj+TThjRmy5JPdHfBXE8e1NojkcEGq6gQgkkLba5oEoc54BssLq1HJTztje0uecgAX2+5/sFSDsSSoC1NfVVUnlQbi8nDGC7va/ZUPNrLF9nWabEgA2W50bTqSKNzWj1uHqLuSUIrNEfTOkjLSY3uuDZdKpHHJysCsrtRpTGSyQGRoeyzDdzTw4dxg59kd8P+Kq5st21AeByy5Dh+qteH/DdTW6jTPa572RekF5wxva/QC/Cvv8A8PYq/WC+ikd63Ftxw0jsUGoseEpG88PeI3V8LWu3B3W60NREZ6VwPZVPDHgR2lQt815keByVop6MRxOaOi4MnZ6EWeL+M6PbI59iNw/dYari3Na63sV6p46pQGvNsc/deZ1DNvp6HKtilo580dgyPTpJ5WmPk9lufDdFpOkRiaugbVVlvQwG7R2J90D06jdJE18ZLbGzrFbrQ9AgFBNIWEyH8x6BbNlpFfFwpy2Zfx9pdPPpMPiHT4RA0vEVTC36Q7o72XmJu5xC9s1OnZ/9B+IopSCGND2//IWXiTcyK3iTuBy/UMSx5aQQB30Qd1bZWqF/oNsWIKrUA82CWP24UlAfrbfpZVZzRNdTPvDFJfiyJwkDHfhAtKl8ylMfJajNM/zImu6jlc8i8S4D09kobixyCkcNu1w+U+3ZPDaOPKqkRMHpCeB7WTWYLh2KkTEWNsmlqkITTlFAInBRuClKY9EwgSgLucpwb7XTGOATwkA9k8BAxzQQngdSkCcCsAcE5IBnon2sgazr2QZ0ZNHUy/zucfsMBF5SWQvd2BKpPi26W/P5f7JkMY942jFidtkJrp//ABtttHVE6mTYwj81v0QOc3N0y2URCPq546qzRQ+bJkKGKIyXtm6M6TSbQ64uQ5aToeCtl+noQ9gbYqx/0hxADY8c5V+igvbARymo7jhQ5Udv2TO02lTNIsX2CKwae8j1Xv7ozHR9lYFK1gJIU3KyscVAKajMbCeBZDWwkyCwvco9qDxYtAsEPpY/Mq424+oJk9CyhbPW/wDDnThT0kePW7K22pUl3Brhc2/sgHg2AtbFawFlp6ol8xvmxtkLmO5xpGY1XRWzxGzbm3CwGtaC+KTLL39l7D5YcCLIRqemRVDcsFz7dUYsm4ni02lSh2IuOoVeShrXenaXDsRwvTJdH/Dym7btPdWqbT6d2XRNP2TuYON9o890vRtQqw2IFzGY9LRa69O8K+FoqFgc+OzrZ9/dX6GmhjI2RtFuwR2kAaMEJbbBJUtIcaZkcaEVws0n5Riol2gi6A6jOLFSyaKYYNnnXjlgNO89cryeqYQ7n3C9X8cybaN56nA+SV59UaS99FJMOWgNHymwyoXyIb0UNHn2F0R/Nhel+F6g1VK+KxuWWt3K8nppdspcL4IN79V6b4Ha50zQDdrs/r0RzR1Y3ivYE8e1o03wfWU9wJK2pEbR1LRkn9l41e0gv3W8/wAUdZZqfiOWihdeCjDmCxwXk+orBuuTfqCu3xYcYbPO87JzyugjpLg2r2ngqZjfJrJI8clUaV/l1Ubr4uETrm+VWNkH5sp5KmQj0ENFm2zbCR6sLRUDrOcwjHRZGlf5NSD2IK1NO/1seOvKhPRfG7DA9Udr5CSJxLbHokjIFj0K622XPDgtA5sy2cwep6kAwmM+p3yFIn7OeQhCYpCE0j2CIpGQo3i6mIso3AIgsQCycuslCYIo904CyQC6eBbmyBjrWT2jCQdgnNF+6wBWgnhSBtlzU8N7lYxDUgfh5P8A4lQSgfgCCPyq5MzdC9vcFVHOvSfAWQyMFWjaZTawOAgtSLEt69kcrW75WgYu4lA6o7pX2yb2CoinoJaLReZaVw9F9v6crRQ0flbuhHpPyFaptENHQUsAHrMJccfmwSpom+a83H1N3ffqpTZTFL8h1EADjuj1IW2GEBivE/hFKWXjhc7Pax00F2uATKmS7eyjbKALqvWT2YUqQ06BlfMA7lS+H6V9bqEYa3DTdCqiV08+xtjcrd+Baana0vJ9ZPKab4qiOGHOZ6l4Wh8mNlwOOyKvdd7jjm6XwxSwywH+I0enr0SVTQx7huuPYqFaOz/VDXEAXJAVColvkFU9Vr5KF7d2WO4Kq/jxLkHrhKgcdlioex4PBVcAMN1xluSP7dUlxzcrWVUEXKecDPVX464NGD+iCMda+LJ/nWHKXkUWKLCc9eXXsUGranByukmdY/F0PrpxHG9zjhouVNuynFRRj/FtR+IqWQjLY/U756KlVwmHSmRNYXyyXIaBkkohJROneJJWm8rt7vjoEQ8hnnPAYHP27R7AZKblRw1ybZ5dNprqadkT22c4ZPvytHT68/w3osswaG1TWmOL3cev2U3ihtKyjgqmkNcHlp+V57qusSanXEl38OMWaPfur408hz5JLEtdgGeRz64ueSXOvck5JJVN4ILh7qxKf4rXDgGyjkb/ABHhekujx2nbbGtNi09keqgJaSGUZsLLPtP7LQ6Z/wBxQPjOS3hLNDRZE36mu7rQ6fNuiaOyzo+kIrRS7GsPQYUZqy0HRqYXh7ALp7iQWu6g2VWlfcDKuObviLurcJYP5Ezr2OZm57qQNUdOdzfg2VgBOjlmhlvdNIypCEhCZE6ISE1wwpCOyY5EA3lK0WK4C/KcAnCL1TwkAsUrR0vdKYVoJ6qRov8AHZIB9k8DKxhR8J4TQE8N6oAFF7ZQvUD+HppR0zb7or0QvX2/9kfmyIyMbVttIT0ay33KGaLR/wDUNdpoD9Jl3O+Bk/0/dE9TJPmY6tarfgeh/wDyk9Q5uI2FoNupT9IZm2qtpFI//W8H79P2QieF1HWRyNF4nusR2KJy/wCTHnDZf0ypXxCRpa4AqJk6YKrYPLfcLqaW1sojWReZSseAOACg4Gx9hgJJR0elgzOgvFPjlUq+cuFhdNZLhRznelRec7QMhqRTzukc0usMBHNA8Rtj/iNO3OW9j2Qaem38BU4qR8NRvbuaXcgcfKMoKS2ThkcXo9h0jxu+lYXeaWge/RWNN/xX0murvwrq+J0t7Abv2Xnmk0M2qxmnubuxhGNM/wAEq6pqoJBFHHG2znSu5XI1FaZ6kZypNHoesVsWo0kZgeHHde47IdTSOjIBvcYWi07wvFpVIKdhdLj1Pfy5VavTAwktSmlO3ohjfcA9uqmLsXv+ygjiLBYhTDA6LWNGYhdjnpymOef+U5xBUbhdKyiyIY51+SqVTCal4jP0cuHcK7sulLBG0nr3SeyeTJqkZjWdSptO1Cjp5ZGRmZxtuNuAoq3XdO0qeOapmYNzwNrckj4GV5H/AIr68dW8TywxyEw0n8Jtj+br+6C+HHvlrbyPc6w5c6/Vdv8Ay/hzZ5M/O4NxijS+J/En/XNaljpSWafHJtiZa3A+o+5WcItLJ3uVZporahI0Zs83/dVpyGyyn3K6IJKqOaU3PbBr7n7FJMLSfITm3cx/sUk5+h3srEmQNw6yNaDLaYxngiyCONjdXqCUxVLHg2RmrRoumEp4yx0jbZBwrNE7dG4fBTq6IFwkHD25+VXonbX2PXCi9or7NJp8942m5v1ReCSzgOjlnKV5Ydt+chG4DviDr8KPTspKPKDLUQ8udzOhyFb2hVHOJbHKOWnKuNyAe6q0cLYh7JCOieU0hEmRkKJ4wpnKJ/yimAaAPdKF3GEoynAhw5UgATRyngIBHNThzZIOE8YQAKGp1scpAnhYxxGEO1xm6hd8hErG3IVTVWbqGQdsrBMLqbNrA++HynH3Wj8HQhlHNJ1fIR+iDa9F5UdMAcEg/sCtD4Sb/wDh4zbLnOP7pmMghUMOyRo5vuCsNG7PfNk2Zl7O7YPwli+gC2W4SMA5rA9j4u+Qg1VTmN55Rsggbm8tVasiEjN4W7LY5UBQbJ1wQV07Sw34CqOqWNOSB90lbo6o5GywQDxY/ZG9A8NjVJ2iSRrB78lZSo1RsTDsNzblDo9ZmZMHsneHX5DkOLfR14YJu5HuOjaHTaPq8LT9BIF+i9ec6NsDAwDbYWsvlKHxnrAp9n4pz2jgnK1PhX/GTVNLDYKvbV09/of9QHsVxzg1K2eq8SlCos9zqHMCF1JY7oEK0zxzofiSMfhqoQVBGYZTY/Y9VFVaoIZjG9xugcc4uHZPLEN3pvyoy2yYysEg5Tg4G6V6BGQxyjLVK5NS2M2cG2CC+LtYj0TQ6uteQPLYdovybYRiSUNBJNgvGv8AGnxN5pi0eF/p+uWx57BPihymkRy5OMWzyeqnfUzyTyG75HFxPuSifh6OR9UI2MLnOFyPbqhTW7nWOAFe0+eRlUwxOLTfb9jhevkX40eHLezSmlZBqsgbwcn5KCV7rGb5KP1IMVVJI7owFZavl3bgOpJUMe2Xg/xI6P1tlb1smy/5TVJp2XvHcJko9Dh2Kt7F9Fd3A4U8JttN+FB0U0OcIyBHs08DvxNFbG5uVTaCyS9inaNNcFhz0KkqGWkI4sVBnQthKm/jU5c36mi6KabMHsLb/ZC9CePxAjf9L8KzSXpq6SE3tchTkrQ0XumG6c7g+M9VaonF0W08s9KowuLZQT1VyP8Ah1bhbDhdPF2jkyqpFoi6Rw+6eOFxbdMRICLKOQKc97KJwRoBGBdKGpQOycBnN04BWhPaMJAE8BKzCgJVwzlKGrGFAvZPtbokAHvhOAWMKBdRVjPMpZW9S0qYJCAWkd1gmT8U04/6fRzNv9IufhEvCbr6PEOxd/VdrFP52ilhGYXEH4/9KreD5LUssDiQY33+xRD6NGW3FuiRgzxkJwNwuDbm/ZIzIewqB7TG8tP0u4U45SvYJG2P2WTCgHqcBsS1uFma2hFS7aSQR2K200ZcDG8WKAVMPlSm4+Cs3svCRmHaOQ8hz32+URovBL65m6KcNvhXJ42uBcDYrqavlo7Fji1K5SPW8aWOWpjovAOpXbEyuaL8AgopTf4SatN6hqMAIF72KSDxI4EOcQXHqCtDpniqQ2bvuFKU2uz1scMVaYIP+F/iGjAfT19K8k2F7tyrUHh7xdp04mrqhj4RgBry5bXTdSEudwN8lEqqpbPEAQLKDyoh5GSL0CtIqpDEGyk3RtkgtlBgAx12i2VaZUEYU2zjSCD32UT5tt1Tkq2hpJPzlB67V3SSCnpxuldjHT3SLsZ9F6v1B0r/ACILl57dAvnnxtUun8RVZLy4tftv8L6Ih08UOnSyOJdK5hLnH4XzNrEn4nU6mT+aVx/ddvhK5NnF5r/FIpB1m2vyrmltL6uO3Q3VIhGvCNKa/W6elYWB8hsC9waB8krvn+rPMl1oK69VCJpbf1OaAstK7ebIj4grfO1CcNc0ta4sBacGxtcfohUZuVPHClZSOlRa0zFRb7LqkWLx73SaebVTVLqDdsjrcFM+x1+pRtdqkhKawXaU6FMxIhPTpfKqW9AUV1JvlvZIOHBAWOLXNd2WinH4nTmPHIXPNF4uhtBJ5dQx4PVGNQG2ujmFgHgFZykktYdloKh4ko4ZP5cIJVoL+QhfaWlEHG5ik7dUOB3U8bh2sr1Od7AD0Cy06IZNoItN0p5TIjdo7jBTymfZzjXAHJUTxdTFMcLopgIQCpALcJoCe0JwHAJ7RlJaxTglZhbX5SgWXWungZWMIAE4d11lyxh3CRLddZYJXlgbI2WN30vHHdZjSXO03VSx+BcxO/sVrnN3IDrlE4u/FRN9bcPAHIvg/ZFMyfoOtN7ZUgFxyh+mVoqIGOvu6fdEGm/CVm6HgBOAN00EjCdcDJwBylNZHPB5jb/m6FB6yDzWm7SHhQ+IPG1Bo7XMY4TzjAa3gfKxFN4/rjqhnqgDTvNjG0fSO4908YNlIs0c0RaSFGKOSY2aDlEagRzxsqIXB8bxuBHZTUD2NeAbfdSlo7caTK1L4TrasjawdslHtP8AAGosLXmw64KMaXVsaWkH9lr9Pro3xtBIUJTbOqEKAenaJUUjbORL8O4CxCNGSNw6KlVTMbm4C5WvZcHPisLn7qjU1rKcEkgKvr3iWl06Il8gvbA6lYGr1ys12YtivHCce5TRxtgeRLRoa7xDJUymmo/XITa44C0PhrRfIb50t3zPy5xQPwxojYdr3DPUlehabT2aAbewTOJoyvZFqUG3TZz/AKDdfJ1Wwuq5sXPmO/qvrbxBVwUenSiR7Wuc0hrerjZeCU2gR6ZPLUThrpHOLhj6bnoreNNQs876hmjGkefGOx9bSPkWSNvHONri33HIXoWpaP8AjNPlnMQ2AXDj1+F59N6Z7D4Xdjycjixz5qyOU3ccro8OXSts8ppNlX0V9lqlO2qael1b1JtyHdwqcRs9jgiVazfCHeylJ7KR2qBLcX7JYTZ1krhaxTGmzrpyfst42rQ6RIKihdEc2Cz1/SSEV8PzWlcwnlRn0Wi9iOaYZyOl8I1DJvoHNvwbofWw+okctKkpJCIHBJ8MY0NJZ2nsNuMIhSG7m9yEP0t2/TXN7HhXqI+pvdFrpkG7TCLLtcRfBUo4UZyA7qE8JjnZxwmO6qQpjkAEY4CcEg6JzRnCoAXB62TmgXXJwSswqUJOyVYwqXjlcAP+Uv3WMcM8g/KVcuCBjvumSxbxcfHypQUqBgB5Emk1Tpoml1O4+tg/L7orFUMmaHRuBB6qWQNIs6xHW/CwGv8AiN+mVT4qKzL4JBwj2wm01LWqTSoDLUStbYcXyV59r/jusr90NJeCHjHJQCq1Co1CbdPK55J6lQSxFowMKiik9mIJXOlJc5xJPJPJURUrgojyqpjo1vhPV5GQOpXkuY04BWkbU7HbmFYTw7N5dUR3WufctwVDItnRjlRoaTWTHa7j+qPUPiQNAvJ+683dUSsOHJv4yo4DyFzvHZ1RzNHrb/GUEEd3ygWxystrf+Ic094qJu48bycBYuz5vre559yrMEABAaAlWJIMszZMyOq1OfzKmR8jiep4Wt0PS2tLbtyhFAIoWgyED+qLs1t8bQKWHPG5yE5JaOeXl48e5M29EyGljDpHNY0dSVHV+M4aVroqFglk4L3fSPhYsyVlcbzSOI5twArdFU01A8CRjaiU4ay/BXO229HFP6lOb4w0P1DUZax5nqp3SSdAeiEz0pqHGYua2BvO45ceoCk1bU21la0mMNDBYgC1/ZVKuR9YLfRG0cDoOyMY0cyg5yrtg/Uat1WwNadkDMNaOCvONTjNPXzM7OuvRalnoIaLDosL4mh8uvD7W3tv+mF34NaPUeH7eNA+YfSRwVEeQpOY7DkKIrpRJlinO5uORlF2nzIQPZBqY2eB3RSFxDQD0KlkRSBSkZ9Q7G6gtm6IVLNk/s4Kg9pa8j3RiCRPEbtsrmlS+VUt45Q+F21wGVagO2cEd0suhkadzBLOW49eFVEboJXxOFrHCl80gxyg9la1qMCaOoFrPaLqaVob2XtCfeGVl0UpMTAIJoTvW4XwUejaBUNtyQsSloIN+lKDYWXAJUSDOJTHJ6a7jqsKNATwEjP7JwTgFtm6d0SAJW8WIsgYW104CyQBOAQZjrJUiW4WMcuC5KB8oGRyX3XAWTlggiv0+rrpC38QI4uQ1qxfiPRXUZMZG7Fw7uvS9oQXxTQ+fReaG5Zk/C0WBnjz7scQeQrLf4sVxyl1Sn8qpdYYcbplC7+IWnhyvdqw9leVu1V3FEK2KwPshxTRGiWtNk8uqabrcRv3RA+ywNOds7T7raUcodAz4SZCsB0jblMLbe6kc63PCh8279xFgOFBoM58SxCLOs4kN7qyKtrDaIAe5yULkq7XA4TaeeSaS4NgEjg2ckpSl2aSiliLg6d9h26qxV6/Q0YOd5HACzE9SYm4dc90Ke9877ZJPAHVBYl7I/aT2w/N4l1DU6hkNMSxpOGtWgjcKaNjGOLpbXfJ2PVAtH04UbPNmxI79Qrr6gyFzGktaMEjqlmldIaEHOXGARp2tlku31uBuXHgH+6s1Q2s2tBsq2mPa3HFuis1srLFGMaPYwePHEv6DnsLmEBZPxVSF9OJgLmM5+Fs2sc5pIFxbCE6hR+dFJGW4cCqRlxlZecOUaPO2G2E13JT5ojTzPYRlrrJHjqF1nn16GtdtcCisbrsDgeeUJV+kkDo3NwlmgwZbrm7oI5RmyoStyHdCETA82kc3GEPLS6Ij+TCnAeSIeCrDHAlpCgtcXT4TlM0KmaCGTfA2/QIzqI8zR45OrcXWfopLs2lH5pAdDcw83wpR0UavY3w84ma9ui0cZ/7sDsFmtBHlva4jDsXK0lL66yTHAssSmwo0YXcJQcLigQY0prk+10xyIo4DjqlIyubwltfKcUVl7JyQH9UoF0AigJQP0XBKsY74FlwGcrk4C/XIWMcAORhcltdKGm2UDCAJ7RdcE4BAIoamTwNnhfG5tw4EKThI82CxjyHxNQGnnkYeWkhZtr9jw7qCtz4xLZtQftGL2Kw1RH5czm9iq4+jRCc7BNCH9xdBnja4t90d09zZYGsFsCyFV8XlVDha108Xs0XWivF/mN+VqtPlvEAeiyseHhaKgd6B8ITLxCD3k4Vd8udrbADkpZZCPS0m5CpTTBg2NOVD2c2SVsdJJvcGNV6Bvkx+6q0cAAD3jKfW1AYyw7JqA2QVVRudYHKL6ZRR0kQnlsZjkNP5UI0eA1VT50n+XGd2eCeiMmRksoYCS4cnskm90I7b4onM8lRI4NNm9Sp2Rl1mtBUTNrRYC3ZWYJNp4uUij7PW8fFHEv6XoSIGDccp8FPLXzAAHbdJSafNWyC4Ib1WroaOChjubYHJKdF2yFmlxQUovzbKz9dSgPNhhaSr17TqcFr5Q82+lqztfrkdS7+DT7R3KWQYy+TA+LNINNMKtjfRJh1uhWeP0/C9Lq2M1CF0EzGlruQsnqXhGppwZKU+aznb+b/AJVoZFVM5suPdozo5U0EvlvBznCjdG5ji1wLSOQRkLsKxzrTDlCQ/c09VVkb5dQ9hGHcLtMns8NJU+px2kbIFz9Sov3Gyhts9zU1p2vHyppwN4d3UUgs66p/CQSpX7Xtzgo9I+9AG9NyzdM++1HiS6lj7XUn2Vi/YWoox/01rgAHNO66K6Q/zHSv7lDaQiOkez2uiGhgsgBP5kX0QmGxkX7LubpEoSkRSo3jClPCjeEUAc1KubwlCcU7qndvZclGUGE7+6W1jY3Xew4SgFYxwHVOb1XAXwo6iqgo4y+Z7WgdLrCku4NyTgZVKXXNPp37JKmMO7X4WM8S+M3zB1PRnaOpCxss8sjyXPJJzynUCkYtntUGsUM5DWVMZJ7FWzLGM7xb5Xi+necwhwe4Wzyjf/U6vywH1DwBnlH7ZqPRKjVaWnaS+Vot7rI6/wCP46Yujpmh5+eVkNV1h7bsbIS4+6BEvmcXEkk9VlBezUaWfV59bBnla1u3FmoNqrW+Y1w5IyiNIz8Np5vbOUIqnmaY59ll2ZdlnRn2lIvyEmuNtMHd07TogyQO68KbXmfwmP63W/0Kv2ArT6gj9A6zB+iAsBc8Ack2Wgjb+Gite5AyUchSU+KEqZwzHXoo6aB0rtzsk5SMYZXl7kRpYdvqUejnQ7aImZQislMsm1uSTYfKJ181m2VLS4fMqH1Dstj493dEelbC9KwjE38FTNhZyBcnuSp4W+UCTbc7JKpucXSX7cKzTnceCQOUiTbs6PFxr95F+nY6Q2I+6NafRxtG52fugYlLG49ISvrpXt8tji1n9U9Hfd9Gnk1+n09pbEA99+AhNZrdXWXD5HNafytKEA7Tn1O9ipmODRudY+yRsZJk8bze9uVaijDxcqqw7yMWCsNlDeMBTdlEkSmHabhSM8yxHN1Eybc7GSVKA9u7zS2MN/nNj9kvFmbRQ1Lw9S6pmSIslth7LAj/AHWS1TwrXafdzG+fF/MwZHyFvG1UDXnZHLUHofpH+6m3V0w9PkU4PQM3H908csodslLHy6R5TC50UovcEHIPKNVLRPSh3stTqfhs17C6SISydHhux37LOzUUtCTFNG9ovYbgneSMtomsbjpglw3wDuFHKLsBVktI3sPzdRhu6MjqMKq+SLGU7rEBaSF3/bs+VmI/S8fK0VM/dSs+UuT5Hxhp5LY7gfU0I3RRmKJg4s1C6WLzqWN5tYWCPtYPLbjoEF0c+R0yeJ24A91IFWhJDiw97hWQgSFTHJx4THcclYDHt4Tx9SYzhPATmFHKW3Rda6e1vXqgYQNsl4yTZcXBoJJsAsr4j8SubenpnW6EhEDZe1rxRDpzTHD65FgtX1yqr3EyPdnoCoqmZzyXvcb3uqD3biXH7J4oMVeyJxIybk+6no6N0hD3DHuupqcSv3OvYIi0hjQFRIrZI1ghb0CGalqIYCxjruKdqWo+U3Yw+o/sgrQ6Z9zc9SVmBKjvVK4ucb9ypWN3H/SE1xAO0ZClZHJKAA0hvsgwMv1Fcx9IyOMcCxVKOF7zdqkEO0bSDY9VYpmhvAukTpCXQ6mjc05Cfr+KeP5upgMA9bqPX2ueIIwMm1ki/ZAj2UNJp9z3TuFxHx8q/KC+zOpyVJFCKaKOFouRk+7lZhpCQSQT3wtKVuxZuyFkAAGVfjjLILqJkfq27eFNWTNhiDQVN7FTA2oOIvm6swt/C0TGdfqd7kqm0GrrGttcX3H4GVcqCXXthNL4Gq3QsNji+SrLZQ0hoyVThB2gN56lWG2YLdeEVpHo41UUiYyE8m64SEYF1BuN+ikaTbi6Vl0TteGe5UrLvN3dsKuLN5XCQk2HJWozZc80MFr8DCex7nuFztZfLjw1V2BrXFshO8jDQL39k9tR9LHESuAsGD6Wdeeq1V2Bz9F4PsR5HDeXnqpoYvPeSS6Z55N8KKCmklb5krgxg74x7K5TVpaPLo6cyX/O4WapTkBZIQ/Zl2Cj25fj2HVXIWtLtpcyMDq42/8A6qX4iVrbzvYXfyt4T5agBpc5zI2W68rjlMnP6jCP6ILnUdMpo9p2Pty8OshVf4h0V7CDJSSN/lk9SquElc3y2OfHC7knlw+FLQ+FdKY7NI2V3d2boRSW5WeVk8ucncmB6iPwrXu2kGie7iaF+5l/cdENrfA9dCDPQuZWwEXa6M5t/f7L0Kn8JUMwDI9MpvuFOPAroCX0VRUUL/8AQ47f0TryK/Vk15TTtM8QqKeSmmLJo3RuBy14sUT06UGnc3ktXqdfo00bWx6uzSq+N2N5kax6F1HhDQXBzqOQ0r7fSZA5pPTINv6LoXlRemdGPzV/pFHRLSUgYe4RpoIFrY6eyGUOnz6cHMkaC0G4e03BCLixaD0srQkn0UlJSdxInsuLjDgpo3iQf6uqbs7FNMZB3twU4Ce6abJrJA7BNinEoAJQP3Tvskalvm3VEw7qE8XTQCmVU4p4HvPQFFGAfiTVzTtMERNzyQsRKXSOL3E3JRHU6k1FQ5973KFV0oiitfJRrYnZUqJPMfsHATW07pHAWICSnbYbje5V+J7Q3HKqkiy0hI4hE3hVNQrW0zS1ti8/slra4RMNjnhBJHvleXOySmCNO6V5Jy4lTutAzaMuPKkjj8iPe8Z6JkbDJICQTlLYWOpqYk7nDCutbI/0xjHwrULGBguwhSbwBaMXPspuVkJS+SuIGxN9Zu7suEZaNwHurbaYQjzJzc8hqayOSqlG3DB2StitjInNkAHDrqw+Nsk4mfYiNth8qSaOBlmkXA7ckrpdNd+FbUeZsa44a4dEjas3IZSR/iJS44AV+WRkTbAjHKqU9JM5rQyUNuL8LjQSyBzm1IcRyNqDaA6O/ENa7dZUq6ra8ZcEyqjfGNrprnsAqRg3Auc427lPGK7HjHkTUEzWSSPP8tgrIJmdfIaoKSm3CzGE9TYXVguAG3F07S7Z148KTtj920WCQOubZKiLjfClYNouTlI2dKRK0EWvn+yk3Bo9yot5Ka4mxP6pa2P0h5kc8kNzjhW49scYcw3lPLjwz/lRQlkcRANnkncf5R2Cia01j9jfTAw3d2T9Em7dEsb31JdHDdrOHPtl/wDwlZrem6PWRxyQOq42H+I2NwGe11DU1hNqShHqPpu0f0SR+GhTta+pNyRfb2S6/wBHNlzxho0Z8YO1YiHSNOZSQfnmnAe4/A4Csy6iREN8jWi3DRa6B072QwemwA4A4UscUlQRLPhv5Wf7rnlGJ5+TI5uy/T1M07btswE/UefsrEMETLOJMju7lRE+drenbgeyvUzg5pxd3IF1GVLom7oIMkYxofJII29zyfgdVcotQfE8PgoWnOH1j7A//oMn7oZA8B+7ZudyCeiIU4aM2u45upSIsKPr9Xq/TLq0kTDyykjbCP1FykZp1PMb1JqKk/8A+073/wBTZQROIyCrcUjTixB7qLbAXINF0t4aIYIY3A2sYm4Vup8FNe0OdSRSN5BDAP6KCH0gWWh0TXn0P8KoaZqc9OSw+yMZfI8Xb2Y6p8KOpiTBuhP8rxdpQ6RktK8sqInRHvy0/de2ijotTgEjGsljfwR/7ys/q/g4OY91PHvbfMThn7KqyOAybi7R5qEu2yJ1uhGF5MF4nfyO4/3CGhxa4skaWvHIK68edTOiGZSIntBFwMhNDjYg4U7hhQyC/I4V+y12WgLBOtwkCc1MEcLd0G8T1Xk04YOSjQHWyxXiis82oLAb2wAnQGZ+V7nO3AXt2QyulL5dp6com+8DC53ZBAfPqj1uUy7BEsMaTYNSzkxtsTZEAyKip977E2QGpqX1DzbqmouitO8zPxx0VqmpMi4yU+mpNl3v56KzUEU1Pu4e/A+EG/gdL2yjNeeoEbeGopTwxsAa2IXtzZQUEDY2eY+13IixzAcNLvspSl6RyznbE/DukHqNgn+ZFTNs0bndLKRzS5tyeT9Kljp4KaMSTC56N7/KRuhGVoqOWscZZTsjGSf7KyAXt8qmaGsHLz1UjWTVbd8g8qnH2uoaiVx/hs/hxjn2H/KW7FZH5EctQyFhvxuerFWTWVTadn+XEM/KbCW0tO6YC3Ro7lSwxmjpHSOzJJ/UpBXokom753ED0sbYKiyYRalI2/ode/yidAzy6eRx5P8A7/dAZv4lZIRjJz/daKtjw2QT3kle8uAZc5UA/jHfb0DAHdOc78VJ5bMRt69/dSWDRZtrDldKVI7cUKHwP2s2/ihTFo3XsbvPa44++E5zIpiDTy3k/NG7Bv3HcKrlxN+uUpja+wIIcOHA5Rey6dErfTi1vlPBLjnlOp2uqnNhN3zHDC0XMnsQOvukttNilY8XY7cAOVIHCIDnzCDc+3++VXwwbndDge6WMOnJcSA3r7oqgTdkjWvqHbW+loy53QBdNOZy2lpQQy9rjl3uoi+Sqf8AhqZp23s4/wAyMUem/grcF/Uqc5UcefyFFcYlzSaGHTY/McA6c8eyratX2ab5cSn1NQ2GNxJ4z8oPTX1CrM7/APKjOPcqUYtvkzzork7YQgIhga6QjGU5sstWNwJbFfF+SFTqZxNI2EZAIJ9/ZE4BYbRa2Oi09DNVskjj2iwG0K3AQ1wNzcKt14UrJACLqLQrdhKN45vjurcUnXPwhEdQLYPPRWoagtcNuQpOJOQbifcgd1dhsSATYoNBOMZ/4RCCfHPbKi0TsL05cCBYmxsSTwiEO0/mv8IbSSbmbTewKvxEi2MKTMmaPw9qYoKgBz/4T8OHT2K3flMnpg9ti0juvLITk5tharwtr5p5W0VS7+DIbMcT9B7H2TQnWh4yLer6DDXsJsN4BIkH9CvPNb0FzHmws8cOP/v7L2KZojkLeN2R/ss54g0yOQb7el/1ex7oyXF8kFqto8f9QJY4WcOijkGOUa8Q6b+Gm85pOTY9gUH5F/svQw5lJWdMMlosWT2gLgL8C6e1i6qLENXKIKaR5tgLzieX8XqDjzm62Pi2tFNQlgOXLD6S7zKl7ieE6FfRBrkuwbB2Q/SIQXOmdw3Oe6l1yQPn2tN10EL3Rtp4uSPUeyZFIIr1tQ+rlLWD0g4ToKPy7EhXm0TKYWAue6Y8bjZvXhGy8RIYRLIdxsxmXFUZHivr7u/ymmzR7K7XOMVO2mj+p+Xd02goWsJdJgf1U70JlnSovU9KyS1h6R1U94ozsjG9/ddHHLOAA3yYR+6lAigFmi54xyoXZxJkbWiIeZJz2VynpNrBV1QLh+VnT7qobD+LJz+VvQJPMqKwl0khETeRewCz2MXaqpa5oe9zDYWa1v0t+B1KqUtM2Vrqio9MfIv1VKR3nyCCNx2Dj3KIU1LLIB57v4UZ74QegMdFAamZsr27YW4jb39ynn/uZDK4fwY7ht/zHqVYke2oaGRf5TRZzuLj2VHUKtsMIiYQOgHslWwVbpHVNWIoNow45ICASyOkJjZ+b6z/AGTqqsdK8Rtdjq5JE1rG5xZdGOHHbO3BgoVoETA1n3TeRtHyUjpNxNuqUYGLJ2zsoXbhIB0XA5uVxN3YsB/VbrsQnoZ5aathfDUGlkDxtma7aYzfDrji3N0RnpptTbV6hupneS4CUseAahxOXtb1vybD36oQY/MdyLdz0SSNHmNZG4tY03v3PdBuxk2iRoMri5+GjpfgK7DSGoj6tZxjr/wqLngj08jk35VnT56qaZrA+7RyOlkk7SObyJtKohOlpG030Nt7qdz7XsblTMAtbohurzfhacvabFxsCuZfkzy1cmC9Wq3SyiniNyTbCmnkZp1IImngZ9yqGljdVGoefpyCe6ZXTipqA0HAK6lH0dHH0XKJxJaHizyd5KM08lhnqboHC653Xt0HwrcVQQbdgpTVk5p2GxNtPRyRz23vwFRin3AXIurML2l+1wBx+6lRLZPEWvftDs+6mDnxuAOO3uqJFyTxfKtwzNkbsmweL/3SyBouQ1NuqvwVJBBDjb+qCuvEeb9ipY6hwHuoyVk5KzW0mpZaHAW4KO008b7AO+6wcFZe2L9Eapat22wOellzzi0TbaNjG0tDXHLDkOViN1xi97+pvZUdCr45ovLkYDs/m4cLrQMooqjETvLdzZwv+6mohTNVo9adU0lrn3M0FmOvybcH9FJOG1NO5j7kkE2QfwtT1VDqE0crHCN7bXPB7f3V2oqHQ6g+Ik2wFV/rssnqzM65pTZTLFLYCRtwe3Zeez00lJM+KQWIOf8Adeq1T6arkdD+IjFVH9LS7OcrD+KqRwcZPLIe24OPukxTcJULF0f/2Q=="
};

const CHARACTERS = [
  {
    id: "c1", job: "guardian", name: "アイナ", title: "守護の乙女", rarity: "N", atk: 10,
    img: PORTRAIT_DATA.c1,
    bio: "前線で仲間を守る守護役。銀の鎧に身を包み、静かな意志で敵の攻撃を受け止める。"
  },
  {
    id: "c2", job: "archer", name: "ユリア", title: "翠の射手", rarity: "N", atk: 12,
    img: PORTRAIT_DATA.c2,
    bio: "森を知り尽くした弓使い。正確な射撃で遠距離から敵を仕留める。"
  },
  {
    id: "c3", job: "star_witch", name: "ルナ", title: "星詠みの魔女", rarity: "R", atk: 18,
    img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAETAScDASIAAhEBAxEB/8QAHQAAAgIDAQEBAAAAAAAAAAAABQYEBwADCAIBCf/EAEQQAAIBAwIEBAMFBgQFAwQDAAECAwAEEQUhBhIxQQcTIlFhcYEUMkKRoQgVI1KxwWKC0fAWJDNy4TRTskNjkvEJJdL/xAAaAQADAQEBAQAAAAAAAAAAAAADBAUCAQYA/8QALhEAAgIBBAEDAwMEAwEAAAAAAQIAEQMEEiExQRMiUTJhcQUjgRSRsfBCocHR/9oADAMBAAIRAxEAPwD87FHatqg4xXlF33rcq5rEYAmKCBjGRXpQR8q9iPBr6q+9ZubqYse9bVQ19Vc42raqYr6dnlY62qgFegtbI465NAT7Gh7ipMEPMeleY0ycVPtoN6yTCqtyRa2xkYKqkk9sV0H4MeFluiNrmowBxZOSnPuGmXdgB3WPYH+ZyR0Wq38M+GrrXdfsbazTmv7qYW9ptkLIesp/wxqS/wA+WupPE2C28LPDU21kAkhRba0Q7lEGQpO27MeZyfc1G1udlAROzPUfpOlTJk3OOBOWvHPjS51PiG4sLRzNcFuWeVTzcpP4F/vVYNpJsFT7Thrh9xHn7o9zVmycFz6Z9ka6yNW1FuYBhvbQ7s8jf4iAT8BVfamWvL+WdV5Y3bKr/Kg+6PoK+0+0LtWUNYrM3qZO/A+BJcN5aaZZqYole52cOyj09eg+O1AdSvZb4GB3LRqSyA78ueoFbpw88rvjBY5wOla2syjIxG3Q/WmwAOZPdi4oDiCTYqCVkQb9D2NfYEOmOMczWx6jry/EUdi01p8qVJ+FS49HLRlWG698dR71ouINcB7E8rCJ41HL8iK+NZOrEgYcjP8A3f8Amp2k2ElvKtq/3esR+HcfT+lH7jS/KIDL6SNx3U+4odm+I4EUjnuItwRgMzZ+BqJPEBD03O5oxxDprW0zSABcH1/D40GuZgAAH5gP5BRgbiTAC7g/kAnDMvpXfHue1aXg55Bt0zmp6MJnTI5F5sDPcmpMtrEzT8kkatEoPKTu2+MD3xWt1RfYCIqX9kJUkCjLKxIqLZ8xQrnHY5phls1ijlPPliwOPmSNqB3S/Z7ptvS24/vRQbFRF1CtujToeLjS+X8SEr/v86i3ykFJASN+Vh/SvfDU2JJV/CwDfpW3W4vKD7YUkMPnQ+jHPqx3Gngu+JIUH1L61z7g5x+WaYrlcPJGCGGfSffuD+RpE0OY2moxsDgFgasSeINHFMBjK4OPcUL6cn5jRG/TWf8Aif8Ao8GB5kwvSh04yxJovdIQTgbHcUJuB6vanlNi55/IuxisgTd60c5U7dalSxFq8xWhlYKqliTsK0TUAAb4mqO0M6O7MBj3qAyeoii11bS2xaN1KkdQe1DpFKmsrCsPFcz4qiNc4zn3rK1uxO25rK+r5nN9cCBVXBreiAivgT4VIjjzXYACeQm1e1jPXFb1i+FbPLwtfTU0pHitgjr2ErYqZrk+AnhY81Iii5t+1e0iFSo4M422rBMIBPkEOe21FLK1Z3VEXmZiAo9yTgVpt4MkYp24A0D996sYmkECRxs7zsNoRj1SH4KvO3+WhO21STG8OMuwUTpL9kHw5EpvuLLiPEcKHT9PLDt1lkHzPf4n2pi8SrFeI+OZjOnm6docKOYT917h/wDpqfkPUas/wosYtF8LtIcQfZLZ7Y3KQHrFARzIp+PlhST7k+9IlxLbrwZNcXTgajq0smozE/hDtyoc+ypv9K8rqchdrnvP0zGEN/xKIvdMGrXuu3jKW8uMWvmsPxSnBI/yZ/8AyqjNR0Zow4K8rqeVhjvk1emr8ZWc/C9z5KCOG8u7gRuOpKKhXP0wPrVYzD983ckuyvK3Ow6DJ601pty3cb1mzIBX3igmjArsu/avl1ol19jLWsBnnLAKnvvv+lWHFoHkJNJKoBX0YJ6H3pi4Y0CGXiXTLJ+VgSWcAg9Qf9Kf3m5JyYlGMkfErSHQiBG4jKlh93H6US/4YmVEkMX8N+jdj/vFWX4l6GvCWtSSxwhrG7XnT/7cgGDj+v1qu7niaU+bE2PKZiwUdAT1/oDX1c8z7G4dARImrafaWlmktvl7mEiRT2yOo+oyKgXuoxsqPHIWVgCCflt+lRNQvn81iW9LnJ+Df+aBRXHpeHsjen4A7j+9FB4gGFHmZfymYMGPMp2OfagEkHLzA4JXYjvRuc+rB6GgV+rrKJF6jY467dDRVieXjmRSx+0L6SWGy+w+NSQFjdgu+fvGoct2EJdyqnoSNq+W988lxGLfKMGDGUfhwc7fGi1EtwE13KF2V2GN8ge1DNcizbPKu5T1be3ej2szy30tzMW5pmLMWPdjkk0La282yYN3TFEWLZFuxPnCsxcqc7lP6GmHVYRcWOSNxtmlDhmcW8sPMMqDg/LpTrenFk47ZH9aw/DQuA7sUh6e2Y4W7gD8xVnabKLq1eMkbcrj4ZH+tVjaYjuGjOwzzD5HrTvpV4sFzacx9MkQRvzxQci8WPEf0zgEo3R4k+eA8pU9VOPp2qBNZlj90/Sjzw8zMCO2Qf7VHng5RtRka+JKz46o/wC8RfktlUdKk6JLBZanBNOheFGyyjrW6e3J7VCljKZGMUVgGBBiqEowYeJJ4ouLa/1Gaa1BETnIDdRS3JbFzRQjJ6V8SIFiSK4o9NQo8TTn1WLHzBcensxwFzWVYXCelW1+GLpjl/EelZSGTW7GK1LWD9J9bGHDdyoFQZxUy2jx8a0quT0qdFEyIrFSA3Q42NUyZ5kCfVQZ3r3MAVGFC4GMjvWcu9eiM1mamhYz2rfHHvXpY9+lSI4vhXSZ8FmRx5xUuNNxXmGMt2qbFB8M1i4YCb7OMZ6VZHCOlSSaRBYW/wD63iG6SzCr18gOvN/+UhUfJG96Q7K3ZmAUZYnAHuavnwJ0pdU8buHoAoe20ZC+w2/goSW+shJ+tKZmoSnpl5v+P7zqfxI1FeG+CtRtYmCRxWi2cX1Ij/pXLXjVx+beLUrW1YxQR2kdpEo64xyf05/zq4v2guI0Thi6QNubuJNvg4H/APo/SuRfGa+eXVb8MdzKpKjsMEAfkAfrXm8Kepk5nvKGm0pPkj/MBWuvPd8N2MDZCC9uSp9+YJj/AONe7XUWtlmIHMWGQD71FGmSx6PaKyHl59zjocHf+teXt5YJCWBznDD41aoC5DViwEPw62ZIOTmOHG/61YHg5bfaOLrZ2yTyM4+A3H+tVTaQFyOUb9gKvjwstobLji4tlTla1tY4z8wqg/mSazXIn2Z6xlT8SxePODU4r0Ce2I/jgc0TDs1cmapw9eabdXiyoR5GBIO674zXc8fJ5XMxAGN81R/jVpWjxXA1ezvbVbtfRcWrSD+Mh6jFHYeRJWmzbBtbqcxX5K5A3x1HuKDvNy3seDtICufj1FMfFMenpfk6bctPbuOZQykMh7offHv3pS1ONrdUuEHMqurEDtv/APutLGnexuEmzuWA7YobqLeWsjjcLhiPh3onLGPMI7EVEuIwzFcbMuK2sxlHEBSxRXK84BYMMgr3rUsn2cci8ofsi9vnXyNZbNiFHPGT901KCRXAVlxHJ2LbZ+Bo/Um/VyO5rkYw2xVjknYn3JrTLcAQSAAbYAr1d84B81SgXsahoOcFj0rQ+Zhj4g/SlAumUnAEhHypxe482wCE+sMqn86StNfnupj7uaa0Ake1bu4IPzFdcczGlPtIm+/BtrmKX8PQ/KjNpcFhCc5Krt+ZoddxefZkkdASK96XcDzcfyhcChg2I4RtaWjaP9rtkdcEkZH5V6MHMM/1obwtfB0ktm+8nT5f7NG+UljttQF9o/HEJmUMxHzyP/YPktRgnGMUKuYNycUxTWxI6ZqHNZbbimA0mlLi4bUlthXk2xjOSDVweHfhS/FkEs5X0r0z0oL4mcDf8GyCI/eakf67G2b0AeZSH6bkXB656iNPr0lvZJbWg8ondm71lQI7YvJmspnYixT1Mz8gxTRMtU1AxQAkkDoD0FaUQ8/SpkcdNXJQmspWKmTUny/hvW2KDfcVy53bNSQEj41Kjh9ga2pBg71Lih2FYJhALmuCDfpU2ODHSvcEO/Sp0duD23rBMMFkvh5BHfxysuVgzORjryjmH6gfnXQX7JdtHFrXEGqz4EiwRWcLN1Z5GLuB8eWOqL0qDlgvSBv5PKPq61f3gLpxtn4ahBH/ADc93fyKOvKAIIs/XzMVP1TftmWdFj3ZEHjv/wAg/wAeryWXg64mXJKztKf8rj/U1z1xuW1Xiu/IPPHLJBIp/wAJjWr58ZdTW04cjWYZtpLye3mOOiupGfocH6Vze9xNM+nWruI7l4hGxzuQhZTj6AVP0gNXPWfqLAAA/H+/5lsW3DsV7wxMqtGLiFfNRCwyxU5wB8s0s6rp9s9rHcxsOYnkKd222/0qZqPDWkwWkJh1hkmYZaN1DEHfsMEfrUXRtIeO9IjvUuEbsQVJO+CM96fIvm557Hl2GiOIOtrYK6yI2N+3VSPhVi6NxJeWmv6pqlraedeSW8QMS9OcqMn9M19n8Pru+VZ47KSG7bHNyrs3s+P7iivCnB+qcM6ozXkMkkcicnmKOdT7Z7rgbV8LnczK4sRf1abjri8st1qMtlbsf+lCeQD8q16Lwjw1ojPLql6NTvE3dWYvy/T/AFp746za6Jc3IWVYokJZIxyvKeyg9hnv7VQvEnhlxRr/AArca7c3BtbRSrLp1qCAsZOOY49uu+TTCbn+wkfIUxAECzHDi+74RmPmaY9vDM6FJYJExHKO3yPxFVJq9ikgmWBgcggxkjOP70I1Lwr1CEW5iMsag8rTvJkTZOxReoOO1EuDvDTWNY1WaJZJpLOJiATsWGf0re1SLDT7HnyKdrJxI9wpKxPjBKDI+m9RbpSsiUf4g0xtDvprKcFWhblDH5d/9aC3v3hjfYEfSsqZUeiLi7fW5SeXy2KknPKwypzR/hXgh9Wtm1DVrz93aWpwOQeuY+yj+9SbHS01GfnEaSMB91jgGnzh/wCzXGpRQzXgtJLcckaOoMbEjfB6A0RnNUJN9MbjKu4z4fTReSexna602RuQeaPUjb7HbvSpKxS3kdUIRASPcmrs8WNDFpo+suygc0STKAPxBwPaqSeWW0tXJH8XHQ/h+FFxmxF8igE/iC9OPk8r435t6bLNh58YP4csPypVhBMWQMGmS25obaGRh62TbPt0zRHgtMdvEPx76aWP8rf3qLbx+XcRMPxLU3lX91cnuuKiTN5cMLH08ooKynk6EbtEkNtexT/h+4/y6f6VY8WkvLGCu+RtjvVaaVMHZVG/OAyj4+36Vc/AEsV2RZTMOaNQ8ZP4kI2/Klcz7OY5iw+qorsSHpPD0l+A/IQnc/1rZqehRxnlUZxTnYWxtrzUrNOnMJkx7MNx+YNSbPgTUNYn9MZVCfvEVLfVUbY1KKaRQKURi8FI3gsXiQb9cVUnj/qc2pcVyW7LyiDar906ztPDPRpLu6cKwXq3c1y9x7rx4j4iu70bLI23ypHQIcurbOBxCa7IuPTDDfJieVERwvXvWVJeEB9zk+1ZXqLueZqonJDlqlJFivsUXM21TBbk9BTJMkgSMU7mtsC5NSWtGWPm5cishi5e1Yuaqe0jqbBDzYGDn4VqjTlGTUyBTsQayTCqJuhhzjFT4oSFG1a7WHmPSisEGQKETGFWS9FhE3nw7BpY8Ln3BDD+mPrVp8Ga+eFOLBIu32W0towuP5Sjv/V6r3h7SlvdYs7d3CRyyqjMewzRa71DPEl5My8qzFiBjoCpH6A0llXe237Szp3GLFvPyB/7HLxt02G60rX7NRz/AGXUA6g/yNkD9CK5M1F54L23uhyzS2DFVHQlNwyn498/GuqPFC+eCDTdVlTzLTUIY7W+RD/gADD44VGHxyK5m400mTRteuSrCa3lc4kXodyCD7EdxSmiNCpc/UgHxq3n/ak/w24L1zxQ4nubNr6fTLdYWmHl7Fj0QdOm/X2Fel4V4u4cuOWE3T3kMrpdJeuvkqFzgDO5zg71dn7NXB0viHpkS2l82mahYpJHHcquQeU55Gx8HyPkats+E5t9TuZtTMF7qMjfxLhVzzDp8v0qkM1HaRPJvpSfcH5gnwh1K41vhLSp7qNlLR8yh+qjJBHy22+FWHPYRSY2GaMaLwUmncKahqMqf9MxQQ42wzNn/wCKn86FEMG+VDXuEcWIP1jhPT9e0x7K7RzExDHkOCcb4J9qWn4KnsEaCxnWK3wVEZGRjpjB60+hvTg1HuQAuRuaJcwoPUqdvCCGRoXnlQvEW5XC7gHO2On1ovacH2PD9p5NnCI16k43b404yYAJbr2oRey4DZrArxDlSRzOUfGS2VOKdQJXGWXt19Iqqb4+VOzLnkQDKjtkGrj8VYjf31zflwVmndUH+FfSPzxVQCOSS2aVlw8hLY9h2/SjY/mFyClCwxwTLDc6nDBcyGCGUlDJj7h3IJ+GcfnTZomnW0guPOPm87sqBerdcYFJ2i6LcTaXcXELFDHKqFh35lYEf0qz+EZdO03hGTUH8uyjiU/aJ5d3TGc4J+eAO9bb7RNSFNtAXjHcrb8KWtrNJm6ueSHOd+Vd2J/ICqLvIMYjG470z8ZcVPxhqkt02YrVR5dvEeqIOn1J3PzoDcQmMR5+90NFQFRUC9OCYMEPKgAGdzRKK4a6nRm2BwOX2A6CtTREsoxgDepWjxCS8RCPusT9OtEJ4gEX3ACHyeeTyc4KoCB86jzkNGceoKxWpKJ5k63GPvKVIHtUe3/69xGej5PyIoIlNxYqT9JuXht4JAfVE39Ku7TdMccP22s6Sx+0WTHzoyc5U+oEfQkEVRFtII45EGQM53q7fBviEKxtZT6JY/LIPuOn6ZpfUg7dwjOkYqSB3/8AJZ3Buu22q8SaPPhRHdQyROvsykMAf1q773X9N4fsg7Mi4GQBXMN1ZLwzr1veWr8tuZedUB+4xyCPqKPatqt1qqgs7MmNsdxXnsujGVwb4lZtQFTdXc3+LfGh4olWKNz5K9veqhu4AxI6EfCm6/tnkbO9BruxwCcEmreBFwoEWQM7Nmfc0W57QBwU3z1rKMvZeUnOVwDWUwH+IH0r5MQ7OHDUTjgGOlRreMq2w+tE4IyRnFHJk1VmloMjFa1gIbcUSaDIFYluBvXAZrbIqwY6ipVvBhhmtyw81b4o+UiuEzQFSTbxcuNtqKwRjAP6VEhjBX41NtlOQMdKGYcQppZaO8hYDcNkfka3zR/bIVnT1SxKPNUdcAbN8ux9q86cXgnjlXHOjcwyMiittpzJPFPalkIOFK9Qfb/fWlW4a5QT3JsMcrrhYa/wFo1gi+ZLdWTXBD9CQ78i5x/Kjiua+KYWkurmC8Ux3UZMbMRtLy5ALezAAb9666tTNLxVpmkSsiOtpDau0agBXMcrZwBtgyCuePFS2isdfuZJ4Oa3uXL4GzI4yGx8QRjFTMDFchB88z1OVQ+AUeVAuXH/APx2aza2/EXFHD13GrjULQXNozDfzIshwD78rZ/y1e+pWjJrM/Nn75rjzwY4m/4D1O01vSyr3Gn3H2hVdcc6HZ0YDqCMjb3rufiLSJr2K31m18mewvokuYZbZiyMrrzAjO+MGmy24k/Eg5sfosD4Yf8AYm3iTULS24C0mxMqxyXN1JcMe2EUIM/Umqxupws7eWwdR+IU16ho9xr+liyDiKZG5oXZchSeoPwO35Cq+n8N7nSuLrxb6+uvt1uQhMUrLEQRkYTp370RWJNRIhVEYLX+PFzD5V6ktzUm3s0srdYlJYDqx6k+9eJpAqkU5XHMUDc8QReQ+/Sk7i6SeC1Nvbf+pnBVCOqDu30/rTtcyjvS/fLDF5sixczt1x1b23NDhg5nOnHWiL9rtrJV9NvCzsPYdBn9ap+9RYiYwBsMV0ZxHZs1nq+qTKPNuFxGAOiDZQP1Nc3azN5F7MP5WwPpWl+0aVjRJm+PiOfR7aO3ht1njdzJKrd9sAf1oVxhcahcpJZPLy2om8x7ePYFyM7++KL6dYm5kgGN2Xmps4c4Pstf11pr6YxR3EcpiEY+7Mg9Odum1dfIMQ3GBx4m1OTYPMq614dlsbL7TNHyuQHVWHRc9frUXVbYB3wO+asrjSNpLhuYHzDDhye7ZP8AakKdPNXGMnHWu4shcbjGtRgXD+2sCzxcgU1I05Y4mkYHMr+kD2XufqcD86231sQzIRjkG/w2qFbN5dyGP3en0pnsSbW1hGG0k57ddsY2NDoDzl3BwysR+v8A5FTYJBGsmR32HvQfRbsTTXAbcOxYf3/SuKPMPkblV+ZNml5IDIu3Q4+tNnBOttY6hE6sezKPcjf+lKNyuIXXqM/1r3otyySKMlWQgg11gGUiZRimQNOu49KtdbsopSvmwTIGRh7EdqB2LTaPqr6Tebk5NvKeki77fOt3hBxBFf6ULCRvUg8yH4qfvL9DTLxXo1vdrEZcpLG3mRSr1Rh3/wDFedBKucZnoCqqOejBEuk+ZlnHKKBzJaLcNHIwUDfJrbf8STTB0A5JEJV1HZv970p6hI8rMxJJNN48buLY1J2bImJtoF1NeuX6zTlIv+kp2xWVFhthOTznFZTgKoNsnkZMh3RbtkyQCKM20WE+71rXZWOcFhReK29Ow2orsIrjUiQ/s/MM14ERBwRRhLYe1R3hw/SuK06y+ZDWPfOMVvjj9xW3yvVjFbPLOem1auCqbYF5VqbbqScitEK5XB2FTIkIxismEAhazT05xTdwJZvqPE1lACVhL88x7cigls/SlazjYIMbmn3hphY6ZrN7AoQvCtpHzHcNIfVj/KrfnSOU0CBKmnUEgnxGTgCZdX4+u7+WPnSRJ5MY6AowB+g5ap39pKxWwvhdKuYbuQTyIOqSkEOy/MjJHcGrm8LL+1i1GS3KYuLmSKKOUfhj5iW/UD9arL9oDT2u9LQY9drIYpB7ZyUPyPqX6VNJ251FcCeh0/vwZDfJlZcF3ZjsLlBGr5ZcEfhO+4+YrtD9k7xFXWdAfgbVHzJb88mlu3dDlng+hyy/AsOwrjXgCyZ7S7KgZHLs34hg5FWXwxqp0SWS6gma2liQyJMh5WRlPMCD2INPt7bcSZlX1wMJP4+07dhgstC1OO4vR/y0ThmwOoG9c1+JX7Sum3vF1/FYJaC6NwUVUbm5tyBvsOw3zVneHXjdZ+J2mxadqYig4j8vDRkBUvdt2QdObHVPmRtsBXjXoy6/o2mR2mm2aS2HMqLFaoCVIwQSFz2rpbqpPwKFyFc4+3cqyDx+KzGGbRpbxwcMdOcTYPxxt+tN2i8Vz8RRG4fSbvToCfQbrlDP8eUEkD50j6VpN7FMFuLcxxqdkAwPyp0t55FiCnYAYxR1JrmZzpjU0km3soxSpxDdSC3ZIhzc55XPMAQvfB/SjNzPhSWNVtx5xfFpqMkZ8yY7Ki9TXYuIveI3FDwWkMcMIjKuPSHByADtj26Vz9dWv2+/YP0JLMR9c0/6vc3F2k95dtuFJC9h7AfWkewDT3nkj/6p9bfyrnf8+lFUVGEYbDcZuHdESd7d5pBAhiLlm2AGDgE9s5Az2pp42Mmh8RXE81xNJBa3cCv/AAcxQll/6cbgBT1zsMHc5o54daRYarqzW93Gsq/Zn5EbpzZA3x8zSlxzpf2DVzMhkGji4IiRnZowVyC4B2yudvgKRyOGy7D8SlpsTDB6qfMh8exKvLKFwoflz3I6/wBc1XsOlvdaklrEvM8rqiD3ycCrJ8QVNroNlZTRD7ZG8hkYfyr6UPT8SchpE0C+S01/TLmUn+Bco7ADcorZJomEkYrEZ1YU5wD5qDuLrWPTdQvrZU9Qcxh/fBwT+lKqREzlfyp/8SLTk4hvyAOUzuQR7E5H9aUrCxFzfcmeX0MR9BTeF7xgyZq8X75UfMj3U7QqjNtiM7fSgOlTNbzEZwVOaP8AEStyySAcpIXb2GP9/nS/5Z5g6jtTacrJOa1yD7RluiHs5GTuuRUCzuMFZM/PFbLK58+1K98YIqHar5MpTcqelfATTvZDCXR4Va+yzrFGwW5ibzYN/vEfeT6jerw1HVxq9tBOm6OgIHse4rkrhy+l0zUY2RihVgysOoroXhfiCHUbZTkDzhkp/JKBuPkak6nHtcZBPQaVv6nAcR+odTNZtVRvtKjBGBIB3Hv9KHz2QZM4zR24YSW8+QPuEkH61AjmiMZgQEMigjP8p6f6fSvtxXqK+mMic9iLl1bvaEEqVDdKypeq21xOcqrMq9/aspheRZMSYFTQEixQhNjUyIqqkmvt7YyW4JKkCoKOxODtXB7uZhgcZqpNEi9tq0heaStkKBwdq9CPBrQgjfmbY7YE71sNsAfhXyPmA2FSYwT1H519zPqE1xQEHcbVMgtizqMbVsgQMwBovaQKTuMV8TOgTdY2ygADamS6RYOHbaGM/wAV5WuHA9scq/0Y/Woul2lmPMNy8o9B8vysff7Zz2rZfO0UwUDZFVB9BSbG2AlDFSqSYc8N/wDltZku5R/BtYXuGH/aDjH1Ipf8dL5IdQtpFtw0U1iHlhzjnBwzr9MsQe3XtR/hqZGs7u1hP/M3hjiUNthebJ3+LBR9aTP2jvMtdXshA5XyGMcbj/CoVf8A4n9an5Duzi/xPQ6MBNO1fF/9xT4WjghtJJLVjJE78yswwTt3+NF1iYhwBzHlYcp6NkGhvBEY/cUTFFUOzOkecYXJ2B/1pglCF1RI5EwMkuMfQf607zW0yc5Ayeqpupq0teWSFxzK2QwxsQ306HPtXVvgP4o2PF0z6Jr8McushD9lupB/6sDOVb/7gG4P4h8Rvyqx5HUr6T/N8e1ZDq8+m3UUtvI0U0bB0eNsMpByCCPj3rYvdcRyouTFt8zoniOaKLWbxPLVFEjcoA6DNKOt63badC0kjqigdScCkm+8S9R1QPdald28Tn79xLypzHfc+5+lM2jeHFt42+FN1rOgXbX+taTeyRXMauSlzGVDABSMBlBOMdR8cVreLgPRZF3NKz4k8T5b2SS303PL0MxG3096Vbe1e9nLys0srdWY5Jond8OSae7LIhQrnPMMYoVJxjoeiSiFr6Ke8Y4W3tj5rk/Jdh9TRlG7qL5G2fVBvGsItLVY+XYbkgfiI2/IZoMnCbaZaxXDZExAZ1x0+H0qJrviHb69pr3CQPDbRSlueXH8Q42O3bGPzpK1/wATtQ1eNg00vl9gMRr37DemceNviDy50XGovuWWnHEHBzveRywNdRQyCOGR8c5IPp23396+6Px63iXw8bBOGJNIk02Frkf8z5qugyH2IBGc5z3qibW7kveZ+ZUdpOVSF3x33NXZ4N3cen2muw45prqyOHbdmAzt+ufpQdTiVULkWRHP0rO+TMuIPSnx8wZrt6LuSZwxZX3GTkjAwB9ABS3ZyQw3ZklQlShA+Ge9GL+zlAluAjNbluQyY2Dcpx+YGaU7268gcpJ5x2A3+dcxKCKEd1WX0zvfiMPEk/7ysbe56sYwrH4qMH+goHw3ZtecR2kOMCRuUj57H+pqFacRsVWzYL5Jct05myadNF0dLXU7WeDzpZz64+RQFA3zuaL6ZxjbEjrMeocZAeqviJ3E0XnaleqRhWkbA+px/ags1iY7aN1HSra4s8PUg0y61WG5MYiI8yG6UISzMQAhBIJPtVfGIG2kjxuhz9K0j8T7JjGRiw8wFCPKfmXZX6V8L/iJ5XU74racxsyEegn8jUa9jKuW6Zpkcye3AhqPLIjp95dxTdoWvzacQQxCsAdu/sfmKQ9Luy5CNt7Zp94EFlqF1+79RTmt7geWso2aKT8LA/pQcoAU3HtMxZhsNGWZpuvHiKxKxSIjsMTj8QHfHwPvW+5lXTpYrmRS0YPlMF64PT9QKrzUNN1HgPVkkDiSHP8ACnUelx7EdvlTPccTw6xo03lqyXIUN5XU5Bzt79KnbBXt6MpO5Lbj2O4xX0/mqvqHIdwF6VlBIZSyYzgHdPbBrK0ooRPIx3GWXfWdpqmj+ZEFDAVXz2nLMy+xr5put3NvCYRIeQ9RU63ge8fKKWJ9qFiQ4bDHiFy5F1IBUczxawhMg1IS3UyZPSmKw4SuJrcyGJuUDJOOlR59OEBIx0oq5FJ4MA+B1HIgtYQSdq2pABnI3qX5XIOmM17jjVs5ONtq3ugNk828GBnGcd6IW+wxXiCJxERkhSc47VJhhPtXLuc21J8B9IBqbcfxJW2yGAYH6VHslRvvAnA2A96m2ycwEbZLZwhA6knpS7mmsR3Gu5dvz1GDgPT0jv11GePngtZFEUY/+rOc8iD4DdyewX4ikDx+vYNX1A2cIAmtZEAb/wBznUnHw9Rz9as3S7qCOIwwuGS1QojAbczbyyn5gEA+yj3qhdfvJtf45uFQeYl1OhYH8JU5z9FOKRP7mW/iXNInpYGLeeJ74cPk6ZbocgopVh7EE04cKaVPxHq5tYSinly0krcqIgBZmJ9gAT9KA6pYS6XfySJErwz+rlLcuWAOcHGB8u9FOHLiXTbmKcncuHfl6Fe4HwxtVC7XjuRWWmvwYtcQce6fayyxWUb3gXIErfw1bruB97HzxSVqPGWo3Z/hyLa75HkDBH1OTWjXtMk0jXbvTrj0tbzNEXPsDsfqMH60LjYE5Ow7VxR5lFkUfSIQ05Y9R1izl1h5rq0adPtC855mj5hzAHr0zXRH7Gvi/a+C3E/GPDfEWlSafLfrbahBHACI5ctyK0YbfldJEcHJ2BrnKFzkt3XerE8bPOtPFrhPXEkiS2EFrYPEpCtbxrHG4VhjYEOxB6bEURTdrJOuAG1jE79qzxel4p8UOIIbS2XT9Fgu5IIbZGP/ADDqxDSNjqObO3QVTvDlze3moNDEEV7mNrdTyAEF/Tt7Zz19s144w1F9a4nM0kXkhWkXmPctK7Fz8ct+lZw9cfuTiWzllZZxBcKSYm5lbB7HvVdECY6A8TyrP6uf3Hi418eTWYs7XT9NUi3tWaKTb7zKcc3+Ygmq31B25uTfPtTG8d3Jrc4fmWOMsZM9DuRj8zQ69SFZ2nKlmx6Rj9a1j9oqH1I9W36rj+0gWrG0eMYLY3I+Pen/AIM4lFrerI7ci4KOo7ggg1X3n+aW9QRB15d8fWugtA8GrngPSLJtRtWm4v1KBbkWJXmOmwOMxhx/7zg82D9wEdycdyAMKbzB4MrYmDIeoD4l4qbTtGfRLVUkhlcSzTlMM7DoB7CkHUIHkVXlwQdyq9Mf3p51/gq+s/NkuUZSM83MN8+3x+dJVxGYU8v1NnIC9c/L4fGg48fpVthNTqX1TFsn8fAkBYxaXGUGEbcY7Vb3h/eLq1jHbN5Juo3Hkl2ALnBwnTuMj54qoZtPumUHlcxjop2Ao3wvxJqHD12kkMzwAHcRAA9c9x71vNi9UCu4PTaj0Cb6MsvxKMz8KxAMSizCU7Y5tioJ+VVdGdxJjbuPgatP966XxrpFxZLqSwX0/MQt8Aq853PqHufcUga7wrq3DDKmpWUlvG+0c4w0Un/a42NLei+OwRxPQ49TjyqpU81FjVLb7NOwI9J6God7HzxK43AG9MNzbLe2aswyy+lqFRxehosZZNt+4ratMZMdsfgwKJTDIrZ2B7U26HO8kqCHJeQgoB15u1Kd9CbZsgZQ9DU3RdQaIgZIAOQfaisNwieJjjejOi7V4OJtBiS6RZC6DOf5uh+RzSXqXDdzpLtJaF5I13A/Ev8ArUjgjieNJAjjmTq6HvnqR/v2NPepW8bBZYm54nGVb3/81GUnG5xmenzoGQanH57iZpevrLZiOdMYOOfG3/g1le9T054LpprRhC7ffBXKt9KyjUTE/wBpuSa/iSLZyKsnwsltpNUEd0AUYbc1VtEcDFF9Fv3s7hWQlSD2r7Pj9XGVER0mX0sgYzrXTtCgubB4oQpjYdhVY8eaDHpF0vKo69BX3hPxLms7RYmbJ9688V8QRauqyEgv3rz+DDmxZaPUv5MqupMTLiHfIGM9q1RRnn3FTpXWY/CviRb7VbU+DJD88ib0IZQB1qQiYXFa7ePB3opa2wnXkVCZCdiPauE7ZxV3zTbIVOQMUe0//lwyhQJ3HKW7oD1A9ie/5e9RLe2aFuYAFlO3fenfgzw/utbsbrU7gva6VaDnnuWXr/hX3Y9PhkGgO4MOq7OTE7jvVE4a4WlS1Rku7mDlaU7AlyQoXboEDE/9wqsuANGluJZdSdDl8pCzfHqfr0qyuJuGNW8W+Kr7TdBtDcLp1rJcyoh9IVBjlB9zgKPfHxq79I8G+AdM8OdP4hv9ZvZ4JLdMQwFY/wCJjBhRAMlgdsUHHZBYDuVdU6YcaYSefgfJnOWuaeLy0W0u05DcnkjztgjuDjqKN6HwJqV7GkVrYy3LquMQrzHbvtVwcHcH6Dp+oXWucR6HZ/u/lMVva6iDL9kUZOAPxyHGT1x0rZxB4yNZSh7DRhwvwmiycpSNIrq+5QcsAdkiUbs52UdSSQDoOx6ieX00G2jx54r8Tjbx50y60nxAktrq3e1ujZ2zSwuMMreWFIYe/pB+tVNrHElnpUiwicXVyTgxW45uU9gT0z8Bmra4n0Li39o3izXdd0bTLgaKr8818sbFRGNkAOM45R8yNz1qwvBH9nXhDT7yDUOIIrieG2nH2opEzy8pyFRFA2522LDcDoRTybcajf38RHLqMjCsfFef/glYeC/htxH4n6zC/wC57y04XtZQ2raq8ZMdvCDlwW6cxAxgZIzvTh+1RokE3iPo/wBkic2FzILlXtk5wYlRDyqQvqKDmGP8Vdqan4nWXB/h/rNvpGjWumabYW0ywxzgQ28S4ccnKB1Jx6N2+O9cQ6dpWra+sXEWvXMiOsKw2EUbGOK0iOeWKPIx6juT196+V7O4Se5fIayGc98aaTcRa/LJcQrBNcqLp4ehiL5blIxsRkUtSyRQNgSKWH8u+KtHx+udA1jjG41HS9TgupriKP7TZWgLNHOqcr+oDlxlR0PeqnjtbyaXy7Sxy5PKowXbNW8ZtBc89lFZDt+Y8yz295p8E/qS5ljRpInXHOMEc6nuDj6daTtWxcSyCNTLudl6d96Y9fln1LVlgeQAQRR2gPRcIoUnp0yCa2NpiRARxRlwzCOLI3lY7Z+WfypdW2y46HJw3Uj+FscWh6xHxFqFtFe/YJV+w2Uq5ikueqs6/iRNmI7nlBrtTwX8UrGK4urrXdNi1Ge+Jlur+eXFxMxzk5+PtXHEjR2jRxR4aKDKoQNmOfU31P6YpksOLJrKPzGl5FXckdvl8aKQTzJBYAkDqdm+MXB/DHGMWmW3Csc95rmohvKshHhGI3kLEfdiiByz9WLKq7nNUjr/AOzfd6Y7Ge1ujcH78ssfJzH4L2Hso2FafCjxo1DgbXzqcMwN09utsYyAQkQJYRjb3PM3uT8BXWvBX7R9jxrbfZ9c02G5iYbsR3371pQasi4Pg8XOGNY8ILjT3kdRIGb7wbfP6UjajwRfw3LxLG0hwSuB+lfp7o/APCHH97PZWSW9zrUsbzw6a12kSxRr1lmYeoAE/dG9ct8d+Gupatpl5qmiWMWraSZ5oI9VYCCxlKE85tYc886j/wBx8LkbA13ffCic219RnIktncWUhzkFTj0kH9RtTrwZ4vT8MZs7+CLVdLl9M1jc4ZJF77HIFaeIOHDCJftEzTOM7fdUfJRsKrS9tfsszOvvmmBuA5g9wB4l933h/pXiDp19q/h7YaivkxmW70eUCQRjfeJwSf8AKw+R7VSlzKYbpWOQc8rAjFPvgxq7nV2hjuZbK7aFvIuIHKOj/Aj59KieJemzX91Lq86Kl+X5L8KoUNJviXA2y2CGx3370mwBJruW8OdiqhvPURL9MSYcZifr8D70ONtJYTD8UZ6NRiGRbmIodyvvX3ylMJRxlBtg9qwGqNvjD8whoGqvY3kE0Zz8D0I7irg0PV0urMyQsJIAMvGesfxHwqioYngX+H6grcw9xTZoOtPp9wrxsVU7ke3vSmoxeoLHcqaHUel7HFqe5ZN7OspHIp6757VledLaDVIlKMIyB068vw+XtWUgM6rw/BlB/wBOyM27CLU9SLC3K2DRC12cGh4zgUUsYzJsBk/Cn24nm0FkARv4etftcgAONqn3sHJIUydq9cJaVMiiZvSvxpl1TSUe1EiAE9SamNlC5KlhcRbH94rQA5xU0rygbV4EHK2V6CpKJzdaMT5i4WhU+wDJydqO6ZbM5DLsB+tDrCzkup44YYmmlc4VI1LMx+AHWjdnfW1oCJbm3hCnB8yZVwfqaA7cQ2NeY+eGXA1vxJrRl1EtHpdvgyLHs8rHJEantnBJPYAn2pl/aX8TLfQ+CJOHtFjjsFgCtIkIwsQzhFAx1yebPXbeh3CHiVwvosLr++dMj+yQkiGa8iR5pSCzbE9SVC/AVUV9xFw7xFxLY3nEmu2UWktcG8u8zrI0zKSUTlXJwz83yUD3pWnPFdx3AmP1TmyH6Oh95eXgc6eDXhgdb1CyN3r+ssLr7L0YLyZijYn7oVMOSf5sdap+48XVueJjfaREsqJfSzzWlsheBY3254RjZiebBPzoT4seOPBXEfm2EXE04s1JWd7Szl824GSxVclRHGWxzAnJAGNqU1/a94T8K9LKcGcKn95Moj/empFGlGcglI1HKmx2GTinFxO9LURfMqFszcs3fMuTxJ8ZouAeHG1TVbM3mqXAMWmafKCqyN/Ly9oUzuRu7A71y5pc3Evi1q91PqWo3N9BeSq9/OXIS6KnKQoBsIUPYbE/IVukudS/ae8SZNbuVbRuGoI1t7W1kl5mWFR/01OPUWOWZgO5rorgS64N4A1S1tZ4m1KaEALp+mQ+fISM4XA2A+ZpkD0RtHLHuIb/AFW3t9I6HzLj8BfEA+HvBi6BFw1HImTvFlTKxBB5hjftVQeOXENtaaJxbHw/Dc2vEbKqPbaZJyfZWL84LSdFIC55M5PtVvXnE/FnEkH2n90f8D8JIVWf7PIr6tdIzcvloUGI+bOML6uu+1coeK/FVrxZxv8AZOFbdbLRbSfltreBRuwdsvcHcGVmzgknCbk1tE3AEngRPJlCsdq0Wi9bcV8Y+MXk2HFWpwaXpekMYbm5nJDXEo5usQOHkwRvjHckmnPizgfTtX1CPWtZ1XVn4dgtxBHFrEiW9sJS2EeONQOUY2wR1PWinhXwvp8N7fagunxiXz38qRsvyrnsT367/CiXjbor8R8HzwS3AtLZT59xcupYRIgJ5sDc742HUkV9utruhCbKXaBZlQ3/AAr4a8Os7s1mTknlWYzEn5Amlt+K+GYb0nSdBuLxIFaR3jIj5FAOXA6DHXegHClnw7fa5HZa5PNbBgWjnZ+W3mxk45gMr06H5VH8Q+L9LsLaWx0mCNdNKn+HCOQSICcFu5JPuelNUvA5JgFTJzYCgRReQK38DyrhG9UV0UPqU5wQOx9/Y16sbWd7i51CSVn+zr5aM3/uPkDHyXmP5UuaBxdHaw/ZdQhU2hYskiLvCT1A91/2Kav35YTW1vpcdxapcKHudpl5bhnwFAboCFUDBo+wqamcmdHxX5kci3wFmZkHYqM8o98UUXhS9ub+5tbWF7q3t3TFzjlickFlJY7AEdvetfEWhJotzcDyrmaIQiaA3EfltJzDYEdPS2R13xQrTNS1FdHksnS6b1GSFlYrCpbIbmUjB9xWixq1ksKCfdGmBW0qZ4Z0aGaJyjq4wysCcg/GmPR+Pr1OeCxme3gUHzrlM5xjdVONtu9IGp3U2q6wYrm6t7Wa4bmdnblj5j2JxtnqSdhk9K+3U0+mahPpGoRtam1Yo0cDBlVh0Jx94bg/HNaLlhQmQoU2Zb2ga7Y32pQLbxXVnMIT9uc3XPz8xb0xkYIDKfVknNdN8X+J+n614V6bYWVlHajSYfKV7dsryBSCpT8IwAcj41wjw/rLWNxIxf8AiOxJb41ZPCvG5SVrUMXll6DPU/2o+MBQINmsxa4+uv8AmmnjYOsnqBHRqrHV4zMxZQFDHoexq0uPNIura8F28cSWsz/9NNlBJOSPj71W2rG2lmfHLbopIxI3rJ+XatM9DmcC2eIR4Nlj0zXrC7t4pvJhZfN5tyevORgdOuKsPxMNvPr8zRsDYXlunMw6EMoBb5ggH6VX2hX6wXkEpcREhULEfqdu2Kdr24s9d0oyBZUEXNF/FTlyhBKkD2O596Sxt+5yO5QYVi4PRuU/dRzadcMSuJEYq6/EHBH51NguUnQMD6T1BqVxHCwuZHcepwrn6qN/zpa81rSY/wAp612r4lMZNlHwYaMbW8ysCTGehH9KK6bdxuhhkjDMh2YbMPrQO3vAy4yCP5T/AGqTIWtnSZQeRtiTWCL4MYVq9w6j5oOozWY8xCyouxKjJWsoLoervaOHD8rY7jORWVPyY7bkXL+HOAgpqlj8qYGKLaLdi0nVygcDsaCAnl3qXZyN5i+2aK67gRPP4n2MGEfDrskdsqoeROyijGmazJc2/ITnNLCWnm2yk7Cn7gjg+TUrUui5HwqZlOPGm5pWwjJlyECQzEPL2Fe47ZpB0wKYbrhqXTWPnRnl98VFS2C7jIFBTKri1hnxFTzBd1A0On3LKzKVjLBlOCCPjSSdKE1ys0iDyxIvM5G256fEmrI1VEg0DU5m2CQYH/czqo/qaQUkF1HO0rlba0jlu3HZVRSSenUnC/Wstuc8SpogmPE7NKE1RyLm9mKeYzSyMARnnZmPWt9xxRa6bpSwRQY1J1Ilnd8hc52jTAC7HHMcn2xULU7p/M8pFD3OOblH4PcmhOlcPahxHqYstKh+230hwZG/6UXxJ7n5VdVdw5nlMuUYTSdzbLcxW9tzyZZ3+5EPvOfepPDnhnqvGF9HM1nNcpzZKRjCIPbmO1dC+FP7JV7C0d5f6dd61dthmlljKQr8s4yPnXRWm+FNzo1qqyw29qqjAjQjb8q4clcJFNu+jl/tKT4D8Mb2O1ihu51sbYAL9mssrt7M/wB4/TFdH+FvhzomlupSJUGM4XbPxPc/Wls6aLOTlGMj2qwfDS2kv9VjiweRRlvlSpFnmHZvbYkvxkbV7bhjTtK4b4el1a51K6MRlWRoorRVQkvIy74OcYyM7iqn4d/Zlh0qYXmq4vLk+oxRpyQJ12VB2GcD4V17eXWm6VaBryaOIAbJnc1XfE3iFZKrpZxg+zUVkodxTHlJ42/zKyvtEt9HjESxLEgGAqjGKqLx31+PSuBbu2RA8mpH7INs4QYeQ9PYKP8ANVna/rU+qTHPc7AVy143cQXFxxGzWzG4gsswRgbpkZMjHboWB+iihVZqVNOoB9RuhzKOuLlreO8iMXn2zAiZGGMb7MD+Fs9P6Uha3YXLSoyEy28jel8d/j7EU8Xt1Lqt28TFVgRiQkS8qc2Tvjufid60mJLXzIpE8yB/vJ0+RB7Ee9UlOwxXJi/qF+0SbrTEt7PkZS5b7qKMlj70Lk4am8mWVl8pI4y7A7nrj9SaermwFvKsiP5sb5Cyd/iCOxHtUaW0a5lePpGyrse4U5/tR1yGTsumUgmQOEuJbi9to9GvpZZo4QXs+cGQp/NGB3GMkD3HxrzxH4iJbXs1tY2zyxQsUWaeTDEjOWCjZTn8qja3osum3FwnKIp4CrsYmzykjOMjuMjpUaw4VW4sr2aTy8hAVkaQBY9ySfcsQCMfGikL2ZJ95HtjDwjrGl6naXcPkLcX1wuWjnbEyEZPNE3f4jv3FE5IGnieYpGZHblE7DADAYCk9OnftVaNprG9UQlo+UcyMuxGOh+dN+i8RjWbGS1u+aO+twXYp0nXoWx05h39+vvWCtGxNgmqYSVEJRcGEgxyBsEHqDTBwlrIh1yJZwFIJQP2OexpbinaeUM3OGVeYOVJ9Iz97HYe/ai+izW6agi3Fot0rNhZOY4Unt6evuM0QNAES6dfsxqPDBYjzDHLuCOgx/pVF8VRiG7k54w6OMOMb53GRV92WnyTcP3N1p1zcfaIoi4SLMiuBn0mM9v12x2qr+JoLfW3+0MsatjdIVwAe4xjbeuk33NSvbe6MflROyyYJ3913xVvjUJeJdDsTzCS4h/hyDv93CsdumAPyqqIY4rO9kN3AVh3A29S9cfOrb4HvtOuOFEmhsxJe297ygIPU4IJwwwdiPypXJ7XVqjeE2jJfcVOMNHSDUreNGEkb20Y513BIBBI+opL1XSuXcDHwqyuM57eSDTZrRAlpySRR5HqADk8p26jmxSlqC+evOPxjP170EMQ1z0C41fCB9hEyNzA/Iw6dM00XGpQTcO2SZH2gMyMB15Qcg/rQS+tPMJIqNErosoboq7fnR2AajEkdsNj5h2yuTD25k+HUVlRrRw6KVwCR0boayhkRtXIHEuoNlAvKOvUDepdvlSCK+vp0sBGVwOxqbFp8gi8zkPJ70ruFTgRviFbW+llgWMDYVbfhJxWumuIpyAnxqpNLkRCAwGKbeGEja7Uc3Lk1N1KB0KkStpmIYEHudMzx6ZxDYk5Qg7mlHWtDsYxy24UkbbUO0bnReSNz5eN8UatNPmumkORHGn3pH3APYY7k+w+uBvUBMbb9qniV2AxqS0ROM9Enl0KGztYGuZ7m5BMUZB2VSRzH8IyQeY7bVzH4teKFnpa3HDGhmJ2ZgNQu7Vi/mspysCMeqqdy2BkjOMAVY3jd4w3PEMt9wjwAWkiLNFqetIRhj3iRwPV7EjbYAbDNVZ4e+GGiaVxNbXHFT3dxp4im82OwX+KHEbFAuR3cKCewJNep0un2Ddk/tPMazXuy+liP5MWdO4M1nVjbQ3ULWjToJ/sqKeZVOeVpSdyzdQp7Y6Zr9Cv2OvDvhrQdP1nU7nTYEv7Qw2kPmoD5Q8sM5GR1LHrVCrpSLaXGuX8I0zz+aaQ45RG2PwnH4R6R7np71af7O/HC6zYa4iMw5JYSOf7zLyFVJ+JCjNOEluakkCiRfJnRPFfGkMIdLZM42B7VVeqa/c3UrF3IB7Cp2raisjFAcnvig1pod/xDqkFhp0DXF1O3KiL/U+wFLtHMSgDmfYHE7Bd2YnAA3JNWxwNwzrPDtpNezwizedcRJKP4gHuR2+tRfM4V8BdHuL/AFJzrvEcERkkS2CkQbE4BPpTp1O59q5R8Tf2u+MvE25ltbO5HCGgKC8i2DE3MkYz96YjIztsvL1rqIX7gsmYdKOJenip4h6NwTK51/XoLa5bJEEkheZvlGMt+lc48V/tdaTavOmlaZeagyZHm3JECZ+W7H8hVH65cxa3ri+Zc/ZDKGd5p3JKgZ3d23JPuTSJrdxyXbQWPlTuTyhlPmliSRyjG2c04mBPPMQyanIPp4nR/BHjpxbxy+sXpgsrLS7KIIghiYtJcSZEaB2J6ANIduifGq74r4hn4gkt7OFEigtAVAi2Uv0Zye7HHWm2Xhq64N4YsOFYWH2uGNpL6aIY5rmQAzHp+EcsY+Cn3pYutKGmpyBCvL2xSZyJuJWes02iyeivq/kxaOmR2qelRnG5FQbrSp72QJbwvLIeiRqSf0pitoFv9UtbSWdbSOeVYjOylgmdskCjPDGovZ6L5ttdzo0mZvs8KjKSJu/MCAcBNzynbOOtEUnuZ1L48XsHcTdQubTSdB0fTnSaS5aaWS8tgoMMsXNhSdubzAeYDHw3obxTYWvDziWO7guLeZWe3zIpkxlgVkQbqRimHV4zF9st2kitLO1uZJob9yOW3WQHnjDEerPUfOq24jgtOIJ5bnQ4JHtNNhBubhzh5QXx5hHXvj60yg3meafKcRPPfia7ws+oXcPMGDJycy4IOy4waHSJHZ6S7Ko5nbPN8ydq3T3qG8M0dsbSLmVViLZwMY64oXrF0I4GgB2Egdf+0701XMDjYekf5n0XqW6QXDpzDmIYgdAcjNbbW3fTtYg1REEsMLeY+Puuh2ZfqCa8pas8UEGPwhmzUR7g6bdLC4aaxL8xizsfcA+/Wuj7T5+vd1LJvIJNEv0urV2iZD5kcsWxxy55um+VIOOlaP3lFqzjm0cKH/FE5QsMnpgDb+lNFmdN1vRLJkYraNZLA1yFyYXRceoY67dO/Nt0ofc3ekaVHySXiW6gY5Y/4s7D2Cr0+RIFYrmJ2ajPwL4iy8KytDNp9zq8CjHKs3l3UQ32D4w+OwIB+NEOOPFLhfiDSVh02J4tQ5jztqsSLNGN/SCo9Xfcmq1sOJrjWdSXSeGuGBd3s4YRz6o2TsDkrGCFHyJNI+uWnEFxeSxajcvFKpKtCsQjCnOMYAotGC3Rh10Pc4LOjcp6FhuKKeGvGP8AwhxPb3UViLxt08tnB3OQGAORzDO1U3e6NLHI+eYsDvmp/DekSXVyqSTPCpOAVznNfFQR3Pg5B6nTXibwrLpWjRTSabc6et9N9ttY3QcigjEseR3B5SPcVXdvGJLd1b7w9QoNofiNxTw3bnTri+uL/TAzQSabes0sLYzkAH7p3yCuCKKNejmSYK0at1Ruoz2NIujDuen0WVWX8SFeQBTzY2P+zWm7sIzYF1BLlsN7Yxt+tT7hPMyvXPQ/GtMOXjZGHpx0rgJq4dwpJHzBenhecxMcZ3BNZXq4t3+0vhQrew6GsohF8xRWoVU6GhlIGGyR8aaNHtn1GxeBFBTqc9qX47Un0kfWiun/AGiyBaNioIwR71IzDcvt7lbTna3uHE1zWyQTcqHO+CRRzh2M/vCBcnDMBUBrdrsgonqA6KKdvC3SbZtaGoarGXsrP1CA7edINwp/wjqfy70J2AT3GMY0JyewS9fDTgJn0/8Ae2skwWXLzRQ/jlHQH5f1qqfGnj2bjriC+4H4dmjsbazHka7qln6fIB3+wwEfjIOZX7Z5R3ot45ftLwcJ8M3+oaURHqKoljp6uNvtkgOHAx0iTmf58uetcw8O8eQcN6BDZ2RJf1SSSucvJIxyzse7Ekkmj6TAAu4CStfqHOUrkNH4+PtLWutB0DgPh0x28EcaxpyRRJ3Pt/qari21O2NwktyjCHzka6eNeYpArhmCjHduRaWda43uNWkBlmLDOAM7CvvC2uaVLfCPWJr2GyldQ72MqRPgEnBLqVID8hIPYGqnp7RZkQ5LNDqfeKte1W9nvQ93My3EhkuLdnLJI+/qI6d8bU2/s98YTaVxNfwxCYwSw+VNOyfwmnUlsK3uAx/Oqu1DUxcpPHazLPMCRzoMc3X1AfHtVrcL2cOhcGcKSwL9/aRR+LzVbm7dQwBrjikqbxe7LfxOhU4lhihlubiURwxqXkdt8AdTt/QU5cEceJHpV3caXOIA6ctzcx+maEermjYnaLl5eYjPMRt8KoHhWbVfEHX4dD0q1gEKDzbvUNRDi2QKSGOFwXAbHoBy522FM3iHr2g6HepD++ZdT0nh3ll1C5eNIbQSBiRDBbxgJzsxAGeZsjGTvSYU9HuPO4PA6kvxQ8QdM17hK8CR3CC1lkjuXRFFmGwQpedxghs82F5m5gABvXL8es3+iu1xZfcOctf26ss/XfyWGy5OQX3z2FWPxRx6OJ5l1S+tzbhQTZaa5HJZId88o9Jlb7zN7kgYFVRr2s/b7lserJ7d6cxY6FESflyeREu6seWd5ZMzOxyXlPMe/wDrVu/s3+G8nEer6nxfeWvPovDSiRcr6ZbxhmNem/L98/HlHeq/lij5SZCNgSQO1d0cK+HyeG3gjwZw9zot7qBbWNSVepldVkCHboqtEMe61vUsUxkDszX6fjXLqF3dCV5a8PG1jn1C/Xnnl9bZHTO4HzJ3P5UscQQW+vXENnHDDFcRhkTkXlaQ5Oc56nO2KvPXYNI0ng+TWNRlt7CCO4kixqYOJwqNytDGBzvlsk42GNzgVyVxX40cOabeSHh7TLnXb+A5W7k6RMuQrcw2UgdkH+Y1JxYGM9bqf1PGCNvYP+8T7q3DojkmjuIxAqZ5xP6SQCR6VIyxyOgFLGo8WW+hWdybazueILlrry4ILideVZQD6yiZIUjAK59WN6C8RXXEHHfJNqk0VpJO45YLZSGwc7ySElm69CTU5tNThDSJdNswCJlRzI3USkEs42zsjBfhzDvVBEC8dyFqsubOQzir6+ZW2r6nqvEt2bjVpi0SsQsEKhIohk7Ko2A3617t47awMnNzLDJGUYod8HcfMZwcGil1b+RlRH6MYB7YpTv7lrK4aGXeHqjfy02pvqJZMS40Ibz5nrV7r7QSyKY1dQAvxUAf2oNdzC5iSTqyHB+VTtZvYpxFJbrhI8c/xYj1H86E3atCS4+43UUaTVNKRDltK93dqFbkVQOb5VNv1gkhKMB8CRsD86WdPvnBYIfV3o7a6mCfKuBjP83Q0MqY/jyqykHzI0s0qWSNE7KHUEgHY4z2706cI38etaP50djaxSWzCC4ijUgk4JV85z6sEfAihH7rS40pSmAIWZck4GOo/rXjgtPI1ma1QkmcB4wveSMl1/o35192CItkQoQ0uTg61sbHUNP1iAu3lSq/K27Kd8r09s4NF/E7gLULqS516KBZNNuWMkcke+FOcZwNj1zQ7SdCPmDVbC7VrBGWKbTZBh/Xkhl23DZGG7ZNWzp9xqNpwpc2H7h1HUba5k2Zo/KiiJyC/Ow26b4+Yrivt7g2XcJydqWhxNN/FTG+CVHaocdsmm36SJEpRWyApyCPnVyeMXCVjwlrEkNtNp4iXYONTW4LnG7AYXAz2IqmLm8EMzMkqMT1AYEH6V0mzazIoCjLGn0NdZs59VsFRuaNZJowPUGUY5wPio3H+GlVsSoynrTHwHxRqmtGO0jjjme1DOohjAdlPUMR94e2feonEekDTNSkZEZLeUlkVhjkP4kPxB/tQ35NyrpMlL6cD2xJTlO5HSs5DFNzDcHfFYfTKcbA71ujQ3CMUXITcn2oXiUebFTZfaY0tulwgz227VlSNOv3snIYcyHqp7Gspfc68VG/TxP7rqXnBNzqFKjfvRlLUNCOU52oPpnkmbEzYQDO1FrW7iTmA6dqnZFN8RjCwq2m+0lltcrHsT3pb4l8SbnTbu6sbRsPCPJ/zdWP54H0o8t4EmU4z6htVD3N/JqfEkpLBHluiSzdFJY9a0mEPywhU1PpH2mD/FfjWTiHiOws2YmPTo3kY/zSyEEt8+VUFL6ayyL96gGtztccSahMdud8j5Vq84gDJr0CIFUATwmXK2R2duyYy/vZ5PxYFabvXZru3lWWEQFjzEofSzDI5sdie+NqAm6IGA2K1vfPCP4g5lPfsaLUV3GWZ4czaRcCSbU7c3PKxXlExiI9J2BHTPuflV46Zb6JbcRWuhT6ldfuCzPnW08lvyS3SuvNGijpjLMpcfy5rlngyOX94rcYlmtXlWE20Tcr3HdlB7ADqfiO5qyde1nzm03Wk82BY82L2zOzrZsmTEE5hkIUJI/xIwpPKpugZRwZAFsidMeKeo33DmhRw8GWVzrnEt432aOTT0zBp0G4Cxr17kBvgWJNc03XEsrQ29vf3Ef2XTZWK26OGWa56PM5Gzcu6r26kUna/wAd3V3fS3EV3KshBtLd43K8seMORj3BI/zGl6S6jVBy4AUYA9q+w4Si89zmfUB29vUeNV44a6PIpODUG31QSPu+CaRmviXJzW+HUinfengtCTme5Z2iXFvPrNhHLGZoDMrTRqd2jU8zgfMAj61eeoftIvpGu28kxgu7uS2ZY7W5OYnnkkLc0h/BEh3JHURqBsa5V0DVpTftIH5eROUH4sQP6ZrbC/n3El7MwaaUl2GclFBwoO2wx2+VK5VBa28SnpCxTanFnv7S1tb4t1fxK4hu5OJNcmvbGRjH5ykoboAtjt/DhJ6IANsZFFNQt9M0vRLbSY1jhiaQSmGJAMqpJy22++ADVaWmogqMMMDr8K8vxDJPPJPIxZnwBnso2ApNgXNz0eIYsK7V5vsx1T7O05d2AUKT/r+maWNW1B55XdjnJJAPbJLEfmf0FDp9cLIQDv8A7z+maE3eqNKh39RyT9a2qkCDzZEfICPE1anf3WSFIC+wpZv5mupcso5kU8wPQr3qRe38qMWDcw70LuL1bhvWPLPv2NNoOJGzvd8zzc26RWrrEpxIM5NDoNQD23lzLnl2JoydSRtM+xtHzSA5SQY2pdkA85mUhT+JTRR95OY7WBWe9JKtfMgPKj9CfbNOc2lpewgRlWYDakSCblvUYgAE42o7Z3s8Lgxsdu1fMD4hNO6gFWEOwWk9rBySAuFOeVjsaK6deR8NcRadqgMVzJaTJO0MW6nBJK5xjOKjWmtrcRiK8UIpGOepltaR3Om3SpCJuVQROuAwTm3IB2yNvj9KED8xrMoobOQZ71Lxd4gtXkj0cjRLckhPIHNKEycKXPtnG1LGscT6zr6+dqeq3moSZwftVw8hHyBPSiN+Y57pw8Dqq+mP0j7o2BOO9RbjRwyF0Ur3wa7Y+Jg4LujcWZlDfhAPfArT+7DMhxsT0NF5dOLM2PSo96IaRYDzER8MjEAiibqiwwljRgDR5J7Nm8t5InB5TyMQfltTvok+srHIZZnFrIPXHOS3P7EA9D8anadoNvYu8nlc0xY+th27YqexGCD0oTvZ4lLT6XaAWMipJzYyc/GiuhqPtTxufS4xvQkpyHepNvccmCAS42wOnzoDC4+rV34jZeaDnR4r9I8qG8uTHwOAayjHA3EMKxSWd8B5EvrUt0z8fy/SsqeczYyVYXLK4VzqHRgL/wAxqgkEqjlyDRKNpIgMqaFW0iBhy9qKpeA4zuR0FZa/EQTaRyZJaXkiMjEKqjmJY4AA71Rt+kSaxdPA4lhaYskgGAyk5BqwPETXWh05bOM8rXGS+NvQD/c/0quAkk0bFQSUGSB7f+KYwg1Zg8hAIAiDqoI1SU4+9v8Alsf6VobOOlFtfsXjvHk5fuNznb8J6/kf61pNqGQHrVJW4ueayJTEQTIc9K0PHKx5Y8uTsEAzn6VPntyh2Fa4C8UySKzIynIZTgj45o13EypBh3RbhrOSyIURLHHhVHZicsfnnH5fCmC81+W4hv7MW6XcV3EUEJ2JbOUZT/Mj4YfNgdiaUNOkjuLQDJzEeUj4djUfVr9bZBmQqWYIG9t9zSxW2jIekrxIH2n+OI2jIeHMZAHRs+r9a3M7OMkYqIiS293OsozLzFj8Qd8j4GpYdWGCN6aqK3cis/qryZiBntWyWLuKjyKQMVuCMMaE5eG8foFCjP0ailvqHIgVolxygcwzzdOvzoLozFbW5H4SRn8jUrLLGrEHkO2fj7Us4syvpztQGGWaOK0EiuSXbkXHt1Of0rX9qONtqHSTr5cIXIIDc2fcntXgzECh7Y4uShJ7XW+567ZqFPOUJrQ8p65rTPJzqMH1V0CZZ55nmJzkBgagzshAA/I1ubmA6gfOvSWoZSzjmJFFHESYk8QY8bxkmMlc9vetFxCokjfGQRhvnTJcRRQ2iwxoGkI5nfrv7D5UAu7Y4LKfpWgYF0oXIlxhFyMe4FFdFk84hsYyd6EMvmbYOaJ6O/2ZGyNwdq+PU5iPvvxGR4IbvAJxy7bVJtDPp6sEYTRHcxsOtQra0aa3V1O+cmilmxyxdAFA6npQCZWRb5MkLPBeKDnlyerbFT7H/Wokl9FAzIzMcHoRW4eXMzG3lj5/xKNwR8RWi708zgFwEbsw3BrEYs1Q7g28ukmYlVxUrQ742l4GEQlyCMMP1FR2h+ylgYxzdielfbORYpCWBJwcfOiCJm75jqNUi1iNHjGOReU4960yoeXON6m6Xw+thwpa3UYYSSHnlBOR6uhHt2GKjkFgRQt24mpRQFVAaQWHOK9xBufC9SMV6I5XIx1ryAykkdQa6ZnzDujXcESmK5HpHQ46fCsrVpOkXuuzqljbvcSkepV6D5ntWUo5S/c1RzF6u32rY/EsqEsjA9KIwguc5rVKsTwrKjDPda2xFURSOvehXuFxfaUNXK94vuGutaug+R5J8pQewH/7r3wla8+sQhhlWDBgfbBqJrcch1y9V2MjtKTzHqc7j9Ka+C9HYJJdshyfQmR27mi3SzTiK3iTwrJolimsxRq9mJ/IYDquRnB+e+D8Krb7RFA3KsgMLbxuTtj2NdG+JGmW9v4W3n2q5VZtTlMFrblSWd09XPnGAAeVfrXJshKhgCQD1FF07b1N+DJusTaVb5EMalfRwIeYfUGhEd6JmLBHK/A4qLJB/CifPOzMwZG6DHT88/pUtYZFXOF+lPgASMxJMZuCeD9T16UeQYYI7p1toDO3LzuXwCBjPKDsW6ZwKg8WcEazZK19cWbHT0Yxi4hIdFbJzzY3UnB2YCjGnXF4mn2zMjRRtCqL7Bckj5ZIzT7aSvo2gx6xrU7wafdkxIiFWuLxAG5gsZ6qDsXbYH3OKDvIa4QopSpSst2otYkJBkhGz/iT4fL4V4OtxbEopJ6lOgpk4g16y4istNiSyh097GN4VWBFAlUsWDMQAWfsSfbt0pWurG3Yn7qn36U0BFCaPE3reIW36GvsjIT8KDTRPb/9OYOvtmtf22QDHMCR2O1ambjJpxxBd4OMcpx77kVNinkFs8SlVWTAYt2wSfpQXhqb7TNdxnqYc4+RojzY5h+EjBoJ4MexW2Oh4nqSRVlZVcMo2DDvWSPhahlGQMBuQeteFueY8jDI9welZq4cNtFGTPMAG9RWkLseXoDvXtYJWO/TsB3resMbDqUPcV9QmiS3U8x2gkwznFbXdYweU5ArXJAR0ckVpOUyD+VfTt14mSz7+naobrzHapEi+rHTFSbHTmuGG21asCCouakOKxaXAC5J719uYPJhTA2BxmmK6t0sYBEuPMcZb4D/AM0LmUeRICM7VwHdzNOvpnaJ8s714oAgPLzGpbpNcpgyl19jQxF3HwohblgPasmHRieDCGmaX5QFxgsVOQPc1KvrhLeIKwK9TyV7+1iAJHys2BsFFRrmJZ28z1I3s9Du+42QEHs7kYSySxu5jzEvUntWjnUjPL+VfL2NyAFXywPqpqLaSMHMbA5G4+VbAivqEGmli8M8TpHYCxu42Ns6lVI3I/8AFZLyxuSvqX+tLWjMJJiOrIpKj4d8UxMjFFYdKCVompQTLuUBpEnHKeYb4qZoqwTapCtwvPATllPcYNR5FLAgjH96+WREcnOc+gdhX3YnWsNDnD+tX3B93JeRQmW0djE6k7ZHQE1lMvh5c29zd3Vpcokkc6CQK4yCy/7z9KypmU4w5DpZlfTjM2MHFkofEOwfdogij7ITgZz1rKyjmSliJrKD/ihxgYyu30q0bVFWNVVQFGAAB0rKysN1Dv4gb9pBRa8HcCiICPmt55jgdXLjJ/QVyrraLHql8qgKomfAHzNZWUzpfo/35k/Xd/2/xItofMicN6gqry57bmnXgbSbPU31gXUCzCDTpJow34XDoAfyY/nWVlOZOFNSTjALCbrPUbiz1l2icD7VJJbTqyhlkjw3pKkEEDlGPbAxSjr2pXVzf2wmneURQxxoHOQinOQPYbn86ysrKdzGXqT7fT7drW7lMfrjgZ1IJABz1x0oGm43rKyjp5i2QURPFxCjIcov5UJkhTziOXblY1lZRTAybwkf/wC1cdjA/wDSjkgwAfckGsrKXfuUtN9B/M0TgGAZHUjNa0jUJ0FZWVzxD1zJFuOSZANgal3Oy8wAz71lZX02v0maHY8mfhUByS5rKytCByeJsADSqDuDj+lN+jQpzKOUY2rKyhv1GdP9UEXMjSTzMxyxJ3odcE/Z5P8AfesrKKOoq3cj2xyzZ96LWw/ixDtmsrKyYbH1CF7K8cRKnl2ztSff31w8pBmfHtmsrK6kxqSRJ2lXEr255nZvVjc9qkRMUuHA2ABI/WsrK+8mZ7QXC+nsY9RtWX0ksM4Hud6ePLUQuABgNgVlZQ37Ebw/QfyJAlHWvtttaSY25mIPxGKyspfxKn/P+JsS4ktrcvE5jcNgMvUVlZWVsgXEQSOp/9k=",
    bio: "星の動きを読む魔女。紫の魔力で戦場の流れを読み、一撃を見舞う。"
  },
  {
    id: "c4", job: "holy_knight", name: "セリア", title: "聖騎士", rarity: "R", atk: 20,
    img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAETAScDASIAAhEBAxEB/8QAHQAAAQQDAQEAAAAAAAAAAAAABAMFBgcAAggBCf/EAEUQAAIBAwIDBgQEBAQFAgUFAAECAwAEEQUhBhIxBxMiQVFhFDJxgSNCkaEIUrHBFTNi0RYkQ3KC4fAJU5Ki8SVjc7LC/8QAGwEAAgMBAQEAAAAAAAAAAAAAAgQBAwUABgf/xAAuEQACAgICAQQCAAYBBQAAAAAAAQIRAyESMUEEEyJRMmEFFHGBobGRIyQz4fD/2gAMAwEAAhEDEQA/APnnCByiibcYfakYV8NL24y1PoqNro5Qim5B4iKcrgZUigo48ua6RJuqE1vyY2omGMHyrzkHNQ0dRqiYHSloxkV5y0tEmRQkhMEew2zVwdinD9pp91d8VasFWz0a3N1EXGVWVsiNyPXY8qnz36YqrdLhWSXmdDJHGAxRernOFQe7EgVaHaXdrw1whpnBomCXMx/xDWZl83I2QeygBQPYetLZW64ryO+nirc30ilu0Xi+5474sn1GdikWSIIidoo9/wB/M/Wo0Ye+U3Dg9ygPdqfIev1NK3KNPqd0hAwJCHCHIH+kf0+1FXH4qRQKMcxyceYFVpJKkBJubcn5GWJnRmcbO3l6e1Frcycu/TcY/rRJsCrZxvWyWLMoAHn1qLJ4jXIjF1ZhkHORRMVmyEMBlOu3lR0tskckcZBEmOYAjYj0o6zt+QcmM+n0oWwlEGNllVkXAdd1cU7aafikDKCGBwV/lIreCwIYZGEJ/SnlNKGhXkUkzKsMhCyn+UHo32/pUdliVDjacIT6/pN7d20Dy3ljH309tGPFJD5yx+pX8w9N/WheEhbyagFt9Tgt5X8Pc36ciyf6W/KR9wfSukuHtLh7P4dJEywQa1FK8tnckhoZXwOe2kI+aORG2b3FU/2wcNcPLriajpjDTNM1YNNZTOvgikU4ltpgB4WRjgN6FSfWlVk5vj4G5YuKUvJ1z/DhqtlpmiS2esWiwSwLh47k80lvGVOMnpLAwJw4zgEg9KYeD+1SLsE1/WuGtPuRecJSO9/pKBuZreCRj3kanz7mXPh81bNcu8DdsOs8CKNF1JTqekpkxwNKVmtgwOXtphkqCPLdD5ijONYnudGi4w0aS8uYLW4y0ptQsS8wwySFSRG5GAQfA4wVOdhV7TUqfkt95NX9HWXG3aqe0Dh+LUNOu4odZ0yX4u0AbHLKq4khJ80kTYfUDyo/hLtnHF9lbGO5IlZFubGTODzKPkPowGVI9q4x0TjB7OeOSB2W2nQMpPmmTj/6WyKd+BuIJrHiu50iOUwC6l+N09s4CSk+OMfVhmhli0WxzK0dcfxG8MWXap2WDX7W3M11Zwd5MsQzI8AOXA9XjOXX6MPzV87tZ02WwvJreYDnQ/MvyuCMqw9QQQR7GvoF2M8aNPc3WlXC8sVx/wAxBG42DEYkj/UNt7GuX/4gezk8J8X6lYRIBb2yC8stvnspGPh6f9JyR/2sPSmfSZKftsX9Xitc0UHKnUUFKu5xTxdwchOKbJk61qMxAF086RYe1FsgpBl3riAZxmkmWiWSkWXFcQIlTmvCMUpjrivCucVBwnjFYa2YevWvPbNSQeAZrKxetZUHEshUd2dt69gHjre2wY8YreIAE5p5K6ONLgY265oZAOaiJTzZpBT46GRzDIchdq8K4JNbx7jasI3qKINcb0tGN6TC5bpThpVp8dfQwHZWbxH0XzP6ZoGEleib9l+nRjiDT7i6UGCDN6xbplVJjz9B4v8AyWoHxzxnNrOu3d8x5muJDIoPkBsg+gwD9ql0Wp/D8Na/qcQ7ozgWVug6KHOWx9FCj7Cqf1CUy6k+N1UcgpKX5Wx5vjjUV5HPS41WPlPzMdz7mlpIBbzpcZBjOUX7U2w3QiUnPQE08WkqT2iQMMkgYPod/wDc0LdgJDjFBHcIOnN6UfBpOcKqeXXFeadDa2yi4znIUcp8t6kKazb20SMqKWUuD756VVQwkjOH+y4cUC7lYuJIECIF8jjOf1oCLhCa2aYXP4Rgfkm/09fFXQv8M8EepR6heSRq6NLgqRtjFAfxAdm0ujs2r2URFrL4JOToB5Z+lLKfzafQ48K9tSXZTUkNhpNvyzYllyVIHkP/AMbj9Kj/ABBfi5VlUgoBhcen/vy+1eaiXktyrE8ybZPt0pgkncfNnA2b296ZTEmPLcSXt5BDN8TL3ioI3XnOxQcox9sYqS8OX/8Axbpmo8P3kheS7zeWkjDJS6RSTj/+RAynHUhPSq9tZDBctyHB2kU/tRkF/NZXUVzbN3NxFIJI2XblYHKkfcVDja0dGVPY8LcXPDEosdSs4by1wJEim8SMrbiSJxuAR5qceoonUdbXWLCW2s9TWxhaMr8JcN3S43OOZByv/wCQBphuuIeRprS5i+J0yZzPDCzcphL5J7tvyHORjocbimSSBDed3DcMVfokicsn0xuCfoa5K+yHKtIs7se4og0e0l0ni/Tfi+GJLsyQXJUhoWACztBIB/IysVzgkDzNW52j6D2d8PaPDHpcOpcQTO7XUWv2d6sQ09WXMdvKMEHIwcsEPodqozjDjnSrPhzhHRNPs5ra90N5/iu+CMj97ylzjGQzEEsD0HKB0oOx4r1rQ75ryxcXTxxhjc7rIY98ByNnUZ6MCKGUE3yLIz4rj2decL8e8NazxLo/wi22i3U4Ec7z3p7yCdRnLsw5WXKP4h83e9dqeu3PQbXtD4VXiHQWj1HU9D749zylWliGRcWzgjO6ZI9diK597PuL7niiVeI5OENAubbRZkknt2tnV7lFJLghWAblB5sYHTaug7vijU4eNZdYnhh+M1OAX0jWg/5S8Vdk5B1BEOxB8x70m4+3JOPaNGM/dg0+mcT69ZRWk/4Dma0mQS28rdXjPTPuNwfcGo/OmKuDtn4LtOHri8fSJlutMSb4mONfmtUmPNyMP5DlWU9M86nBG9Qyb5rbhJTjaMHLFwlTAHGKScelEuuTSBGxoikHYCknTBohhikm9OtSCIla1Zd6VIIJrUihJQiy1pgelEMtJFdjXEM0C5rK2jwCRWVBxKoThfSth1NIRHIxS6j7U8gTxkzmkDlXog9PWhmBL1DJDYW8HStwcnpSUJ2xSqjeoOFANqcrYmzsJpQBmfMKk/y7Fv7D7mgF23pzigNzeWtrkALhCT0H5mJ/U/pQMOIfxKRpnB2j2mMPK7XMg+21VG8heTmzuQWJ+pq1O1m4U/ACLwp8MzID6EDH7Yqq41Jl5ceQFKZOxvIqlxXg2l5hbNgZJIXH1NPVox5cjqp/pSWmWIvJ4I+uZBtRj2r2l1KhGMMQR9KXZyXkMt5GYshPhDZAp0tY5LqVYUHM7sFA9SdqbYVA5WA67Gp32aacl5xVpKuvOpnaRh/pRSx/fFUydbGIK3Rf/wDCzZvBwzqBO5W9ZD9gKvDiDh+HiXQ7mwuAGjmQruM4NVD/AAzHHBF3JjHPfyn9lq359es9Lj7y7uYbaMdWlcKP3pR/kzTjuCOL+NOzS70TWLvQ5Yyt8Sz2TnpdKNzGP9eNx67iqvn0yRGYlSJFyCGH7GuwO2Djns64s05rObUu/wBQiPNDPZIWaNx0IYehrnnjDUY72NZ7iym/xIHDXqQ8sd2v8zL5P6kbGrouSFMkY+Cr7mMW00Uu4CthlPkDsaIlQ5IA3pfXIY720eSHYgYYelI6SzXltCZBiTHK3/cNqvT0KVuhr1JZYlhkVBKgYo6HzB3/AK5oi2ktjbuEJEhHgSXYofUH+lOWo6RLHZTMisU6qQOjDfH6VHVljLHvZYlHucGjW1oql8XslXG/E2ncT8M6bZ3ek2OmazaOzza7Ejd7ery4CyKNvIb+v1rTsk1GC81aC3kdGcExqH+Vxg5U+zLkfWoNqMrySd3bTGZW27sDmBPoK10u0v8AQtUV5reezaQZAkjaPJByCMio4fGiVN81Jo6Q7NdVPA3HcmmS4t7LUn5FWTpHMu3K33JX3Vwa6X7PLeG4ebhW9Tx2A+P0l3G5gJOYx68pyuPT6VywSnaPwKdRRHk1qw5Y72KEZlcKpMdxGOrMoBDL1ZR6rV39jfG8nG+kaZJKYk4m0r/Lu8+CX8p5j/JIAAfRvTNZ+brka+Cr4/8ABAe3/R5OEtYtbiCPniXvLNo3Hgnt3JkRG9t3X2IB6iqM1zSV065jMLNLZXMYntpG6sh2wf8AUpBU+496717auzq27Suz52SIWV8i86Mw/wAmQHOG2+Xm8/Rs1xZqelXUcEGjXMDR3UBuAIyN0lVi3KPZhzj0OFNP+jyqUK8oR9ZicZv6ZBJExQrpTpPFkZH2oGRCDWizKA3XrSLDHlRTjPlSDjeuBYiRWuMGlGG1aMKg41K5rUrSijP1rfu9iMUIQHy4JrKWKAE4rKgEe42IIoofLQKHxCjUBKU6iKNjv5UiU3pUHI+leAZrjhSMbbUqg+uaTSll3FdRITaoHmjBGxYZ+lH2amW4lkHWVgn2Y5b9h+9B2ZxcRZOPFinTSF5bgBlKiLOc+THb+xoH3RZBXQ29qtyLq/gx8oRlHtjaoBGeW7kz+XlNSzi5zdXFvIehMv7NUQusrO5A+aLI+1Jz7L57lZJOD0L67Ch/LOP61MuMeG2sdeLhPwbpeZD5cwG4qvuHJ57i+U2kiRyPjxv0BqwtS0/XLqzWO9vJJ+XxIAAcHyI/9KTk6kMQVwpIZrHTpbqCURoWaIczqBvjoTVk9kNkLa71TUpSP+Q0+QjPlnz/AGx96h2jRanpt7Fc91i4GQecYWUHIIO3UirB0XRFEJFlmR5Y3UMpx3sbDeGQH5XU9CdjtVM3aoZxraZMuzrVdX0Hs9jstOQpcvPIXblyVJAphuuAta4t1J5ta1SZYiejNzEjfy6CrP4BtWht7kTW8yiVu8VmiIX5QGUnyOV6GgeN7S5hsLx0DpCyNzMgwwHU4pdyaeh6MItLkN3C/C3AvCE6c/Lf3qdeY96wPuBsKN424/4J1rSLmwvUhWKPzEkYdG3wVwcg/SqUvOz7iDiHha51iZntLWLDxWEOQvd5wS2Opwc5NMV92ZT3Wn2htLQRGONnmuu/5hcczeHCY8BAOMDr12q5YvMpC8s1NxhAL1jhzS2lL2dy13buMiaMBZkG/wAy9HH6Gos2nLpV20YmjmQnIaP+4O4PsanXCPYfPqfGDW1rd3L2MDDLv4c7b5x71Ke3vs8i4XsNJnhj2dmiZwN84yP710Zq+KdgyxPjzaohHCUcOrXkWmzyJHBcXKKzPsBzAr/eq64y4b/w3VbmzePMsMjRkr6gkU9WFhdPcxpFO5Z5VRI2PhYk9DUquOC9Qt72WO4jaK4cliAObPXoattQd2LuLyRqgDsh0jT+FYxrF9FHPrUz9zp9vNgCLPWRvQ+/lUg7SbC81HvdP1ORbuSVOeGdMlUfcgqfIg7Vrp2m/AahAFtFu0hXM0F0vikbJyQfLFTzjBoNc0XT7uzh5IllVShXBU56H6UtJ3PkaGLHWJwo554L1l7g3FiLh7SS9i7nvY2KlJVPNG23o6j9TU17He1waVxJG2pPHZair8ks8y/8vc9QyzAfI2Nu8A3/ADDzqnLKZjqN+0XhAuXdGHkCxIpzvx3mpx6hEApuN5FHlKPm+x2P3NOSgpWmZEcko00fVPhXXLPiTSxyx/5kYMkUhDMVIIzkZDqR+YbGuS/4geG9Q4c4sa2dEtoLZXu7K9RPHcxkgrzN6xkBcVFOxftD1/gzinTNOttU7rSbte8iW5UyRREjfbYhc5DcpHrXSnaTZW3afobaDr1uuia4Qx0+95u8tnlwRhJPRhsUYA46ZNIY3/L5FfTNWX/cY3XaOKNfijnZL6FBFFcFueNekco+dR7b8w9jjyqPTxgGp3q3CWraDFr1hqtk9nPYvE0iuNg/NyjlPmGUkg+gqE3K/pXoItNaMCap2xslGDQ7DfpRcwwKFbrUi4i21JmlnFJEb1BJibGlDJsfU0nXjfLXE3R4TynNZWYB61lCQPKrlt6NUfh0gib0QE8OKeijkJgbVgGKUVete93n2rqOPEpZNqTVPWlk2qCGKKtGvcyWxgbxF2cTP7gDAz+5oaBO8cLnHv6UWhVryQHITAKqd8LjGPtQtbRbDSZHuK2EWlwTE7i4lQjzwcGoxJIGghmPRGw30PWpLx7AbaDu+U8shEqZG3TDConZMTbmN/lOVJ9PQ0jk7Ln+Wwrh2+XSpLuJ1DMPEjeo9P71K9Mu+INb0y61BYQ9nbkKS+TgHIG3p71XqTmK6CSrnkODyjBx6V0T2ZTLpVu0SWovLK8h5eRmC7Eee24paVRdyL8SlNcYvoj+ha/e8P3lvBqNnzpJGJc2hLFFPmVOQfpXS3ZhqFvdXkcNxDFKkiBkflBDqehqOcN8C2l5yrcQO1sowIweUAb4BI3PWproWl2un8SWENrEsMKKUWNegAPSk8jjLaRq4scoak7LiFhZQQottCkIIyQgwKE1fhvTda0e4tJ1I70YYKPmHpnyo1kAVOVhnHStkQsSD5VSmXOJWlzwle2SNb2M3w9t8oQAbDpjpTTZdlkaySCTulV98qviBzkY8hVr3cAO69aFEWGyRQNjMY3uhv4b4as9CtSkEShzuzkbtVd/xJxQ3fBtunJzOl3Gwb0yGH71ad3eGKNkQeE+ZG9U52vO2rXuj6YWJBke6lUfyqMLn/yb9qGL+SJywqDs5qjlSLVLUJ1SdWP1zXQeiW0az8NX10geNkRZiw+VuXIJqhND0xtT4nitoxzNLMVA+5rqW70cGGwMBAikhVXXGwwuM/1pnI0qRnenV2yu3ubbi7jfVLvTbVriFH5AY1wp5RjmJ6DJpq7UddtuDeBL4JJG1/eTGOIR/KJCCPD68oyxP0qy9T1HTuCLC7jktf8ADdGsoFllvjhIAzZ8HqX2z79K4l7Qu0O67ReOGuwHh0yLmjs7UjASPG7EfzN1P6eVRix85fpB+o9QsUK8sb9KjSK9CDo6H9qPuUEUpPLzKuGK+o6Gm+zRxqEJx0DZ/SjLq4aK7QlSRykMp8xvmtDyYi6L37MuFH13RdK1WCLvzp1+kcuB/wBGXIYEY6YJqyuBOLRxdw1f8MatOZLiylewkZj4gEOIpB7gY/SoL2W6/D2eW9uk9xzWd7BDID/8xHA26dVfB+xqC6Vxc2j8eS6iAUS6fM6D+cZDf/6/WkJQc2/8GtGaxqP77J7xLr11xpo9/wAOauDJxTpCN8NcfmvYYyWMbfzOgyyn8ykjrVH3oKsVIGOox0IO4NWX2uXTWnFtrq9jOYbiSOK5jljPiV12Dfsp+9Q7jSCKaWy1O3iWG21CEyiJBhY3DESIPYNkj2YVp4PikvDMv1Hyb+1/oico60Ky9aLlUjNDsuPemxAHZK0Kb9KIK9aTIyaggRKjO9aHGaWZc0mw26VAXg0GfWsrAPWsqCCTxJtS6rgVkSb4pbl36VookQ5B6V7yjHSlimxrRlNQ0CagV6teqvpWwTJqKOoIhXkj5vNzy/bzo6C1aa9g5Rlm8PT1oQr8q+Srj79asHsmudMsdYk1TVrB7+DTYjKsf5DITyx8/qASTgb5A8s0P4x5F8I85KKKx7W7pJ7nS9Ot1KfBWfNLGRuJWPiB264AP3qAxYD93nxMmcepxU61OGfiluIeIrwl7iefvecDbmdyWyMdAuKgN9EyXSY22H2rOlb+T8luT8rQnyC4mEiYYg4dT1+tdHdgNzHe6KLaVQ8lrIUGR+U7j+tc5CPvLrnQ8kwPjX19x/tVudkusHh/iNIJJQkV0oXmGw5h0/vS2RXEv9LKsmzr+x5VgVVAAx5Vpo9u11xVGydIlz+ppt0m976BcHm2pKbVrnQL742KJpk6Oq9ce1Z9SaN74xasui5tLuw7sTxNGWUMobzHrSsLF1I6HzqD23FWpcWrAdJu4ICQO8e7iaRh7AZH71OtIs7iKJpLxozIRgCMbY9apSdlk5KjySEv7Um8eF6Afaj3UZNISDwn0omqBjMZb1BCMlWcnoqDJNVXrem4/wAZ4gu8EiNljA3ARQQqr9/PzNWvqUAnBDO/dkYMatgH6+dQLjK7jniW1VOWAOqjbwsdz+gAY1EV9Ezm2tlC9jfDEtzx7MzoS1pE0hU+Tnwj9yf0ov8AiG431HRrGystMvZbGS0HfNJA3KxPQA+2BnFWP2G2lva6FxNxLdEKs87Rq58o0BJ/dv2qjO1VJuKJZZlX8bULlYoEPkGPKo/ertPJvwZ7uOHXbK64i4z1vjDglpdQmurxRdhZZZJG7sBB4Mr05ss3iqIaZCnxkL49Sf3q0U4Lvbaaa1FrO2mW9z8FNG0TFUTmCFieTAHM3NnOTzVXBs/hNSmghbvu6leJG/mwxAP3xWhjpaRkZE2027HzTdOE80kijZcID/WltX0lIQZZWCqiE8oPibr0Hp70ppWqSaJ3aRrDLIhLlpYw4LeuD/72pq4m4imuo5+cxgyNzSMiAFjvjP8AtQtNsstRjslHEHEba7p2nRLb29jFDbhUhtVKopOSTuSc53znrTJp19Jqt/GSMyMRzf8Ad0z9/wC9AW9ziNFJ+WML+1P2mQWmlNpl2iTmRgZJlmUBSwdvk9Vxjc+ea6MfolybabHbVbmW90+17zLy27vbEn0HT9tqBvLhrjSYrUvzR2khZAPIvs37qtEo7Pp80kjDvprhpUXzOQRzfSgLq2lsrZRKhjabDqrDB5BnBx7n+lNYlcEvpleR/Jv7Q1yJg0LKmOnSjJDt0oaTemaEmDYFalKVIrzG3Sho4HddqSINFyDrmkGXyrqIEAN6ytyuKyhOJhFHit2TFb8hXGcV6w+9a1JB9GvJ4NqS5N6XC7ZrOShashiKrynalEiyem9KrDvW6JjO1RRAo0OZCfJtx9DRmrajJp/DD2du3Im91cOOrPgrGPoqkn6ufSk7c9FZBIudgTgj6Gkrtfi9Nun5Pw5UJVQckKBgfsM/el8ik0oUNQaVtHvCjqNCuI3UPCyZZSNiMMSP0UD7VVV0rTXRDqVc74+xNWzpel3lto93LHAWsGs+eWVhjlycZHrltvaqt1abvNTkk6fi/pvilMz/ABh9Ev8AFMQsYDc38SjZ2bBNSxWjgUsQ0VymOVQPPOxFRfTHFtrEZc8inPKT6+n9am8NhNdQTTLGWjt+V3b+UFsCghSi2yIpvSOnezvWYNb4as7yILG/L3dxEv8A05QNx9D1H1qbRIrjBGa5m4F4wm4P1US8pmsZsJc24PzKOjL/AKl6j7g9a6H0jWbXULVJ7S4S4t5BlZF/oR5H1BpbLi4u10zVxZeUafaJXpfEuicOQSrdPHFdcwZDkZwOoo+Hts4VuJjG+oiAqcEuu37VQfGvBLXmpC6OqXZgkfxLGQCv3p80DhvRUMcEoe+jxju3IQH6lcE/rWZkTjI1sUI5I/8AsvF+1DhbmhSLWbe4kmbljjgJkdj/ANo3qQCVbhAy7g1FODND07Q7Umysbe0ZxuYowu3p64qStKEG2B9Kr7KJJJ6BL8DlbyFVh2jc0mg3LW5CyxMrJ9N0b/7XapzxBqKQwsXkKAbnlOM1z92h9oPx00mm6eTI+fGw3C/+tFFb0DKSUaY28PcT3rcJQ8MpH3NqjtJcSDPNKSchPpkZP6VAe1uY2tp+ESWtpUZsflOen9KszhOwuY9MFzaJG+oRqZJIZekiv+UnyPmD61WvaZeWs2mXdr8PPb3DuWdLhcEHPr59KtirmK5NYxmh7V9Ri4JlgiM6Wk16kcnNdSFS6jnH4ecHyOSPICoUtzEZJLqYpzsSx5VCquSScD70FPdxW9lHbRtzxq7S4IyS5GCenoMUzS97cXAj3OTtEv8AenYwoy55G6skSXKyRPcMcB+gPkPKmaWJr+6DuCIlPNynzA9aWkl7uVLfOQvzv5A+1OMlo9rBztG2JW5VkK4VsbnHrR0A9oK0S1APxFwj8mCF5E5iW9Mf++tO7JPcXgt5lkiS3Vo1icljEMliPrk09aRc2ek6XBJDbyXGpxxhY++RRFC++WHmxHUUNo0M9vPLO8XfoMSSGQdRzZwf+44FXxg1G/ITatRse5+KZbC0tYNPDJcC3WBpO7USDYjkUgZxvuepzUPvZ5bqeSWaRpZWOWdjkk1JdZ4gs5Z7iex0z4S6nZmaWSXnEfNnmEagAL9TkjyxUVcY86vxw4KqopzT5PuweQbUgwpd/wBqTZRmrigQda1KkUsFy29btFzEAUKRPYK0R5eYjb1od8Zpyvcxxon7U3Fd66So5qnQly7k1lKhcVlVgkzVM16U5felIxW0i5O9bHGwxHlyNq9C9KWCZ6V6I8b4ruJ1HqRZGaVWEYpWGLw70sqYo1AKhBYRsDsDtmtbWMrAsRGeQd2R9NqK7vm60rDbosjyMHPhPhUDxNjbOfKqZpx+SQcVbpgGo69c6PwnqWmSkNB3Pd27Y3VWlDEdPIg/rVWa/pk9jcSRToVlADEDzBGQf0IqzuPLa2On25W4RlaZEwAVOPFkkEZ8gaB4601prc3aQh4Ecgyj8uQAB9DisvLjVycf0XT5NJPwiA6SqXU8bOokU/Op/erUtNKuNP0KW5Ud5a3KcskHVuUZww+h8qq7QIYTxLbxSMVjl5lHKceLB5f3qxbLWr3h+B7C6iN3bjJgkH5evhYelBjxxlF8ujoScdobzqWEmV4SZkwF5dgw3yT/AFp70jjHUeGtWM9nMQmFDwP/AJcgx+Yf361H7jTrpNUihVO8uJgrxpEMhs7gD+lSbW+FxCttEjK1+ttz3AQ5HPuVHTY4yPtQqM5Jr6CTp2XLwpxppvGUQRG7m8UZe1lPiHuP5h7irS4S4b0zvEllhV3Pma5B4b0S81S5s7u2mezjhcP8Qpw2R1C+/wC1dF8P8cjTbdfi5d16yDofrjoaTy+nycecUP4M0W6kXyLS2tYh3ey+maZdd1610u3eWaVY0QEkscYqq+Iu3G30/TnlhEtyFGPwkJGfr0qjeJu0TV+PLgrcyG3tM7WyNsf+4+dZ/ty8qhp5Ix6dlgcd9qU3E88llpDEW5PKZx+b2X/emfTuEDY6XNO4LXDKceuTsB9ckUJwXo/IyzSLn+XPlU5vtc07SZrNb64SBVJmCHdnK7IAo3O5z9qmt8UD2uUhaGxn4R0ZCtvJqE7ECQqwBZ8dST5dBVOdpi6prUsqvpiwibKgGbmCnfyA61IeMu22S0uZUt9PMsaJmNZ35QAc+IgZzn0zVN8S9q+vaxMx544s7COCLYD033q+OOd3QvkzY0uNkT+EkFxLBFDI0yEq5YY5D70TbabcwJHKkRSKRiomAyGYdRzevtRFvfzXOkSLcLIl+bgv35YBZIyu6uvmQQMH3NZatKn4KSS907B3hViInI6Er60/xVbMvyPXDXDtuJpJr+c2UJVhFMYWkDN5gYHX/est9Jt59cKLM8tujlzNcIQXAPknudv3qyeza3/4n1Kzg13Rpr3RLYFe9ju5LeO2U5J5fygnrjGTXTlsn8OPCmmyWs1nG8dyAZzfXbSFmGcEZ8an/txQTyxhUaf9huGHkuVnIxVDNI0bM6nYOygMw9xW11O4shbrGqKW53cZ5pD5E/QbYFdldnPYT2AdrupzQcOcW3aXGSV05L1RIBv8odAzD6ZNO/aX/wDDrjfT3uOBOIHku0B//Ttb5Qsp9EnQAKfZlx7ir4eowaT1X2UyxZdtefo4AukwTtTfKKm/H/APEHZ7xBcaLxJpFzo2qQ7tbXSYJXyZT0ZT5MpINRCSA77VoaatCLVOmBFeYdKSdcdN6KePlOAKSkGKFoij2ztGuJQqrkmj9S0w6fyc2xxnFH8LXtnp7PNcDmcDwr702a7qh1G5aToCdhTCjCOPley2ko3exnvpO9ce1CkelKucnPnWuN6Te2VN2aADzrK32z0rKE4myjet2G/SlBHg17ImBW1xZYzxY8ituQ9KItkDoNqUaAE7UfA6jLeLw0v3G3Tat4IvLFG9yOXpvTCjotSG7usbivRkE56US8eDtWndZNC4gtAd/p6a5pxgkHjXG3nkdDW8enLdaXNbTKyxyIVdWGMevl5Gi0iGQSM46HzFGWdnc6hfrb28Mt1cXUgVYYwWd5DsAB6mlXiXLlXjYSZS3EPDE2iTxyEiWInMc6/K3+x9qmGlLcapaRTWlwt9AwAe2ujl4zg5Afrge/lUg7WLjR+z6WTQp5LfVtbXw32m255obZt8pLKNu8HmsfQ7Fh0qlYdTu7KOVbe7eKKUgyRKxCtjoD6jyrIc8eOb4bRz+L2XNJ/gXdtPqWvQaK9qe7iYZkumYA7qibgfWtbzjbhzS9KguILyTWL6eUvJJEO7nwM4DI2yD3BJ3qo5DHrF/PecghWRs90nRdug9qLMSKvKqj0AoXknLa0Fy7Jcvanc2VnHb2enwoI8hXncyYGScYGB50NL2scRuhxqAgGMYhhRcftmoncFYFx8z4ptkkZnzkk+goPdn9lbZJTx7e3HEGnnUr64u1jmHOJHJCA7HbpnepjLxLpel3ZVZPiJAThIRnoCcZ6VXyadeaxqq3rxorsoLyuuOd8bsR60+W3Dkdug72UyBSSBjABNLzhLK7kWY5uCpEov+1bU7pUttOYWUWBzGHd+nTm/2pFdamNzHMqM7qrgvO5JYttn12+tNSQRWgBACj6VubnYlV5VH5mqY4ox0WOcm7bN9UupL9U791IjXkRVGMD09TTK8C5wuFHooxRk0rSA8qZY/mNNtxfJZNgsHl8/QVZpFTdsMi0dpNz4U82IpRjDZ47pA7DzIpsg4nvpA0UcffRNsQV2/Wi4LuERn4q2lU5+aOUf0IoU0dp9Dhc8UaneRJBLdymFRhYw2FH26UOqNJ7+9JC+0lSCZJwfRkH9qs/g3jLscl02Ow17Q+JIdTOR8dpt4kgc7/8ASZdqGUlFaV/0LIx5vcivdP8Ai9Nv4bq1llt54m5kliYq6n2I3Brvjgb+I7jfhzgnRRqeqSnUGtkdmuVyxUglAwI2OMb9DXL9rZ9jeoX5DcacS6XBuMS6NFIfP8yv/arz0XT+E+LOA14Z0btI0jiWe3B/wptR/wCRvrfr+CefaSM+Qzlc7bbUnkcZNWv8DmFOF7/yEfxH9tUPbT2Vpb6xZQNr+h38U1pfpGFdoJOZJYz7Z5DjpsDXI11EMnAq8eKuxbjrh7hniC51jQ7q1gtYovEV5xIDKPEhUHKgDJPpg1SzRcyk7MPUHNa3pePt1ER9SrknQyzR9aH7nmO9Os1uM0MycuTTVCnQDLGEFCS5Io+c5zmhGBOQBQtEATrvvWuKXZM59axbdm8jVdHAx9ayiJLbk67VldR1E6ZwxryU7bV6q/rWOnNgVsuy1sMsF8PSi2tznIFL6Tahohtk+dH/AAfO2ACKchjbiixRdA1rBuNqLkgwCcUtFbiL61vIMjHWr1Ci2qQ0tHufStAm9GzxYGRSSx79M1S0VNCQXFH6b2pDsrSXUINNe71SV0jguucKsCDJkX1DMMDI8s0IFK5z1pG80P8A4jtn09YzJJOCEAG4YAnPtjBJPoDSuaLcGjotxknHspTiSzstQ1S5vNOuZI1nkaX4e+2dSxJI7wbNuepxUcuba5tncTRMvL1JG3tv0p81FDECRgj1G4I9aQt7prMExELzjDAjIP2rzEoqyt7ZroYMkJwCfEem9HC2u3uMuiwxA4BkOCR9OtDLfzNkd4Qv8q+EfoKWS87sdN6JdUTaCl0aORizyM+d8KMU5W+n29pHkIqZ9Bkmm221HnbBB+1OSxvNjBIFcq8BIXW5VCFUco9T1rYXKlWdySF3yaQMaW4yTzsaRks5b4Hmbu4h1FTbOFRqkMr5wXI6DG1KPqNuqM8rFeXyIx+lC9wscbR2iM8hGDKRgD9aEl0QOfx598fKgLN+9DbOtmt7rQuE5beQIW8z5ULb6fBI4Dv3jnqxO1KxQ20BMcNqruOryeI/f0pJ3lu5+RWUQr1ZV8OfT3qK+yA6SSODEcZ5+UfKnQfU0DNJc3LMisqH0jHMfuTW1vYyyS/iSc0Q6LHsDRr3CW6FFjBfoEUbD60LVhd9idlpdpYRQ3dxIL655siyePKYH/zDkfoKkfD/ABHfabqsNxpsMdg4f/K09Bb8w38PMvj/AENR2FZpCDy5HqRTtpvGVzwyx+CvBazHqbdA0n/1YJFVvGu3ssjPj1o7l7F/4a+z/j/QItU1/TLuXV7n8V4Hu5kUZyfCCFLfc1aMn8G3ZgYlguOF0ijc4S4E0ysP/MPsfqK+f2gdrfHOsODZM17NECVmvr1oyOv/AO4oqdaL/Et2z8P3sROi2Op20J5pbKRWkWdd/m/E5iPcVmyjNNrl/k0llxNWo/4PorwV2RX3ZvaR23D/ABLf3WmRDlTTdYf4lYxv4Uk2dR7HIqMdp3Y52Y9oPe23EWhWmm6+6lxeaE8dvfjr4uQYEo9mU59a5F4e/j4424b4lVNV0f8AwHTLpsLp+rmVraMnP+XMy95Gv15wPYVbPFnHXAX8S0R0q/vV4H7Q7JM2U98yqdxlQJlPLNC2xBU5APMPOgSyQladBJ48ip7OZO2zsku+yXij4Frn/E9IulM2naosRjW5jBwQVPySKfCyHcH2INVrNgDFdEahxDxVqq6j2U9o1oZNS3k02+nGZIrhVJidXG0kcijl5x1BGelUBdWpjyCuG8wfI16P0uV5Y1LtGTnxxg7j0xouBtmh1IGdqNmiyDmkVgJ8tqaptigjDatPLjHWnK4torCAEnLkUlFcLab9TTdf3bXLkk7UVxgv2Gmkge7ue9asobBLGspVybdg2yyAn3rxlwdutFLHSckdbrTLaHzh45HK24qS29oCCcU38DWUN1JiQ+LyBqc3WiG2h5gMDFa/p43BWaOLG3HkQy6i5XOKHK5U06XsY5yMUC8e21TJbKZLYE8eeuTWghIPSjDEcVYnZD2NX/aheSSGZdM0S3bluNQkXmy3Xu41/M+PsB18gVM04YYOeR0kDHHKb4xWyt9O0qTVtRtrOExpLO4RWlblRfUsfIAZJPoKce1LiHT+A9Cl4a4ZiE99qGkz3F/rsyETNCQVSOEf9JXIJI6lSuTuRVzdsc3Zn2e6EOFOGbW3vtdlY/F6k799PEqAsVMnQM2MFFGAOvWuVdS4hbi7jm/sWVBHIj2cbkb57sqo+gO36VhvP/Nq4pqP+xhxWBNN/IpuwvmuEeydPEgYxN/pHVT/AFFCJdAMY32wcZo57Weyv3mSHmni5gUIzvuD+lNvPHPNzHwMfmU+tZLutmYwjn5GB8jS3z9Dmh5EVfDzftW8RPyqCT9KAgcre6jtUBIy/pREXEDwk8yhl9BTYLNwCTu3vRFtYF2GQX+vSpthKwmHW5JZnKW5cN6npREd7ezsUTkVfXGcVsltGijnbC/yjYUX8ZbwoFTlwPIDNTX2w0hF4Z51Ve9kY+bE8o/QV48EVqmZZGPsD1pZ74vGeVRGP5m2pvimhnmYHnnbzc9KnRDE5ruIoVRc5O0af3NFWNnLcgNMgSJeiDbNexvCj/hoOUdWPT7UPqXFcNmpjt8TS+eOgqOuztDpPyW0ZZ2WJB67UwXfEcETlLdO+byPl/60wz3l3rM5Mrkr6eQFOulaelsi3JAJclYeb26v/YUEp/R130KSyXV1AWuJWRydoEGAB71tZ2pmKxxRY9W8sepNSix0dUtmf4m1lJGShQs569K1urIxlrZFOx/FcD5m9PoP61Vd6R3HyxTh6/XR7uOSBuSRDzLMACwbyK52GPI9RVv9nUa6lqUV1HxB39283eSW+rwrcxSNvu+TzH6g1T0WkSEDlQ/pRVm1xpl5GyuY2U5znpVU8PJfsYx5eLV9H2U7MdNHGnDOlaHxZw3oGpWN5mGKERC4spFCM3NGJASpxnMZwR5E1Sv8VP8A8Neyn0ebirsmDafqlgjTHhdWLQTKMsRaFsmNupERyjZwOUmqk/h+/iubh3Szod9qRWAFJrS6kHMbW5Q8yN7qSMH1BNfQzhjtx0bjrs8s+I7aeOEzxnngV8lJV2dB64O4PoRWfBrGmpdjuWMpyTh0z5B8JdoGqxaVHcOra9a6M3f3OkTgtdaeFO9xasfEEB+ePou+RjBEL4gu7O/vp7uwkWazuHaWJ16YJzj2IzjFdEfx89ls/Zn2iaV2tcGM2n2Ov3H/ADZtdhaakF5ucDoFmTJIOxYOD81VRw52f6d2y8OajrPAscdnxXCO/wBV4OUhVkIzzXFjn8rdTF+U7DyFaPpc8cb5vp//AGxfLCcv+n5RWEwzSMjNj09qPe0eNnSRGjkRirpIpVlYHBBB3BHoaEmjINb/AO0ZrG6YEsc9aEePrTjMmNzuaDYHfaqpIEHEWN6ylT9P2rKB0jizlQFaSaFi3TNKwL0HWi44ebfpXpeHJDdWh04MBS+TJ5RmrI1jV0eEICDgYqqrO4a2kyuxFPEeqvNszU9iajGhvHl4R4hlxIHlJx1oSRD5Vurh9+prD1qy0wHvYlhY15ndYkG7SOcKo8yT6Cotx5/EbrFxosfD3Dd5JpeiRkwJ3BKPIn53ZhuC5O9D9rGrmx4eSzTIe8flJH8i7kfc4qmFiM8yR8wTOfG3QDzNeV/iuTnNYvCKnmljuMNWTXSuKe81q0RM9xCjRqD5+E8x+5oWC2ntorbU1kImmd5mYdUOcqf71FLHUhb6rbyRoRbJIMlh4nB2JP8AtU9sbu3kszZkeOPK49RvvSvp2pR4tlKdlf299d215K7uWnDli58zk5NIX8MGoyvMVFtKxyVGy59qe9d0tre8EieJXBzgdCP/AGKZ5gE+YDNKyTj8ZFbVDYsdxE4UfiqOhG9O1oLjBxFgkYzgZrW3uoQw7wbftTzDc27JiEqDVaS+yUgdLGRlGQB/3HP7UtkW7Bcl3x5VssEsx3l5V/0iiFgig3HXzLUVBbBktw6klTnyDHal44AgzyjPkBWLMJG5UUv7gbUo3NGrFiigeRP96mkTX2IzoioTLux2CqOn/v1ptu9QgsICMci+nVmNJahxCCTBaqJpT1ZRtQMWlXck0VxKys5J8JbJxvtiqpSSI/oAy3t7rE3dQqwTyjQeXvTi+hw6dbmKWXvL6VFxGo2jyfFk+oAH61PezWHRLfWYTfxveaZC6yXdpE/cyyxAnnRJMbN5D9aQ7RdY0/VdUYaTbC2095D8PCzCSW3hUsI4i4Aydzk+dUO29hKKqyBGBXlW1g2jzh5PX1+1OiqHccuQqjlQHyApea0hteWND4lwOUD655vfPlS11YGzk8Ld5E688cgGzKfP6+RHliiTVgVQVp9z8DC87dT4FH7k/wBKd9I1dXPMQMj1qMTzFlijx8i7/U7mlIiwAAPKT5DrRRVbOb8F+cEWWncS6e9qlvEdQPM7TyNhUQDoAOrGq54shW3vJkQYwSKW4D11tNugUJLoMjH36026/cme4lZjlmYmrH0FehpstSexuAwbFdSfw0dsb20k+hMZpmu1Z7cLusMyqSxbboyA7+wrki7BDc3p5VKOzviObhziixvLZ2VXcRsF64bKsP0NI+oxqaGfT5nCR9Fdcmse2Xsu1rgnVJ1SPU4ALa4YZ+HuU8UEn2cDPsWr502moapwFr9pqWn3M2l6pbu2JYGKtDMjFJEz7MDt5g1072b8btFfx20soblkMYIbmAOfX9P0qlf4g9C/wntT4hgVAkV+ya1bADAPeL+KB/5K/wClBhxpNxXka9RK0si7LTsOOOG/4iLZYdWkt+F+0KVO4fUI4wLfU1x/1B/PsNxv6Z6VUvG/A2scBa/NpGuWbWl2g50PVJkPSSNujKfUfQ4O1VskzQurxsVYYKkHce9dWdjHbJw52v6FbdnfamgmkDcuka6W5J4ZDsF7zyJ98huhHQ05jyy9NruP+hV1n71L/ZzrcRYB2oAxEb1enbX/AA28SdlLy36KNa4bz4NTtk/ygegmTqh991Pr5VTE0HKOlasZxyx5QdoSnCWN1JUAFVUe9ZSrQnOayooAsGAliANvpTxZ2rNEzcuwG9N9nEpkAPSpAAI7flU4Br1OND8ENzQg52rQKUO2T60R+Y5r3lz0qxo6SN7aU53o9Dnem6NRmj4VyPWpVohMqrtlm77VbG2VsmKAuw9Czf7CoHBZi7uFiGxMRzUr45gE3H94lzMYrdmQNIRnu4wg3x7AHakNA4Yg1nTn1KS4NrptiW+JmkARpJCCQgJ2ChQufPLHAJrx3q5cs05P7KKc5aAr/hC80GG17wrBc3UJmwvilij3C5A+Qt7749qaNUllt3BzyToAkvKejY2/an3U+LLniC5kgsPx3yWEgGwAz4iTuSB+Y1CbxJ7C6kJb4jvfnIyQ5z1B8/rSfK3cVSIdLSCptXup4mjed2Vhg71raRrOOVt8eZoRcMM7j2bqKItshxjeutt7BCjp0Q8yaLttMjh8ZU+2a3jk7kgkAMN6UkvwgJYqM+Z3JoqQSpBABCYXA9zSDvAhzKxkI9TtScNrqerK7W8Bjt1GWnm8KgfWm240szyd2kzzqOsmMKfoPSgeWK0g6ddCl9xIkbFIF7xugC/KKEaw1PVyr3LskBOAo/pgU96docFuvyZb1NSHS5v8NaaTuY5kETp+JkNHzDaSMjo6kDFL5Msq0FGHJ/IadH4Jk01WadTF3nhJcDpgsCD5ZGCB5063mhQWmj22rSq0lkbk2yhRu8qpzFAcYPLlc+xp64j1230y2tFuYF06eeNVktov82VcsTLMDnHiPMBt16UjO8F05shNd3cMUkndJPF3UaSOMycsYzhnAU59gKXSk3bLvilSIcx1HhxJ/g5ra1NxHl5QgaRecHwKxG2R6UzaPpjfixcrCcHmDA5yKdeI7KW21T4JgQ9uvjH8rtvyn3UYFGaYY7SWxupWEcfed27n8oPU/Y70246tC/mmBtpbphWZ+95gp5l2JPTenyPhrVBcXukMsXPZZkkfmBVQcZwfPqDirC1LQbOx0Z7hpV+OfZbKAB1EYBJllYDABO8YGS2CTgdY5czTX2j3j6bAXupHZ7gqA0hjTOAq9SC2S3pmkvdcuhj2lHsi/GPDv/DOrG2OWjdFkidhgsrDY/rmmDvT3nKpy3rTtxNqlzfafZLqEha8jkcRo3zxwnfD+nizyj0zTXp8Uc7NHzlZT8pxsfY03jb4/IVmlz+JJOGIgHfEv4h+YZxt6VprPPb3kvMDy/MDjy9aT0qcWcZj7vEmdy1OGqSzNErghZmUqAerA+1W3rQP6I1fyLEzI2S42IA2pPTZ+WXIJTcMD6EdKUmsp54gGjbvIxjPL8w/3Fe6e9tpchkv7WS4QqQkUcvdNzeucHYelVt6OS+ReNjc2eiNpl1YfElLrmuD38YQLuAVGOo5uYhvevP4qrwT/wDBHEkIyrRT2TuB+ZXEgB+zt+9Mq9onD+qaVoNrf6BeWCQ27W0F4t80kcSAsQpTly6gurEAhh5UV2whr/scWF5Y53sdTgfvIjzLlkdGIOOhyp+9L45NON92aE6lGST8FRXciLKDEPwpBzJ7eoryGUxnOcH1pLScXmnGBj+LFuhrzDMnMF6bH2p6aS2IJ2dv/wAN/wDFPBqWiW/DPF9yvxCL8PDfXGGWZMYCS52Jxtk9fOl+2T+Fiz13vta4EENrcOOeTRy3LDKfWBjshP8AIfD6EdK4l02R0RuUkYNdG9hP8Sl5wt3Wi8QTPcaWfDFcOcvD7H1FIPHk9PL3ML/sacMkM0Vjzf8AJTup6Td6Vez2d7bS2l3A5SWCdCjow8iD0rK7Y450XgztVs7eXVYu9lABh1GyYJcKv8vNjDL7MDjyxWVoQ9fjcfmqYvP0WRP4bRyjbTsCKeI7zvIwDTGgxRcbkLsa9tB0Up0OqNzdP1ohRnJFAW0mSM/pThEQSfKmU7Lls2SLPlThptu9zOkKAFm232GOp/bNDqwBAximfjmdrXQFNvK63L3MaCGJiHkQq22ANwTyjHnVWaaxQc/ohpLZV/Gutw6/rupSxGJrSCSQpIi4MiDCqxON/l2ptvuEuL9c4F067ls5LLhOC6EUEjL3a3M8rHMgB3kO3zdAFAFXNw7/AA9ahwFoFvxFxTpMN1PKe8XT7yYR21qMEqbgjJaQnGIlBPrQXaLxprOup3mu3UY+HI+E02CPuooAWA5iuSebG2Cdh5CvKPC8lzn/AFA9tpXLyQPXeGtK7OxqK2tx30hmNpAkrczHkA55JNhtzFiB6qOtRizsRfSCSQFsHOW6k+9G8VXCapxFdd5IFiimdizebkk/c4xWWs9upWGGROdzyjmJJOT9MCkck11FaAlTlS6JVD2VsNCgne15++XvG9RneozccDXmnzt3A8J2xIvSur9N0YJZQIy+FY1GPtTbxdw5YXdmkIYwXjn8No1yT6g+1ZqnJPTNF4ItdHJDcPaldX6QRLIOdsCRoyvN9B51YdvwJpnC1hHfaz+FzDwI/immP+lf79BUv1qbTuz48qAajrTr4RLusY9/Qe3U1Wer319reovdXkxup5Ni7eQ8gB5D2q53N/oV4LH+2Ia5rE2uyCJY1tNPjP4dqp2+rH8xoWG35h4QuPUHJoiKHM5VY+ZicKo3pKbVIrUyd1Eb+VTju4jiMH/U/wDYftUJeIoF/bFGUWsbSsyxxJ1kc4Vf/Wme61wXjIloXjSVjH8ZIuATvkD069TvWTtcan+LfRd8w+SJTyxxj0C+X160rpli5E0UdrLPEfxHt1XnU4Bydtx9RV3tOK5SA5t6RKeA+zCPV0a6v5GjAkKyGR+RFXByxkPXYHA88VJLvW9B0r4Th9g0eox3bSf4xEnJO1mI826jOwbOSMjOOXJps1a+XS7XShYwXImeFZZIb7Jt0kPN4eQ/OV28R22AxVf6tpWo3GqyX91cNc3E8hle4f5i+TudqiUo5VpUFft6HiysVuTJczs8hnlLGSQeJ+bOGPuTmh9QteWJrPkIZpW2I+XA2H9ak/EHd2mh6RqNhbTiO/tniu5p0/BS7ySyxnG5UHPtzVGLu6Dxo0cpkki38e7NjPU+vWihLlsiSUdEa1Ka4t+WO3uJoVjOeRJGA89wPXejuGNae2vTZXjNkvzRTq5V4pD58w8j0NCancRm5V/yOQT+tN9w6gc3/Vdi59h5V0oplFtOydcSaXZfDW88eBdzBp5iWJKrnChsjqdzmovju8GPBHk4FS3TFg4m4WtY1tpDrHM8YfqkyjPXzBGRsKY00iZWSCC3nmnZ3SSEpgxuCfD77b1VCVfFhTjdNBVvKWtBPzsJuh880m01yzl+RubzZwSf3pO0lDyDxNCq7YA8VPtzAkMKtExmdwcd6ebHvjyNXUVjFqGrOIRGrMSR4uU7D2pHTrFtQCSkLJEJlSVAfEi+pHp5Z9qTuYpo2aN+Vt8g8vT6U2yTz6RdpJFJyzAbgHO38re3tQSWtEp7uRcXDWlrxB8RpFxAVju7lFimSLa0uASI3zj5WTKN7YODgVr2k2V5oHCmvaZEiXemx3CxLeQ+OP8ADkBHKwGMAkjPuKB7I+J5l4ktZEW+WO4UieCAMRIBzHGAN15gPfGwqc8UycQW01nwvqJt7S01G2lguNMSz7u3SV+chlyM53Qq3nuKSjcZUaDqUbRzbYag1reI/wCU7GpRCO7nLD/KlwT7HyqNTWPdpuMMvUe9O9rdmTTwwwXjGGB8xWr2qEI6Y9CNVBwAv0oaSQpnc17bz/Ewhvz9CPWsePn9aCSaote9om3AHa/qPCam0nZriy3KqxyVPtWVAnt81lUSwxk7DjnnFUmWmdq2Vjt1Ne8oNYRiveoqC7ablO9OkDhsUxxnBpxtZSD0q2L8BxdD5CkU0M8TqTJJGVidQSUfIIIA6nblx/qq5OBOENL4I0mPi7i+KOC/tw09vbSAN8GWAGw85TgY9M4HmarHh3inSuBLX/HdTCzXZyLK16nPnJj9hVddpnbLq3GF/GvfhYIvF3Y3UOfT1wPP1JpLO8UZOcnbfgcjOOOPKXZY3an2v22qTm9nJlu8H4W1JzHaKfQfznO7fYVzprmpz6pdSu5LO5BJ/wDIGvJJZryVpJXaRmO5NLJCoKRnAdstlthge9Y/qMspx+kJzySyytkWmt5r3VLuR8/5z4U9Opp0tbJlIZu9QEdcZBp3TSY2urxCwRlmfZtvM1kr8zW0MU8MJknWLvZjhFJPzNt0FZC/FMoa2zq3hziCG84J0vU5NjNaRuR6ty4I/UGq5457R10UvFausupS7NJ1EK+g9TVcw8fXen8H2Wkic81u0qqsZ8LguxD5/lGTj1zURuL552Z5GLs35j50tGCTtmlLPUUo9j3eyi7naeSdpppG5nY7nz3J9aRnjSKIyM/dw55efGSx/lUDdj7D74FALd8ixGRTIzD8OFTgv7k/lX1PU9B7Fwq93Msk+GlC8o5RhUX+VR+Vf6+eTTkISzdaQpdA0iS33NGoaGFtjGD43H+th/8A1G3rmjV0FbeBQ6+3KNgPanLTYFe7VVXP2qQtYd8p8GSBsAK1MeGGONnKN7ZF7Lh/4tHKoFSNS7NjZRT9bXFlpOllbaGeNFfDry8jzS7gEsPbqBgAD1NWNwnwvd6Mq31pqmlQmBWe6V5u8YeFu8WWPlIKqpAGDjO2cmotdaW91cGeSEwW4J+HgZQCqnqWHTnbqfTp5V5zNm/mZNL8UOqHtK12Ra6hkv2FxcnvmC4CKMKij8qjyApn1Xu7dOcRFowN8b/t71MbqEW+e7iLDry4qJ6kn4Eq/K+5VSentXR1pFEvtjRqXFF3rWl29pNO0ltaysyIdt2AXmI6ZwoGeuwzUcvYCn4sZIbrt50VcpGspZGALZV1+vn+tNF5PKq+HLN0K+9NwpaFJtvYDfOChjPUeJT6ih7JXu5yB5D/APFeXQldTzKVddxmlNEuFiM0r7BRk1L7Kye8BSiO8SAXDW/w0xljmC55XI6f/aN/anrUNQi0vV4rjT2N/dSc1xHLfKCWfJ/EVegb0zvtUV4P1v4Mm3mAezuZA0iYGQ24DA+R3o+4sFW4E06sGDcrEZBjIJ6ehHWlpQfN2MqXwVDd8YzSvIyh5JGLFmG5J6k0/ac7So0LKJyB8w2CHfYetNmo2Y+HF5zoJGkMbxDrkDPNjHQjH3zSmgNM10qQxvIxOAsalifbAphNFFbGrU4prW4fDENk/eh7eOwu7iP4tJIvGO8KbqVzvt1Bx6VPOOeA9Y0u4jfUbL/CXlQOIr2RI3II2PJksM+4qIf4IsQZmulYDryISP1OKCUovpkqMk+i2Ox3hyTjPj+0/wAN1iPR7y1uFm0qPmCCTu+bkjhYjlE2QCFcYfcZzXSv8RsGicQaxDpMFrJbcW6LFBeydzalLfupB3mEYjmBDtkqehLAbVx92Y8U6Zw/qi9/fG2fvVkVrm27y35lzyl1ByMHzHSvon/DPpFl20cI6rY8RTaVf6jpEn+H2WvWl6stw1vKpljSQ9TGGJ5Q2+xU9KzclxlRqYmpRt/3PmBxnpk2jcU6rZSxmMpOzqCPyt4l/Y00aXKYbkxn5W9a6m/jI7FL3gzXxrHcjurciyu+UY5Dk92/Toc4/SuVrsiKQMvUGtTDk5wUjPzQ9ubRI7dRE6kfL8rf2NOJhHUfcU0adeCTkY7odmHtUrTRpGiiYE8hbBcjIK42I/pTSXL4vyCm+xnkjDLjG/rWUXeWUlo+CMrnHMBWVU4yi6aLPi9k35+WtgcitpIcdBWIuB0r2qTAPVGfaiWuo7O1lnmbEcSF3PsBk0l3eMUzceM1vwfqTrsTGF/VgKCUnCEpfSO62QC+4tvNev7i/nckIPAg+WMdFUftQttOX3JqNwTuLaUBioLrkevUijLa8IGM4ryMcjlJykytu+yXW06qRk079/p9wiJcQG4jGeaNH7t2XG4DYOD9jUKivjy7Gifjh3Ykgf8AFX5ozV7nzi0EpUOWv6jENTkmiVoobhVlVGbJU45WBOBncHeidP0VL3h6+1u5kAtLSRcwBTzzZyARtsvNyqT7nFN9m9rqJ+In541gbKL3YKO5GShzt1AP3qSadrF1rF1cWV14bXULVra4uLjHhDnMRAA8KoygnHuTWTKcopRXgtUVJtvyRGW6MwMpKnm3PL0B9PYDpQ/xAZSM5c+FV/mP+w6k0iDPoUt9bXkQhkjDW9wki5ZSDggehyMZ9KG0+RpGNwV8TbKo6KvoKuiuToqbJJYxraoSZDNK+C0jef8AsPQU62lwoPUVGRdFevWtl1Ap0NaEZqPR3Inuj3KQ3IkJAwetX92IaNwbxRxakvE+qtp+mhOWLuT42umBKnYbLGMufU8o865NttVbx+IKFXmJJxt6D1NSLSOMINOu7aAydxIgDNK4yhJ8Tg7eYAH2pf1eZzxe3DyNYppdnW3FWgaNwpqa8LW95HcrAEvNUKqF5nJ5ra12A2RT3zj+d1H5ar/jWWxgBa2OSc5B/rVSR9oMlzJc3eXSW5laZy7ZYliTkn1oS74umvAwkkOD51TjxRhDj5JeRNh+vaizEgSsoPUA4qD6kEctl2z653ou5vzISS2SfM0zX1wDkZGapUadFUnY0XcCKWxKef60hHc8jqz532J969nb5iVJGetITFkHhjIPU59fWrnraFTe+dZMjamNuZZe5z4GYHHrRkki90wZSJM5DHrQhcPNGehDb1zdkEjsSI8FfmG4qVarLc3mpzzM6xxXCrIVdgoGVzgD61AG1nuh3cI3OxbzNGw6xfPGIo5+QKMDAGQPTOM0MrbtFqcVplhCxtntLaVhEvh/EeQ7FtxnfAxsKVj4q0PRpcNqMk7D8lomfXbyA/eqsuzcvzmed3YHADNnNDJE8EsUjDwlsZql4+T+TC93j+KL04g7cNN1XQ4rG04RsWnSPujqd4Fa5ZATgEqo6epJPvVU6txbfTSMFggiXyVU2FIpHNCWKrzRtvy+efakZI1lBIz7gjepWOMekdKcp+RGz4x1WyullgkjjkU5B7pT/Wrl7Nv4xu0Xga+uJNOOiM8kQilaXSYg0qgkgMVAJxk9apBrVjcgIvznH3peCD4W8mQDpiueKE/yQMMk4P4s7Tu/43OHO2Xhq+4c7V+E1sZL23Nv/wAQ8PEkxn8ryW7nxBTg+Bs7dK5Q4n0RtC1W5sJJ4LsxEclzbPzxToQGSRD/ACspDDOCM4IBBFM/Lze4rd5GdjnofIeVHixLHfHphzyvIkpdoI0247vmjJ6dKv7sUhteO9BvuHZ3WO7h/FtpT1RvL7Z2P1rnQMYpg1T7sv4sbhHi/T9RRiIQ4WX3Q9aulycfj2jsMkp/Lpkt1ewm0rUJ7K7hMNzA5jkjYdCKyuhO0rs3j7RdJtdY0dYzqyqqlcgCdPQn1XqD6VlPYfW4ssFKTSZZk9NOEqStFLOhPXO1ed2Aacp7Qqdxg0O0BU161xaYLQkiZPSm7jXTWv8AhDVIgCWEJcAf6SG/tT1FET5daPS3WRCjjmRhgg+Y9KiWPnFx+zqvRyzJaMilgNhua8QH0qdcScJNo+o3Ntg8gJ7s4+ZD0P8Ab6iombQgEEYYbEe9eKniljlxZQ4tA6ylOle/E5PjX7jqK9aIjyrxIQX3HhG5HrVbbQKHdZZprQ2sPNcJCpZABsFIzI2P/fSnWye50uWK4vIWVJI1ZFcY7yPBUY26ECmC0uprK4juImKSo3MrDyNOeq6xc6uIJnNsltbxuiRRYDxLkswPm252J+nlSb32MrQjxnINWihu7jvVnMxiaQLkOqrsGP8AMowAfMY9KZ47gqoVPAoGPekbzX21a3t7blaKNJGkZebIJxgHHrisBA8IyV9TV+K4xKJtN2ghpzjrk1r32T13pFOtK91t0+9WWwBRHLkDrk4p0u0EHeymM5kUBWZcDr5HG/SmuCMiaPbbNFXdxK9usbSM0asCqEnA69BVM/yRbHphMN+cYJ2pQ3pzscjzprTNbjmq2wbDpL3KnB3ptuJ8+deucHFCyHc77VBDdmslwyKVY8yHypMF5M8rcw8s9RXnd98+ANh50WLdIkyTkjyFR2CNjROrESZ36E+dBXUTKQxUD3WnG6uCwOY/pk5xQjOJEIz9jXHMFgHNOvuaeLcckmw6gEUzxjkmU+9SbTYVl5eYfLUJ0iUrMOnG5uBnZANzR+oaHzWyhBsRt/ai9OiVp8kZGc49aeJ+WZCuMAnH3qLtlygqGa20nVdat1SHTyGhUIWgjxzfX1NM10lxp7ypNEQ26nmGGUip/wAFcZzcIa8l4HZYGXu5vww5THyyKp6lSAf1qPcSaiuot8bJktcyOxZ+rMSSSfuap5y5U1oN44cbT2RrTSZr2Pu0aR87JjJNG6pp89jrF3DdQPbTRcoeKQYZTy5wR9K0su5hv4pZG7uNWy3J1+3vT1xHeW2pXYkRGhm7rxM+cygbLzf6sefnV0ZbrwVqOr8jMqhkI6H2pFsY+lKRHD461pMnIx9DTDKjSQZFKWVyUPKT06V7ycyA0My8kgYeVDVM7ydfdgvaab7hmG1uX5pbX8JgTvgDwn9KyuduAuL24Y1AzZPcyqVdf6GsrKy+lubcTZw+qSglJ7OgtTiQ78ozTFMPGaysr6xl7Fp9i0ABUbUXH0rKyoiVoYe0C1ifhmC4MamdLoosmNwpQkj6ZAqkNTUJqTADAZOY+5rKyvN/xD/yg5OhEopzkChJgFO3rWVlYeb8RddmA+AfWg9TPLZy42z4T9M1lZSa7LX0JiFO4iflAYKBkUqm/L9aysppFJuQNqKhGVFZWUSIFWUKVwMb0vfRqqoAANx/esrKon+SLo9MSCDPStWGAayso2QgaTqaBY7/AHrKyuKzQsQ2M7UtCoKMTuRWVlQgWCzb5oKQAbgYNZWVDIEOripRpBPdt9KysoX0HHsd7NiEJB3p503xRyMdyDgE1lZQoZj2gG7A77oN23pm1S3j7xDyDJANZWUYEgREVZBhQPEPL3p74sUJqS4GPwV/vWVlHEqfQyp/mCt7gVlZVnghdGRf5dITjDVlZUvpHG9vumPLNZWVlVnH/9k=",
    bio: "誇り高き聖騎士。黄金の装飾を施した銀鎧と剣で、正義を貫く。"
  },
  {
    id: "c5", job: "phoenix", name: "フレア", title: "炎鳥の化身", rarity: "SR", atk: 32,
    img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAETASIDASIAAhEBAxEB/8QAHQAAAgIDAQEBAAAAAAAAAAAABgcEBQADCAIBCf/EAEcQAAEDAwIEBAQDBgMHAwIHAAECAwQABREGIQcSMUETIlFhFDJxgQiRoRUjQlKxwTNi0RYkQ3KC4fAXkqJT8TRjg6Oy0uL/xAAaAQADAQEBAQAAAAAAAAAAAAACAwQFAQAG/8QALxEAAgICAgEDAwIGAgMAAAAAAAECEQMhEjFBBCJRE2FxMvAjM4GhseFCYhSRwf/aAAwDAQACEQMRAD8A4uvLCWHlcuMGq5BWkYHSpUxwuu771uQwlQyBip+lQF8TbBQkJyRk1PbQF5xgVrieGhOCKkMN8zmU0tpi+yTEjjGe4q7gtuHrnFQ40NznTsRmi2DBCWBzAZoU+PZyj5bI2FgnrRtZIaVkZAqht0dCSAcUwdG2P9pTMLc8CKygvSX8f4bSfmI9+gA7kip80tleLHb0Pj8M3CpnU97auFwYCrdHPjeEof4ykHYEfyJVgn1OB2NdL8YtRz7FpX4SzNl7UNzV8Hb2k9Q4oeZfsEJyc1A4FaXOm9DxpT8f4ebcUIe+H/8AoM4/ctD6A8x9VKJolt0Nq6Xibf3h43hIXEhA9ENpOHFD3WsEZ9EipauNeWa0ajL7I5csnCxjTWpmtMpe+I8Nr9pakuqvmeA8wZB7IyRt3zk0P6840S9N6gnz46g3KkILEdAGfAYQMqCfQq2Rn3WabPEQnTGh9R3nOZd2uQYLnctN5zj2KuauLeIM12bdkKJKsx2zv7gq/qTWeo3KjbTtNv8AfyeOKfFm76umSiqU58LLkqkFnOyeqQkewTt96BNQT13f4WSpZW/4CWXs/wARR5Uk/wDTy/lW2XFU+5jHStQgKRK5SDhSAR9Qcf3q2EYxWiSUnJlMbV46emQsbpI6ioUC0uQZKoDgJYVkx1H+E90f3FF/weG/LsUnI+teXLYudlKU8qxuD3SfX86amJaKBuCUFaMZz2qOYQbfCwCV4xynosDt9RRfFtipbPOU8jqSUrHoodf/AD3quvQS0sjwgjKQSU9lD+If+d6ahTKMtJfQVtKynfI9KpLiN+nKpJyk1Ofd5EOy2iUAZ8dpPVJHVQ9vb/Sobj7c1GygcjII6H6UadAFW9++QFAfaq9ZIWR/EN/rVgUll4trVyhRyknvk4I/pUacyUELSMFPUUa7BC7Rt0HhfDLVlJPkz29qNWWOdO/SlRYn/DewNs7p+tNmySETYLTyeik/rTe9oyPVQr3IjOt8izWJR61MlNDmJFeG2QoVZHpGUzQUe21aXiRU5bRSkitKYhcWNiRTfuzyIiCRnPX1r14p7Z2qZIg+CM9KgfKTnpRJ2cJsdYfwD0qWqMhaSMZqujuhKqnIkDIwcU2KOGRrcGHvEA70YR9RuxofI2rkOMbVQx8OJJG9Rpb3hn2r0oqWmdUnHaPuomDcY6nVq5ljfNCiJ3Inw1K2FX8iSpyOsZ2IoUdjlbiiOtC1x6Op32bVTkBR6VlQDDVk1lc5MKkLReVSTg96smWVEA5qqUvEv2zVq3KSABtUBZK9Uby2RgDrV7aIIThahnFUjQU84MCiGK6ppsAius42EMdTa0jYc1S2y6TyiqmJJSkAnY1bRpIUsYpLi0eS2XdqCkrSFDeujOCui/8AaO+6Y0+pvm/a7ybhPP8ALDaJKEH/AJilavuikJpS3G93iHD5uQPOBK19kJ6qUfokE/au0/wjQ0XS+6o1eWfCjBpEKAkj5GRsMf8AS2gfnUs2r2auFVG0dG3uSqJb5Bj4Q6cMsgdlqIQnH0z+lVd21BD0rYVqKkobYaw2knqEjCR+e9Q73eUJfhBasYU5JI/5UHH6qpA8ftftwY7oU+UxYccOOkHvj/8A1WflzcX7TWwYOVciZx01TFk6ca042OZ6NFROUR/NnmWP/apRrke5x/i1NKJ/eJaS2oH/ACkj+mKZvFDVXwuvZUqO4VIZLaE83ceEBjHpuaAIr7K5LolELcG4d/mG4BpMLk7LpJQikU8a0EqOUZ/tWq/W1No/Z7z+Epkv+An7g4P9KKf2lGiuPpQkKPIAk+hzv+lVN4YTq9UOE5gDx1EY7Hl2qhfcT9kRW9PlRJWAggZKT19zWSo7ERoKbwp5GQcdCPT7g/pWu4PyIMotPlQfTlJz6jY/ntVJMmrQsgnAV39+x/rTEKf3MTODM50jPK8OYf8AMkb/AJp//jVXdViYVnbmqsuc1xnmcbO6CFp+o3x/Ufet7yg6yp1s7EBaD7Hcf1pqEsFZ7a4szIOEueU+mR0NaI8RoRnXC420EKI8MqAKT6Yq2uYTIaUQAFDqPQ0NXeKy+1zLIQ5jCXDsU9ds9xTVsS9Ee9ymSjwlLAdByk9sjqPY/wClfJK3UJCnUEIdTzpV2INeIGoo9lfgO3VmK8zCcCwlCUlx7BJSk7HOCepxUxdybvgMvxAtcjndcGMBKsnIxjbr9NqOqQjk3KmVcCQpBKh1bVzA+gpg8MNSsSrwbM6oNB10eE6s7EKUB+Q3NL6fHQG1oVHKmT85bJSe+5rLch5ibHYZW3EWQHPEWDhtAyQFHrgjc/XFHFt6XYE4pr3dD8nxfBkvNZC+RakBQ6HBIzWuOwc5xXy3S/2pCRI8JtjmJBaazyox2Gd8d/vU5oBCTkVowTaR89ONSaI60JVtisRytHoNq8vL3OKjrcJ2pnEV0eZ0sOkgiqpxJzkVNeANRnE+U0UVR5kZSuQ5HWpDDvMdzvWjwic17bTyL2FNWjtBBDc5Gt+lRZbwWTUcSiG+UVqPM50Fd6BNbiyEkVBS35jVkGDvmoEp8MqOBS5SCS0eSyM9KyopmKz0rKDm/gKhPObSjnap8QoUvBqBJPO+T0qbbYinVg1Ii7wEsJtvwwQN6sgoKTiosCOG296mISOgrjoT2z63kEYq7tvmUKqm2vMKube1hQx0rj6HQWxh6aQYGnbrcU+V57ltzCu/M55nSPo2kj/9QV3Z+Guwf7P8FmHyCHLi6p0Z/kHkT/RR+9cOhgtwdOQMEfuDMUn1W8s4P/sQ2K/R+z20af0Xp+2JAQI7TDJA9Qnf9Say836dGxgXuoX2ur8WLzPSpXKiPbVY9suJBP6VyD+ILUz93tU9kHC5roaAHoT0/JKfzp78Wr38Nqa9sFXmdtqgkfR0f61zXqF46juD7JA5rdcW0n3QtlKkn881jx3K/g+kqoV8nvW91/bNwEtsFJdix1uJPZfhJCv/AJA1SJkKDYUpJOBjHcg9atL5FcYMVbbZXhopUB6AZ/pn8qrCErKEhXzjKferIonk9nkKUkZGcelW+jCZOqWEkbIUFffeq1DKkyGk4y2rIJ9D2q/0hHMW+svqSUtuOEJX2PKP+9MTAotOKum1LZFxjJAWMcxHqOh/LalXObLqFcwKD0KT1SfSuiLncbd8E43MksttqBBDqwNqS+o5NmbeWyzMafdTkNLbOedP8qvcdjTGt2hfa2AjkcymV5ThaSUrT6H/AM3rXZD4lqDRzzR1KYVn23H/AMSKsH5cV15TkV0LcA5VtEY5wM/qKg20fvp62lJU07yqGDuFJyDkdtsflRJ2hLVMqrslTKVOJSSpGy0+oqhcUJCXUHlcB+XO32NF9yYK0uLGD5QTS81T8TaJjE6KnnQv90612V6fp3p0diJ6LBmzCSkhltKEpGVqXhKUdepNaretq0XJt5poSwlXnccb5kEEEHCT12J3NV7N3buKSnlUR1LStnGz6p9asWJrgV4TjfiJxlMhIwD7KHY/1oraYHGLNF6lNMyFphK8WMhZQ24pHKVpHTINVDM5wTHiUZU+hTasjqk9cenSrqVJSxFmsFLRRKSkKK/mSUnIUk+vUfehxiQIk4c2XWxlSgOm2dx+lNj8oS/hj9tdxiOSIBiPc4cjNtvpCMDxAnAHTqMYon8DmRkD70otCSH3XRLLSfh4ykuPoScKwo45gMbgbZp2MhD8ZDjR521jKVeorRxT5N2Y3qcahxaB+Q0UkioDpIJxV7MjKIO1Ub4CFEVTRDRHOScmvhAHWvY32xWeHvXkeRrDWc14LJ5ttqmoShtDjj3iBpCFH92nmJVg8o+6sD869NRypKSoebG/1ryknJx+DrTSTNTMYlJ2qZHipx0qyNmdj2Vi5LLQYfeWwhPiDxCpIBJ5eoTuBn1rzHbAye3vXbUloFprsrnonlOBQ9PjAOnNGD6sAgDNCV/Km3QR3oHpWdjd0Q/BR6CsqGZBz0rKDmhvEVbyeaTygdTV9DhusNBQTj7VUwWhIuKQN96PmYgS0lJHapl0VS1oqYrysEHapzC+Y71qkNpbWdsVtZI5PQ15ryKLFgZVVxFPKk4HaqSI6AcGrhhwJUCeg3NKa0U4xuaEYVqPjJZLSvztLmxIqAOyWwgEfklVfoTebol2NkHHgz22z7Zx/qK4T/C800vj+0p9sOfDCW82T/CsJPKr/wCR/OurYd+/2h07d5UMKIdvGWs/5VIx+fKfzrH9VJx0vg3/AEcOW38iH/ELMVB4owEk8rMpEiOT7qQlSf1T+tI9yZFganmylyEtty/CKgs4AKE4zTN/Ek8/cLba7zHPivpb8ZOeqXWlYUD/ANJ/WkHaLpZ71NnXWTlbKVKT4CjjwjuVA4/MfWosatWbMnVRGfO1HZ343+73COqS35kJ5up32+9DaYqZDSAkeTPO2e464x9KEXL5pCXI5mFstDOMKkJbJ6/wk0f6eZhXKI2y25hsnLTgUFYP1Gxqp6Qlb7NaWHA0edPMoDII6kj+9RpirlOt7bcB3wG21rJWB5klXUfpRs1pKbylCk5PZYGQfqKjs6UkwpSlKSpAVseVeQof1r0UeaoVc3Q6GF/GXi6uloHKi64QPpV4xetJ2mFnyBKRsstAD2OVYr3xO05cZC4ceC0HJj6uSOl04Q36rOdqVWseCVxsl0Jl+LdVyIanELddJC3hsoewGTsPbFVQjzVtkmXIsNNRuwvuOqNPTXvEhyG3HFnC0gpUlY36kbg/rUZmMyLi9JYWhbTrRStIHnBByCfUdd6VL/CWdAW+p8/DuISSEtuZIcJ8qc9xjemBo/QdztNs+JelvSHFJ/i6J6/LXpRjFaYEJSy/8aJ7qQ6y6UEKSpJAIOaC9QRDJhltbJdQpYC0jqAe4+hqycnPxXXluIWlSVkKdZGM9fmT0NQ592ZnR3EKfaGRspB5FJPY4NFAXP7glE0FKl3cIMxUeI2C4t5ZyUp9vftV3e4AiNLFsekNOMI5yiWjm8ZO/mHoe9WKZwTFS2+80okDmcSfmxnGRirKatF0ixltFt5TZIK+YdMHI/7ds118m7OwjBRaXYv1TnVMha0JdSoZC2+hz7Gq1x11x9IWA22pW+P7mjGLZ2YbLDKPDkpSfDUUbo6nv3xVe/aC06ttQ86DkHHpvTo0SyToLOFDTV3lmG+SlCwtAI2PN1H96d9oZXGj/COnmU1nlWBjmT/rSF006bbeUvIVyc3K4CPUHrXQUV5M+EzNbwlWQSPcnCk1VjkkZvqINr8muZHBQdqEpreHFbb0dPo50HahW6Rwlw1oJmQUiB5qtoNhl3CI7Ijt86WyfKPmVgZOB3xt+dQksEr2GT6Ci6wzxa7lBbCgptocqincFR3Ufz2+1Q+t9TL0+NSh2BN0rIQej2PSqYT7IXNvrqw2pY/wm2MHO4O6lq5R/wAtaLVaH7o6WYzalqS2t1ZA2QhIKlKPoAATv6VS6qvkfWPGY295h52BaW0x0IiEJJdSrnJJx08RRz38tSeLmp3NNC3WOBONmevocE0x9luQgcFBPVIWrbbryntWfh9Y1d/qlv8Af9C32SlCD1S3/kiKvMDUN+uF0tMBdvtD/hohtOklwoQgJK1ehUoFRA2ydqnl7wPh0rBT8QFlvP8AEE45j9ASBn12odu2rrJpuxtraQH1AhhqKwR5QMg5PYAAgeuK96XkPaikyrklx12EXVNQQ91bjpJPL06cxNXYcydRj0C0silllr4CJxXl9aG742FrTmiG5ymrUpuG4149xmI5mWvE5DHR1Ly09SCNkjoSaHb44E4OKrc1JOgPpuFcvJV+En0FZWkvDNZSrCFrpdAduQV70xCkACl/pEATPemGUYxtQUOn2VspgLVmoawW8irh5nPSq+YzyDOMUSARkJZKxk1fsEHA60Ow889X8XcCgkhsND9/DPcWLfqq/wB5kocU/CsD60LTjlUUlCcq/wA3Lge9PbhPeXHeGjyVOJATJRJDiepSs7n7KSfuK5y4I3mJarfq8SxhuRbURy4B8iVvJSVfbIP2o54HXiXAmXjTkpJWiWyVsjqAtOScHuFDJyPSsb1MHJTrxR9D6TIouF+bK/jS4uZZzNZaVEWp4yksrH+G7hQdQR6HBPuDXG9+Yl/7QXCJZXmkKuA5vDwSjO58vofY9PtXbnGhASJCZvMmHJaSl11KcqbVuUugd8HOR6E1yLqawyLPOblhKQuOsOpW0eZCk5yFJPdJ9e2cGovTOkzV9SrolWrguxO4cyLgkF+7xpAclZ3WUk4UMY6Y3q20bpe86X1Kl+0n4m2uSAn9nspUQpk9SonYKGT0ro+Pw9guQoF0gsripmxm3edokBaVJCsH160SWDQzZUhqO0XHlnA7nNW/Wco8WhL9LGEuaZrs7ylwAlYJU0SgKPUjtW5UdLhJIBpp6u4dDQ3DmA24hKpsqQXn3cfKeXAQD6ClejI70KtaYepLlFka5WGFc1tuqZSZCEeGlzG4HpQ7d9ELuDaUuOIeS2rnQHE55T0yKMUqCR715WonOBRNnoxb0LZHCuGZIekjxVDokDCRUi/WdmFb5JDaUNtxlBAA/iP/AGFHTzuEY5fN60A8Qbkpy2PMRiD2ddG4SPQepNLfQ+qViJuaWYzpStIy++cD2AJoRnWMSZ48NIT4quUYHfeia8x1vX1rbyMNrOP8yjj+gNaC2UXSKnHykqqjHpGZPbIEy3MC4oC0eApLQStPYL9q2XuG3pjTs+c+Q2HE/u2iNyoghP5k9PQGiNtlizoM54JWCVLfmPH5NuvsO21J/WerntdXlCGQtu2MKPgoV1V6rV7n07CjScn9j0pLHH7lpol8vaadRnLjDpxn86n3J1Ly0SEDBGy09xVHoN3kk3OMdgQlwD7EVZXiOXC6CFA8gVlPXIBpi0yXuJJt7gZmxlL3Slzw1eyT/wDcflXQWkSl62MOYHhuDlUOyXE+U/niueI6C9ES6hQdJSFAjvj1+1Ong3dUXGPLt0hWedIdRn8j9/lNUY/dIjzL2h07HISaGLvH5VnNGY5lMlLg/eoPKo+pHf79aH7xG5lHArRjJSVmHOPF0BN2uKLJAelr2KcJbHqs7D8tz9qq7ZrVqzQ3bk6AuPb2jI5T/GpPyp+6ykfeqPi7dFxpMC2gBLeDJKu5JykD6AA/nS51TdlptlvtiFeeWv4p4Ds2gkIB+quY/wDSKxvWR+tPj4X7YUcfLvwM/hjIEeOLpNlIRNmSFyZDyzuM5JV07eY0p9a6ul8U+IVwuycpjrUGIjY2DcdHlQB6ZGSfdRrfqrUibXpBUVjmEmZiO2T/AAo6uKG3phP3qJw7gJclR23H2ISXD5pMlXK20P5lHGwqbHj+m5ZX2+goprlN9sJ9VQoWnuHkaM4nnu1wkpcacJ/wmWwedWP8xISPoav7XxtttpgxYNktD0r4ZlKcPAJQAkHJOOoJ3+9KHXOq1ajvy30eVppCWGGh0QhOwHTucq+9EVmjIsWnVhwgSpQ3J3Oe5+gH601QcILl2xkkoxSY37VqSbrW83LV15U0mZNSGwEjkbYYbAASkdkjAAHtUTUd6bU400w24tx5IcaKkFKVoOcLGeqTjqNqA9R6p8GNGtERKURvAbcKmlBRUnGUg4998e9FdqbKLJCVNQ5+0AyGwp1wq8JgZ8NpIPygZJwO5qvA5JKK6DUVxeTI9vo+hJwMnfvisrYU79DWVfSEWwD0THLk2mSWSMAigHh6hTt0S2B1p3v6JdbgfFBWSBkpIqNzUOyp45Tb4gcuKQAaqrmPLjFEjzZSvlxVHeEYPSmp2KSKthHKc1cwVcxHXFUrailzery3jKk16Wzsewt07dVWlE5HJ4rUtjwVpzj+NKwQfUFIp18DLubbdLlPmupfs1uhuzkA4yVEhCU46pJUpORSMiN5xtmmpp63JtnD2TJOEP3eUIzavRplIWo/QrcaH/SagzR068mpgl7l9hx8SbTG1dpuJcHQIrM1vJXsQw7khWf8vOM+2RmuL73DmWG+TrQ+kOR23VAxnOgzndJ/hz6jY967I4eWT4fgxbQ426/EdnS/GcUOZKCrlGNx6Jz9sd65b4geJG1ncIUpAc+GcUhoqH7xAGdgruN9gfWsVLhklFH0kX9TFGTOn+Ck+RqvgdEYSyytdmd+AcIGHkoA5m1KHoUnGR/KaMNHoNsuLbp2Uk7H0pGfhU1PBj6uNmkzzGYvTBjsKQvl5ZCTltKx0IUOdIz3IxXSDmnX404hRBSD8w2zT432G5Jrgzfxy1oiezabUl0ER2A65jutX/akw4oKWShYONyAelO/UnCSHri0LnofchXaO1ypdRuh0D5UrT+nMP1pFwdKR4Mp5x5gJlElDqiMKJB6E01uUpWxGNwjjpeCey2XWUqHQ17UyQMVKSAkAAAADbFfF4IplHFMq5TSSkheCkjcGgHVKU3BXw0ZILKDupA8ufQfTqaY0lCXAQUhQ9CKFdVPNRIhQ2AZC/KhCRv9fYDrQNDOYh7vbvAlPOHusgH6Clnr69yLdGfeiOeC+2EBKh2yf9Ka+s5LVuhgK/hQVH3/APvSV14wpyyB5eyn3UnB+5/0p+Mz82ugfc1LedSWm6JmTitv9wTHB5UqAURsn2zk1JsVr5UkkeZQAH3NTdIWEO2mSFMh1UkqAWE5LXhp5uuNs5/IVY2ZoF4YG22PYdaa5dpEsYvTZGgtJtN5mPKASkhoZ/5lYq/lsBxIX1JTjahzVkz4ZtbgAB52f0JIokjkSLa2tBykoDiSO6Tk/pXN9hKugdsLrjcZYOymVH9CaN9JahNkvcOeg4b5vME9OU/MP70JMsGPIUOy1uD8jmvUFxbS5DGM8hJR9t/6ZpkZV0LcbVM6yW6l5LUls8zTyQOYfof7VX3BvIoQ4Raybu1uNllLy4hOWSepT1x9u30oxWVOFSF/4iFFKvr6/etDHNSevP8AkxM2Jx/p/g5y4pQlydfSGis48NrBPRA5cn8tzS5ZWLreXZYQVhxYaYbA/gHlQB+VNn8Q9i/ZE2A5b1vv3e+BTXwoGSAkhOU7fxZCcexNBGp9HJ4aabgSnpLitROlTaWgQWmyU7kbdUA9e5I9KjnF8pMKMKST8gDqCV+2L+5ykfDRv3LYHQ4PmV9z/SrjUzj+mrS2w80WX5TKHUpOCC0ocyVH6jG1UFuQiO4lBxsNs96qL9dDcp3K0FFGcJHUqPTP9q8ocml4R2k3fhE7T0NUmSqc8FfDsryVAZyvqBVter048vCMhavIhH8orytDVjtLaQMOEDmOfmVVTFS7JcceIKjg4A9Bua5Sk7BivqSssWZBihtDZ/eHClK70caXZVf5YTIuAQQMlKl5WfoDS+isuSXfFWeRJGyE0eaN0wp1xufJSUsIPM0k9Vn1+go1G5JHJ1J0MZFthtoSkBRCRgEqOayo3jH1rKtpHOKA/h5NLF4QR1G9Op/WkuU0Im4B2OK5/wBHPlq7skbZOK6D0tpSVfJaVNNlSQM5AqOXCKuQ+PNy4x8kVbRyCRuaqtQxUJaCgMGjyTpt5m4pjuNkKz0xVHxCtBtTCOZPKT6ihjkTaSCcHG7FmcpeFEVqaKwk4ofcV+8zRRZAChNUtCVovYjaypISkkk7Ad6Zd3ktyoTFkadCHrSgsFtWyXF5KnSD685I+iBQ9oW3MztS2hp9SW2VSmytSumAoH9cVth26TL1K5GKFGU9KUjlPUrUsj+pqCat/g0cftX50dycNLTGa4JWmGttLjCUcrpIBBWoFaz03wpQ/KuM/wARWj2GNeXRcRKmpsXyvNL/AOMgJ2cR7gEBSfYEd67whtMad01BsKG/3UOEATj5v4VHp3UVGuLPxNL+O1LcJEZK1SoB8OSgDzcgGEO47jHlJ7coz1rGySTmmjf9NF8GmJ7h7BEdmXLCCp6KFLbUDgpI3SoH1B3Hpiu3eGHFFjiZpNuS+UN6ghpCLgwNuY9A+kfyq7+isj0rj7hqGpVh1Mv4Vt9SY45XCSFNcysBSCNj5sAg9QTUiz3+5aVcNytklUOdFytDid8julQ6KSehB2NFyakM4px/B2Xq7ifctI6Qua7TbJV0nFAQy3Da8VxKicZCRuQK5Ru/EPXS7o81cLJPgy1kuOF9scyid/Mc7Z2p1cM+L1r1+yyhQTbb6U5XCUryunG5ZUev/IfMPcb1q17wzuWorlIuVuZBbUApwHrnGCaY7bHennjgmpLvyKqx6v1tNBZVBtyXFHyLddJKR6qCaYdrVLEJsT3WnZWPOtlJSgn2BJqptWmpNqJDuyxscCrRXM2NzTFa7F5HGUvYjZLfDaCR+lBOprw2lKFFIQUL6qPXO2Kk6t1VFscVS5DyUegzuT9KSWodSytSywUhTUdCuZDY6k9ia92L6KDU093U0ySltBS2HEsjI9D5j+lAfEkhMJtsDCWlD/SmiG2EB1bYwpa1rCCNwpR3J+lAXEOylVndUDzEEEn771Rj8WR5N2Dun7u5Csc1hvIEpQBUFEcuM52GxyCRvRBb4XgsJUNlFO35HH9zQ3boniSUQ0DZrlSrHr1NHS2/AYccUOVKAUpz3PejfYlbF1r4LcKGGkc6nFtgJHcgUU6bkIRY4XmCiyrwV/Q//f8ASgjXM/xZbRZUQpDhVzDtgYH96s9L3AOtqjLVyCUjlSR0DidxR17RUWuTCqa0mNIaJHlLh3qjW4uJODvvuPp2q88RdztTi1JHjNKzgeo2IqK5AMtlaxudlj+9DFjHEYmgtNOakszi7MeS/W1XxEdKTgvtKOSj6hW4+pHejHSeoFTbsoXB0RC/+6ccdGEsuJzuodhjP5UuOEmp1aV1LFdUohDawFjsptWyh/Q0Z/iT1lY7a7IehxkPOucrE1xlWA4TlWDjbITjcdaovilKPZE48pOEuiJo9I4pcVL1rBbKm7Ra20wLU2v+EYOFfXlJUfd32peXizt8ZOLk6G0+r9hWkBl2Qg4HXzBJ9VK2+iSav7zxCZ0DwaTAtyFNXeaD4JSnzOB7KvFG3XG2PUCqA44PcJvhlqxeZ4K5CgfMXljdOfRCNs/X1psVa342xEu2/nS/Ao9esWiz3i5xrR4q46nlIjKdVzKSyDgqJxuVEHHtVLp60lbomvJ5W058PPc+v0FOrSPDiKjhldrxf20JmXNsSSp1P/4eOkgoSNtiQM+u4FU2l9JRNdmXc5pNi0nCB8R1oDmUEj/DQT1IG5Udu3WuuL6XbJ5vlqPQrLs4u5TuRCv3aNk56D1NfEjxjytrJZSnlGBjb39cnetslthCnGIhWUvLOFODzJbycA++OtEVg0bPvLeIUclhv531DCE/fufYUC+Ecl/DXFdnnSlq/a91ZjlWG/mWrl7Dt/amzJWlCAlACQBgAbAVV2azM2KKGWE5V/G4Rus+v/apElSubNUQjxQhHguryd6yoxWc9qymWwrASwrcbukYI+ZTgA/Ov1D4R8G3LPw6iXhxCXFuNha8dRtX5aQH/BfbX0KVAg1+gvDr8VioXCmNaVtnxktBHP67Vj+sjJpUa3pJwhbfYTt2Ji46tLikJCEE9qVX4k4jLMllLPKkdDirmFxSJK5PLhSt96XPEq/O6pkB1fypqf06kppyCyZYyg4+WKh1vDoA6Zops48NlJocWP8AecY70WWxseCAPStxmWE1omFtxCs8pBp/8DdMo1zxGi3F4JDEBBuEpxQ2BCe//WnP/VXPEBolQrpjSEs8L+EzqnSGbrqTDhzspuIhOQfbmKs/RQrPzNLS7Zd6e299Icmn9VJ1beNbSo6/FhxXWIDBPTypUVfntmuSvxbRJtq16u6Q31IGQ2txlWFNOcuRnHTmScj6EV0H+Gh1LmgLn4qCHJlwefCvo2nIP0H9a57/ABL3B6NxDvjqGxIjOpS29Hc+V1HICAfQgjII3BH1rHyR4ZVRv+nblBsE+G9wjuad1A9IUhmS+0kDCQkOKCwrYY6/SqzUjjjENxTKApLgKF7/ACjff9MVEssdxOmxIabZbab5l8i8l1W5BOemegqrvd6LjDTW4CnCPyFFxtpoPnSaZMtUdanY6gogIUlWUnBGN8g109wz49uPWqRY76+lq4M5ESa8cB9I/gWeyx2UfmHXfry+xq2zWGO6u4TEMktKCEgcyiT7UGal45xvinlWmAt0qOfEknlTnGM8o3ooxnKWkLllx44+5nZcrVUZb7hdcTkkknIpca24txIJdjW3EqSMjKflSfc/2rju5a31Nd3W7tIuZiQIslCkblLZdSQsISkbqOw+gIzjIrsTjTw7jTIlu1xp9Acs1+itzwGhslTiAo4+5P60+Sca5HMWSOW6QpJc2Xfpvjy3VPOHoOyfoO1WKI6IUda0pBc5Tjbp70OydRwNPY+Ld5XCCQ2kcyiPXFUbHFePeLv+z4rQShSFlbqlAlIA6kDYUSg6s9LLBOmwpfLVpirfkOpQXTzkrPbGw/KgHU+sIchhUZsF4LIBUfKnr13od1xrN9N2kQiD+5ISVL37bY/ShODYJt0lO7relSFFhlSj2O61+wCdvqoVTGFK2Z081ycYIMOG7LtxcmSlK88iR5D7bkn7D+1HOonVKjYB8p2Sn0G9fdM6aZ0xaEN48wTla8ev9O32Aqlv9wJdKc42Ow7f+HFBfKVoclxjTFdc3RI/auMlTTiN/bmINSNOLU6wEJP7xJBQfRQ6f6VWQ5i5bl0S4AlCWQOXHQ+KOv3zUnTznhz/AAB1V09iN/7GqX1RFF7sZOmLw29cJDShy+Mnn5FdldFCrOEQ2/JjY+XzJ+lLuRKei3f4pohKioOJHY+1HsS5NvmFPZb8RLp8NxP8ueufpU7jTsrjK9Mi3AORXkuoyhQOCR2NDc3UpTqJ2HcGEuwphS4kuDKVKPYj05hRzeoodQVpTlJGFY/Q0I6h0+bpalJSnmkx1Fxsjqe5A+o/UU2NMVPXRPu+oEX/AIkxnZzbNrjW+OlyDtlk8h5genQ+bA7EAVrkLuHFXi5BtE2KWYYe3j74ajpPOtZ2/iSBv7gUJzJqHo6HJDLjzDrRV5R52XBspSc7EHumre3ahnaZgDUtluaZFyQ0WOdr5w0MgoWkjOMAH7DFMTd7J5RVWv6DN4uXBWrNRRdCWdeE8wduDjXRtI3CD/yjc+5SKqOLOokaV01F0fY4oMuW2GEMNp5i0yTjpj5lnb7k1U8HtZWbTumNQaiuLTq7k/I5EKfXzKlqwTyI7gc26ldsj0FEXBzSM3Ud1l67vv7x+S4oQkqG38pcA7AfKn7mrF9u2Z7Sj30v7s1aa4FWiPaoK7ul5y6Ac8kNu4QSf4PoOmR1o7usNmDZ/horKI8dtPKhttOEpHtRC9FJOwqq1HHLVuVk746V1pLoTuVyYtHyEHHeoklZcGakP7umtT7JUg4G1eo4r8ELy1layg5O1ZXToukjlIJplaMuzioaW8nlT2pbuDlAos0bLKOZGdqVNc0M8DttF9YejBtWOYetbp8Ry4MHwhsB2pdImqZOUnFEVn1ouE0UEcwIqOWGUdxOxp9la9BU3N5D82aJILamUBKhvQ+/dUzJniBPKc5q5jSXHHW0IQpxSyEpQkZKidgB7k09yaqzyoaPCqwsXa8/Ezmwu2QQHpHMcBQzsD7E7Y6nIA3OxHxT1G5e9UPtLcUrwkJZUOwwOZQx28xOw6YAoaRcxZrhadMRFgojSUPXJ5B2fkjcpz3Q18o9SFK7ivtsB1JxC5FfJKmjr/KpY/tmo3ubm/g0Y6h9OPbdHStihK0lwwbt7BUiUYJU8pPUOupLpH2SECuZOLd5F/ejy0Zdckx0Nq9edOUlJ984375rpq1XxvVFsdkxcnxbvgJ/ybBH/wAQa5c4hQEwNVPRWApLMZSkF1PQuJKjkbbEAisV+6dyPpIJKFRPF6tcTSSIsK5y40R9UYPKhKcSHyAk4JSfk/6sHBrnLVesZ9ymOR4objMMrUkONblW5yc/6Ve8Z/FumoGry+tT78zmTJWs8xU6jbmJ9SkpNAjighO6SB642q/DClb2Yfqs8+bh1RVzJC0KUpxxTizuVKOSarnpvKnmODnoK+3B7ndWe3aqvxM9elXxRB4DzTXw+tdLydPuBTNztypF1tziBlL37tPjsLHbKWkqSrsUkfxbdZcGOM/7T4Fad0JyMLuMWBKfZfluBCCy26oBPmIGwWTueiehrjnh8Gv2lKkczuW4rqUljHMFKQU5yewGc1cMsR3pun47jiRHYCwpTmyAPGJI6bnHbvmlZIctF+DJwqVbN3EYGU7cHBcBcm3JhSmU0nkS8nBOQMdPbpQxaUJtenbpKQnkcecRFSodQnBWofomiLifI8XWl1JUlA58ltKQhKTyjokbADsPeh8p+I0ZM5T549wQtaf8q2ikH/3II+4psV7UiWcl9R/azVfvidSN2+5xWlPvPBMKShAyUvpGEk+y04OfVKvSnfpTTrNtZbQpKVyWm0tLUBnHKMkfcnJ+oFLbQbDmj9MSNRSwrE51Me3wz1kKSo5dI/lQTt6mnC22qyxkoLRW8Rzcg+bbJyT2Gd6Tlf8AxXSLPTr/AJvt/v8AuZe2+WIlwuJDXMUpTndxQ6/Ydz9qT+uLi/FlRG4wK3XXPEUAM+RP+ppgXOWUtOOPqAISQB0A67D2pWXaRcr3eGBCWWGHEHmd2GUZOT9AN/SixLezuaWtA/q9pFtQ4uPkCc6FrWOiQlOQPuok/ao8KV8KpDytnHE4T7A9T9+n51eSJ8Sa+6FxVKiYCG9gUlKehKcff71SSLFIXIW7Ee+MaWclCiOdNUpqqZHau0ET6xc7eXWv8aP8ye5T/wCf0qXp/UJYVyE4BIK0euO496oYDsi1PJUtpaP4VJWkgKHpUm427w1CXGP7o77fw0tpdDlJ9ocTEpuWyQCCehFQXY5YdCuiehPp6UG2q5vt2wTWMrXHHI+1n5kdj9RRtbbqxeYaVo3JTkg9aUlQ+1IANVxnbdeUSVLxBT5eQjIbJyfTofWqiFYzDlTJkd9KorjZUyptW6Fg5AP649c00rpYUXOK4wpAWVIKMKHzJ7D7Gldc7U9aEqetT6ngwSH2OrjRGdiO6abF2IkuOyrkzGbotCngWAhJCC0MJTnJPl6DPciukeEfE6DqBmLYDETbpEdgIjIQvmbcSgYwD1BwM79d65gffbntPyoqQhaUnxmB/Dn+JPtnr6U0Pw06DmXm8HU0ouMwLespjpBI8Z7G/wD0pB+5IHrVeO09Gfm4uOzpR3yqqh1QVOQVmiF5Hlz3of1KU/BKTnfB2p9eSFN9CwdTgknc18Xz+CQlJNbVDLhHvVrHLUeEsrRkkbbUuTaWhsVbA5TLvMdu9ZVguUnnV5B1rKXymDYqlgkjNEWjQXZ3h+tDgXkjNWljmGBcG1p9aPxoa+hiy4LrJORUZpwt5BHWiOFOjTYgU4RzYqqlxUOrJR0oYzvsCmtkVhZDwx+lM/h2RBRNvjqQf2Y0FsZGxkLPK1/7TzL/AOilpEZPjctMpppcPhxD5fllXV7xCO/htICR/wDuKNDlakkg8b238GzSsnxL6nGVLDTyxnqVBtRFXek798HKEhxtT3gtq5eTZaCUKGR6464PrQtY33LZdIs1kAuMOBYChsr1B9iMiuiuC/4f1a01OzeIKS5YFJ+J+HkJIKFZOGlnoUA78w6gY71BmVN35Ro+mtx9vh3/ALGdw7t9q0LoMTZEr4tUOOLhICkcpSpTf7tJT2PLgfU1zBqLVL1xjv2pZCW5kv411WASl7zhODjYeYg/auhfxHtwNF2tFjtstcufNcMm5vq28VYxyjHYbg8vbArXwI4daec0DL1VrNu3t21ha/gELbHxDyk5CnDkZUMnlSkDfBNY8U5zf2PoOax41JeTirXNgde01IeVEeS3GlNnxi2rkHMVp5ebGCdx37e1LC9hpMAMtpyU7lXv7V1T+JD8RyuIujb1puPbXolvhzG30HmbS20ltZG6AMlZKh0OAD0rkS6yly5CIcYczrnX/KK0MaZi+oank0B9wWtbpaZbU86T8qBmtD9pkMrbRMSptxaC4lhHUgdyafGieGSGIwecb53lbkkVpb4czLtrmXIMcNMttBDLj3kQoJyMgkb5UFADuUK9Kr+qlo4vTuk2DfCjT3hsyFTW1RmXM4dUjZHlVg7j71b3LTUD/bLT8OMtLEd2K2plpwHnO5KfEGNlOKwrbYZ9BRnc9c6db4fSokaKhTq8MyLhIR+7bCivk8MAAqLmO/ShtuZpvT6G7w2hF8uElCVsOTpBDbI5SEjwWxzFQAHUilOTbsdUIxoA9XR0q1JclyeYPeOvnCACUqGQe3sKn6T05bhMubVzW4iG1DMmcwMBaGkLCwPZaiEgDqOarGI1LvFxueoZsZpiPbI6pKfAihltbpPKwnGDnK1A79kmqjSNgl3O06pZYLsm4vRGnOXlK1vf703zgbbqJPTvim+OyJJKfKruxmcB9OwuLnEaW3fUqaSxbhOt0RlP7mOWXEhCMYwEJQo9ep9SaN9Wx4lsuEiNGd+JSCQXldVkZyfp7UwdKcPm+AnDB+K+hCNVXZhCro8rcsIAy3FSR6bqVjqrbsKTN+ffeLi1jwmwckr+YjfBV6ewFQuanN10bEIOGNcu2LfiHJffkM2+LzLekeYpT1Kf7ZoJuUZURbraX/iJjifDecR8qED/AIafbbf6fWiGVqJy6TpyoMUpfcPh/FndXhjbCR2yaO+H3CX9rRkyrhH87uUxInTxSPmWs9m0dSe52HWrOXBbM6S+rKobYqrRpedcUZjIU+6dkR2Ecyz13J6JT7nf0pgW3gJeLnBbXIdjW2QoZUCFOkfTcCuquHnBxDLDMC2RDMmOHdSUAcx7qPZIHp2pvr/DHNjwfGky20OkZ8NCNh7ZpbyvwWw9HCKXN7Pz7e/DjfYyfEi6nK3BvyOsfuz7YydvtVdd9OXPSTJNygILKRhcmNlTf1I6pH12rs7UmhHrA4ptxOcdx3pdX+2NkKCkAg5GCNjRRyc+wp+mUNxOY4L0NqUXmEhtDg5VBJ5m1j+1WNtthhvITGkJZUgktBz5VA/wH+1V/FXQrmjZwu1nUWbe+5yuMA+Vlw9Mf5VfofrVHa9QPXFIYfBbfSPIo7A+33pzj5RFyp1JbGmJ/iNJWgcjjZPMk9Un0PtQdqCzwrjeFyYkhUG4ODmUlJ6n+cDv7it9o1Ah5o+NlLwGFAdVY/uKj6jtH7ZjJchrHxSTztKBxv6Z7ZoYqmHJ3EDrTYJ83iAzZnbepNykq5GnogwFg/xkdCMZzXYOlrHH0XaodhSgtssJKWXDjDu5JO3RWSdqU/D+waoiPqmw3GnZcJtKgHglXiBY8yQexByD9KYqNcRb5GVCujarZcE9l7AKHQgnoarhKtvRm5YctR2v7hFN2Jx+lBuplktKANW8S5uTY6ku4+IaPI5joT2UPYjeqm7RFPoVsao5WQVxdMC2Y37wk771LlIUqMQlO30q9s2m3J0xLZScE1I1TARbXExEBIXjJNSTyrlxRRCEmnLwLw2xZJ2rKt1RDzH98OtZXvqSB+kIgAg1JjOcjiVHsa8JQCn3r2EFPaq6PDDsjxlRhynAAqd4qxlI3oV01NUP3fNii9uK4BzkZBrlIXdGphxSVZPWiyyaq+Dtr1quDbj1rkqD6FN/4jDycp8ROdjkbFPcY9KFFx1qJUNsVdxWGl2eIpZ/fBxwY/y7HNLmk6sZjdW0Mrhhp+HrTVUCzQRPu0uU6EIZYaDKQO6lrUTgAbnA+9foQi52fhNpO26btmQ23HU48+ndQQhJKl/c7JHYGuffwoaLb4f6RvupZraEXqS2hhptXzx2l7pB9FLGFH0HL61ccTdVlOnbhPSvxFynUxGz38NPmVj7ACsP1OepOMHZ9D6P01xUpqhI/iR10Ibz1xcUo5S2kg7+ZeVHG2+CofkKhRuIc3WVgRH07Gk2+0NsFP7UnNBLhaSFJPhtjoN8cx7mt1kh2HibrWZBvs1taISC43FTCVJS84Qec5A5UlCEkDmOMgU3NVTeH3DLTcabd7xFREbkh1+NC5X+blA5EHlSAeTOOX+JWegBqKFRhVbGepnKU3GL0cicYdGucP8Ahi5LuH+7z74+iLFjn5+QK8RxR27AJz/zChjhVwxeuikS3WyVrAUcjonsKvuJOrZv4g+JIvciM5B0/CBj2q2HdTbQOVKXj/iLO6sfToKOXLrYtCWu0yZN9beW6HFKtNpeSuUAkEDxD0bBOR5t8dBV1yhGvL7JcGNL3y6DG1WS1aai/wC+r5nEpOGUbrVsdsY2G3U9Kia/s9w0fDiSPjIUWbJgiVFuD5J+EUeqWGkjmWspKWWxj+N1Q3JNLyINW8bb+IsFCNN6ZSlTz5j5CQwCeZSlnzPKO4A6EnYVT6r40X+46oi2nT8HncjqRDiTJDXOUpbCghxJ5RylCMkHtueu9Djb5dW/8DpyU/NIC9SWZFha1e3fGoNrBRHLVshOIW8xIKi4y2lO5SlCSQsE5GcHfamPwT0Va/8AYpN8u1tXlxSyy69yttqRvlXNjO5B6em1A/Bzhoxrt6+XCapyWp9E1wOOZJVyoJ58kblR9acGitBXK7WSIhtMmdEYaHhMoSt0NJAzypSBtjP60eWVe29/6J3HilKuyq15cbXf7AbDAgLUyuQl9ZgNcgKhkJGSCV79z1zTY/DdwihaS4jONtRQ/LsrPjXaQsBZjOnduIg4wVAqSpZ9QEjoag2Wxv2GXHdt8Jb95blNpiNS4/KkPc2ApSMZ5U9fQkAV0xpDS1v4N8MZTr2DOnPqlOOPnLjizkJKz3Uo8yz7qNTOXtpD/Twt8pIT3GePGjvzrlcZCOZSlENpHlYG+EJHdRzkn1rj7Uc25aitt6u8aM4m0sPi2xGkJKlOyXM5J28xCQfuQKdHGDWkW/3mFbFLlzXp7/IiHbkgyHUZPOpOdm0dis+57GgPUfGC0af4hWSyaCtESXZrBKL/AI8oc7T8gEnO3VCCT5uqiB2xRYYtK2ir1GSPV0gx0F+FebCtsOLcURrWppTPx064uBDa5Tg8kdvbK1IBPkT1UCTgCnZwA4OwNZSrlqZ59b1n+IVDtyVDl8Rlo8oWR2TnJA9dzXPmt+Meq9dXZm8XaW2FwEutWqFEa8GNFdfBSXEI/n5CpRUST03rqLgDMlp4a2WztNGFaeUtuSc4U4jJyhHpnoVe9Ne9t2KwU03BUh+8N7DCtsd6ayw20mSshkJGOVlJwgD64Kvfmoj1G+2Y577VRs3ZtllCG8JSkAAJ2AA7Col0uocZVlXamKSUaQLi5z5sUfEqO3JLmE5NIXUVuxznFP8A1kkOocPc0lNRNkFYIoI9svb9qEtrLTzV6tkyC+MtPoKDnt6H7HBrmCO3JskyZBfA8WOsoUhYyMjY4/rXW+pXm4qHFuLS2hOSVKOAPua5r4nP2yXqVE63TWHi83ySQhY2Unor7jb7VoY3yVGR6ioy5FW3dWnnUKCSy4ThRB8pPY+xoqtctLo8PIDvYHYK/wBDS6WplpXKt5AzuKJYclLrSZCFI5m04UrxEgK+3r7V2S+BCmr2OPQmqHLPcEOqWVNKHhvNnry/6jr70x7rboN7Vh9luQhaeZK8b4PcGudIF6ClIUVFLnZR7j39qceh9QoeiR2HlHyK5UK7FJ6p+oO/0zTYTVcWT58bf8SHZ9DDukLjz+d+1ueTJ3U37fbtRQ34LqEvDlca+YEHYips2CleELb8RtwFKkkZBoLdUnTN3dgP+IqE4nnbVk+QHv8A2NDN8FSFY6z7f6l/cNIOqosGQs/DAAJ2IFKjXF9eul7cdbygdAKNmWDMtbxbAUtCiCoelAN1iFuSrm61PiglLkcy5ZKPBlGVPkk85396yphaGelZVlIi5MVhaSQCjrXnBBwRUhtIbJONhW1Ljaj5k1RYyzLc58O8lQ9aZNmuzMyOltwhKgOtL1CmOw3q0s8ksS2FFPOlK0qKP5gDnH36Vxq0c0+xl3i0JtryIxSQ+EJW5nqCoAgY9gR+dEegWY9qfbukmMiUtlYRGZeGW/FOSFrHdKB5sdzgGt+rtHXy4Xx/UEGHIvFkvDy5USdCZU4gpUSfDUEg8i0DylJ9PSmPw0/DxrXXkBtJtp0/aG1rW5dLuksN4UADhJHMojl7DHvUeSacFTK8eNxyNV+A6YvptblitK5Dinrsw/OeWs5UtSt21K23OEk/fFD+uI1+u0V2HbYC7hIZDsgQxsnxCei1bBKQBkqJAwOtOm+2XQvCO1MqnPf7QXyLAS0uY4OUIZQk4JAz4aSN9vMfak5B45WTic1LNwMmBpi2AuyIbbIaiSFAkpKwjK3E4weVZA33Pavm5x97ktn06yrHiSf9CVoXhDN/2AeuOodWpM2SC69Ka8lrhMjmK0stgBLysZ/eqHIntzdaQKNMXXjbdg1aEux9G2p5SY7743cUTu8rsp5fX0SCNqIeJHGpvjLdha0SpFr0SxguNNIIen8vRPKMBLQx0JwPenBw14rQNMWiHa9F6W/bU9Gc8za3fDO+zaGxyj3UVZNUQTh7pab/ALEmGEprk1aPWj/wivy7C6iTKc03BcYUhD6UZmOZBwUA/InuSfMaSyuDOleHl6XZLWx/tlq5bpQllSueLE+bC3sfO5jfl6DG9dF6r/8AWLiEWoVyI0bbJiinwo4/3p1P8WDklIA6k4oNXrjQn4drJqMLt8h24NNlqJIW1z/HrVzJKeYjI8wyVddgKam37Yhz4wXKdE7Wlt0vwq4Z2dVyU5LvUycFLXEUkvyEBs+PsR5UjPKE7cuTSV1Tbn7XpWfqW5RGLZPuDBgWu2sDCIEdf8Cf8ygcqV1/Os/D/Y42s5wul6kSJ0h6S4858XlTbXKorUnmI6ZBWtWw2AqPxevTvFziVbrFpZS51vQ4GIqwnAkOH5nMfy5/QGmYYxTbfgTFScU/LGR+HTSbVjvdntkyAIhfghaW1DzOtqSsFZGNvmJ+9O7S9i/9OBcLAy2pl3xT4bqRvy4PJg464zv03NWfCngM1oplNzu81266hUzyLlOKyEbfKn9B9qqvxEXi9P6PZjQG2Lfc7nG+HVNQD4jKBs4kH+ZWUjI3HNU89yciyUbSivB50JNsUjU98kICnP2UgSJd3WQpls8xBaCyCSoDm39zilV+KbjcqW2wwyJTcVtPN4CWy2QFAhOc91DH0FM7S2joHADg/DsQbTO1DM/35xh/ceKRst3O4Q2AAlJ+YjNcPcf9Yt6h/bTMO4ruMiKpK3ZvXxXFLw4sHHQbAe1chDlkS8HFJY8Tk+xVa+4t3e+3tyDbVphsqR8O78GOUrG/kLnzFIBIO+DvtTM4c8P1Wq1Qpa45lvSQHFKQnICOUqSjp3Az7Z3oP4R6F07ddM3hVwt91cv0p9uBCuAQkwY5WtJIP8RcKQ59BjbvXVFqsyrVOTp5lKYJjtIW4tagktx0p8RW5HRKcZ9c1T6maivpQ/qZsMUs/um+wIOlVXPXtssIbCSwUF8f/muAKV+SSlP511rwshrGkVWvPJIt7qk8p9Ccg1z1wajq1DfLxqt8El2chTSvUlYUSPonkH510Nc35Gjr/wDtNtHNCkjldCaDpUzUxx4xpBpCuDqR4bhwoetbJUtS0kZzVI3fIt2bD8dYOdzivkq6xoEVyRKfQww2MqccUAB968detsrdQOAoUVEAeprlzjLxog6YeeiW5tuXLGR4qz+7SfYDdX9KYvFjjL8ay7pvSKUSblMbV8RcXfK1DY35lcx2BwDlR+UepIrkjiFpgW3U0tEG4m8RgE4ubrRQl08vmLaDvy5yAo9hmix7ZHnztRuPXyL7WmoL9q9x6VPmKW2k5DS1ciR/yoFA0gttd1LPr0H2onv6XHJDjLZJx861HJNDcq3lAOTk1qwWtmHPIpO0aXHylSPEbPyAgg9u1WFnV4bynkkEAY5T0+9QlMKdYLnXw0DJ9s4rQ1L+EbeUD5iOUUdWjvKpbGJHKFtNqaOEq7H+E+n0oq0xqF61PFtXmbUMKSr+o9x60stK3dx0LQ4AW0DcjrijyB4ctnAUCofKsUiSouhJSVo6k0lqFGpbQxIbbCHAOR0DssDf8+v3oc4kxeS5W57lGAk5OO3MP9f1oJ4RametV1VEWseC4QhxtX5BQ+h/rR9r192ZdI0MsLbBKUJUsfMSrcj22oH8CY4+M210Uc4P6fKm2VEQJIwR3QrrjPpQlc3/ABXTyjJph35gPxHGlDykbH09DQbDW1BUpbrIcdT2NHF8GS5H9WHPyu//AIygMSUTkNqx9KyiFWoHSokMJxn0rKPnL4JPaJiQyhxHO3URLKubpVraZMdLakPDqNjW34HxFFTe6arsPpFYzHUVjIxRhpLTCr7OU2p5uHGZaXIkynQShhpI8yiBuTuAANyVAd6pGmfPgjFFrbTlu0mt4EhNwkeAcd0NALI/9ykf+2gcn0g4Ru2/A8fw3ajmStWptNocm26ys80mVKS8UPlpPzOOrTslONg0kYJVuVda6q1PxjauM+VEaCJibbs4yokttyMcyQs/xFIOSTtkdM1yFwKuDsfRl5iQY5MyTcoCpBbGXXY6S4fCTt0LiUZ+tdG6I4bW/Q+nrtqjiFc47DSnHLjOZWQiO0VHosj5znACR1O29Yvqp1Nxj2b3pnwgpS3YobxpHU3EK53i/Tr8dL8P0gqud7mq5VSgFEnwUn5iememfXpRNo7hBceNzNst9ttreieDUJxLqBPQr4q8gHPiKQCFK5sHc4Aznc0w2uEGqvxES7XqnVCI+mNARX0yLPpO5NrS7ObTuJMtCSOQEbpbPQHcDO/SVlahqic9qS2hoIKEPpZKQEgHdHNslI6ZrmLC0lz/AH/sCWT6jcn+/wDQn9G/ha0G/rbU8p7T7DUFuQyuHbkt+GyylbCVYCB0GcnGT1p1RNO2rR1v8G2W+Nb2EjZEdoIH6UM2vU7ELiWi3xZSp/7UYUt1SUfumfh08o5V9XCrmGT02q91ve2okblKwDjpTOMEm12N5ZJtR8HMXG/jxcOH/EW4Jm2dx+I7EaZtstt1IDQOStzcfN4gAI9BXK9p0TdOK+pEMOuy5kdb6/hEOjmddKyeZzGPmIHLn79q6d4qcP4vFjUMD9y5ImxwtthKDsrmIykjvuAd9hTV4U8MdN8CWPibvPjyNTSwEnHmU2D/AMNtHUe6jjP0pUZOSpaHzxRi7nv4Qmtb8L2eDmk7NpVTRZm6jZcRNmMNkphQmsKcZQQD5l9D7A1G/DfwggadvTuvbutq3ROUotjEkhCkII+c5A7DlGOuCa6l4i32cy3b4cm3sGJLfDao3+LKU1k+KrOOVoBPXck0D8P9ARbGq5zFTZV1cdeeEQSiHVRYwzyNIPQA5Pn2OOldUN8Y9Axy1HlLsoeJH4jbXopTCI9mn3eN4qG5D7WGy0lRISUoV51ZIONgD61Mbv1vvGoIV0mREuRLZFVOKHwNnCSQDt1GAMeuPSqPjVqnT9rssmS7LtwlMviW+iItLjpLYPKHFYJPKQMAnfJ6UrIeuJV24KzL43GWzLkEMuRjsQA6rbp/Enl396ny3BoZjmp2gF/Eb+IBU/VV207E53Lk/EU5IlpV/hOFJPJ0/hRt6eb1rmL9ivxrDLnONkeOAnwiMZbPMcH6nG/tTV0fY2dX8ObxdZkCVH1BeLnIW/OksgNKSlJDSWl4zsrm5hsOme1LmbqKS7AlWybH/wB9i8rbrZG6glWAem42xj3qjGuNxj9rJ8kudOX3oeln09atK6W07cY09qNbYiA8zbXsplOynQo+IUYwVJ8o5iPlAq813xQi3aQoSbXBTL/Y78dBSjC2l8jjaN+4/e53z0FI7V2sFah1A7PvvxD81xsfuIZDaI6QCA0nOSEgY6UILvEv9spUVrLXlHnVkpTzjAJoI4XJqTJ36ip8Y9He2kNNxNM6TgW1rlT4bI51D+JZGVK/Oq3XPE1blnUgjHIShYPZQ2NDl41oqFa2nQvI5AevtSV1vxKaRIeKnMsSxhX+VwDY/cf0pii2aqkorY3NHcUkwXipbwSwMlWTgADcn7UieM/4jrjr3Uy7da3yzaGcpZHNypPXLiz6kdPQY7ml3rHXi029duhKUXZQ/elPUI7JH1PWqK1BgPhzwQpWAVknIKx2H+Ufqc02OJRXKRl+o9TzuKekPHhprONYVtRJlqF/trhLrjMtxTRfd35XFkblKf4Wztvk71D4j3tm8S504stRPEKl+AwDyIHZIz2oW0/deZLqspQQMcyulQtQrVIYKefKVqyVHpip1H32Zcs0sip9Ae9GBCldSo5qiubAKVZ2o8Vb2EMKOckDqaE720iPAemOJJRzllltO3iOYyrf+VIIJ91JHfa+Em2JUW3RDNtTEsjDnMX/AIlClKSlOyRvsT6jlB+9Cd2iLiyg0QeUjnSrHzA9DRTYZ70yJMYWyVtsJ+ICmkeVsFQSoHbYHIP1Fark0/cmWGyhHhx3eRISnzAKO5J7gYFUxdOmUzjcU4knSlnLULxFjzO749u1Xsf4iC0l9A/dk8p+voanRmksoSlCfKkYFT4SAylSFt+KwtIDjZ7j19j70D32UxXFKjxZ75zTkLSFIdKCnHr6Ypz6T1adXTYLlwkAzI7RQ2kjHOenNn1x2pGTbWbfIStlfOgnmacx19j6EelEelJiRytuZyTnI6g+opbjYb90a+R73iK4pshPy98UFz43hS2iR8/Mgj7ZH9DUtm8XJpDDMqTyx3PkllBUkj1JG5/rVixY4js5Dsi8x5aR5ktRkqUtR3x2/SlOTVWTY/Tyjy+GqBZeyiOTofSsoue0wnxV7PDzHbwDWUX1ET/+Ll+DnVuGAeYdKmNOra2wcVqCuU7dK2OSS4EjAGO9aLTJTegKUsbb0zrbYH9Q6Ct8SKypyZEmFSkJGVFMhAKTj6tfrSvakHO9dy/hz0GzY7hfNS3Dl8NxUZq3MEZCUtNDLpHqCcAexNRepyrCk2X+mhzUr/H7/wDQUcGeDNv4JaQe1FqiS1GnpjKelOu7twWhuUj+ZWSB65IAprcOOEM/iNdoGuteQlRLREWJWntIyE5Ef+WZMT0XII3Q2dmgR1V0gaGDHHPiUYz0bn0lpGQh+Y2sZROuAHNGZPqhlP71Q7uKSD8tdLzZIfcDaT08yjUmDHy/jT7ZVJ1UF0ink2xN2Mtl48xkJCZC+vI1nPhJ91fxH/tQvqqbHuMRLCnnLZbHHBGSUoAdkqGQlDScfKk7Zx71aXqbJnzl2y3yzb22OVcyYgArSFbhpBPRShuVfwj60GWbUDV1vN11RdwWmIHNGtjLg+RsfM8kHqpZGKpb8HYrdooNUSY3D+86cfkKhi5fGPxSxFBKmY7rZ5Q4sjJUVoBP1pe6z4jv3q5lhlRW4rOEJ32/0oW/ELrm4vIjTGURY6kSEXVLMnIK20uhptCABuslSjvnYVmjeGataaTdVd5kmCi4LUt9UJ0tPPDflQVjdLadtk/N3qDLTejW9PJxTtbGDoa9RbG6HFOJbmyD4ZecWA4c58raeoGRucZ+lEmq79p6zJtIvSA3bpl0bQ+ltBUtwI5nFA4BUs8wSNuudqTWnNDMNT4Me0Q37ZeoV1daisKY53ZiUghXLzZ5kkHJcJCUZJ7iukuHPCI6Zko1JqBbd/1UGvAiJwfhYCT/AMJhJ6f5nT5lYPQYFdwpz14FZ5KDt9kPWWor5rCOxAsFgbtsmXgsv6hQfGDWVDxfhkHKGx/M8pHslRoc1dwrUxap7+qdWXO6QY7ZLzEdQgxFOkE8gQ0MqSAcnmUdhinmxaBbWHUtnxZ0pfjSJSx5nF4+Y+yRslPQACuSvxa8TZEiW3o60qJU4fDWpHYZy4snHXv7ZA6mqMsljVvszk2/wc83Ix9VX592JDRF01EdKYsJCcJfWCcKI7hPXcnc47Vft3ZbkCdan8pi3BHhrVj5V5JQv863QGWG4zLLbIZDaORLePl2O31PWg7W2o4r4btWn3JEm7gkXCS6yERbfgnZKs/vF4wQB0rF3kkBjyS5/UXgUjmorrorXVztUBv4lM3md+AeJLJUoEObY8vmGSodQMVVcXLGXLe1IedTJvEl9RWtkeG022lOfDbT/LvsScmmHrdMWCUSmWG3XpLbbyZBA50qGULOcd+496UfFia/IMBIJZWlxawlJ+XACQPtitTE7lGinLqMmQU35xduZTKUH3kthKlq65SMA/lQ5MvSRPbcSrASfD27gnI/UVFduHichWOV0ZSv0UKHZzvhcyVHzBWB9quhBWZsnbUkdUXDXzdy0jECF87qmgMA75xST1W66jmekOYCleVruo/6VZ8PJaJ9qUsuZU0eUg9qXOrtTm536QpvdltRQ2O2B3+9DDG1KkX5s38NP5NoZdS+JiyeZeeUn19R9K3P3hcVLTbB5SB1qsZ1UFJSh2Mh1tG3ISdh7Vk1wS7ggtJDaFgYApyi79yMgP7RcM2lDz55QfMqsY1/LhXaJKgpbQYjodb8VsOAqHTKSCCPYioqNPyZ7LTbTzXghIwgqwauNL6EBvbSZzzUeMpKgXnEKWhCsHl5uXdIOMc2Dy9cbVMuF7DgvcqN2mtbW5F/U9cbUXA6laWgFZZafWcJcWkjdCck8o9BV5xZtemoGqW4NoQ7dtLQmvhYFybOfiQndyRjuXHS4rBwcco7CtcmFp3SeoviHYMN6IylSXfCmPOqZUUqzhz5StIIxjZWegpcXm+2uTLLcVMyFFb8qQ6orKsZwSRjG3tXoxUpXFGj/Li1KrJUqOXbn4VudZZiKOyGlhCQADkqB3JHWqyPdUwL1EkOw/ioTycqaWSlKic4OQNt961O6lix1pSZDbwxsotEqb69DgevepL8V5drakoUDFkLcU0tH8XLso9PcAj3qiNxexbqS0FcNYeccbASFglOEHmTnJ6HvRtom0ePdlIdQFJ8MghQpV2m7/sp6Et5r/dSvdY6o3OR7gE5pvxJS40lKmMoW4PKU9cHNcb4uwl74NeQZk2CTcLtJhRAVKQpa0I7EJyf6VURJRYfTg8pBzTV4aNJe1rcHHEcxjsrHr5iQP8AWlzrq2i0amuDLaeVCHlYHoDuP61xnVLfFja4fa5jw4LkORFanxJCSpLbu/Isdcf+Z9Krr1r242ea+beoNRiSUoTjnQN9ubGSKWOn7o5EdBSTyhXOPqP+1Wt6cVcXlusq5UjoD3oVDkxeSTju9E5ziPNWtSirckk7/wDasoTLL4J8ifzrKZ9L/qJ+p/3InNzKONsVIZaK6jDyr5VJIIO9WCeVSQUDlNW2Qk60Wg3O5xYoPKX3Ut83pk4zXZTPEGLp/TLriFp+EhRysYPVKEn/AE/WuM405duUJKfnaBWD6HBqtc15JNmucZ59xbbsYthPNsCSN8fTNZPrcMs0opdFOKTiqXk/UP8ABvqmLZODrK5byBcp8l64y1E4K3XTzH9OUU+oOqmXCVqdScjmVv8A+dtq/O7hlrNdss8ZhtZ8MJGw+n+lNKJxInKcW4h9SSpJSEg7Yp1Vo0lBNHRatbW1WnXwiSsz5jrjjqeXupR74/lAFRrxrbT10Yj2u5xHLSllHO064AlHKkEZ5sbpABO/ekqxxEtt8trDc5P7KnhIHxaE87DuxHnSN0n1IyKV/wCK3iZddP2G2WguN3J+7xHG2FQcOBLKCPEV06kAULi2tBqovZe8VuLWkNdalREs6WJttjOto8ZIAPKwFBATtnBUtaj9B6UW2fiOxDtbTMdtSglKGWWmk5W4SeVKEJ7lSiAB71+d7eqYtvvclVtkPKic+WVvpCXCntzAbZByK7Y/BzahqCAriBqG9x7ZBtry2LSh5AWtx8DDkgJOx5c8qNj5io42FSvA2+yqPqVGNJHZ3C3hvI0jFXdL6tErVVzQEPqSeZuEwNxFaP8AKk7qV/Gsk9AkBhB9La+folOyfb1NJ9ni5CtseOUvSZoU0pzxpysurBVhJOAAAcbAdqr5/GUTGZfK8hAK0sJCT3PzGq48YqkQSjObtjH15r9jSmlZ10UtKXl4ZjBRAytR5U/3P2rgu43OINR3W8XG7RZMSctSLc+gh151rJK1hKQSkFRCMHckVV/jw45PTXNPaYhSCGUhc59KFYz/AANg/wDzNc62vXE+HYDKgrTAMUgrfRjmQdwgJ2znOd/eo8+OWSnZ1OKThWxx6l1ZKmXKda7Sl2O624I7z608riVq6oQO2xAKj07UKS5qIUdUJg8rLKiklPRSu6qC9Na1YtAXIYLrkshwqU+RlLy9gr1VhOTn1NQbhqsoYKARipvpNOkQ5WlpBPqOa2/pmMtTgSGZK2VEnoFjmH6g0tdaS/FREk+GmRgeGpKjjG3Y/apES9C8xrlb3VZDjYdT7KSev5Ghi5Slrt8iO7s60QR779asxwrsqc+WNfj/AAVF2kReUKZQ6Fd0EdPvVBOc+IZS8Ox5VexHSpMt5xSCkbevrVOvCXFIJ2VuPY1oQREpdosrTfJVtamMR3fC+Jb5Ob+U+v5ZqmehSGl5KeYdiDkVMjxlNPBTySE4PLjue32rch5ufIDDroaxseQdTR+QqbSTKfwnUZWU4HfJqezOKm0EfMkctWsqDa7e0VLIUf8AOvJP2oXkTFOzCWWghs7BIHWur3HJR4hnB+JMVLwdVyqVyjCu9EVskXMzkRjNebaQQpawo7DfYH3G2KA4lwLIaHOU7gkHtRvbJjkiawgvjwHVpStxHRIJwT9gSftU8oi93ovFwJd0aEuTE8YuuLKYZXyLLZB3z02Oeu5PtUOZbbQ7CjxZTpg3COlTfPIb5C6jJKckbHHQHqaIYzryFKLiFLHMpIcG+UhRGfuBmiO0WmLdJsN6cwh+HHeSo+KMJK9yhGcdyM/bfaplPj2UKTcuIoLpw+UiUI/jYfUnxAhJBIHUE5x2waIWrlDtL9mt8yAiNGgMmMeb/ihalFxwnHUk9ugFEmv4DCLu8tRQpbh5l4wrKsnzDHY/pS9uRMMqSh3I3PhK86SPcGmwm8i2Fy+nJpI3yLjHtN2eh5RJjtOFtagOZJIzhQ232xTPh3pU6E3LYYDSmG/K4nzIV1APsem1KJxhm5RXrggMNq5Qy7HR5SlX8JSO4OOvbpXnTuoplnk+H8T4aAfM2o+U/bvVKqUeJ1txly8HVnBzT6o0m4qcPO94aC4o9eZWSaXvE6KHdYXNQH/Ex+QFH/C3X9nTp919D3NcXnAHGBuoqxhIHt70A6tkqmXqa4oFKluKJB6jekbWg07m5AUwwYsjl/gVuk1ZMPlhs83yg8p+lerkyPh0lI3b3GPTvUA87jTg74zTKqVAuSnjss/CSdwQR61lUXirHesp3Jkn0o/JsbdDrnnTg1NMfKeZH6VBjMKdSVDcipkOUWiUKGd+9dt+BBsda8SM433Ukp/MYpbJKkuLbUDlSVNqSfy/rTWaZS+sYOxoR1pp1dvmiW2n9w/vkD5V9/z61zIrVhwlTHHwu1H8fp+GvOFBASoeihsf1FMuFqEtEZURg5rlrhvrBNku7ltfPIzIPisk9Ob+JP8AenUm6h9sKQrKuuB3oGrNKMw/N9KWXWecYQSpHuk/6GuYeJWpl6113KtzcxwqiJ8CAgLwlbuQVoCu3Nk4PqMd6ZGrdVt2iwS5Ty1tlppZbcb6heDgfc4rlluPLuaVyEguLCipZB3B3UT/AFNConZT6LXwJRvZtyBmUHvAwnfzZxXdegLPE0Fpu1w3HxNbQlLbKmnOZs5J5lY7HJUcH1rjPQXxi75BuwaQr9nvJJcKd3CScc3r9a6ci6gakx0rSwqOokHI+Qn+1dqz0XQ47hrRVynyXufAK8JA7JT5Uj7AVXvajWkeVZGCT96Xjd8SHFDOCd69O3s4wD1oeKG8jnzjrql69cTbktThcDAQwnfoEp/1JoQVc0uOhxCgogBIQAdgBjfb13zXnWTplazvbquqpS9/vVUHeQcqeleaRA5vkwiROHjuLCySfLn1AGK8SJ5cyOYmqBqSQgb17+J9aDiIk7dl7ZXVpnqdQrHI0sk+2Mf3rXJfRPZU0VBElvIQo/xp38v1HaoNum+DHlq/m5Un6ZyaqZ8jL6lhW2c7V5RtlEZ8YpEKW8UOrSsEFJxUE5fWQgEqqdkzHVuEgAdSa0+EEpUWwQSevY1QtC6V6MLpYj+EV8x6kJHX796gpcbD7ji05UtON+gPrWxeVr5cb15nQ/DQnG+epokdtshulbijgI+tFGgNPC4Xht51HitR/wB6s48pPRI/PJ+1Vdls5kLC3MBv3/07/SuiIHDWVomyxkT45YmSkIkLQobpSoZQk/QfqTS8mTiqH4sfJ2xMXu1sQ9RPxeQBkELSPQKGcVd2eOmHIDjKAlGCFJHf3qZxKsrcCdGnozzvpKFj3T0/Q0NxLs4186iEjfkHpSn7loTOLU2hjQpmUhLKeZXfmPKhIGep+1MqwXuzQ5Fq0/qqKiZp6Wvx/i4g8B6FIUClT7bndOAAoKyMY71zlqDiLFakOotjHiJU2G/NshO2/wBcnBoXkX67ahkNiVMfkHHIhsqPKB/KEjbFKXp3Lb0OhKGJ62x+cWtfaF05KELTMld4abWtK3YEYttqOT1ecJU4dx8oCaRN919KubyvBjNRUZ2z51fmanz7vyiJEfYS18HGVFK2kghZUsqKlbbnfH2FVEi2xJKctKRzexx+lU48UYIHJNyND65i4bbvxC1h9J5sbYwelXGhdPHVWqrfbJTziRJXyJUTkk4OEjPrjFfbbHaTYnmjhTqSs49AMH+5rzE8eM5ElxF8rjboCVIPmStJyk/fbemX2geOkxvI0JduG2uW5dnlldvaUkBfOCtIUk+RacbjtmruRKMyUXXfmWolW2O5qwhTGLzbIdwQ3gupSrmJySVZyOm+Fc1QblGwT5cIVnGKnt9soSS9qPj6USC7ylIHQZ6VU/Dhl5CST1KT9KnMJ/cBIHXt96jzkOKcXyDz5JBP9aKT2mJxJVJPo1q+ECiPB6Huayq8uoBIIUT6isp1sTxRttysDKRn2rethZeK+Xr1rQ0nwRkHFezKcPlJ2Ndad6EFxbGwtQOaLWbNAuVouDU8czSoy+QY3CxulX2oOhufDhP60eaq1Pb37IzEtbDLSBhsKQn94pIGSpZPckn8qDK20opdjsSSub8HO+rdPv29fOkHKDzNuJ746j696JNA8SBJAhTl8r4Gys45vce9M2y6Ob1TCQzJt7kiI++GS6EqHhAAlSwoDZSRvnpXMOsojcC7FUNbj0N0cyHVt8hJ3yCB327dqGElKTh8DY8lBSY2+KmphJsCYOAVPuAlwfxJTv8AnnFK2E6uO6EsKCFugtknYYOxqHBWZUZIXzkIBWpSTk/rtVoxEhuyIrT7rsIPo50PqIWBuQOcDoPpRNpB7ex26BtVigWJ4OXFnxnMZQeuR6bf+bUdydQ2yPaVPQHMONJw9EdG60nYqT6jP3rnaHrJrT80xZcDkDR5SGz8w9cEbg9fvVtc+KcA3V1u2RVv28Y8NyUA26cjzeUZAGc/au1YSklpjYjX1t7lBc5VdUk1bszw4gHm3GxHcGkX/t8y4OVEdSEg5AbWCUH1T/pVlZuJ8YSvDde5HR5Slzy847de9co7zQK6tSWdR3HfPM+tX6mqkoIYLgIKckddxtVhrCehzUEh9GQh0+InPv8A96pkSg65gqwVZAoWmTvjZ9bUSAO2K9BeCRUIzAhJGfN0xXsPZaKj1H612hNFnBcCi60o7LTiq2TzBakLBCgcY7mtC3V8/Kz53Fd/Sr6JHUplJkpSpQHz9649bDvSKlmFnzLz/wAtbHTyjlAzU2ShtDmEK2PtUJ1wcxCRt611AbIxQUnOQFfSt8K3P3FQQhKeVH8R6CvjbXiKA6k0eaM0nIuL7DLTSnVOrSgNpG7iicJSPqa6hqk+gp4HcNE3bUbNwmtl6DAIeVzjyuKz5EAehIyfYe9dQcVLWm/rt7iG+eRIioSkY6rCx/8A2rG9AtcP9N26CkhTy2yqQtKfmex5sew2A9hTBiaTj3TQqb1I5xKgsLdjYOAFJGCTtuNqz5uUsji/Bq41CGOM15OC+MKHuSMttolmKtaXD3STtk/lSonwFzoS1IeBdBKvDChhQ+nrXSd7ghd5mpWnnSt1RII2IJzj9aMrNwEtv/p3J1U7b4jKgolln4YZcazyqXntudvoafjnS0hGXHbtvs4bYjeIvHtkVaWtwR1nq2vpzAbj6VYaksh03qObBVshpZ5FeqDuk/lXm3NNvsfvEg5Ud+9X3asgqnRMisqJWpKkuoXvyq2P/etCrYyAvxAUrJ8qAKkC2qQMtOZH8qv9a+OLebH7xJwPXcVygrKa4R3uZPIoICBhPLtiq34mVHJSVnlPb1q/lqDqcgEfrVU+kEHNdB2PjhE4y7aURuYlAR8SzzKyAFbLH2UD+dEVycSt5RTkIGyc+lJThpfnLbcm20qJ5cq5PVJ+cfcb/YU6JrXit8qSVFWFeXsPWp8ipr7j8e7k/B8SgNIStQ8x+VHc+/0qBNQXiUE4HLnPqa3pcJUR5ivuVdTWiW74SyopJ8uMUNU05HFJtNQKlUU8xyySc9c1lbTKUSfKn86ym1D5F3m+EWWsYLFq1nfYMVvwosaUpppvJPKkdsnc/eqkfMPrWVlexu4qxeX9bLZkDAqWvyoJAwcZrKymiTtrRVuixnv2e1HbTCipiMMsco5UIWjKxjvkkkk771+ef4g7RCtGup1thRWo0FiKS2y2kAJPjLOfXO5rKysH0bf1pG7mS4IVrACWQAAM5P6VOksNlmG5yjnUhIJ+uc1lZWw+yJEK8uKePMtRWpPlBO5AyRiq1v5xWVlHHoXPslgkDavCyXTyr8w9xWVldOFmywh6zx1LBUpKlpBKjsPSqVSiFHB6HasrKBds5NLR9mnlmOY23zU23JD4Jc8xHrWVlE+hT7J6AGyOUBP0FTUOrKNzWVlKYLKpZIkObn86wHJrKyiGPpFlZW0uT2woZHXFdWfhat8aVr9vxWUOfDQHX2cj5HMpTzD3wo/nWVlefR6HZ0DrM8zjqFAFLWFIBA8pyR/SiPWDirdwVhiMfC8dpptzlHzJJyR7VlZWfk/VJmriXsh+TlCWyhwKeUkFxTqgVe29PfVzqmODrDTZCGxamyEgDH8P+prKymYen+DmfuP5OBeNLSBeIzgSAs+Igq9QCCB+poLtyj4XXvWVlW4/0IjzfzGXkZRKBk17Wc5rKymiCouSQ2QpI5T7VWyQFJJI3rKyvHidoo41PB/5z/Suh7UALWz9DueuxIFZWV5gS6NbaQbgkEZBUM/nUC/Hmmyc/wD1Ff1NZWVJk/mIohrFL+hSYHpWVlZTiW2f/9k=",
    bio: "フェニックスの力を宿す闘士。炎の翼で敵を焼き尽くす。"
  },
  {
    id: "c6", job: "dragon", name: "リン", title: "竜の娘", rarity: "SR", atk: 35,
    img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAETAScDASIAAhEBAxEB/8QAHQAAAQQDAQEAAAAAAAAAAAAABgQFBwgAAwkCAf/EAEQQAAEDAwMCAwYDBgQEBgIDAAECAwQABREGEiExQQcTUQgUImFxgTKRoRUjQlJisTNywdEWJILwF0NTkqLhGLIlwvH/xAAaAQADAQEBAQAAAAAAAAAAAAACAwQBBQAG/8QAKBEAAgICAgICAwACAwEAAAAAAQIAEQMhEjEEQSJREzJhI3EUQpHB/9oADAMBAAIRAxEAPwDnZgq6V7RwfU0oMcbfQ17DG0Csm1PjOB8zW0V5Q3t5IrYn4eaybPlfVrURtA716OFV9SjmtmCaW0FKsrBIpwZ2FIxXlsngYyK3Ntbj0rIUUIbRt5rc202OcV4aZOa3BojtWTZ62A158snilKI6lY4pQmNgZIr09EKYpUOK2ohHNOjUUkDIxT1p/SE/Us9MSAz5jmCpa1EJQ2kdVrUeEpHcmhJmgXBluGMgYzRQzoOcxs99ZVDUsBQacH7zB6Eo6j74qT7Joy3aYKFwV++3BI+K5LRgJPfyUn8I/rV8R7BNPMfTa3zvcWW9xySMlxZ7nJ6fXrTkxM2zoQGyKuhuRXG0ewy4jzGisDkocOSr7Dp+dPIS3GYLaIraWv5Anj9OKkB+wRYYCQjcs9EAZUf+/U00TbcpKt/lhsHggck/f/aqhjUdSYuTA03RyGUqbixgE9lRkn880+WHxJYizmTO0zaJZSoEOJjqYcB9QtBBB+dJpTcfcQEbscA7MZpqMT3pxSWW45xyUIUkq/3/AErzKtUZqs12JYV7QOgvGeImY3ZTpjUy08TgkuQ318YL4RjBPTzAnPdWetDj3sbaymw39rEF2UysoVEdUnas8ctPN5GDnIzjPoajzQ3iNK8Pro1KgTVspChvb2pfZUOMhSDwftg1LniHrZvxM05H1HY5bcKbAbQifHtUl5rcONrimlDOEk4yCQB3qE4iDSnUu/ICLYSBNdez5rbQziFXDTsxDDv+GpADuT6Apzu+3PyqLpMdSXFIUkoUk4KVDBB9CO1W+0Z7SNxhINg1yU3qxOgIdbujfmpUngZKh8Qx2Iyad9Y+yvpnxdsb2pvDHUK7otCN7tokO+fKYGOja+FOoH8i8K4+FR6ULck/fqYFVxaSkC4+O1awzRTqfStx0pd37Zc4xjy2Tykg4UD0Uk9wf/8AcHimkwzgnGKKBRGjGwxsmvKmQ22c0vUnb1pDKBz14rKmWIiWOeBxXxKM8GtpGK9payM9K2ZEbjYSa8BBxwKVutkmvqWMoJxXptXG91BKCKZ5cfCsgURFvfxSOZC2gKPevdTKjEGa1bQF073CN7opAxkKGabkIDr2BWg3PEVPBC1DjpWU7FhLbQ+EVlbU9qK1IwnkV8PI6YpQHEFPFfCkKGMVk9E6G89TxXvy89K9pSM470obiLWnIFeueq5oQ38q2eTgZreiMsHGKVsW1x7gjAr1ieqIUN8jFLmGCCMg5p0i2LaoEjiniNbmk4ymsu5vXcZ4tvW5yEU4tWhSv4P0orsdlVcHQ0yjKvSn93Ti7bw+3tV8xRULqe3VyORBKDgjFbUsZGMUVTbcySdoANIWbS7JkNMMtqdedUEIQkZKlHgAVhEyzE9msj12mNx2QE5yVOL4S2kdVKPYCpbscduPBTbbYypuESFOOKGHJSh/Ev5D+FPQfXJpttFoYtzbkBlSX9hAkOo/85wfwg/yJPT1PPpUk6a08Xi22EnJwFlPX/KP96djx/8AZoLvQ4iIrbZVyVhLQThP43VcpR/uafGLISMNEgHq8r8Svp6UXM2VtLKGWGh5Y4+EcH5D5VunxW7Vb35kpaY8VhG9xxQ4A6D6knAAHJJGOtUcojjAmTaIltjuPSHER2UDctxxWB9STUU+JnijZNOww2w2uRJWP3TZG1TnTnHVKT6nk9hRd4havtGnkSJ2p38T2WlOwNNNDzHWzj4VyAMhK1ZH4uEDPU1XC2aec14qLfZ0kNrcUqZNlPHa03hfwp5HGMBKUDrmos3kcBqVYsHM7jfrzW9weii3FCmpm4pke6/D8QwS2lX8KEcBSuqlEjoKELBKnWOUmXFeMKUnlLrI+NP/AFHJqeB4SSdU31tVqjquDFwQJMVxhJVvbWrnoOCFlSSOxH0ox8QPZBPh9ok3m/3ZqBPUkFFsQ3veVnHXoE9etKwKuTGHY2TGeQzY8hRRQErIrU1195W6m5SS6s5UpRSrcfmCMGjvT2tL/Bt0huUW4Vvls+7yLnEjjhpRGQ4kcpSe6kig+4aUfYCHQgpbUcJJp709q2bZZTbMlIWhI2EKGdyemCO4PSqDjA61EDIfe4fylyYSBbbrkPtpSpt1KtwKVJBStJAwpCgcg9waKfDnVmoNG6hiy4Tb5eChhUEFDyhx0x1H0yPWoZumuBa0QIgY97jx5DkOIypWFpjqw6hAUR0bWpYHyUB2p7t+rhIlCMlZhS2E+allxZaLYACtw9COvBrUcOvF+/c1lKHkvUvb4keG9i9rXwzbvennow13bU7QVJDCpC8ZVHfSfwLVyUnpu+Rqhd0sMy0uOszorsR9p1bLjLyChaFoOFJUD0IPGKlrRntkOaPis36fCan3VtC437RKVJclNjA8qQlJCXx3CjhQ65NAHiX7UFt8bbkxOuOmhp+6j4Xp0ZxTqZIwkAupPIUAMbhkkAAg9aiB4kgdSsgMLPZgFLb2HpTdIQVUSz7U822w+UhceQney+2Qpt1PcpUODjoR1HcCmiRFx2pykGTspEZwkhXIrcngD0r082U9q3FnDIOOKIwRNCWN3OKUe7YY6YpchgGOCBXqQwURd2KG4VRmTHCeeppHeG1CMFJHelzi/LTzSmXDWu0BxbZSg9FEda8xqaouAMuct91KVH8IwKVWyLvXkjmksqMET8Cn+3RihvOKIdRZ7nh2MVpxispwDJUMYrKwmoQFxuSwWxkV6SFLVgUqCdwxiltvt2TuUOKKDEsOGpRJIp4iNqGEbM0sjx0oTjAp909BZlS20OYSkkDPpSyYwfUyy6QXPwrZ+lPsrSP7PQnc3j7Vcv2ffAzRN3gxZFwlokuLAPllYAFS94s+A+gNP6Jl3JEViOtpGQoEHNSjOCbAlZw1omczVQQkYAxSd1nyyPh5om1GYyLo+Iww3vO36UzvIB5I5roDc551FOnrmq1ykvI/EKf73qZ29lBUkIwO3ehRtnBBFLmgU4ouO7mX6m0p3dR96KLS2xp60vSEp33uQAyz6RkqHJ/zlP8A7QfU0zwUBIL6gCEkBCSOFK/2HX8qIbfbVPzWm1gqWjlRV1K1cnNaFsz10LjnpS0OMhKwnhJwn5nuftUt6WaS0ny1q2KIAUehAPb6nvTBZoaIrKCUghIASnHU/wDfNP0KIp9xOc8nJPqap9RI7khxG22EIzs+IeoCUgDuegAHJPoKqH49eOt41Zc3JGlnZUbR9ok+REuTCClMyWM7ngrHbnYOwG7qaf8A2qPFhyy2tGhrXJLT8toOXV5CsKajn8LAPYudVeicD+Kh7wu0jq7xF8IpulHWlQrDJDCY0+S0AlKUOeYVMtYB3/FtKzwQBXNysxPFJdjRa5NAe4Xi2aMQ21IlyHYl0YSuUtJCpk9DgRvyo52p/EQD3TznNDOhdMu6iS7a4hkSGGnveWGnPgK2/wAIXsGRuAxkDOM1cnwu9k3TemGxNXBVLlpGDOnnzF5GMhII2j6AUL+Lfs73XTUr/iXSMJTyUOea/bWSWnArjK2FgZQrHUchXoalbxzxNGzKlzfIWKEcPBK5SfZ+0w7qiVOgONtlQh26QcrkOrSEuFtQGWvhAySCklI4oF8TfGuB4g3LfcL26G1nepFwQEr3ccbkfCoDsRj6CovvWv2ddtz7ZIvbcRUFkvbLmfcpElacAsApBQp0EHrtBx2qJ7rCdafIjSH0NHol0hWOnHHFT+N+XCx3X8jvI/HlXq/7Jtuy7Nd4yBHuERQQc8Op/Ko5vgtjMourmtrYbHx+R8Su3Geg+pNDkPbGslzXLnNompLIitKAysFR8zoCOBjqaHHy5enfdo4XNeAylKP8NHT4lHvXSOXI+tTnfjxpvcT365ydU3tDlvZ2Rov4OfhBJyTk9T/3xSmdOWwuOqWy424kbQpR3J29MA9eKkvQHg/K93jrmpUxGUdyjj41k46enWnHUXhz7xZJzbjQKWHFISvHcHgimjD8Yv8ALuDA0HfL3oi7XBm3umBZbiw1IeCOEh5sho9OeUYz/UKS6FuCtJagiTFRmpKGljzGH0BSHE90kHsaLNO67vM92M+9PWqMiKYT8DdtaUhptIKCnp8SUg7uxFJGLdBu0mQuO6lXO5JHcHkGk+M3K8Z7jfITjTjqXO1R7OWmNQ+B3/ib4YefI0+8z7zf9KA+YuOpAw5Jid0utcqKDwtGR6VUC92dUGY4z5iH0DCm32uUOoUApC0n+VSSCPrVi/Yb9ogeFl+uWlbopblquCg40n8QbcHByPRQODQn7Qmh7fo7xE1FbbKjNmjONzIITyG4ckFxtA4/ChzzED5FIoXX8Tfww1P5U/olf5cbA6UmW4oJCB0p4uCcg4FM60/FThEHUdoqCqECK83F7y4HPYUot6d0HFJby3mArHpS/cO4PIe3OAnnB6VLEDSNy1npZSokbc2yjcQkelRHDbAebK+U55qboHjANIaeEG0ICVOt7FlQzWZL1Q3Cx17OpXe4xlR7yptwYUhe059aIo5Q22BxTHqOSZN0ekKA3rWVH60lN0cKQOlMXrcW1XqET85tjk4xWULOOOO8qJxWVtQQ1Qvt7KXnsKFPaGfK4HFDsZTzDgUOlO7F2A4cTWCaY4DJ+VK4jy2sEHBpJHfRITwaWoAQBmvGaAYc6c1xcrIEKjTno6k9NiyMUQXvxl1Nf4PuU28SZMUj/DWskVGbDwIA6UpTntXuCHZE9zcauLnni65uJ5NbSCrFIEE5pyjHeBkZpimKImxmPupc1DPGBmvURonHFEVktpcc95d/dRI6kqddIzjngAd1HsP9KImeAjppHSvnPzbjKT//ABlnaK1Z6Ou4ylA+qsfYU56aYK5iCob1qVlR9VE8/qaLrufcPDeGhLQjt3FwvMsjqGEH8aj3UtfJP9AxxQrCjuLgpbZyJElYbTjsOqj9qPEbBMxxRAh83CKp5aTy2wdildt38R/0ojkOs6etUidJaJLTZUlkDKlnA2oHqSSBx60hskNEOE2jkpRgqKupPXn9TTZqjUMv9qwrXFcdMdhvbILSBuSpwZJ3n8Kko6fX1peV3UACHjRSTci7w68GI97uUzWus3GrpeZspUj3U4WzHUVDCVDotYGBt6Jx0zVmdN29ZLQCBHa6bj1wPT5D+/AoV0lYkuNxl+SliHHG2LGaGAkHueOVK5JPbmpEhsKJIJSVgDdt4SkdgPQAVigKJptjJKsN0grXGQIzag02I8dCh8LeTysjuTk00eJlpkS5cDS9geCblcgtRlkA+4xU4DsjHqMhKB3Uoehpljy0wWvMKw00hJWpauAkAZKj6ACh7Sd/l3WVNvzjziH7sUlkKJCmoaM+Sj5ZBU4fmupjjN2plAyCqYQc117Eeib7BEWLAjQ1tp/xQr9+s9SVL6knqSruag64+wfaW3UoYuM9kHscEY45yR0+dXGhXdtjKnFEoHKhnlXy+9aL9qaLPi+7+TiW5y48kYCE9kgY+1NAYaO4s0drqUilex/pCxl6TcJsyfGjpK3fMd2N4SMnp6c0QWbwdsemrYyiDZWIxkhLzh8vJwcFKcnnAGKPPE9KtW3q26QtqiliRNYRcXUdm94JaB+YBJ+XHepiv1ihXBQLXloShYQR0zkE/wCgFNTKt0PUF8LBQW9yst3sCUJTtRt2qB4HcUD35tP7Mko28PvnjHUCpz1jZl29aso+E52nHXp/uKi246fdlSY8cpwScfQnlR/LNVjcjIqVi8RtKr09a0TGNzLE1wNv/L+VX9wfrQZZbjKsEgrQFeVnC0HOAT6HtVpfErTke4W9ERxsKbLracEds4qt2t9OSNLPvRVBx2GhfwFP4kDsD6ios2Mg8kleLJY4vC/w/wBQwbZqmDcXpQYZQ6FuKcHKRkZPHXv0qZ/EC8TPEHWt0uunpWLQ3pxtlbbn7t24MMkLccbaI3FtJUCFHGdhxVSY10cW6gNlt3kDg7FZ46g8VMemLPL01qudebQ4+uzGMpmLMdKVpWHmg240SMjKcufDnjg45FRuWelMqxhUsiI5bJO40yvIwvpRJcFJQgjpgUPSDlWRVCydu472pOYhrRdgBBXxX2DJ92i8pyDSe4yfPjKSB2rPc0wabWEkAetO3kF1CSBk01soBVz60cMQmWYUZaPiKgM152qeReUi7UEZTcsgjFI24ZIyaKNYsoTcl8Y70OLkdAB0rUNiC4ozy4zsbrK1uLU51rKOoAqF6cKHTFewwFU4sQEOnGQK3qtJHQjFACIwgxFBV5C8Glsh85Tg1qTb1IdAIpQuGpOAQaw1c8LqbI8pQIzT1Be88gdPnTfAtK3zkJ49ae7faloeAxW3MjnHgIIBPNL2oASBgUpjQ8NjtTgxGKQk4zRWJnEzXabY7MlIZQQjqVLX+FCR1UT6AUYwWFajudts1tZV7t5yWWEkfE4tRCS4r5n9AAO1NCY6moIbb/FIOV467QeB9zz+VTL4X6U/4W06nVUxOyU6oxrWgjkuKBC3vohOcfMj0rC16EIL7jd4xSGHNTG2Qce6QGEw2cdPLZRyfurNJtE2vzGG5CmiXVfumGyOQkHkn6nJ+grU3FReL5LkLUlzcvymmt3KgDz9uBzR1Y7a5b2Qo7FrI5VjgDjiqRSLxiT8mubpsdEKHIdcSXGIbXmrA6uK6hI46qO1P3oT0Joi4QUTZuonw7PuT3vL0MKw2hec88fEeQOOBgU56om32RNis221Ny4qXPOkzJMgsssqGNpOBuURnIAFOj16tlutwnuP7gRjzCSCtXHwpKuTyf4Rmh0YVEQiiyExG2m0Dc8tQQhOMEk9OP8AvgUVsNojsJaB3nGXFfzH0+/X8qjnQ63LrJkXGQ0ltbbhYaQhRUE9N3JHKs8E9Mg4o6ClqaH9XA+frihYQgYPeJ10L1liWVlRD96lJiK29QwPjfP02JKf+ql8FRQN4RtCzhtseg6D6AYoOv1xQjxAfceT7y5AiIiRIjZBWt1z43VY7AJDadx7ZpwXd7lDiKfllqI24n9462vL4R/IynBCf86uflnFYfiJ4CzH5zUTPvEthLySIKd8x4H4I4xnaT03kc7e3eh666olOR2fcWSidLSCw3glTKFcBah/Oew+dD3/AIi2P9juW9FoNoitOANRJB+BxRIJdfWevPJB5J61MPhFpqyXEi7IukS7y87v3DqVhCj3OO/9q5+XM3Szp4cCXyf/AMg5adEt6JtMORLQF3N93zHFq5KTjOM/fk0inXRxRK0HaAcijnxkkiEuG02kvObFLDae5PAH3qJn3nWLc2p5zcQjc44eAc8n+9UeKAq8fcR5ZLtymy73g3kwWHkblRmlq2pGStZOE/6UH3l6FDYJbRmQMJKj6nGfz/0rfdpKmU7m9yFHkrPBHy/KgWfcT7yd6vhZT5ivr/D+gJrojU5hsmCXijfk2x+0oRhRfubDCs/yA5Wf7U1670xAuAlSFpStSi4ypBHonIP5im/WTf7XmQVryRGcCh/nKgSf0Apbqd7zPNKT0Uc0KuHJH1DfGUCn7kM/8KwFS4nmspKVK2rOOvI5q7+qPDLT9v8AYyt87TsBMR9i4M3CfhRUVu493dVznHBbOBxVOZjSsJUOqXVVcjSmplL9mO+x3U+fFiupdfR6sKKA6B/0rUfqBU2ddAiPwGyQZUq5QVKyOhpmct5SeaN77DMK4vR1kLLSijeOisdFfcYP3oemYCsYpQM8w3EEhnyoqab3ElTSsDtTvP4jJpqPLaq0T0ZGGlKXgDvUyaP0FcdTWptUOI4+GxlRQnOKiy27RKwocZrrj7HfhnZrX4M26euO29JmN+YtSkg/apPIystKvZlOBFNs/QnJTxQsblqvS23ElC0jBSRio/KSlYq0Ht5woFo8a7q3bkJbZKUqKE9AojmqvuL3AHvT/HbnjDH3E+QvBysxKcrOKyvjS+euKyqJOKkjxmQXsCnduGVkAEjNN9tZWXM46UVWaE5MeQhDZUonHApJIEdRPUQC3eQ6Djd9a+uBt1xKAMHNFFzsci3vhLzZScZoTUgruoTggbulCu9xhHEVCiFDQ1GyBg44pVCY3Hdit7UUCEFd8dKU25jKRxTbia+4rjgcJIpzjRN7eE/Er0xzXhiJnGBT5DgIcQN+UoTypSev0HzrDQhKbj1puwxDPEm5lSLe2sJ2J/G7jA2J+3U1JOr9Wp1JerZHtjC12uFHS3HbYbO0qUBuAGO3A+3zqNLVYp9znx2GJJw8tLaG3hv25IA59PWne16iulrmrhx5bchlpwtow2cO4OPhA9cd61ACbExjQow1054emKr3l5luKsj/AAkncvHX4j2rNT3F3T8J8wFNuP4wC4R5bZ4GSe+M9KX296/z4f8AzJjtnr5DeRjp+IpqJ/FLVMN+QzaLhJh2ksPNvvIcdKlu7cFKduDhOeecdKdX3AWrEILPdrnYrhMzdnHX0KSlbMZzzgt1WCUr/gHToOgNCmpbfJN+hagiNynn5uI0VpYJjwHui1hJHYcpGOtJ2deWaz+Wlch7L25aS0yPNBXjeUjgJ3c88nHHFOdk8SbQ028I9mnyY0YCS4qQ+nCNuEhXIOOuPqagxLwfny1Otmb8mPhx39iTNo+ziDaYsVrKG20BIT39fTknqfrT5IuTMSa0zJfb95VhCIzRyQAM4/p4BOTUbRNd6lvam41p0+6ypQHV4gJBxypW0YH0NLZ+irlYorF2nzUPTHWH9zTCcNM5QB8OeVHnlRqp39ic9Md6MjqD4k2i2Srtd2WVftC5SFuvzZgHwjdwlCB2Ax1/KlNn8ZtLS7oItyu0dMgpLqkzJBaS4B2346nsOgqNPEX2br1edLf8QQnH24aFgOJSo4xkDIHyqOXfAmbbrpcmGbdK1GhEYJZQ2ssqStYGx48fElPPHfjNc7n/AMjRap1yn/EHJUv+y1928RNE6vtKWXosa3ICdqFAJLeOPwuIyB9FUBQ9H3CxXNF30vcn4rqfiQ5GcxkemRwR8jUA6X8GdXR7zLNkMiJIjRRKUg8jBAw24nG3J54NWC8BrtMnQW3lxlRnUOFmTEwdqHB1KQex9KUyth92I/G6eSNLRkp2fXl+vkJ9zUzafe2GClL6EbS6Ankkdj9PWvC83mDEeSvMZOCEYx5qwB+Lj8KT+ZHoKIJtoUqY1LdWy1HbG4Ib6lWBgknjimWVdWYrICEh5QGAlJ+EDsM+n6mrMT/XU5+ZAO9mCWqXPdGgVHcpRO1P8x6/l3zUe3K3vRY61yCS88vcsEYJUcEJ+w6/Wj+73CK3IMqS4HnU8lZT+6bxjgeuD2HXvUR6i8R3o15TIbtS57DZ43KICec56cnvmqPytRP/AJJxiUkD/wBizUGljbbLEfe/xXXklQPbJzQjKc98jOPJzhTiuvpuxTlqbxVRqCCw2/bn7f5bgWSv4k/2oc/ayI+nPOJB2trXx9T/AKms8WxdzfMKtVRllRx7rHOPicWtf64FWP8AB64NTvC3Udhc5VMtcheD/S2D/YK/Kq73IiO1HaVwpttKT9cDP61KXg3dTF1DEjKOGn2URcHuVsLz/wDvVrryWpz0bi1wMvbS3GIMhQytbIbWr1U38B/QJoWmI/eDFGVxSo2ogjhmR0/zJwf1RQrKby5XPBlDgXEktjewBTO80W0kEYohkYQynjvTTdE5TnHajBmEVGqA2C/1711m9lPXcK3eBloakvJ3Nt7BzXJFpRQvIOOasl4eeJc+16AjwmHSlKF561F5SMaKyrxmXYaCXt3yW7j4sS5TQCQ42OneqxEZRUye0Dc377dW5b6t7ikdah7aQKo8ZSuIKYnym5ZCwnllIA5NZXps81lVySTNaowUvoKm3wp001Nks5bBWSO1RFYmsqHHWrTeA9lQ8YysckjmubnJAnS8cW0HvFbRLkKQlWz+HIwKr6qCpGoSkjHxdKu544MN29CFKQFDy8VUBSBK1QtQHVfArPHclaMPyVHIGEiYaUwOR2rzbmOQAKe1wT7thQxxSe3RcOAdqpBkrCOEWETg9qf4sLKGkY6ncf7D/WtUKPhI4zRPEhxpyGvNcTFdbQlCEJTnzsE9PnzyTxW3AAMaFXJuxkkPBEgoUlrAzgkYznscE4pjsOp7ZYZTsy5zmYi/wtIKsqQn5ADOTxS/UUJvVV2iwGFeXDZUEqeSOcqUBvzjknnHoBmgLTej27vdZjEZreguKaS+5yrZuCQSfXvVWIAfEdxWSzRPUnrTOsRP0ZO1BDaW1bG23FNuyRhT5T3A7J3f61SvX16lPTLi84/50yQTJkPL5KiTlCTxx/MR8wO1W48fLgzoLwogWSDsjofWzDbzwAkev1PJqi93ckSoDs1wktyQ4pKyeuDtP6Y/Om9CL9ywHg5pFHi9a0TosjyXkowr4NwQ6MbmzgZB5yPUKzUyeDWnolq1PfNPXuB5FyeiBIadTwtsEE44+aVA1VT2UfG1zwU8RGZEt4t6duZTGuQ27/J5+CQB/Mgnn1SVD0roFNkxLlaHJ0SVGuAjywpFxbWlxSisAKSHAOQcg4+lfP8AkIcZK+j1PqfFzDKoNbHc+aAkodQ90Kgraoj1Bwf7Umu17bvmnAVJKvdHnozrY65SrB/TmtOl4arHCTOBKoynFIfB/hBVwr7E0xWJiUi86mabO9K7g662kcjPCh/r+dX5X/xgzmYMd5iPo/8A2WMt1nt//DMWA3HT7n5CUhtSexHQ0AXnwjYClGEUhsIUhDaxhSEnqkKHOKObNclPW6ItDKlBSE9OABilr7u8kjp2xXF0259COSEj7kLWLw1n6agyIUZhhDEhW51ZG9xfTGVHk47UT+HHgpbdNruj7zwlJnFC0t+TsLSh15zz/wDVHbSAtQzwKfLZHClAAAAUwfLuT5GKghdQPuvhxapkYIfS9vx8Pkp3K/LFQP4r6OVpJsvsqfajk4CpgTuJ46JT/rVt3ng0lQTxVXvadu3vVztsEqwjBWoD1zTgSCADJ1HLbCVf8QNbs2dCHrlLyejaVd/8qB1qNn/GuI1LDPubmQneQ9EVgJ9cg5x86nfXngBAvCk3h6SJQcZbS2wU7FNYHISvpg/MVG9r8LrVYmpN0mER47LKo7MZ9YU6rnKir88Ad6qQY2Fs25LkOZG4omoxva8ter7S23Fix0PMqCt7JyFdODxTPa4ce6G32+IsriuS1vLz/wCWwg7yD+QFRLfRI0lc7ncIaCzGfCmWk9Bk/wCw5qVvBu2uN2eOuSCmS62FONq4UhnO4A+m9WPsn51XgWjYOpF5DctEbinVUd1yeEIT8TnQfMnij7TrRgSbBcmz8BuKUj5pSpCR+goP1LObk3hMVrl90/EQPwp7/c8AVIkmzPQ9N2SRj8MhT4QBwE+YEg9PlVrNQnPUWYz6ojmHNu8fHwplY/8Aks/2NBktsBdSf4m+5ovUmPF+JSnfPkLBz+8IGEj5JH6k+lR5KjfFkCoBqUNuNM9WxlIxTVcDubH0p6vbHlxmlD16U0SEh5APoK0GERqD2MK6d6OrLfDBsKUpPOelBa2yFn607RV4hBJ7UTDlFqSvU0+JMszWI7hH8NRyUDFG2rXi/b0D+XigxI4rMYrU9kN0ZpCMEnrWVvbbJVzWU26iwLkyaG9oq3NLajay0hb7vFJwudbB7lMR0+IFPwKPyKeaut4Et2DU0FM7Rd7ReWQgvohPI8qWGxjeCnOFKQSAoA55Bxg1y58ouN5HBqTfZ+1nK0frBkGe7D/eolRlNr2pU8g8tk46ONlaD9RXMy4xxJWdPDkPIBp0B8bbii4W5YUdrqEkKQrhST6EdRVYdPWoyr+VY4Cs5qS/EteubBqSLFitt+I+jbq2mVbXZCS4+0yrGEecjDiFIzjknpnFLLZ4VXu0wFX1dhuFtt5CS4JSkuhsqxja4nhY57hJHoetLwsFWr7js4LtddRuuELZFIxg4pngskOgY4zRNclbWc4z8jTbAi+dI34xk9BVgMhMeLYwCRnpS6U2ptZ2jkIO044Hwk//AH9qUQYJSE8UvucBUS3yJid/+EELA5GM/ixjqMkfQ17szehczS2mQLE26ps7y77wsqHPAOP/AI/3NMWibUxAkPlPwZQlzaRg8jf/AGBH3qTrJZp1/gsQ4qjFtzgCXZCkYUtHGUoH+tBGo7TN09qAyFJCGw4qI5t6IUFbmz9CRj7VRgI5EXsxWayAa0JFXtlXr9u2q3tMq3MsPoWoJ77mwQf/AJVXC/2sQtOQm8YcEJT6h/mXkVJ3iNd3L3cBajuKnlIjtgjjOGdqc/zJVuGD1Sr5Vp8VNEqtYZbWNiZSW4ocI4SAck9PQg/Y1VUmuQTKgqh2dSzwrYVE/r/rT/d9W6m0bdm4sOVOs7cJLEhmEVKQhK/KQoOFBwCVdc47063WLH05fGGrg2p2Ogq4QAdiwAELwRghK+SO4FPHjVZWIjUaLMkOL1BFjsNPIfyt1aVJUsqUvHI5SU/0kDtUz7YLUdjJA5A7nQvwourWo9B26RJSnMyK046jtuWgFX6k0q0ZoxUG6yXyrDMiQppC1c4cTgDP1xQb4JByHoKxNOHaF29kgn1SgZ/Spm0ylEyNcYrnxIL2/g4I3JBBHzyM/aocx/xKROt4+sziPen48qK6uI9GUlnBUhfZB7p+ncH0+lOj8U4zik9tmykgMyVtuKTwl4HBWPmOxp03AjmufQnR5kGNaWSlVO0NflI5OK1JY3nPak13Zl+5K9x8v3lPKQ7kJPqDitAqCWDGjHE+bMc8tpsrWegFVV9pKA6NSQX9p2ltSOnQg5xUozvEi9aFflP6mk2xphB3x1wwtCgnuFbicn5j8qhHXPiiz4mTkOxwTGaWSHFJxvOMZFGm2BjSvEGEkNv3iwRkuDchTScg/Soe19omAsrWpGBnPWpcstxbdsDSSRuaTsP2qGvF/VcezWmdMW6keSglKCfxK/hH3NaAeVCMJBTkZWnxChLu+smrZa0t7Lcnc46vAbbWeqlE8ADjk0faeRbtJaIdlMSFXB55wgy1g5lvY6pzzsHQZ9M96ha2ifqCSoOuqZhrdLr7y+EqWTkk/wAx9BUpR2HL0qHDitKTCipDTSD1HTJPzOcmu5iXiAJ8nlfkxb7m/SVlk3Ka/OWguqbBfcV9OEJHHdRFSixcJF30ZBW8vDyGEtJSlO0I2HbgD1yCSfWn/RWkzbrBGkIiLaYx7wXnEYDzoGE7RjlCOuf4j06UxWeXELkuI6le2IXFIbaRkOLKztSo9Ej+In0pbZOVgeoQx8KJ9xDqm2Ij3eY2g5Ql0gE8+n+uaG34meByaI5/mvOFbnxLUcqV6k9TSBTPypIM0iA2pVe7uR219BzTC68nzylH4TRPrpgeYwQMHFCQQW3+RmsUahMd1PDiMk4FPVnhNORCpzoKaXUFKqMdC2H9vktOOBlkcqUaNiALMUikmhA7WkFpNsC2vWo9CcCpn8UrJGtUJTUZ4PIH8QqGQk8963GeWxPZVK6M+tkBQBrKxKSSKymEwFGp7TD2IGCFfSs2bRlBKVpO5JHUEcikzM5ccBLiSOcHNKy4l5IUjrSDHiSRa/GHUditCYltnrjtyUpcUscrT8kn+HnPSnrwo1xe7n4g2SJJukt+LOkKYfZceUUqWEFSFYPcEfqah+ItwRnAE+YWlcJ9UnnH96JtA6oRp3WNnvDSA4YdwYlJZdH4iD8ST8iOPvQ8F46EYMjchZl3rnbUqig0ns0FJeSMVtg+I2kfEaM7L0y86gJVh63yU4djKPb0UnOQFD0p6ssHLqVAUsN8YTL8o+Wy1oKgVj4U8nFEcW0pnx1NqQMOJIKcdAeK0wo+1AO2nnS7MuZdnY6EiOY6/LJ2bioHBSfuD+lKsncYKGoRWt9qzWNEiWjeYqNjjaRy4rgJSP8ANx+dV51hquRdXb3LcwkPLdVsHIBScgjj1CvzqWPGq4o0fbYSl3DfKkZWGyAkpQjosj/MSBVdtX3FKNFXVxv8QhOK3emUgf3Vmuh46gfP7kedj+sjKNJfveuLTcLZHHu1wloUVtHc2UjBW04nspKhuSr0JFTJrvRjOutMuQlYYucVSXGFnssdM/Ij4T6ZzVcvB7UqdN+IESM5lUZ8ZKeoS4kZSoD14I+9WznodvtrhXTTshhSkOIdIUNyXmRw618lY6fNIqwGSGU28XLRIg3tpbjCmyEbVIUnooYOP7flWzxmYtp1PETanXJEVNrhoDzqytTqvKBKgSAcc4A7bcVL3jXAQiVMizmPPQY4mQZA+FSmsgLbKsdUKwQo9uvFQBYIse7zYERMpEt9EhtDbLg2OJbJ3KStP9J54J/F6UrIa3G4hyIWXys0tdp8MLKttW19llojA5ACACfpkmnrw18Uw7d1suIWHFteW4z1KVpPwkeowetD0OE9FtlllvkvQJrYgSMjAbWo7mzjsN2U/cUHX+xXTSLNr1XBysMPGNKQB0KVFKSfqBj64rjs/LAAJ30x8fIYmXGsjrpYDjyQlxxRcKM5CM9Bn5U5PvqbbKkDJHYVHXhj4iQNbWZp+O6A6kbXGifiQr0NHrUjBBqQblDaMDleONp05KkRtURLjpx1Cj5SpsRRbfT/ADNrTlKh8s5+VZ/+Rug31tttXVxxbhwn/l1JB/8AdinnWE6PLta2ZbSXmR8W1aQoZ9cEYqrHiEixyzLiwgbYh1Ox1EQDy1fMJUDsP0rGYrL8HjYs4s6P+9SQvGfUemtWWZ0R5rMu4rfQW0DIKWwOQQR86hqLDUyQEpwkdAKAtPaKuJ1A4pi+yFQm+Nr7e/7A5qVFsiPHSN29YABVjqarxA8bMj8gKj8V9T1FuzkJtSAThXGPnVdfGjVy7rqJcCElp6PEJDhUgLC3e/1Cen1zRr4oeJY0xFdg25XmXd0FBeTymKO5+bnoP4ep5wKgNJWtl1SioJDZcKj37Dn5mrkxUOZnIz+Rf+JT/ueYrBVITMmySoo/w2UYJz2wOiQKOtD3N9CZ3koDLao6gCrk9s8/6/OgK3t+8PttdMnk/Lqasj4E+DD/AIiWbUkzCmIsSGpptQHCn1jDaenTuTVoIRbM5dFmoSftZT5+p7bCDVscskduK20VvthO3CUja2gdQOxNREjT7Vukz2GspQHUuAK5OFIHU/VJqbndQqv2h9OTHvilOw0JeB6+YgBCv1SfzqNZbAcny14H4W0/kFH/AFrlqvHkDOgzcuJECbnDQ2n4CTxzkUzbAMcUWXiOEJUf0phaYSoZWOK0GARAHXaQXmOKFJEfElIxRrr1lPmMc4OaEZS0+9oAORRo2qguvuaJDHOKc7ZdnLTb3Q0SCoY4rQ8kFOaU2aM0824l4gD50TVW4CXy1Ba+XSRPt7u7KkjuaB2VFzOPWpDvtwgR2X4zQ3AdSPWo9gyEsSyop+HPGRR4zByj7ihmIsnJSQPWspzeuyHm9qU4rKIncBaqC7sVDaywpKi+D8SgrIFeSsxduStAPRWOD96I4UyI4l1ufby4laAlDrQ+NojGCDTdOiSExYofbU5BSSW8pISs8ZpIP3KCtdT7bJ62g6AhDhcSFArHYdxW+XiNObeG05ShwFA47UwzpLr9wSsE78DBSMAfIUodmPJaBWQogbefStmSV/BG8SbV4rRG2iryZrxYcQOikr5H5HBq81qdbt7sb3laWkurS0grONyz0SPmcVQnwZlok+JekXQoIcVPYbdB7HcBn7g10mumh412ty4k5oKZ3BQUDtKFJIIUD2IPINTMQW4mUoKWxH7S3uLlxaMsobZAO0r4TuxxmkOtdWxNE3VuVBfQ9IlNbX0NEKKEpUNq/TOCRig7RrF9vNnckt3BtVuS6tEeXLYBW+2k48zAIGODyevWtWgNFOeJNym3qc8V2hp4ssIwEmUpIwMgdEjg8dc49aaiKtljoRTFiRxkMeKN6vvjF4gNxICXUGW6llgPHAbaSM7lHslKcrNRdftXLtemJunjK96ZTIIak7dpeYG7A9QCcHHzqetJQFwtK+IV8dwiYixSWGFHqFeelDwHHXapH51UzWqFqxjPmNLK0nH8BIwftxVyNeh0JG61sxL4ey4Jvku7XFl55mA2laEtnblxSkpAJx3G6rW+D0Vdvv8AEetVx9/01dG1OJCx8TawBwodljOD61UyLNzppi3x7c2wuRI8199GSuQpPCE4PQDJ6d6nH2apblp1Rdozk5t5iLHbXsbUSELKwFHGOvYmnCKMkf2hdOi26afuEhoriwVKlRZKU58vIw7Hc44SpOdqunY1VvwsslnXqRGoY8hx2Glzy0JdRhUcqxkK9eDgH0roS/Pamw3GH2U4WgoU24nehSSOhGDlJFVq114Z6Z0XHuItbKLB704X/dXSfd1r4z5LnIT/AJVY+VJyAsKEdhIVgTLQ6Zs8O9+HTkVxaDHdiqIcBBCSE7kqB/pIB+1DWhJ0TVFuuFmmtlaJ6HH0JUnhSSEb8fc5qH/B7XTjkBuyKlSIrr4LK2tx8t9BA3YGPhITnp1qdPCNktzrhFMZb0liNH3JYQFFlJKyoKx6rz09K5BxlMZB+53BlV8isD6larvc754P60eMF5SFsrxg/geRnjI/7xVofCDxttviNb0gOBie2AHozh+JB9fmPQ0JeO3h0xqK2LuMRAVJjgkgDkjuD8/lVUP2jM0nd2p1ukrhTGD8LjZwfofUH0qYC5cSJ0wdZivRyXcKBHeoQ8U9F2RxD02O2liSnk7Rwv7VEFi9sNbFtLN9jONKaRlclj4kYA5JHUfrQ3qb2o7HqiL5VplmY84cBJSUpB9VE44+lOTG7H4iJOREBLNHG53qFpyOp2Q8iO2noVdz6Adz8hUd6m8UZtzjLat2+Gwo7fOPDqhjnH8v9/pQpdHJV6vKX5khUh1R4z0T8gOwp31NYY9j0zYZBQoS5yXZDiieAjftbAHbhOfvXXTCErl3ODk8lsl8dCDV0s4lwWRkAjklXzHrTJdIj7jDLa/LCW0pT+6RtCtowCr1POKKxJQtpsHsBx+VPWoy3J8OLcwIQbEGQ447OYbLm8uY+EqAAz04ycbabkIsCpNjB3UjOzQxFU9JWM7f3bYPdR61dr2fNRt2Twyu8JtC3EPyYbbDTScreUWQtwDjvz9hjvVKfOXMU2lttTbLfCEnqT3J+ZqxngZIvrjVlIcjotFsfDzisfvFF1Qb25xyducegrcigpuexkh9SZAovNXIxozrMX3txcZqQnYUpcwspUMcYzkjtQ1JjBtrCVeYSoqU4P4iep+lS3NthefcAUCsJKhkjOQAM9OTxiowuWwTrihACUJkrCUjoOmQPvmuWX/J8p0ePD4wSujG8EEUxuoQynacCnq/PqYjOLT+IDio/fmuuLBUsnmvAFoJIEHvETauWz5X4RQVKCmnkqP1o71Kx7wts4zQde2i2rkdqYhrUB97iJVwKiADStKXvdQsAhJPNNkCKuQ4SnGE9SaeJdzEC3eWpO7PAo2+oCaNmMzdiDokOOAFtXNMDUSE5N2KSEpzg0+y74UwVIQkjI60DrdX5ylg85rVBMxyIau2m3JYPkpGRjk1lB6ritLJAcVk46GsouJ+4PJfqNkKWClJyUqHbJBH0rzPnuOrZTuXltatoyeEkV7Q+y8pS3Sj4jkgDAFJpKIylpIWoAf1ZperjaNT0p5tIKlAAkc461rjJEs9/oa2piNPJ/dODP517gtKZlto8tKnFqCUgHGSa9PRZbXpUWelcRtW9khW5PbBq8XgtqvWF18HtTakvk6Q6h6Oi224LUT1UAtzn/NjP1qpGiiiDqOCt2OmS370jzGVpylwbxlJHcHp966WuaakO+GSreiCwh5KQ6zDjtBpsJSvehsJ7fCMUiwcikiUbVCLjtcmBa/Dp+NDRtEe1FDQT2Aa4/1pF4D3uOnQrNvbWlMqA4tLrf8AEkKVvQrHoQRzSfRHiJZpdjjwLy+LdObb8pbc1JQlxHQEKxg/CQPrUaXa+IdiFy07IN0sG9CblGf8t6VD3Hagpxhe0YIJ7cUYRmUp/YsuFIaJ/FuSvTn/ABPY2GUe73d8z47qT8TAWR56CMfhVtSftUYah8PzavCRqfdSyg3J1MyBHSgKdkNgbFr8wD4UcqynruxTRrLXSZswyVTX5Ux/guSVDevpgJxzj8h1FBM/WFyjwTb3HHm4nO2O9wkZIJwk9MnnjqarVCFAJ3JiwLE1qCrqmrY43JQhcsNYS1HSAMHjBUewHX61u8O9cPaL1Ku4IPnOOoUVt9i2DuVu/wAxH+tM17eQqEXfeWoqs4y+4Egjv8zQZcNUxI7Tkdh73qRIGxb7aClttPcJz19Ko5CpPUv3pLxPZ1NY2bnYJCblATjz4Sj+/j9M7e/HoevY0W6jsTWsNLPpZw6tTXmMqI74yAR8+lc8fD7U1z0PdWZ1vluxyDyWz278dFD1B4roZ4G6yY1lplMotobdSkKcCB+7OR+NPyPPHbBrykGadSFND6qZ8NbrLmOW5qVKDC4sdbw4huKKcO4xyAkq4+1WT8Afe29T2yQFFLN0tCuH0EolLQ4XFpDgHwuJDgcGeFBRHaq26sEV3VTS2ykJecUjPY/Edv8AYVZX2Z7+7ptuTpqQ6VRdnvEIK5LY/jaz3xnj5EjpipsyexKsL+oXeIgW1JelvtyGI5QG3ZEcBwDpgrTjJxk+vWqP+IllbekzrhCUvyUOZcZcRghJPC0kcEE9uo+dXt1xcI6bfOS8h1x1awhlpkfEskevRI65NVY8Q7b7pFl5aQGnmXAsJT/TxzjnnH5VOUBEsRyDUqjrt55NnMOK2p2VLUEJbQMqIHJwKji721FrFvW4gsXF1BW82OMDOEkjso88VKFxcbkJMsBYkNjy0L5ASngqI4654+lRTqiUH728P/SSlv8AIc/qafiWlBknkMGcx9tWtrnby2EylL2fhDo34/1o5vHjQvVUaGxcISIyYjKGGlxVEpCUjHKVc88ng96iOJK+FKVpBHrS0NJCSSQR2HrVNbBkn8kn2vUsaalHlOhZHGBwR07VZ+73y2O+zvBcIaZU3LjttsMp2+Y4hJWrCSOvIyapVYlNNux1FkhTSgpW38SxuBx04q5Ea1w7roLVF2flGe3Eh+RAdd2p85xbjaXHUN44SMhpPrhR+isihyt/cbiJS6kD2+1KcIUobcncs9OpzipR0Xd5drsqG4by2ob25cwJT+JKHUhJ6fw8UKs212S4iMync64sJQlPJJJHbvyaljQujFWbVETTkxpxsf8AMNuIeTtWpotg5I7bioqx9Kod1XuJVCx1Jn1C9dJtqbfjKZTuSF+8pXlZSQPiSnGAcfOgp5puKwltCj/1HlR9frRJ4fvOuacXa5St79sfchFR/iSk/Cfyx+VIrhbWFSH0EBWzCkY7HnP9q5JHa/U6Qbo/cCL3GDsVYI6igF6BtUdqc81Li7aH1FKxxQjqG2IgSUpQAd3agV61NZCdyNryl49EYwO1CVxiOy0qUBuwPyqRLmsCQpBTg4xigyX5sPzUAfiogdwSuhAwMvsugZOFHpROmFEXGaVIwQnnBpEtClK3JRWu4suyLespyNvamncUNTNRQos9oKaQltpIx8I60FJsbTjisnjNETTct2H5YQoo7mm/yVsE7qNdQG+UQP2tiM0SACayvtykZaITzz2rKOzA1AaxqQpSgtG/B44zRUmDEdjgqYznjATzTFZYTzsdxbDZKWuXCOAnJxyafEOLRGzsCiBk81M+zqW4xQ3BWXajElrWwsoTu49BRhonw/vOq9QQoaGUtuqdQhLjh+BJUQATjtzmm9DDhiqU80UpkJ3pUoYB56ip08CI7ltt4v0hv/kIshBKhySE7dwHrjilZspRLEbgwq+Sj1LR+F3sk6a8PXoFzuS16gvMZYcS66nYwhfHKW++D0KifXFTyCUnoee9brJcIWobNFuEF5EmJJbDjbqOikkZH3+VM+sLqYTLcOKr/nHx+IdW0dz9T0pHLiLjVQ5G4QNvWmody1C+2gF5kObvIbO1AUcFQKhyRu5wMc96JbdooxI2yNEix0ejcZA/Ugn9aeNE6YDDaFrTlZ55qS4Njy0DjA+lKLvk7MuKYsGlErvqjwY0/qNwuXewwZjoH+IuOkKH/UACKhvV3sk6UkPuyLehyG8sYDUvMqOfltWdyfqlQNXgu1lRsUCkZFAd4szat6VpCkngg1gLr0Yd48n7CcyPFn2X39NTku2lsoU4jeYLiisEjGSw4fxp/pPxD51C0jT7sfKHWiCOCFCurGstJiVCVHU03Piq/wDJf/Ek9iFfL14NU68WNCLXcHorlreh3jzCmMtSSBcBjPlq9HsA7VDheCk4VjNuLOW+J7nMz+MF+S9StNuhXFEyPHhMOSlPOJbaZQkr3qJACU475I4FW3tHiNB8P9EzNH2R9JvkVkNXFTR3pjOqwFthf8S8lSTjhPPeoM0VqJ7Sd5Q/HZCXwlaG5aEYksb07SpCiMbwCSkkZBHBpusujrxZL61Cty/fEXJxCI0hI4dKlAJyOqVZPINX48k5r466kuFx+7XC2QkLT55kIxlYTlCOM5PzCqsdpCRdkT7fPYhFLsUJSnyUklQCQAVDHUjOccc1VlDjVxv9xMNvzmo8oxGVAdUtgJQcf1bFEH51ZvwA19HsKG7dPlmElZGxU1JdYJ4/i4Ujn7VuQ331DxDWu5YaDLa1baXwhBDqEBamT128Zx64/Sqy+0DbUuvWmC2pwF11xwcFBJCcpJ46dPyq2BlLjRFyW7QHZziP3M2G5vbVnHxHAO77daq37Td+lf8AFemoJjMrkRIbjk9tgAllbi/hzgccAKx86Q1BSY9bLASnLi0KenwI01yZEYc8xlTidhIP4js7c1GGoNPzG7tJeZbU60tRV8/mKmPVNrVbnwuJGShKH1P7fLwtZUAC2V4/Djkehpv8uPdraXo4/dKHBIwpJGOCOxFbga1qLzJ8rkJsyMHaePr2p8t60K8pSuxwoevpTtqzRmZvvDRLCnACSBkE98imBuO/anUF9AU2SMKRyk/L5VTcl4kdwgtTSXHS44soSnBOOCemAKkGwXJ7zGEoUWm0FLQSlRwOchI+hJP1qKEXFIf2KGEhe9PpyRUsWa1KkPRkJztYCFL+a1fEf0puOLaXm8Hrdpi3eHNp1TLhWy0LgIdblXANfvlug4KlLVklRTg7U/akfh7He154kXfWS4b8O1eX5EHzm8FScBAPzO0En6jmou8Ml2a8twZd4npbhMPk+6y3CIinUgFS1ADqUAY9elWB0vq9jxbdVadJ6lslpdA8tPvpW3JWMAfuErCUfTkn5VzsgGNj9mdBLdQa1BPQI99Z1BNKMNyrm8W0nuBxj/SsgMM5lLbTjLhbAHQBPH981I8/wrn6EtjNufjuwYzaNqFDkudyd/TJJJJ680B2tldrekBhILAcygrGewzn8qQWBJjAlARpuu5hlSkcK+lRzdXXpMkKUSSKk++efNK1KSVLUOwxQbJ0pcnty24rikjnO2hUr3Nbl0IIzrU28yp5XC/WgW6xfMm7ABycUV6hkyYMgsHgjqKDbip95R8vlw9KIDdzxOqjjeIdn0rBbdkPJkyVpB8tPQUETtYokJLTEdDaD6ik94tFzlqO/nHqc0zM6OuUp4JSsgk4AFMVQNkxTMSaUQljyFuQ3D5icBOcCk+itQWG23Vx6/RxLjpBw36miN/wWuNg0m5cpr6kLUnIR8qj1nSTjqC4rJT86IMrA0ZhV0IsTf4h+INsvDymrTamoMUK42JwTWUguGmojEHzVL+IqAxWUwEAVUSwYmzHnR72iv8AhC62q42mXPmqUJEZ1m4JiFx3BGFkpVlCQeEJwTnOaZoN0t8RHlIs0FtX8SXUuLV99yqj1uS6zGSQPM+EEgnAFKIOr3Iq0pXgo7oeTvT9j1FTnG26lYyrrVSS42oFsEGLBtzKU8Ae5IWB/wC8GlUbxPulviv25DzLcN85djtR20IV07BPHQdKB2LmLmnEV9uOpf8ACtXwn5bu33puvMS5affZNwhSYSnhuaU+2UpdT6oV0WPmkkUsYgxoxpzldrLZ+Dnta3LSSY9skNtS4+UtojrRsz0ACSnjP2q2+nFO6gua7jIbKHHiFeWTnYMDCftXOH2Y9OnXPixbvOb3xbckznQRxlJAQD/1EH7V080dDS20gbeakyoEbiJ0fHfmhyEbkhWGMltCOMCjSNIS1GCe9C1sASlPanRyTsTgdaNTQk+QcjNd0fC1En0oHvW0qViiGfJyOvNC1yWSTWHe41BUEb03vZVkUD3TUsSwttSbpbE3aFFcDhQpsLcaHQuN5BwpIO4Y/lqQbmNwINM8TSzF3cdbkIyytJSR35oASrAiU6ZSrSu/tFezdZUvxNXWC5xotquykqQ6ceQHl8pGR0S4c4P8KsjvwC6OsCtHIMt2xpvl4aCm231yg0iJkBKlIQBuUvBIyeMEEDvUhe0HofUdk8P5VjiyHZVlYled7pn4e5Ch6A7uR0zzVZJc7UuoNPvRWDJ9/gJbW6+kELWxkJQtSsZBSohBPTBSSavBsBx1OM44koe48x7OrSuq0uRw4m3S8pdiPH9+wOCASBg7TyFD6HrUsRXGm3Ysx9CZsJQHvTEZW1SkkcPNnHpzjsRVaZlq1D8Md51DbzicZW+CpHTKdx6E/P1qRfCO+zLIi3WG8MKW6pwiKjeNxQcHy8joc5Kfngd6tXIGFGRFSpupefw1c/YmmHF2W9LmJLYcYZmKHklBwApI6c9+m0jmhDW/hgX9aybzfrdIflS2kF52O6psrAwA5gDBHbp2poiRZLTDMO1+cYskh4svMlpQXxnb2Gf4k8AnoKmrQV8dvjzL19+OdDiJiNrKcDaCDkjHU5wfzpfA1RlfME2JUTxU8OXY1xhQ7Ew7ekT2VupaQ2FPoSkjeFY4x3zULXGyM6dkfst+I/BnRhvfUsHa7uIKcpxxx0IyKtP4wy4LXitpaI02pl1LLqHXmHzHKfPc2tZWOmNnOeMGoa8QdMqlX2ZIny5KLiwwpCHHT5i97aUlLP4fiQeQFA45AqQX+bgsdk4ri/I0FouhWr5akS1SkPMqHCW+3yPzoa1Vohli1iO0ylIUrJVjnAp9sTcuNLLtuX5bvG9k52KyMgKHoodD1B4NEE9SLyy2otFlfKS0vqFdwPXvXRQg/wC5E4sWOpWi4adebkjkhxH4k9lJ9RU2aWUw0Spbm1ck7U5HX4RwPtTDqTS0ra4pBSpSTltaRhQ6cH+1CV71pLs0azKZbQtAbWh9tY4K0qHGeoIGCDTBamSsBJY0RPmW3UU2wXBYDM5QXHcV+EPJ/wANWfRQO0/WpCkW4WtSVoC20qCXEJUMEJUApOOPqPsajXw11laNZoYjTkBcgfgbf4WDxwFDv3qW4thS+/GInqehpHlFuavBQkqz8C/kVE4Pc0ORRkF+5RgYof5JY8IfaSulgS3p/VDr170i/ht1l5RW7GH/AKjSjyCnrt6GpXuWnY0GY43HfRLiLw6xIRyl1pQBQofUEVVq+aUlaXub8KYypiSwU7214JAUAUnI4IIPBHrUoeHnida9LaLkuamfliBb3W223IzPnLQhzOE7cj4dwPPbdXLzY2XQG50UKuOQMmnTNotapyBLSnHqqtXidqGDaLc5EtzTe9ScbkDpULXT2wPD+0qzCsmoLuR0LnkxUn81KP6VHOsfbPh3iDObgaLjW+SWwIr0iWqTtVkZKxhIxjOAO9SrjcnYhl1HUa9ZJULitajknk5oOZfHv4z0oGvvjlqaetSi7CSewRAZH90mhSX4n6ldO735CFejcdtP9k1aqNVSNmW5M0hrLhV2rzFvrFhlNyA0lxaDkA8gGoRb8S9QoOXri456J2pA/tRPD8XXdS2yJabnGjIdiIUI8mPHCHXiSDtcI/EeuCa8UYarUEMvYO5J2ufFG46mtYYWNrI/hHpUazNSySgMtJCEAYp01BdWyGUsIKf3YCgR370MOJUpW71piY1A0ID5WvuIb3LUYJ3qOdwrK832Lugbs/xDisqgSU3cD1JCrYFDur/+tMbicK6UQMRnGoDjS+dhykjuKZn0pbWQRk1qzWBuamiWlBSFKQr1TUp6A8XbnaLC/pe8R2dQaOmK3vWieCppC/8A1WVD4mHR2W2QfUEcVFyUgKAAp7srbqX0FBwcjg9DWZEDruFjco0u37JWhLBY5l7utguK7hFmIaWGZQAkxEAnKV44WkFQ+NOPmBV0dPNJQhBHpXNrwNuV20tfW7rpx7bLbUN8BQyFk4ynH3+is4q+mkvF3StwscK5pmC2LU6I1wtkg/vLe+eme/lk8bugyPt86XYZSHN/2fSoF/GAoqTNCV8ArY89hJ559KRxX0lpK0qCkqGQQcgivLzwOaqEnPc0SVbsmmOa2pSjxTs6sCki8KOKExgjC5bi8sZGadLfaQynO2lsdpJWOBTyyyAgcVlTS0C9U6VN9YXHTtDjzRCFLTuSFp5GR3BBIPyqoPjh4OPaeJu9qgLhvslXnwN5CVpIAca3D8TLieM9uDwRV5b+VxbeqSypLbrB8xK1DIT8yO4+VRLcZz2rNJtv3UR3HWpnu7rsdP7pfO0kAjoQrBFXYWHHiZDmU3zE5/8AiCyLY7EuMNPn6duKN8R9aBuSoY3sOHHwutn4SO4AUODQbLllplLy0LZSFApccV+8J4xtHXI454FTN7RvhU7oO+PPoVPGnp4LnkQ3NqEyUgY8wH4cEYO/GRyKhSbYl2hJTLtjTEgBKkiY4txW1QSUqSlZSkpIOQcEEHjNNCcZKzXJRY8Xrv4g2y2W6Y+4JCnUfvkEoLgGB5qsDJJPHz7VbuwG56ettkTNkuSffIqVNvSCPOBwkFDhHXhSVBXocdRXOy23hy2XCHPacW6+hYK154KeBjdjrj04FXG0dfXtT6OgotAS6yAdrpJKm9wAUOeijySD9qc2QKLaZhQu1LGnW9pka81ZMmRUlwPyEtRyR1bbAQk/Q4UfvRVctEIi2JcZNvaSFJym23A7mQv4fjYdzuQoEZAzgntR3oHQkyERMmJbSsICGmmh8LYwMnPqaMplsDjCm3WwtChgpUnIP2rmFiTc7AxjjxMorbtORLFq1hlmVMkSX2V+9sSmAgMqyMJyOp4yT8+vNENx0suRITJZZU8AQshJwpKh0UPU/I1YS5+HMdMySqK2hTclO1cd3oFD8Kkq6pwe3SkOkNHJuEyXBW1tktcLQccKHBH6U8ZCqfZk34V5/Qlab82lC1ZiOOOLwkstgJXnjnBwDn5GoW1np9ttchLzTyG3VBakKb2rQrH+IjscZwR3FXy1h4Rof3B6LuA74qE9deDbpaUWS4pKejTnIH0PaqU8gHTSXJ4h7WV08PrZpuz3Rr9pX+XFRuSsslrykOYIP+ICRj8qs2m6Q9UW9qZDdT7sr4RgDGeBnjIP2qumrfDifBWtbDKlKQcqYUMH7ev2pns2s3NH2mam3Ri1NkLQhT7p3BgDOQlP8xPc9hVSuJAVKy0dum6gkpnvz2ZCIwdRGD753lxhKAGx0/CMDB+gpxUtD9vnwHT+5msFhfHQ8FKvsoJNQz4M+K9ymx5rCphMlraXEKG5t1s4GSnpx049akpvUUSd7uHVJgJAwsFBWncMdFDnB6c9KUyhv1OxKsTkft0ZCN9lJTHbkMuh1lSi2sjq24PxIV6H09RQy7IBOSrinzU+kZVi1de4MeU1Mhy1OFIbPKHP8RAUnGQRnGehB61H/wC0VpOSnd9aH8f1Efk+48Le3qISOD3pI+gJPH51paurZOFDaacYURd1JbjALVtUvrgYAya9VTwPKM7oJJxS7SaAdS2zIyBIQT9jmkjoxlJGPWnjQsQydTw0ISVK38ADvg146BnhsiHz0YvNhaup5NIHQnZtxginzbtb2kcjimp5oblADmgno0XhouW3pwFCsoht+lJ+omkwoLKn5LhJSkDsOTWV78iromEMTPsCRXGKlktk5SsECmeUz++Kcc5xS1twMKQpJPwkHBrc9b3bjeDHj7QpeVhSzhIGMkk/SnHW4oW0aVNeW9tJCgDjPrRBZgA6njimT3Zxl5SHElKkHBB7U+WhCg8gAdelbdiCNGWc9nVFuuF+QZr6IExhvdEnOp3MheRtQ+O7aj8Of4c5pB42a4k6h1s7MtkcWq5RU+7SmgvJcWk4Wgq6LSCPhPpivfhxZXLZo2fLklMZ2QlPkpX+NxAHIAxkA5698cVGrt1BucoyFAoeOStSc7Vj8Cjx68Eeh+VcdsQbK2Rd1OyuUrjVG1ctj7L3tXoR7vpXVDxaYGG48p08x1HGELz/AAHse2fTpcMy0lIIIIPQg1xjkzXYkv3tLvlyEfF5hI2qGB8PzHYetXT9k32nW9Uwoekr3J/5wI226S6eXAB/gKJ/iH8J7jjtXihXY6jUyhjR7lvpEwJHKsU1S70lkHJAHrTVNugSknNRzrLWYgtr+LAHelEyxVuSzZdSNSZvlJUDtGT8hRpAlJlt5bUCB3qo+h/FBqW7JitrBly3w0k5/A2Op/P+1WL0je2GoyUIcC+AM5oVNdz2RNWIW3VlZt75RgrQnekHuRzj9Kartp+JMs7rSoiDEklL62kp2jaogq6Dr0P2pfKnb4TxSf8Ay1cfanWy22TJiQw422+2y2GXtp+JK9qQQRjt/pV+DdicvyNUZCfiH4XW/V1hmRJhdfkRQY0cOEFW7I2qwRz3yfQ1z8vOi7jG1I9pmawx79GbUYa5awkOMoGVRwtfCdgyUDjIyn0rrfL06wp19C0lSwFIUvbwoDGecduD+lVk1x4I6X8VWda/tpJj3uJepC7Y80rC0FCE4SUAfGhW0Aj0OetbkJWh9wcdOCfqc+pTrKoyWjGhIUrhThSVKxxztHT04qa/Zl8RHrPrO12udECIdxKmX+CN7iE5QUDH4to4/m/DySKB9aLdvdylXO0Jt+moy5KIj9pgJDP7PfIASklQ3bHCkkOA4z8JwcZGkeHt0JCpC5SVbgrzi6s+WQRhWVAcpP0+VLIBFNDVmU2k6jN6t0u1EacRe7etpaQUqQ8CCCAQcdR171qk6gsUtv8Ac3e3uZ6bZKP96oRozUfmRYNrm6k98vkuQ62vK+WVj4gpSgPjDh2kY75FbbhAu1oekKmhbrYWckp8wJVxlOcDAT0+n0pi4g/Rnm8hk7Fy7L8dp4bm1ocB5yhQV/am61OxrPqRqQQlCHB5a1fPsTVK37+7DaS9DkvRHk8pLK1J546EYrdb/aU1Zp1yOqW83doG8IWmWjLiOnO4c/c1jYGA0bmr5Sk/IVOhU+E3OZ3bQQRwcUGXjRDcoKUWR9hVaPA243trW6rxaLyX7Q6pcuQzIkkq8r8a0qbJO89gU8jFX0i2tm4WqNMZAUy+0l1B+SgCP70grugZQmXWxKp6z8KYcqMsuRQrHTaMK+xqqfiF4ZNWC9G4wm/fDnD8VYA94b/iQcjhfdJPcCulN6041IkOoV8Pw4SrbuCFE9SMVCHip4ZRZO0yGRHfXna6gZaV0zg9vofSq8INSTyGUmqlDEsTNFXJqQxDhuQpQK405iP5RkN5AKVY/CofhUgj4Tn60fW+5MXFiO80R7slvzU45IO4ZSeOo6Ur8RNKXTTUK6W9LIlWiUoPLSEbi06nH71vj4V4yCP4hxzxUU2a+NafNwZYlypK5JbCYqIoWlxIwSsKCshXyAPzp5GqrckDcSPqPnipNFsusG9IbCivahbas4c24KQcYPKe4OaWaG0lonxCs7rhWdPz2Mecl3e818WMKBBzjOR0yOOTTdrVLGstKOTGnVJEZBfbRt53DbkK44OM8etNnhc8izXJku5DUhCmVHHrgj9cH70WPagGBkFZCR1Nnid4NXDw8cjPSmA9bJad8W4w3PNjvJ4zg9R1HB9RQbbnVWpMhbazhaNnPbJGf0/vVl9UahsivB9u0XqSpKo05EyM00AXPL2qS4lORwFb8DPHPyqsuobs1cpi1R4rcGM2AlthrO1IwAOTyTxyTya8NniYBHH5CfJcwT5br6Ww0FqzsHQU/wChHHI2oorzClNrbUFBwdQcZ4/Kg1l8hWEgKKuOakrSNmehPW+atv8AdSS4sJH8OEgAH065rH0KmY9m4XyipSlLUOVHJpL7tvWDintDKJKc7SBjuOtH3gP4VK8TfEi22lxBFsaPvU90dER0YKvurhI/zUq6G42rOpK3h14XtaD8IY93uTYaul7CJSt4wpiJnDSfkVn4z8gmsqWvH8Nz7Jb4bW1ldyklSUJ4DcdpGEJA9Pw1lSabZlwJUUJyPWysMrcWEoQkhPJ5P0FFMGNFejxcxXYboZSy+8s7i4FEfEBjjCc0Ex5LL90Y96dLUTzAXFpTuISOeB9sUYadvdzst+/bMXyxMtxVJSiS0HEFWBhBSRgjCsYq7LZFSDFQ3EWtWG51zEyKhTcdeGSMdCnhJP1Tg1t02pxIaZWMlKgUqPUD0rVari8l0vOoQlsKBOU5SpRV0Ce/BIx86NYrGlk31halTI0ULIkxIxS47HTxtWkkYVjIJQeeCMjrSuZWlIh8Ax5Aw1iXj9nWdzJCUBv4s/Tj/eoxnz/3qj0JP60X6ohuQoDTXmpfjuYcakNg7Hm+yxnsfTqDkHkUPWvTrd9kONKlKZcQkFLTbJdcd9doyBx15NGpVF5HqebkxCiDcppqVFQCMLS5gAngpPPp2P8AetWn35NqlKlMF1lthxCi+3kFtWfhWD2IIpReba5CcTtbdDJGApzByRjPIGPtzik0u7ybVDaYYX+/V+9eUoZABGAjB+XJ+o9K2+Q+PuAPibPqdAPB3xya8SdHBua+gX+CgIlpGB5w6JeSPRXf0OflQp4r6lLNukuBWEoSVE1TLQevJ2ktQRrhDc8tbasFIOElJ6oP9JqZvEnxDj6k09C9zX8M5Qyk9UgfiB+h4qJ8JVx9TsYfIDofsRPoydf44N0jIKmiSSQfixn0qzvg/wCKBlttNvO/EODk1Dvgnp1q7QC7IdUGU8BsHg0V3LTf/C15bkRMpjuq6p7GkPRNStL4y49n1NHkBgOOAN53rz/Kkbj+eAPvRfpS8xHIMp+E4Y9zjEvlsklMlokFQIx1HPA5qpLGrJMKPH2OkLUNvPPHGaNtB+JCYmpLZDcdAmyVFbTfUoSkBSnCMdO1dDEBjw829zk5wcmb8a+pbOO6dQRfPhsttEgBS3icIIAyUJA+LjPNRVp2HAb1hrPzWQmaLu6GHdmVBG1ClAZGOtGs1l2926I3BmLtUhlxLrMhpIJbOMFJHockGmXR8R1yRPnutxXIki5SpD0tZ2r2ggZAxjGUZ+lGfkRJlPEECc+vau8AtVaL8TJut9I24ptW5ElTbaUrKVKIKk7FJwoE/FjBwcfKoH1L4f36Gi0v3BydJavEVE+A6+6t73llRxuBGQVAgpUnqkjmuxFx0latZol/tNgr95bxHaXwY7X8KgnoFqOFE/QdqoX7THhBqnSDjbJkSU6ZiyFu+7x1kMIW7ge8IA/DuOAsDAB570LFhVQ0Ctdys7egbhY0NyJqY9sSCFbZz6GVEDB4Sfi+Y47Vdr2aNHuao0eq7WBdn1TEgyPcpCLi4XJLbgKVAoyNoQofEnI5yoVSZ7TMZDyw81+/ScKUrk5HXrUm+zP4qOeC/iMh1b7osVxCY1yYQcpU1nheO6kE7h9x3rwv9iZ4gVxAqWyvvgbZouqLrMVpCQ7HlbJIDbYcQxuwFoSgYAGe2D1qINSeAelb8xcrjEaegx4e3z4ba1JeQg4/eJSQcgdx2q+EFDs52I8opmRHmgpmcychxJSCAr1yOQoU1SNIOKlvsutsSErSQ2uS2FFSD1QVdcfWmg/UX13OeDXgTq3w41NBmWGVImMFQejFtOx1QwCCkfhVwedp+1XT8AtcXC4aTjWi8Oq9+YThHmJKSkcHYQRkEE4wfWnPUeh7Za4MVt+PLt7bJAbTHPmNoOQR8KvmOCDSzTtpgaquTcZ66A3BlOWZaGS1K4A+FWeHBgd6RkxczyHcpx5Qgo9Rzeddk+ZJU2h2zrdLTpZBEhsA7d+ehTu4I7UPautrl4iybRZ5UeTKwNr8llTiEHjBUB1+tNNx11YdE6xVomVqeKZjrmPKaPl73CU5aKjw2s9hnByO9HkLdcmUQbRbnYyEqxJK8IKMYyCrruzTQQooRTAsbMr3D8EbnKbdev8AID93a3xHkRSDEbScH4AB8WU4IKuQTioS8T/Yol20G76TccdlNK80wlHYHTwdzShjy18ZHYnuK6Lw9MNQmCGW0oCx8bah8K/r8/nWmTYY6mikJwP5V9U/7iiBI7im4nqclIwh6kfk2nUzv7CujwVGN4dZKUlzGNs1sDOexdSNw6qCutDWsYOpPCF2Npu/Wj9mOJT57T6gHWpqCQUusuDKHEHspJPXnHSr6+0x7MMTXcCRdrQ0mJqJtPVIATKA/gX/AFeivtVU9La9atdic8OPFO2v37Qi3D5akcTLK7nBfiqPKCk/ibPB5GK21vcymqwZWzUmqZF2k+WtSnUbgpxZPK1dAPoKaXWw4lxe/CQoDKh2qSfHT2f7v4Makgq95bv2kruA9ZdRRE/uJrJwQCOdjoB+JB+oyKjqaoMF1nG5a1fCPy5poodSc37nqKwhPxlQcSOMjoenFTVoZb7liQXnnniTt8tTmW28Y4SnscAZNQU08ttbbKPhT2UR1NHHhteJ0a+RmAVFl50NOIPQ5HX6jAOaS45dxuNuJoSY/N4A71dP2Y9CL0b4RvX15vZdNTLT5ZI+JuIkkJ/93xK/9tVc8OtAL1/rSz2RrITLfCXVgfgaHLivskH9K6DascZ09ZkpaaEePbYqUMMgcBWAlpH/AOo+xqLI1niJbiWvkZXnxkvrlz1A4lg7kQkCG2B0BB3OEffA+1ZSS+24RC2FnK1ZUpZ6lROVH7msolAqaTucvWXERiS0A45kJDricgHj8I9fmaKJb2x5yIlCnZD6+EDgr5BJJ9CcflQ1bbHJmxkTJiVMwUHhRGC6RjhI7n51tjQ3psxUqQpRyrpn9PoKsYAnuQKa9R5h2+VJl5dd3bThKWTwOnQj/Spq8DvBdzxA1TCtcVplDjhypTqglCUgZWpSiOEpAJJPpUb6ebcS62ENAA4A4yfsO1T9HnQvDvSHvbisSHBs2pVgvrIH7of0Dqo/bvUuViNL2ZViUH5NGLxc0u/omyK0wp4rNiuLzZjxD58ZxLh3CU251SFABJTkjgHg1CbtyfYBWw64yspKCptRSSkjBGR2IqR9VapuItyY78xRlyle9vqSADlXASeBgAdulALkUXFSXSFMRyf3uxPHbhI756UxNL8oL7b4x2YbEjTkRVwgiCwAVm4Oqc3ykbhhDbR+E4wRlI+ZNR/crixJuL+4FlLiypJWMYz2P2xRVdtX3C46XiWtyJKQ9DmOvF5eThtaEBDfIyAnbgDpimFu2TpzJdW0A3284gE/QdTW4wFBZtReQliFXcZ5en7jBaMr3ZwxN4b84cpyQDj/AO6fdN3APuNxZCilxOVN7u/qPrRhAZcd0KqzzWm2Al3zWZK29zsfplLaiQAFYBIPpxQqdKQI/lvG8tMuBQKVPvoTjpzgZND+VWBDGEMbIQUlpPBCc0izJaSob85IqW7lFYkWt9clQS0hsuKUf4cDOaqPpfWkbTL6W2rsxLwQUyIu4t544OQCKkLWnjITosBa9qHSA4EclYHRI+px+VSfiLtYnXXOFTfqOGo/FyHbltbGnkvIZJaZUjd5i+oHHTJOftQ17P8A4oz5fiRFj3V9EvzXlPtvS/hMd/GQoKIwkKxtKTxgcDOKhj/idzUU2S5ImJhu7cRmSvZkn+vHBx+fSkjCZNsdQ5NZfKVEFQeWQV9MgKHBzwapy/IcR66nOxtTcz77nUPTPtEe9sToAbaj3RiMlLUVbuZLkhYSlJSkjBRzuyOgIqYdDvJlxoVoaBVHjNoVIJHBSPwpP+ZWSR6D51z79mq4M33XEG6XFwbbZCecdkLA3KSMAE8ckgpH29av74dLmRoDb64ZaEhXnLKiAeeg/wClOBQ4Q4S37hZuBakh7cLep66RpqFKbWElpSk+h5Gfv/evGoNHQdX2aTbLvFbkx5DSmnEkcLQoYUPlkU4xpqXE89D2NL2ZbaSncr4e59KoqS8jOVvi34KztBasuVrfSp5VvfTHU9j/ABmlAqjvf9bYKT/U2oUEuaPHk8JCVj4krx06V0p9pjSFpXbourZcUyIEdlVrvHlAFXuTyhseHH4mH/LcH9Kl+tc8b1qdlmKmM3BTDuMdxQelF9SlFSVYwEfhTjGO9T/INxEsUqycjLzexl4hNag8PmNNzFH3y2tqVFKz1aSoB1oHv5alJI/ocT6VYCew2610wodCOork7oDx8vugtcWm8KnLksRJ4mOs4ADgUnY8OAPxt5B+YT6V1Pg3Zi6QY8uK6HoklpD7Do6LbWkKSfuCKanIaaT5QL5LGue0/wCWpBw40rhSFjII+lCC9ORGZ4Uh0QnE/HHdB/wlfyn5H9KMrnI+ApCtvzoGvMZwkrbmNpc7BRppEBYD+InspaU8apy785cZtgv63AJ5h7Voec4+LYr8KiBwpPHyqbrY2xakBmKVLW222lxbhyt5KUhIUo45VgZz3qOWtRO6XdZmOMF5tQDT4b5Slo9T89pwofcVojan1bdrjthR4S/dHlMTEJScqcyMKH9KkkKBoaA6EYbOidSaEOpSAfNG1XIyeD86x0pcThOCn1obtVueQhTbwD7owsFZ4CVdh9CDSxx1VuG4lKUHqlPQUYiP9TxPjNqbWhYCkEYwr09KqD7T/gxCaam6lhQG3w9j3oAc7+gX079CevQ5q0t1vaUrI3Co+1pOj3W2SbfIAWzMbWyrIyACMc0LIHFGNxlkbkJTPwf1jadU6SvPhhqphcuwSEKfitFWXIy08lTRP4VoJ3pP+YdDVW/EbQEzw+1xOsktxMpYKVRpiRhElhX4HU/UDkdiCO1Heu253hpr4PF1DL8d4PpQlwFRSFFJyByM4UMHtTv4wKb1ZY4c9nDky3Ly24epYcxuT9Arar7q9aYg+G+xFZP2qQ9ItzTaEYQV+XhRUB+EetSP4eyrKpLb20sSAChlDoG4/wAyvqal3wF9jTVnifp1i7SIibZY5fxJmTOFyU8coTjO3rhXQ/MUY6n9gxWg58W5t6mEz98hli3GNhSlLIASFg9PtUrZUbUeuJlo/cmT2MtFp86XqN9nKnj7nHJHRtIC3lD/AOKfualbxNvipriGEpyHHy+oD5cI/vRpo3Tlt8O9BiGyEMtW+MmElz+ZfV1f3Wf0qH9Q3ttb0m4FW1AJQyFfTr9hUqAk39ypiOvqRh4paiXaIDrzSU72lJbST3USM/pmsoeuS29ZX9bDyC5aoGfM5/xHiP1xWVV1Ju5RC7SnZD48xZWEBKUg9EjjgV9tqRkDAwPl6VlZTPUV7h5p0BDrakgAgBQ475FfdbXKTctVBqS8XWmVpYbQcBKEfDwAOnU1lZS1/eGf0MkXW+jrPbtOWeaxCAlSAjzXVrUsq+FH8xNRs68tUu3JzhJKuAMAfEE8enHFZWVHjJN3/ZaQABX8iDXq1R3pLyVKU4FlIU4d5AGAOuaia6amum/yxMWhAHRACf7CsrKt8ZQRsSHyWIOjGh2bIf5cfccP9Sia3RVqU0STkg1lZVxEgBJi+FJdiPpWystqB6j/AL5o6kyXXjJiuLK47MRbjbZ6JUQDkVlZU79yzF0YzaYPnS3EOALScjCgDj4CePTkU6adbEy3zA8VOJZSC2kqOEnPYVlZQN7mj1J49mlR96iDs5MYaWP5k5KsH5ZANdB7NqK4qdZSZStucYwP9qysoj+ojB3JOt77i2kEqySMmnRC1HjNZWV6KM1ajitXXRGoIUttMiI9bpLbjSxkKSWl5FcbtTSHF3MrUslTrTLiz/MpTaSon6msrKH/ALCMX9DB7erzk811X9ma4yZns9aEdfeU64Lf5YUrrtS4tKR9kgD7VlZRnuA36wzuL7hUcqJoQ1NHbEZSwnCvXJrKyvQlgKZj6XQgOr2HgpzwRwOlSZ4dtpatDEtCUiQ9GQlxePxhC1pRn1wkAfasrK8YTR+l3WUiYwpLuFLjK3YSOcKHy+ZoI1FqG4uPeWZS9n8oAFZWUfqCo3Ed1lvEJPmHJAoTvct0I4WfwqP6VlZXhDPU57e1KonxRnqP4lYKj6/Cn/c0a+CFujaj1pom2XNlEyBNlRI8mO6MpdbUpIUk/IisrK8f1aTf9xOvMlpEVkNMoS002NiG0ABKUgYAA7AAAYqHtc/vvEHSjS/ibElx0JPTclslJ+xrKyuO/U6OPuetdXGSnw/teHVDzVbl/wBRwTz96g/xKkux1MNtrKG0MKUlI6A88/pWVlOxep5/cCdPLLVoYUj4SpG8kDqonk1lZWVTJp//2Q==",
    bio: "古竜の血を引く少女。冷静沈着に、竜の力を解放して戦う。"
  },
  {
    id: "c7", job: "seraph", name: "セラフ", title: "天界の使者", rarity: "SSR", atk: 50,
    img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAETAScDASIAAhEBAxEB/8QAHQAAAgIDAQEBAAAAAAAAAAAABQYEBwADCAIBCf/EAEUQAAEDAwMBBgMFBgMHAwUBAAECAwQABREGEiExBxMiQVFhFHGBCCMyQpEVUmKhscEzctEWFyRDguHwJZKiCTRTc/Fj/8QAGgEAAgMBAQAAAAAAAAAAAAAAAgMBBAUABv/EADARAAICAQMDAgQGAgMBAAAAAAECABEDEiExBCJBMlETYXGRI4GhsdHwFEIzweHx/9oADAMBAAIRAxEAPwD880Nn0rc2R0NS48beQKkO28bSQMfKmxUiBCCjAH1rWhvx4r6tBZOKZdL2iPdEqQsgL8s1BNbyVFmhF8J5xXsJz0FE7xaf2fJU2PI1EbaweakG95BFbTUlvIHGK3ttDzr2lrFbktj0opE+IR5VJbaz7V9bazUtloV06emGCT04opEaAIBFeIUcOGnfT+hfj4KbnPfNvtAfEYPhO52Q8ee5YR+deCMk4SgEFR6AwxCjeEAWNCGNEWK6s/CJsUF6Tqa6tq+BMdsrdjsAlKnWwBkLUQpIX+RKVEYKgR2F2aWJv7LPZK6i8R0N6inLMqW0hYWpSzkNtlQHOACeM8k1O7IbHHl9p9xt9ktLdp01pWJGt0yUjl+4y0NgJYW7gEtN5JKE4CiCVZyKSvtW3lT8+DJ3FfxBdcQ2fMJVtT5cDHpWB1eYmkG1zc6TCt6j4iB2idrDusbi+63JkZEctOFRG1S1cqSj+H3PpVE3iA9dbimLCjvS5C1bUssJ3K8+Pl7mrjsXYxdPgmtQ6q7y2W57Hw1vb8EiSDkjj/loxySeSOg86sTS/Zbd35rb0SyGDEdADaW0bEIQckdeTxzk81VUhTtLrLqHynPsfsjuTaNl6CI6Vp8MGIMqR7lzzV8s0x2LRFrsq0uR7PGLyOj0pHfKz/1ZAP0FdYMdmiY7yxKLMie2jwh1OEvo9AccEUkaokQYaXUMR1xXk5SUqbSQD6dOabqJigFBg7Q2o7hG7oGapBByI7iu7QR7Y4/pV72DWjT7AE9iRGG38fKkn/qT/euPbzcpTzp3LTgH8jYTUmx66utjJ7qZIbHl3bpA+o6UJXaECJ15cdP2HWDDpbiWjUuB4ocxtPf49Engn9aVrHpjQEdEqxRmZOmFy5aXZLKV/hWAQlIKhlAP6cDk1ScDtIk3qS2q4QX5zYPMqKC26j3DicA/XNMmrtN6h1JZ2p1tN8nMNp3N/HsofUBzwlxvxj+YpZJXaGAG3MhdpP8A9PyXIbem6W1DHmp5UIlxb7pfmQA4nKf1ArnTtB7Hb/pC2Mv6gti7dPafMV19ZCm5KSMtubhxu4UknPOEnrmusOx7tzudpjOWC+TxCbz3Tc6Ygq+H67kHjOcdM+1G+1y0JkQHn7WH7paX2z38e7W9wRpIOSdiykDnr7eRq2nVupAbeU36RGutp+dEyAuO4ULSUqHUEUOkxt3lV/6z7N7RPtYf06HkyWHCp23POd4tlo53d2rqtAPiHmkFQ5FUlPYLLikEcpJB+dbeLIuUWJi5cbYTTQG5GATUJ1vnpRpxvcOlQX2sE8Zp0VcErZ61GcbwfnRRbfB6VGdZz5VFToLcQR5VqKfXip7zdR3G+K6TNIGfetzUZSx0r42PDzRe3ob7oqVUE1Og12MW0g4qOpORRqdsWngcUNeSMDA+tRc6D3G8eVZUhxGelZXTpLhAeXWpK9w8q0QcAEkVvU/uX0wK6dBsxHNTLFLXDc3JJFan2y4TjmiVlgpcSQoV3iSJsmyPjnN6uTUMp2nAonKtymgSmh2w55ogJBM8p6+9SEJrw23znFS2WcgcVMie2mzgYFTG2s+VfWGciiEeIXPKunTfaIjsmS0ywjvHnVBDaB+ZROAP1Iq79Q6dks9rWnbBEIetlkhw1Q9nLbiVIbdW77966skn3A8qrC2xDYoKZ54kyErbijzSOUrd+mSlP8RJ/LXUv2d47t47O7jfGrULjcbXBhQO8WBlMdiapSsEjjDYQD7I9qpZ8mhS/tLeBA5CeTOq4kC06B0VdIsN9mO+0t5T77ygFOy3clTiuMkk5AA9AKSbP2OJlXVjU2o2xMmx2UJg291H3cZI/CtafNZPISemeal6ahv6knsawnQkgrdSzZoDicguLUSXl/vbcq2n2J9KsjtDvkLRelFTZThLbZ3FX5nFAE8fxKOAPnXngTkt3m+R8LsTzKgvmipfaRfruwHilm3MqYbcI3BUhQy4o/TCasjTdpNjscVqe4hBZZSjvVnGQBxnI8umfPFF+yixCy2BtuSn/j3kGTIKhypxZK1fz4+lVv21a0l6dfbFskuHaohyG62FBB56ccg+lHpCKHMDUXbQOJv7Rr1At7sP4lzuO9KkoWpJAPnjOPrmqI1xqa3OTHG3VuHjwvrYJCh6bh1/SmvT0tOqoqrlf70ItvSopajLeBGechtrnHX0qcvs8sF833pxEq22SKrLkySrC5HP4W0ep6ZpQYk3H6QoqVBbtFzdZlxdnhvKbbP3st1HdMt+xUep9hzQC6WpixOrSVIlOJOO8UnwZ/hT5/M1f0nWTd3aFsisJtdoaT3ce3xxgrPkFq/mfWqt1zYGLO++7cHmW0Mo7x5W4bGh1wT/AOelNDG6i9Iq5WcqU/Md3LWtzHTeScfIdBURfa1D0rlpFzlLfTwWrco5SfdQISKHXcXXWIWmGhdpsZ/5yhh6QPUDyB9KjWbR1kgyUMvs94kHClK5xTKHmBZ8Rkhdp69TMqlqjyW2VL7oypC0ugq/dWeoz71b3Zdqaza3bk2TU0txDkGMp1i4ybi6hLDKeMbFEoGCemKpWZaLctx6JZY7MLKQH5SyduD0Tt/MT8qV9YaOmizNSmbg6wHt6A6yrCsoVg59jwa7QDxtO1mo+auULVfnnrNcmrgyy4VNSopKTwTzgjIPvVf6ztib3uucWO00p1QVJQ0nADnPjSMcBXmPI0p6c1jdtL3VqDqB1UqEvhEkjJSPJQPmKtJS2Y7iVrSFxnh4i31wR+Ieo88VaxM2JhKmVRlEp51kpynGKgPsYzT/AK308LdPQ4yhRbfTv3geBRJPKT7+nkc0nyo5SelbikOoYTEdSjFTAC2+vFaHG+KJyG/F71HdirDe/HB86mRBDrfNR1oqe4kDPFRlI96idIpbwKIQ0JS1yaj7QBWxpOWzihIhCfZTycFI6VGRHU8rGOK8rbUp7BpltsViO0FO9ajiTzADsJSMDFZRee60pwlI4rKmRF9Cij5GvSFHcPMV54Ir0jgVMiTG2vBn1qZEK2B4RyagtuEDAovbfvTyOlSJ0+OS3ACFD6VG7nvjnpU2W2EqJxXhhFTImtEfbwKlNNe1bUNYrchrnpxUyJujsjAJotEQAQMYFQYyMY44ps0nZGr3dGmHXfh44Sp2Q8BktNIBUtQ9wBwPMkDzqDsLMkb7R8b7Jr1rG2WK7W8RWrM7BbYXPlyEsx4jjI2OodUfwnf4wACVBwEA812Z2NdjVs0NpWPpdqY7PeuATMnSdpbSpAUVZCMZCMkYSrknnocVyRpm8ftuY7PmR1GyWtDbUK2JWQ0g7vu2gfIkBRUvqfESea/Rbs2jd/pZepp0P9nyLq2Jao61biwwAShG4j90Z+tY/VByAp4mr0xRbYczZAjRntQFplCW4tpbSwy2OiXFDJPzCcCq6+1E8RatMQUKCTJnrUAem5CAU5+uKeLFNatGlZF7lqwHlOTXCfPccJH6ACuYvtG9osq72DR91Cgp2NPkhSR0CkqQQP8A28VlFgFo+ZpqpL37TpNrWDc6xQbowsMqkNh0DOChXO4fRQNU/qnUdlujSZa2RcZkkrUll47GWG0kgrdPBPPQedV9fNUNx9Hoi3B6VEkHfc7crbiMy2sFOX+MkK5KR5cHPNJEzVqI1uRAYWvUV0nuJwCSpLqySkLWRjIzwE9BjNL1HJGhBjln6f00/qe6u3UFu1aajDvJd1UyGgtAzw1xxnkAdfPNaNX9oreppqWWd0O0RR3cKGkchPTcR5rV/IUt687TZcq0wdPiYJEeAkJdU1wh98fiXgDBSk+FPsPelGC4vf3yshSvKiCheJJJbmWZFYb7lMs7WGkAkqcV+EDJJJ9B5n50gydOzu0GUu8ym1jT7S98KM4MfEY6PuD0/dSfLnzoq1L/AG4tu1PK3wmtrkxI4Dnmhn/L0UoemB51Z9qfTPtrqGmgsZ7pCccFX+gFFdbCBXmUtcbG+5hptA3nzxwgevzoFcdOt21glKCsp9Ryon/U4q7LvpxVv8CR3i1fnA6mlWdZSX2wpGQye9PHn+X+5+lQDXMKgZT8/T8hgEEYKAVqI81Hqf8Az0oNLjyXILaVblN7ThPp5n+gP0q35trS/wB8VJ4PAAoRIsITGUju+EoP9DTA8ApKjmacj3OH8NJa3JWVbSOqFjkkfMH+VaNFCTClPabuCitTSS7DcP52/MD5dflVmK0wrDJCcEPBz6EHNAta6beilqbDTtnQVd+0fUDOU/IjIpobxElfM+/EfD2pxEiG1chDV3qGHU5SoDlST7KH9KqO5ONSnVusoCGnCVoSkkgA9AM1ar13bjSY05sf8JJShwjHQH/T/Wq31HZk2K9T4SB/wxUZEUjp3aj4k/8ASrNa/St4mV1S+YtvNc5NaJC1d3s8qIrTuzUKQjFaJEzQYEfbIzxUNfnRSUng0NdQeeaGGJHJPSisC2OPNFQHFDCMEZpgi3dDEMNpHiI5pbbcQl+cGuMpaf56ivj0vcMA8CtEyQS+T61pzuFdOM9LWVnisr0kFXlisrpEgrUABgc1iTxWpxXPFfUHNdOklrOQKbNLRPiXiPLFK7DWRmmGwzTCc3CpN1tJFXvCd6gJjulIoa2jngUUnzxOXn2qAlOCRXJdbyGq9ptQngVIaQc4rU22eP6VMZR6DmmgRVyRHa44pos0r9maavK0p++lLZhhX7reVOr/AFLbY+WaAxGio80x2yOJUdy3kDe84hxknjLiQQEH03BRGfUJriLElTvL1+zd2XPa0YtUyfKYYsouJQuKsHvZTwCTtTxjb3e7KieOfM13try6txOzy8LZUlIENW0J8k9OPbFck/ZnQ7P7VJtqZ5stltj0FCAMIKtwStzpwVulZJ9AB0FWrre+y3tJ24vtLgK3riSmFk7W8oUhxJ4/DwFA15nrMjqxviei6TGjKK8Sd2hajaHYxbvhydshYaOPy920okfRQNczx5cV96Yq8W9d4sUCaiYuO0rHeyvEG4yDjxKdwMgdEpUo8Cnm8dpVsRbmrFOYGySWpgRdN7DDEpSCkKUUYV3TuN/GAMnPWuXO0PW2otW6mlWpVwhw7bp2U60yq3tBiIy/uJ3tICckqIAyrnjk80jHi+KdTbAR75TiGlRZJlwdsHaMnWLEUCDGatr7SJP/AAjiXA/kHBUtIz4fw7QBjHSky16ldtrKNkVmIWUq+HQyzhzccgunIyAATjpkn2pNutytjamJ7sNVqltthCWo7qkF05UVKCP4lEnPGM9K92uC3eEftGSglbp3bFKJ45xn1qQgAqGclnaMlukd86VcLVnwtg5CP8x9faj67mYUbeU71jASg/nUTgD6n+QNQbXbu6SkpSEgcYA6fKtMomZewznDUTrjzcUOf0Tx9TUcyY6aaxGYG5e9xZK3HD1Wo9Vf+eVPFtvyoKktR1fdgYyPM+ZFVlCnBQCWyCj1Hn8vajyLq3BaDjp8wlKR1UfID50lgbuMHEuA6kjuW1SpBaYQhKnXpDhwG2wCSfYYzQLs2gM610p+3nnlb7w6uUy2oY7tkkpZTj/IkKPuo1WOoFStVWuZbEk/Cd0VzFJPCgBkN59OmacdM3xVhtUOI14G4rKEJSOB4U4orsbztBXcQrO0s6w2t1Le5pDpBPsOKFz7SC0pKUjcrwime3amS42zFlrHdHG72znOf1ofebxAM51uI2XNoSlBz1WpXJ+WM0IFSb8GJtxgEIkBIwltBGffFAH4PfuM96PCjCV5HkeKY9VX2M3HuRjI2MJZc25Oc4Scn6mgir6zPsTDyEp3SIbS8+fKAf8Az500RZ9pWV3tQjw34KRkRZC2k/5FeJP9aXr4wblaYr6xlTSdyTjnIG1wfUDNN9xWV3KUDz3zec+qk8/0NB4zQetU5kDcplzvUD2IyR+gNaOFiCKlDMoKm5Wr8UsKUnrg4zQ2Sn1FM06L3bjif3TjP9P5UBlt+IjrW7yLmB5qBZLWc+Qoc63k4oxJTjnGBQ55AzkChhCD3W9vXmvaOnTmtjyCrHGK2IZOwUMKoPlZK8VtYa3qHnivMoePpU+3tZRmonTUpnBrKnBvOTWUMKKawd1bmk596+PIw4a3Mt8jAopEJx28MjAqUw0ry6V5ZRhpIqdFSAOlTBm2OwcdOakoYweamQAggDAzRJy2b0FSetTfidpgdDZHXipTSMEcV7EVQPpipTEY55H600RZm+GPEOKfdIacTdAZkiUxb4MZxBckvnjdnKUJABKlHB4A4xk0nRYvPFWZ2faD1Hry1PQdP2mTcno7/wASotI+72lOxQKz4QoeE4JzjPpQvsOahILPFzrr7OGjo2ko12vsl+3pi3dapQmsyw4FJWVFKcbRtx4uOuVYPSinanrKzxHH3BIT3SkmRvkxwW3SgK8e0jJAwMkkDpzS3Bkq7F9BwLLdAibIgwnZkss+MIWSdzScDxY3JBX5ckVV2p9b2q+abfvF8XLjv3RDjUO2sJDe5kA/fJeUMhvdgb8ZO3jNeefEct5X9APPk/SbyZRiAxoO8jjwPrKp7UNaWXtEviJ0BN0ekyG/+NkXZ5Li5K1khKgEjCEpTkAA4wBVLv6kU7cly1SC2y/9yJTYwVKZPdgrwOeEgn9anavub7lwagWRLUJD5cc3k/4acqy6tR6nB6/oKCr0pC0pp95USUdSW9Tgcfbbwh2O503oxng9OfanZAg7VFCDiDsNTG5u+KXcboEgB9bitm5KivcSTwD71btmgpixmkrO1pA2g45UfPA8/wC1Vd2dXi3yr0hEKzOpLKS4t6arO0DyCRjJJ8zVuWoOTpanJB3LPAIGAkegHkMVVfbaWU33hxuWiI0p5Q2sx21Or9gBnFJVpu5uT6o7ILoKiuZJT03KOS2k+Z8j6AUw6vhOz9Ky4zLnw4lONsKcHVLe7coD3IGPrUWzWj9nxmY0JgNNp8KAvr9AOSfekAgC4+iTUZreyEJCykk9AlCcknyAHn8q9wrXNul1GWz8SCUNMA5DA6Eq/iP8qHJav+mpj81papjpYKPh2AlIZB9DyUn1PX3rZo3tvtOnn/hbxapFvkg+J1Kd4PzHBqApO8bsOZbMjTzem9GyG+C66kJUr1UTilmS8iM4ltatveOJaQPU9f6Cit37RrRqq0R0WuWiWVOBRQg8jHqD0pXeSp24xXHlBS8rVgdEjGMD/WhYDgQtzuYWembeATzUB6Zhxw7jvHmPI/8AYVrfmpTLaZQN7hySB+Uep+vlQ67OfARVuq5IyrHmT/5xQVIkDVjy3tO3JlheH3GFsoI8lKSR/ShVgWU6VtAUTuENtJz7JI/tUy1sPSlFp5OVNoU67/mPl9OlL4uojWltoHBQyoAe5VtH9aaB4gMBVzXLkg3BlR45I/VJoXCccQLgtn/EDJWAfPHP9BWS3syo6OpKiD9BWuG+YtyfyPCWlZHtnn+9WsZoylkFiC74hl5hiQz+B1oH9On8iP0pPlZDhzTcLW9EtTcdzxKZJBPz6f0peuEIhWcV6FPSJ55/UYClpB4FDlsKPSj6omQSR0qEtCU58qmRAjzezrX0ugpHHIrbLRuXxXwM/de9LMYN4Jk/ePDBopD+6bFRjGy8CRxU5Kco4HSukTWtXU1leXDkH2NZUToClJwrgVuikAgGvEhOV1tjNEqGKmTxC7RGBUtnPpUNlGEg+lEIyN3tRgQSdpMYcKSMcUehTAEeI0vpGCB5VNZJTjyotNwLqHgG1gnp51eugvsha61vKQGGLdGtxwVXRyahxgD0Hd5Uoj0A+eK58juFXhz5VYelu13VWgJnxOnr5MtYcCStppzLSjtAOUHKTyPSlZBkqsdfnGp8P/edsaF+xToXRXdSdQSXtVz08lt77iID/wDrSdy/+pWD6VchkW2xW1MOCxHgwGE+GPHQlllsc+QAAFcm9hnb/r7tV1i1b7pcoabRFYcl3CUuKhvu2UA87xgJKiQkE8ZPtXq9dp72uLrGhy33GIS5DYMWJlTbSQsqcP8A/orYD4jxk8CsPLi6jK+ljxNjE+DGupRGLtb1/CvUl1rSt5nOXGG+4mT3LZR3BIIJbVtyUknBHCR15rjrXN+e1Te5Lirkuc6Mh6U44p3ITkY3kdAMAAYHNdt9l3Zg7fbVqG7TGPgDLbRhbwG8vOpceyo7eiA4jHlkVxBrSzuQHp1vQhIcVIW2CkDIaBOEjjoSc12IY8Tb8Dj6+YzJ8TKnaN/P/Urg77ncpKlbld4pDKR57c5x/IU1CE9apUcvwwmGtPcvN5HjbVkKTj26g+oFRdDx2ZGp50Be0yGHEOoV5E42rH6kUcuGnHnDLmOuKLrZIO/8vXw4ocj6mlvBh/Dk/Q+n4kJ+YUSVSX0r7kqWjbgDOAD78VYUSIIbbhWW2sggblDNL9rtBsVo3OkLcfW0VYHTOOP5UxFDTFpceCQD3ZUVY+f+tV2JMJVAivr+8iJbobiUvvtt98990NqTjAyTjPr0FV2r7QAtsf8A9OhKEjPLpByE88JznHzNdBaX041flhLyAttEfb4h6n/tSPeuw9u1Tbiy3AZciTkkJd2jLSs5A6cZPnUoU/3EaUyEfh8xQtH2jFJhuOP2+5Q0BQzICQ+1k5xuyOppotup7P2lNKMiMw6EcmRH429fxJPKf6VPl9iFulN/CwEOf8a62RFWra02dnK18AcEkj1xUvVfY3C0PdbLcrG/teihLMttPKZDfRROKcwxgWpiMRzO2nIsnWjs3+GW07a3NwUCQ45+UEHGMdT70RiuymSI8ghUhjLRcHn6H507xtPTIMYNoSRkeHCsEA/2qAdFzkb3QhLhOSQ1yr5DNVfrLZECw+6gJUvqs8qWo8/U+v8ASglwu/x8gOIRlhs5SpXRavIj2H8zRK8299lKhKZcZZSeW9p5+fqaVLywu5xylMhEVCFZUFK2/Qn+1SB7xde0sTS1lUizvvukd4/4vp5VT96iiNc2mlAkFwoGOgUF7hn6ZrczZpcp4Ij6hEZsfj7uRk49gD1pavkqdBu0cLeU/GS8Fhx38RwCMk/KmAe0BztuIQbOdTsR857tlTivrnFfSrvLksJ5Km18frQnQdxTqK53i7JJLJWWWj7JGP8AWj1uaCrxk84aUTjyylRpyDuqUnPbc23THOFBQU2hWR06A/3pVnNjnIpkDW63RlAf8gfy4oDPGM16HG2pQZ5/KuliPmYHeQNpAHFBX4pWVYo+8eKHPjaCRRmLEAOxcK5r06ztQDUx1vfzWuW2pDAV5GlGMEEvnYM1tiK3oNa5actGvtvBCKgQjxPEshpORxzWV5ufLX1rK6DBkhH3gqXFa8zWp9J70UQhs+DOM0QnTagcDyojGaJSOOKjBvpxRSE34RRCQZrDeDzUpCenFe3GhuBr2lHH9qOLm6OCk0RaUDgLBKfbrUJhBOKJsNDgYqanXH3/AG1jWLQKbBp9DzS7g6XLnMcAS5ISgJ2IwM7W9xUdpPO0GrU+zn2f3K6sydZSnEs2i1PpQ2h0ZMyQPEllI/dC1NFR98etU1pewN3R7750RozYLj0gp3BtscqVjzOOg8zgV07qHU9v0T2e6f01B7yO47FMpqMMlSEK3KWpagMZSkqJP5lH2FZfVucOP4ePdmmn0w+K2t/SsL3ntdk2/Styt1kjuPKDyWS85z3oUBHbCABnlLa1H5iuXdeW+bbH5VxuDRblPkqQ2tOCFKJxkeXnx5Zrqf7O/ZkvVOlbxqG8Lx8eFMw9o4jqCgsuJH8JDYH+VQqh/tVOvft3a6x3UhRUt1A6JXk7wPbduPyIrBOL4DjHdmbqZfjIXqhOUHLi9pG9x7k2FP7XVd6gnHepOdwz7g/qBXQzUeDrfS7NxjywC+0CJSfwujBA3p/eGMHHOc1Q2sLYuS3cGgPGw4F9PIpBzW/sT7SH9D6iahybf+17S6tTrkNasd2oJOVp/TkeeKuMmpdQ5icWX4bafBl4FiU3Dgwpm1TrauVNnIUEAgH+YrbqOS7H0dPS2n71lIB/y7x/bNDuznWcHtBkuNxWnEfCqCSpwDxbs42+3FN2r4bcNTDS0bo8oKjuADpxkH6VVNg7y2KJ2h7QM1Tb54wlXhOPL8w/qaslEZuUj7xIUPekPS1raQ+1uBw62ACk4wpI/wBKfYkYtjBWtweW85oBL6gVPa7DCfbCS0kj0rZH05DbWCthDqf3VjINTGmzxxUknbTBEOCOJjrbbiUgICQkAAD26V9aW1GacUoDIGQa1KcIOelaJSO9YcPtUkxQU+ZWet70uU3OkgKcjxW1LLaOqsA8CuZrkvWGprsC4l+DbXEKUj9nBIQ0NpIKlK6j1866utcELSo4zlRzQXUmhI8xSXkR0FKOQyglCVf5gOCKYjBWsi4rIjOtI1TkC86c1jpTR8XUMpTUhiUsjxM4cQOcKCgBwa0XXWszUNmt8NlbYkvZS8p1W3YAOVKPoP54966D7RHL1q1KYFwiRo1tZGAlCcAAZx9AK5ZlxGbhqh+Y438JY46yhtI6vAdEp9c45PlVkFXNgcSk6viSmNky5tHQWLDpJluMsht1O1okYKgc+I/PxK+oo/ox34q9yXNuR3fAPucAfon+dJrV0W81FbVhs7AopSOEZGf0CRimHs4uCrgqa4htTLi1BIJH4W8HB6eg/nXYR+ICfeKynsI+UMvlLSH46P8ADaWpCT6jJIpcuLfWmx6AqRPnbcIQ3HLxGP3SEgfzFLtxa4NbiALYEwsjFqJi2+nBOKGygSCB0o260CTxxQ1xkrfCQOpozBEHPRilvIodIcWtOD0FM8iCUsncPKgMhjAOBSyIYgiUdrXStUVzan0qVPawzQFU7unNqRmhkwnNIUzzWUMlSnXEDIwKyuudU3KTvcHOaPRGgGk4oK0jc+kCmWOwe7FEJBmpSNp4ojBGU1GLJK+aKxYv3fAwaMQDM7gkA+RqQmONo4rYiOQBxmpbbWAARxRQJqjRsdRRNhkcYH6+da2W+MAYFEorG4jijEG6m7tA1VH09oa1xIDPws6Ylx2S4tQJWA4UNpQPJOMk58wKMw+2G66l7OLJBnKYlSkNqhfGKZAebjMqG1oLA5CjtJJ58AHmapftdbms3lmU5uXE7hDTRA8KMZyn6nJ+tMXZG2u7WmOxIjuJjJfWpEoY24P4gR6cdaoDHb78iaBydgrzP0+7CnkQuzGy2k4EiNbmHHkeYLqC7z8wqucvtHaZc1Ley/HAW8AUqTxlR/Dkf9QT/wC6ny2dpMbSXbLcGlOEWaRHitBaBlIR8OjYoccgY/rQTXzjY1jOiveJAlkAHzSVEEA+6HB+grzedXLhx53noumZApQ+Npx3qa1iJfEPrQfh5cdLa+OhAx/QA/Q1E0J2dQpuprkbhPZtkZmDJc7xwFRHhwSEhJJwCCAOTnAq7+2PQr9kmuR32AxMSsqShzAHeAncM9OeoPTmq1iMfCIWluSG39ndLLLm4pTkkJKgPPGDzjFFiy9u87Jh3IEDdiLC9NapnMqxtSltRKenCucce9XrqVr4yTGzyhD2/wCmKpjQD3xOt7j3qCFqZWpWRyrCgSennzV9WK2OXstR0pK5TG7wjqoJSVf0qcptrh4R2iFbfb3WEILX+GCFpOM7T/pTzbsvMhSkBKvY5B/lQiysoZZQySSsDw8dU+RzR9obAKWBLhbxJIQMelYWyr2FYl0CtyOecUwCJLVBTu4uKycBJxW9SmEQXStZDgIx+7jzzXy9WSJdoy0SWEPIVyULGQT8qrvU8C7vuIgRZHwkNPBCB4iPTJ8qEg3GqwIhm1Lb2KCDuSFqAV68mvVxcUhJ29K122AIERtsc7RjPrWq6SUpZVlXNTvOWhKY7eNQKselJPdHbKln4ZrHXxfiP0Ga5ptdjHfsrmBa0DCWmFfic54AHknPU/pVs9q9/kX/AFO4yzuMWCChCko3ZWfxKBxjyxn2pAjrbtswSpZJdB3IZ3ZcWryJPkKt49lqZfUENkvwIct0RdwuS46uEKcDKncdcnBI+SQRVtyIrNi1K2YsbEeVF7oNIGAFN9P/AI4pB0hDelSIzwaBDakyVtgcBO4HB/rV26ktbKWGZ3dKbZiOB1Djicd5yQoAY5GM8+1XMIGkt5Ezs53A8GJr6HZUh50gtpI7sJGRkZzz60CuTATkGn28IYLLQaaKV+JbrqjkuKUc9PIAAAD/AFpHuwO81rKLF1zMh9jXtF19vBNQWG90sefNE5accnrQ+N4ZXPrXGcJLnNEtEYoBNhltndim0Nh/jFRr1bu7hcDmlmGJXdzBDBoGmKgJ3befWmK6NYZUCOlBkow1UQpCeTu4xWVueGDwKyunQha4gekpA5zTSu3GOhKvKl+ykongAU4PIcUgBXnUWYQEFIbzI4GeKOwYKlo6UU7P+z66a91E1a7Uyhb6gXHHnlhtlhsdXHFnhKR+p6AEnFdJa87GdPdhWmoyoiYnaDrBbfevR1pccjQxjgmO3z9XlAH92q+XqUw88+0diwNlO3E5rjWp6Qvu2GXJDn7jSCs/oBRH/Zm5MpBdtc5seq4rgH801E7RO1jtADPcu3iTZUD/AA7banEwUoHOPuGMYHuo5qnZ/aDrQKLzGrruh3PP/qjw5/8AdSl6wtwv6/8Aka3SqvJ/T/2XSuL3Z2qGxQ/KoYNbmhgjyqlbb2y9oMZRS/qCbMA/5dw2ywfo4lVPOme25D7qG9Q6biykn8Ui1rMJ8e+3xNH/ANg+dWF6yvUv2N/xEHpb9Lff+mFO0ezP3nSjrbDRdLbqHlhIyoJTnJH60Y7HreVaaioKCO73Bvj8Sck5HqM5qxtHQdOdoLezSF8Zl3JQ4sl02xJq/ZvJLbx9krz/AA1DetD1nlrhyIjkGTHVtUw42WltH0KTgirON8eZtSH8pWyK+JdLj84zWa4OQ5kWR3gMiIkNtqWM/d8+H3AyR8jRvXtw/acuHdUvJQX4yA4knBC0Du1YGP4Un60nR5DrR3JcUhWCMjrg9RUhcj4qOGXfFsUVtr80kjBB9QcD34oMmHUQQOP2MZjzaQQTz+8c+1K6f7xrNp+4x1pdn/DGNIbPXvUD8PTz5IP8XtVKsWBqXcnESVqYYQ06tSg2VfhCjsVxwMjGfLj1qw7O03JbkQ1OJaU4N6FrVtCXE5IyccZHQ17jQHpcjvJjiXSU4Cm2ghxQ5/GodevSsZejKZCq7gf9zbPWBsYZtif3EWuy3s2l3PVV2S3EQHoNtffdU2oL4UU7RuAweCMY96fdK3tWm9QWy7NISpbByttXRYAIUk/9JNWz2FWf/Zyz6huzMFhyI+/HiyVFs9623hZyggY2gqGQao/WUd3TWo5rCRlqM+Vbf3kZ5x9CKoZ1rIVmh076sYMsFV0hzBEnW1RREkIJDZPiYcHDjSvkeR6gii0aR3qRzVCvXibo2ciRHUJdskkKUjPhcGPCoHyUAf6g1a+ktTwNQQUvxHwsdFJPCkn0I8qWtiXGqNEkPuRXUxnENSCk7FupKkg+pAxmkq9ax1nYGe6/ZFumOgf4zD6khXuEq6H2zTf325Ph60Ev0KbNaV3AysDjPSmH5QMZGruG0Q5PbhcrShqRdoyGU7iFxzwtOPVOM496P6J7Rbd2g9+uO4337Z8bSVgkDyoDIsl3lOKamR0IR03BWRj2o1YLVC0zFxGjMsrx43EIAUr5kCoUHzH5zjrsjVJSEIOKpvtv14dLWZcaG4P2pLSUsgf8sdC4fl5e/wAqM657XYum2VMMJ+KuCx4Gvyp91H09uprny/SJOpJz8yc6p+S8cqWf5ADyHoKsqm9mZT5aBUcxfQm6wYjTFyeeKVtpdbQtZI2KyUnHv1oRBYE2SgqHGck083q2zLltlGMUF3a20gDghCAnCfUJSnk0H0NZHJ9ySSgqZaG5ZxwSeg+v9KsN2rcpL3GpfPYppiHIVO/aGEIXbpLnPATtR4f0wKZ9RSlXSG2lwk94ykbT5Ap5H86nfZ702xrDtAZtUgFyEhlRkpBx3iU4JR/1KKR8s1p1NDRDdl92MtsSFtjaOoC1BOP0wKsdD6mLe0q9d6QF94mRi47a2d3KkgoJ90kj+1ArlG3k5FNceOqLb0trT4/EpQ9CSTQOSyXFqGK10J0C5kP6jUTbgwEH3oME93IB86Yr4yWnMGl13hzNQZIh6ytGRIwOTU7UkUtRSFDnFZocoEsrV5DzqbrOQh1Cto/SlHmMEqC7jhYoIhP3auKYrgwXHlDyzQqZDMZsnHBrpMDuA7qyvqyM5xzWVM6FrUQzLQo+VM7s8uEY6UsMqHh4wrPWjkNO9IzzQVJuXX2e6nbRaLTp60FcFc1Qfus5v/GdXlQS2k9QEpHHuSa7g0NFhay7JZ2j9O2phlggtyJaFFpgLyT946PE8vjkJz7kV+cOmZa4Y7to91IW4A26DhSUEHvMe+ABn3Nd7fZS1uv/AGdk291W1ppn7sDohIB4HsM15vJiIyOW4M9Ajg40C8icHfaN0rc9O6kmQHJu8MrIIZR3bfU/hSPL55NUAZT8SWlxxZf29UOcgjzFdWfaluCZut7msIIClE5I9a5Ykx1yH3EoTnbkk+QHrV7EqhAKlPKW18wTju0AIHOfxeYotbLvJjgpyl5ChgodTuBH9RQ4I2ukZyOh96JRIRKgUirBVSKIlcMynYxp0+uFKdAccctywdwWoF1kfMjxJ+fOK6cZ7UJmlbRbIGvXImrrO7HSuJJTNSbjGaOcKZkYJUjj8Du4D1FVP2NwO4cW/wB2lBI2FxwAjaeo5B69D86SNV3ZartPRHZaaguOqUYSAQyDk8pH5T7iqb4WLXjNV/djLq5VCVkF3/d50dHvNjvr7qtP3FVwhp8WHm+7faGejiMnHzSSk+R8qKMRyMcVynp2+S9M3Bu62Oa5Emx8rDZxvAwc8dFpI4I8/MVduie362atlIjXBhq2TnONzXDClewP4M/UZ9K0un6tr0Zfv/P8zNz9Kta8X2/j+JZ0eOEkkjr1pz0t2ZRu0mz36E9crlZltsIWzcbYr7yOvJ8RT1cGBygckZ5pMbcK8bRV4fZ20BA1ELxdr1DEyPF2MxUOFQCHVAlbgwR4gNoB8smrfVWMR0mjK3TUcgsWIB7JO33Q3YL2eRNFaxu8663IvPqm3sxitp4rWvBwo95gJCU9OCKrO/Xe36yvku5xXkPQS24ptwfhUgApB6efH6VSv2t7DZrR2gzpmnnXXIjiz8QlxZXtfwSSFEZwsc89CCKE3vUsvSWntC2qI53TklqPJmrVwERkHd4uOASXFH/KkV5rNjLaTe5npsGVceoVsJeFwszUqxIjKxgIBSR5GqlkXy5aHu6noThZdQcKSeUrHoR5iqrtPbffrPf5LKZchUFT6+7aCkqCUEkpwFcHgjzFOV61w3epLbUqIS6trvEPNp2buuUlJ4yPY1PwmTkRo6lHGxnQXZ32yQNVoSy6sRZ6R446zz80+oq1414YUwMFPzrg2M9ElPB2HJw82dyVNq2rQfX1FP1s7R9S2+E4p+4pcjsNqcW440CsISCSeCMnAqNBHEYMqkd06fvl0jMR1OLUPkOST7CkLUfxl4s85pl5UF51paWig8oODgk/6dKV9F9olp19b0TrXdU3IpSN6VeB1onyU31Sf/M01NSeQTW50/RKBqfczzvVdezNpx7CV3L7OHbho6A6FlVxYjlaedyVglS9pPn1/F7UA7O9LuXae5NkIzFjHABx43MZ8x5DmrjuTCrjBMVqc7b2l5DncJTuUk8EAkeH6VAtGj4VosDTEiO2eFF1ThwFEk9c4pr4FDA1sP1ldM7FWF7k/aKsW0qvVxnSVOB3hcZD4GWmG9pAQ2PzKPOSOBn1oFGbi6csyO5aQ0o/gT5qX6n1wKb9Taht0a1SGYdxiokJQUNsMvIBPUbQBnA69KVtC2g6kvzCLg/GbSnhDUl9LSM8nblRHp9elZvUKGYIDNLAxRWdhLK7CLnctHXJdxYaQJMmCpSVyEFW1KnBzjjk4z9antXGY+JyZCGU4fcSgNt4CQSc468nceetSVokMPS3IaAnu2vhUvupwjfuUTjjxYGOnHShzbXwrCGQoq2jlSuqj1JPzNX+nwrWqpn9Rmb03B81lKUqpZkABxVM1wCglXrSnIcIdVnjmr7DaUBFy/ow5/elWWg78U4XdpySrAGRQGTAUhXiHNAd4claUKg/t9aK6kjhKSM5461H0wyG5qUkc1N1eruHNox4k0lzUcguVfLUUy1DHnQy+PAtAVKur5EtWOuaCXNanE+Yrp0GLc3dKyvIQc1lRcmodZa8SRTBAaVwMUMaaSVpx1pmtMTfgV1zpKiIEaTEkr/C04Ar/Krwn+oP0rrr7OFyXDkymUMOynnmFNMsMI3LcWfTyAAySo4AAyTXP2guyfUPafOes+n7Y7cZTjRBKRhtoHopxZ4QPc/TNd59nP2frN2R6PQ5qWSi63Esj4rBIjqwMlATwXBnnxYBPUcVkdUTqoTV6atO85y7dOwiDcLbIv0+7qeO4oMfT8By4qSo58KnhsZB9fGa43v2josRMqJCRcHCVEud4lkPYGeqUqOB9a777cftPwnrUuwosbcqIlW1qFIdDcdOM4UttGFH125AHvmuU2LbL1LKWhMUIacXuKGGg22OT/Iemazw7DztL+gHkbzn9/TCUEFp6Qk+j0VQA+qd39KeNOdlmpJVqN0h2ly8W1sZdk2pSZYZ/wD2JbJW3/1pFdQ6I07pvTq2USmETpY6sxWg8rPPn0B9quQ9jM/XlwbveldPI03IhsfdTJkRUZ11YB579laVjoMBORzzVoZMp3UbfOVTixj1HecPm5piW9MaLhGBtO3yPINVxfQW5CwfxetfoX2n6NsWoYka0600uzH1tIjvLZk250IkvhvOVsykpDck4wS06kODnk9a4L7Q9Mu2Sc+qNKFxgpWQXdndutHJG11s8pPuMpPkas4sysdB2Mr5cTAauRE9YcIQtGUnqlSeoI9KiSoypLiZLA7mYg5UEDAc9wPX1HnTPaLK9Ota3UgBtHiyo459qiTIiWmSocEc5FGwDnbkRYJTngzo37M2qZfaLMgaWWWnLw793FU86EB0gZ2bj54GR5nGOor9C7BbIXZ1owWcuJD7SFPSHMY3LP4lD28vkK/GC1ajesVwauMJ5caUw4lxS2SUqQoHKXEkdDnHyPzrtZP2oZ/aX2dMOzNX2SHdXGjDkw70lcNZdCT941LQCkbgc4cSPnxSmzZKGNuBHphx2XXzOVPtHXx+Jr6/RUPNvNuvLyUEKQtJUSFDHQ1Vj19uVyizJU2U9KDwTEU68slWCQogfMIAPsAKYO1HSF407cDIuQS8zKUpTMxqS3Jae5OSHG1KSTSM00VgAK3AHO0HofXFWVAYSszFTD9siNuBLiB3i0fkUM7h5j6eVFbo20mIlbJ7vgKG0kJP0qFp/CScgjA/St95SpT6EFZaaKVFYSnOFdQQPQ02ou/aLiNSO2+4BxCVp2HgoXkpPPIz1+VOdy19cZ0eVbFuttwnIZL5Q141BQxtB8s5AquLrHQ88QyScnblY29aL3exy7MHS46l9pZQyh1J/EGwCrjy6iqzIuoSwmRtJl9fZk0Swq6qubTDsUR0qKi64FKVuBSEcDGOprpC8Ksmm7UqdeLy3GcJw1bYqe+muj94I4ShP8SyM+QNc+diGuv9kNJTizETJub7w7t17BaaGzBUU/mVnoDx5nNb5tykXOQ9IkuqffdUVuOLOVKUfMmjbqTj/Dxjfyf4gp0wyfiZDt4H8w5rPtbmTZPd6ejOWSGhON7joekOHnxFWAE/JI+ppD+Mk32e2i4XNSQ6vaqVOdWtCM+aupx8hUmSgDcCM0FlpBUQRxVfUX9RuWdIX0io2xtCJ0/JF0fkNvEJKYwbWhaVr5y4kpyFISM4PGScYpGvV9aXfd5b+LYjcIa/I4ofvfw56gcmie9LEZDSQqNCGVrW64kuOnnCUgdATS53A6+vJoEXckyXegAsetGfaA15pOW65GvSpUN9zfItc9tL8J7yILSuEjGBlO0jAwa6i09PtHaPoxGqrA0YZbJbulmW4VrgOgZ3IJ5WyoeJKjyACFfhJriRtHdr3AcHyq5uwfWMjR+r4rrTqUMzNrCw7/h785ZUofu7jsV/A64POmDIen7sf2ijjGftc/nLhmxQ4g4T9aV5dmUp0kirFuQtztzkm2EpgLCX47azlbTaxkNq90KCmz7oNAJrYSpWK3UcZFDDgzEZTjYq3IiXLtfcDcRSnd3EokA4p6vT2xsgkZqvLssOyDUmQDckWSQBOSoGteq5anZm08+GhkZ9TMtISfOpF9JMxsnzTVPMZcwiIdzSG5Sle9CpYLwPFGr23mWqhchrY2T0qQdoJG8Cd3tUQRg+lZWw+Jwk85rKm5EZ7Hbp13uUaDBivTZshYbZjx0Fa3FegAq5bEOzbs4yvWt2mapu7I3Oaf0stJZaUOqH5x8GR0Ia3Y/eqlputH7Jbn7FZVFidPb2T5TX+Mps9IyFdQk8FeOVEhJ4GD2V9mX7OGlLN2Fq1DrHTjF9v10fL0eDc0qLUdLSyhobOOCoqWonIITisjqOoYcGh+s1cOBfIsxeuf8A9SVvQelRZdBdmdt0vE9fjlKUeviJSkFSv4iSarG6/b11Xqhl1q5m4Rm30lKvgbmvbg542uA5HPqK527Q4Bi6hnQWDlLLy2+BjoojgY4zilRp0R9yHF/hOPXHtQHCuRbO5+sMZTjJA2E6Oi9o+l7+4ESb69anF9VXGCrYPmtsr/XFXh2bdjLesIqJ0O7M6ohp8X/o81MgJHugEEH5j6VwEu5NHI2uqPltISKI6X1XddK3Vq5Wa4yrTPbIUiTCdU04k/NNSmBlNg/eQ2dW2I+0/a3stsejOzthDsj4Vq6JbCti2T3rXXyVnB9/oK868+0hGt7T8e3oMh/keHnHXkcda/P3Tf279UTrCmz9oFvjalYSjazemmw3PjHBAUSnAcA9OM+9HpXaMu7adXdtOyEXeMEFTjaBl1AAOVJT1OPNOApI6jHNND91ZBX7RRSxqQ3+8sXW+vrvqhQMlZYaakCS0pH4mnUk7XEnHChnGfMEg8Gqnu+mmtd39+E5bg7OuAUllcbwqjv4JKk8coUMnaeOo8qr6R2yAFakSSd3JKlZz70uy+1yUJqH4y3WnW1Bbb7R2qQtJylaTjqDTMmHULXmQmWjTbib9S2d/Rkp60S+7Cm1qQh1hWWXcE/hP6HBpJuD4Vuyrj0rbqfXk3VCpLk8pUt5xTiu7TtG4kkkDy5yfqaU3bi4ttQWSSDhR/ofrTMYIG/MTkaztxNb8paJri0AKSkY2nooeYPzp97JtVwtO6gSLlAReLNKR3UmE/0faPTB/KtJ6KHIPzqr3cqfA3bdx27v6VOs8hcWWG3VEJKsZP5D6/ril5FvjmHiejR4ll6u0x2e3z4qdpG9yI7u4qNju6e6kI68Nufgcx74PzqpJ8TuHFFlRJBwUEYNMd6YYW8mQtkpD4yVJ6bxwofPPP1oW7aXHfvIzgUT+RfINMT03AfmpHsl8fae+HdcCUL8OXBgj6+VF7kZEVKCSVIT+BR5wPQnzTUSJGS9lt9hKHE/kcGQflRN34NuIe4L0R1PVKT3rR+aTyKZcXUVrulAjl1tJCuikEdK2tyzIiOvuncVxWz8yDtPl18NTrsyt2MQhLSlKH42iR+qTW223Vae7jvygxHS2AY7jWdxCdpSDjBzyQaW/FiMTyDLO7H7nbn9OS48t9xqclxTyAhorCkBPizjnjbnjPXpT3Dhi5RmJMNxMqK/nuX2DvQ5jqAfUeY6jzFc7wUvKnMiM8i3KRlBSFEFJGQcf6e9dBfZf7Yrf2LT9SWHUcVi7aeu7CJDTa85akIJTvQeqFKbKgSOfCml5MYbuXmOx5CvaeI2zOw3Xa4Imo0fe1x1DIcEFzBHsMZ/lVXXyBItEl2PMjvQ5LeQpmQ2ptafmlQBFdFaB7PI+ttdXFPZj2u3K0XyKkS41vv7hmR5TSgohOQcq9FJWhRA5ppXqqH2mSpnZ72m6ZUxra2pL7doekqU3ObTnK7dJzvGf/x7lDA46ECtunMtUHGxnErj6VLPIzW5lQUnBq/tbfZp0PqHSczUXZ5qW422VGSVu2XUCdyRyoYC9oWnkEZIUAeuKpdjso7S0WP9sRdHSbvauf8AirW+1JHGc5ShRUDx0IzTgwbiV2RkO4kNLYUjpRWPLTDt61E9Bj50jP6xVZ5Xwl1t8y2SBn7qUwptX6KArTcNYRpLYS0tRT16YqdBMEOBOi+xnWM3UWpLVb0KVKmXCQ5A2FQG9xSe8QeeMqUlf1V71a94YkwZLseUw5GfQcLbdQUqT8wa4h0nqZ5m5KVFecYfbUiU242cKSts5BB8iASR8hXXNm+2Vb9XacXaNf29t65RBxcGEYccxnK0KxlK8HcU8oVzwDVjBkOEFasCV8+MZyHuiZGviCpJOKQLg0pTiiRjFXzeuzW4TtNuagsKm9RWVslL70A945GIGfvEDJAKSlQWMpIUDx0qkLqguLVt6e1aIdcg1KZQKNjOlovqX3D6VDkg5oqqG5diHADkCvFqsTlxnJSQcZqyo2n27dGACQTiqmQy3j4lH3q3KamlKhyKE3CNiOrjmnfWDaUXVXGKVbsrZFUa4HacRvE4JVk+lZXtKyckdM1lHcVUffsy9k72vO0qNLmtqcbYlJKUkfjd3cfoSmu/u3rtWtvZ7YHoTsGQuNAhBYfSB3SuqEt9Mk4Kj065Fc8fZ1njSzDlxipjpltr7xoyUktBaipKSvHkCoEn2pX+1N25R7pIl22N94Qpxojpv5IURx+EqClH6DzrymcvkyBFH/yeoxBUTUf6Zy5raf8AG6zvk5EhC47kt5wSEnwqSpaiCD8j0pZckW99lwJDiXUjKFhPCvb5e9Sp76pseQtSmyEJIbJTtaRyc4Hy8zzQlb4eSy0glbbSSAtQ5UScqPsPQe1bONeB7THyN595iAD5UZtcLvFJWU9OahwoZecAxgedPdh01KltlTDfhSMlR4FWuNzK4F7SPFgJdTynI8xipsbUb2ibgZNsdVHfKQFoQTscx03AeY8lDkHoRR2fpeVYrOidJ8AcX3aU456Zzmkm8tpdUV9CetB25VrkQhqxG+DCtyfgauUudHSiHcidzzQwlDij1JHQEn8wwCeoB5IB1ZaUptYKSk4UlQwQaBPSZEKTujkhaeQRzx5/Me1GFXRi9wO/cIZlNJwrnJP8J9f4Vf8ASegNLW8RrkftGNWTcbGaUq2vnPRYyM1EdTh1RAzjIKfUUTYdZXb3N7XeO7vAFAjAIOTkdCODjoagISkLOfP1poYERZWjIEmMUL2KSoAgEbhgkHoa9qbDzYeJ27hhfuRwf7Gj9vthvMJ9vJLsUgpUecNnPB9gefrUC52l2yuBl5bTyXk982tlW5JHIPOOvApWsE15jNBAscTc1dNtmWXGi+13iS6SPwZBGenr/X5VMj207Q5GO9JG4J9R7UOsinNktpONxbWnBGQoFPQjzBwab9HtQ7vbWG47LcB9lngd6oolEZKiN2QhwD8oOFY4APWVbTYnMLowKuM3KRtcST9ORQ68wXoziFhC3mWgBlPDqfr5/Wn+Su0/BMNwSiRNdUXpDpRwzjIS2g45zypXplI8jQqTFVHbJUO8QfPHIpqte8WwraKzJRMZCwe+QepRwoH3HnQ65RkKSpLbmcdULTtUKZUxo8FUiSmP3gIG5KfyjPKsedDbg5HcmrS81hgcocxkkc89OntXXvUitrgG5W24Npj3NTK+4fQhYUPM8oVx16pPOKn2y03O6zZr6glHcnGXlhvcfJKc9T50Yk3aYqM2qK6zObYR3aGi2D3bfPhA6gc9AaZtEzjd7bKV8IJczvm2Uw1J3JWpe4AgYJ5/DgdOvlSXdsa3UciK7VcVLRcrlom/RrqlciLNir71nu1ltQXyMhQwceXB5FGLv296mvtytci8P/FRrXNExlPIdYBOHUtufiSFAnIz1APUVIva3G5bDDcZL8d8FAbdBKFuAkHaeqcnI46YpGu7cCcxJbYadhSjwWXDuBIPQHqDx50xGGVbIguDjagZZs/7SGsLrfJLUm5BcpKlNpk92EiWjkBTgxhSynGVYyfWo+kO2rU2gry/OtskNNSCTJgkZjvg5yFJ+vUciq4u0Vbgjstoy8sgoI6j0x9a0MXMySWZHEhHVQH4h6/P1oiijaoAyOTdy2+3LtvParZLfE+DbjsRVFew/ebickEKV4kEZKSAcEYNUOi5fBvlKgS1nGT1FG8BDymzkNr4OR0PqKGz7aVoUojC0HCh/euVQooTncsbMYtITEG/wsYKXCW+PRSSKbnGGJ0Z15nwy2fCoeuM81WekZPw1+gNqPAfSRn500z5b7E6SWlFslagcemTUA05+kg7oPrLV7Ju3bU/Y3dmJtolvtMpKA9HQ4Uh1sZAHsQCQKvPT2tbR2/Qpjy4seza3bVuUhpIaZnKOcApHhClDooYBVkEcg1yO3fmJrQadQUvKTjgcZ55oq5IkW9tUqDIUy73WwqbVjKfp6EAj5VJQ3qQ0ZwcEacm4nTWmYpalkLbLbiThSVDCknzBHkaapqsNH5VR/Yr2j3G/wB1mtXuSZMkkOB1f4j5Kz688596tu932M0x92rKsc+1QxZqkqoWxKs1tlV0PkKU7ztTDUM5NMeqJfxcsqpLvzikDHkacNos8wMgAJ685rK0pyelZU3AAnRlgTc4Vvbg2+E7PlOM5VFaQVKdGN604x5pB58q501ZHfvN7uN3fKjGkSXXW1OcHYVKIzxx/wBq78KbT2M6Gv2rtWBVqmXZh6Na4yQBKWFghXdpI8IAwO88ua4JvqGtZ3Bi3W6auGh5YS3GfThonnHIGSfcj3rAxN36pv5V7KlbXmSZruxrhhJ4A4z71lvhkkZGB60x37TELTEwRnrzBnyAT3iYhUpDfsVYwT7Ct8Kzok7FNuIQg9FlKyMevhB/pWqrqBtxMkoxO/MkWO0/EqAGAR5noKtbS0lmzNtrWUq7vxALGUj3pesugblIYLlueg3JI6pjS0hz6oc2q8vSjo7PdULhypL9huDdthDfKlFhRZb9N6xlI+WaglMgq4Sh8ZuoL7R9UKvMlKGnnVWxsZaQvG1Dh/Fj2Plmq2nyFPJUhAyfX0pm1NhTakowUdDikYuuvSUMs5K1HaMeZo8aBF0iBkYu2ozwpJaebU4lRbHCgnglJ64961PzLbbe8Swh9+Tu4UUgI285H1/lU2WpK21I3khP5ldVH1FDXWEOg5/F6AZrigY3ODFRUeYF1RqNqGyuOxIUoBtmQobHADkBKlDqATjnpVh6bsVimxHtNst2hpYUfir8IS5ciSokhDDSVH7sbsJGwAqJyVYql9NOm3IkqO4JbIdRuGOoIOP5UZt9xk2O5QJEJ4okuyUrQpPRtKDuCjx5HB+lZrowJVTNBHVgGYbwreJaNKCZFZtRYUiSuLJacSQoFO4KC8dFAZGAfKoF2hyb18FHgWZlZZZLjYjrcUsoIJ28k44GaaNFyU3q4hGqhLfgrS9KcdhlIkvOKStSTvUMYUvbuPUDNLT15YsF0bgTHO7DjTa3lMcdy5yUngeWaKiN13Miwdm2E86esK3Vmay2pcZAUl1GMrbIB4UMZx6Hzpi7P+wrWl30neNSQ0x4FohAOE3F3uESVJ3f4alJ25GPMjJwBU3UOqbvc7fMDEotJEVTjJgNpaS9jO4rKeSopJPPrRfs8u7+q12ODd03J3S1uZBMRg9/gjJcdS2ohBVnIwrOM5xxSxkyUW2H6xnw8dhd4y3DsRu2otFae1labOUXC4rLEy0wCHitQztkoQjOwK/MjjB5AxSpfNCXqxEJulql29RJAElhSATzkDI9qt2/M3GyariXIQbrpq0XSQhhMhDRYUUEZRKaeb8Dj7W/kIwnaraRXQM3QmsXdNzrbquV/tSzYHUftBq4KEZK2/GpC0vjBJWkg+I9TjmpXO2MC9xIbAj7g1Pz2NkffWqKyypeVZVsTlWOePl86ybooMLQZDRVwMJJ8Oef1+lX32nItTst5Fhbuzza1Huo0dhuHHR1wAQCpw++Mn1qr71pPUbaWXHYfLqgjuwgrKTz1J8/eu/yWeiNhO/x1SwdzEyJam3pqkOvKY2gltthoKUo84CRkAfU0Utzj1hMlyEkxnncodfGO8KSCCjcnhAI4IHJ9ccVMb0jLJcRtbfAyFKT/gpVzwCPxkevT516j2Da0pmc26hwHh9rxceik+Y9xXM2r5iSqhedjPa5Uh6Ixd3LDEucBleFRHkqCTtB5SUYKcZx6+eDS3d7RFuDpmS460GUlUhp9IySnJyFDAztPBI9KcYMZmIENCWktJc3lAwhfvgKGMkcdagXNMSJKuIbcUG3ErcjRngO8wT4QCBtJzycdcUON9BoTnTUN4nphNOxSlnZJLZ8K8eJB55FI+oLFIjud/GJQ82dyTjqf+9WALUVNpdwYpI4eT+HPPBx0Nb/AINTsZSZrCnUjIDyAFD9R/etFcteqZ5xXxEayux77asuOKjvNnY6yEghKv64NebnEVHW6kjdtSPGBwoY61vv9vRYpX7RiNqcxwtBA2PI80qxyD6Gt8u4yJyGxBYHwcnYttttBWpRAwAT5kHypusVtF6D5iTb8p1PblJ4BkIH/wAsU7XrwzXDjgk/yJFLExlEO5RJDadrZeSrb+6oKGRTjcozTl6kpkOqjxkvrytCdxHiUQAPegLUwPyhBSVI+cDtJyp1SRghGB8ycVuiTJbKhEAKw6QhIPkScUUbtTTD0hTbyHWCoJZJOFqByQSny4xW5u2hS3F7gjukKPeEfh8s/wBaL4gAsSBjJNQ/2bIXGvTklDmS2vB29Cn8J/tVvyH1EeIk1S3ZzKahXMsKOEupKU59ecf2q3e/DrKT5kDIpy8RR5MEXc/e5pXvuC2D50x3TldLV7G5rpRGAIEGB1rK1LUUisoYUPfaJ+0J/vg1hNuk9+QtpZ7uNH7wqEdkcIbSSOg8z5nJNVVC19GtcN6PFafT3w2uODAWoc8buoHPKQQD50FmRm4sD7xIU4s8Z/8APKhTaUg5xmqa4lC1Lj5WJuNMfWcVlWVQllPp4Bj+VNOn+1WzQH21S7XPcQkg4iyktKHy8JFVmmIXVZPHonzozb9LS5beGYrji1eYTwKI4UbmAMzjida6V+2D2X2fRN7sa9N3+Bc7o33YvkiPDuTsYc/hSrZxzRK3dvXZtD078DpO+R4dwlMhudJeYetj0lQ3YJSFFrz6ciuUm+za7vN4Tb3VY9hUCVoa4QkfeRFtuAnO8gDFKfpVZaBIjE6llNkAy89RWOHeUuyfi3F78kOpDa0qPOBlAHXqTSVL0+i2oQuKwn419pwJUtZwEjhTnI4znaPrVVtzp1jkOGLKejbfxFhZA/0NMlo7T5TDiFSwxPCUd3h9G1WzOcAj3rhjyoKu4RyY3N6amh8rhyVMy0KYUnkpWMEVCfnuLQdiu7R5JScf/wBp4iXa0asbfU6nZMCSGhJIITnP4TjB+XtQKXoubKcSIUVbrvRWxOErPPKePOmLmBNMKMU2EgWpsRYbub8SSFPb3I6hsWCckD1Hy64qwoDgTFaWooVGUjOUnxrBzngDPmf1pL1Bp+fp8ttXOOuIp0+FDmN23OCce1WmLS3Bi97G2uKdWpTjbeN7SQMNjGM42gcjrmlZmGxHmMwhtwfEFWoLeiR2I6VqSxuR3W7BHUjPHQDz+db50eM4/IaeabceQeqkglWR0Bx5citCZdtjXZtd1jzH4BQpLiIDwYe3YO0hRBHB6gjn2qbpCNCuMS6Nz07XnGEqjSsgCOtDm4lXltKdwJ9+KQwNao9SL0wFd7iNK2O4SY8RaVAIj53nu0qWrPA9doJzTNoPUotffS0KcNudHeodaCT3bnOFAEYzjgpOKR9e3mHe2W7XbnQ9EYdU6uQBgPOdBj+FIGB8zW7SdmctOmYt0gXKRbbit99vGCpl1KMcKHT83mDmjKD4dtyZAc6yq8CX9ZbdcNfzWE299DKWtzqwhxZjREEkuOFKjsZ8ifXHANX5qbta1Z2sIuN8t1nf/wBnIfw8eZcIjSnYe1pKkoeWgAF0glTg8hwCDXOOk9Oax7V0wrJCuUKYHIypSbZaHERoyEoB5eQkABxRxgHnJ6YrvD7Hna/amtLs6Iu8IWO5W4KabLzfdtuJG7KXAR4VZHJOAeKoMurYmXVahqAhPQfZxp+Po03ZpDl/kSEFx+9PJ3qeyCSdxHgRgZ2pxig8v7PMnXj6J3cLiWEDcFO+B+WnnAbHVDR81K8R8gBzTvftV2zQlwasem43xNmky1S3Ib0YojQU78KSSB/hKc8aT06jOOKtOZqh5bH3sVB45LJKcfLIxVVOmZrbkiMbPpocXORdXfZ6jxA4mClMdSRhLDqAE48glQ8qonW3ZrcdP5cchrS3++BkD6iv0GuzjVxyW9qlebbo2q/0NJV7sFvnMuJfjlGQQpTX909DQplzYTTjaEwx5eDvPzmnRFBZaWgYwT48Yx8zQy72RyRZkTbQw28WnCzKQ41ktZB2qAxlKT0zyK6q7XexWDJUmfBVFabCSlSFMkNrPPKinO0n5Yrm7V9m1Fpq6vPNWNdtgKaKEvWlBWytPPiUcqznzB9a0EyrmAKyq2M47uKD8qPap5hOBSYygAl5Y8OTnIPHTOeayZB+C+/iqWyrzCD5f3+tF41v/wBqnYVtSwgypTYaa/KkOkkhJJHAyD8icUsMXR2E26w60pxKF900FKG/OSNpHXjHWrOJtQ0kbiVsi0bHBnqfaf2oyrvY+5RHLkcAKP8AmQeD9MUk29qVpW6KjNb3oxUXGtiSFsrHseR61a0VhcYpJzxweOKk3ixMX2K2pnDE1sgpeA5T7U5TYqKYUblD6od77v3CULdW8XcjzVkkkjyzVswLpae060yJ01pFmcQhTcCKw1vQ68CCtta+qcpUdpwfSlW7afUtqVAehpD7eVIUB4lZzwDjk9SB59KTdO6hf05cBanHUpbcdDqVpOQCU4wfTPAOehFEy61BHIgq2hiG4MaVPptlzff7lmSdy2y1Ib3II2lPI45HUEcggEV7lSVqtu1KSlvenvCepyDtz88Gtd0bVF+KmqbbkNOkqSjqAonk8emKhOSlpelrcCi08E+DpnBzjp6DrUA3RkkUCJ7iSlRJrDyDhSFhX6Gr1iT2rglJYQQA0hSuOCSPL9KpeZGtiZjiY0pxEcneyXUhSig8jdt/MOh9xVm9mVyjSWVwnVLKthbDyRyEZyPD54IzjrVxXviVilGjJ1xaKlUEuzQLGCOKa75EctshbL6QFgAgpOUqB5CgfMEc0s3rBiE0w7iKGxgL4OMv81ZUZpWQaygAhWPaIusNKzLZdnoE6OYslogqbV1QCnIH6EH60AFsabVtQnvF+p6U26/1hJ1dqqfcJK2y9JcLjhaQEJKj6AdAOlQrdbi5hWOtJxghRqjshUsdMk6ctTTZ71bacjnJFWXphtTryFNt7kDqMdfele12lTzqG9pCByojzq0dLWpYSGYjCpDqyEJS2nJJPA6DzOKYWAiwpbaRLpcjCKg0ClIHicI/kn/Wq6vjr1wWtRyhr+Zq4u27s+HZtqdqyybomdP+BakTEpQEoYfXkllJ/MEjHPrVMXW4pDKmx1PnUI4cahxCdSh0mKs2OyMoSkc9eOtBntP/ABq9qG9xPoKbbbY5V/mJjQ2FPvHnanyHmSfID1qYx3NiaedbLcl1mSUhwDKHFJHhxxyMlSvomod645nImrc8SvFW+TaHiiLJcbCeVYOUk/KmGz9pN70++A3t7wAglClI3A5znBwQfOoq2TIdWryT4lce/wDrUSNF764hLrKlFahsKT+E7vMeYxmhZFYdwkq7KaUz3qC5S57r11uSxImvnCEkYSPQAeSUjoKH27Vd2tu0okqcCeiXBnHyPUVovU39p3d5LHLDR7toeoHU/U81vagAtNnYoqVzkjijRAV3EFnIbYx0tfaPCvrTbF3AZcaVvT3gK2lH6eIGg+qtXv6nmN2uAPh7aVAK2J2l7njIH5R5D60pW63qkzVADwpWSr5DrTRbbe23qJAOEIaTvJPlhP8A3FCMKg2JJyswozzAsq1Qg7tJfJUUpHmASAPrVy6FjW1/sliRJ7KVSl3CS8zu4UlW5KBz6EBX6VXyrq3FbU6lhXw6eG3DxvPlgelTmLqpNvtcdSlJSlvesjyKiTn+ZpXUprUKPeO6Z9DFj7TprsBuFu0lOfl25tMcyX0AK/EraCSnk/xZP0FdnXO6aZ1nqW1vNaaiT71cGkw0OqUUKkuqBKg7txuaQNyiT+78q/O3Qs1xLzO1YSy31Uk8BRHJ+grr37PGoojD/wC3lOEzHQpmMHB/gM552jHVwjcfYAVjthZ8lA/WaoyqqWRxxLhvPYxrLSOoUXOBJe1bBcZLM1t7alT0dWe8YKP3B1b2/hIHvV36Ej/F2xFuLq5CGGUKjynBy8ychJIxwoY2qHkRWvQ+s27khPfSUOZ/84qVfL3D0bfY7jY3sze8cbSgcB0Dc630/wCYkbwP3mz+9VlUGI6vEqM7Ze3zB+pbChAWlbScefh/pVWarim2MqdQ2pYSoA7edoPnV6TpzN7jpebKVNrTlKh5g85qqtcRI5ZcQl7YfbkYo3Ut6eICMB6pUyZUadJmQEPtqkMkFTSVArShYJQSnrtPPPtVXdrc53RWmZF0h25E1YdShQBKA2FEjveBkgHjFMna72aQtYMN3GyOGNqy3tKESUyop3p5JaWRjI6kHyPsarm39sdv7QIlwsWr0xdL3bYI5bWC2y4QkhS96gQhe4BW08cYFZTdK+NtYWxe4mmvUK66CaPgykNb324R4EOVcNOIZduDfxcK44LaVtZV4myByTjBBz5UR7XeymHp24Rbzpu3vIgyYrEgMy/xAuNBY2qIHXKhz0I962s611BpV9em5drjaltLDqpKLbIiiU23tzudbwMpSc7sp4welPX+9mH2sTY9rvDEe1Py2SxEUkbWnVkkpSSRwD5EcZwKvZhlwgPiXYc0fH0lTEUyErkbc/vKAtmpo9yLjKGHUyGQQ8w4j8AGec+ntRCHcmY7jbbzmxxau7KcdFeWePM8VD1kxL0hdpTb8ZTiWnti1fhXs528458wCehGDQ8zId0ejobUVodX3SgpO1SRzjPHlyAR6GrePvKsvBlV+wMrciG9RWNN4ZBHheR+FXr7H2/pVb607NHtUsLnQ0AXlkbXGkjHxWOccf8ANxz/ABjpzVtWJxcpbsWYtKpTXTAxvT6/PGD9faijtgSpReaSku4wUk4Dieu0+nPQ9QauIdXcJVfbtM5e/wBsH40aHFmxkOoHhcd5CzjofmP7Uz360rSWZKjvjlASEo4CQeR+vrT12kdkJ17a5V1sLJTqKIFOSbeB4piB1Ukf/lHmB+McjnrTul9dOIjptk9lUlppJQjjxbPNJz6eXpQslUyQla7V4b7oM4DfIIzu6Aj1ojpbUXwV6bRFdS9I58CDwcep6UCkrauBbbaStEdIIAWfErk8nFSrPp5SpK1sDa+ynvE7eDx5UxVY7xZIUy/n9S3C+adZiXOHFLjS98eQ2tRcaRg5bHGNhOFY8jnHU0sXBsGMsH6VNYmf8Iyjz2DP6VCujuGF0zSFWhBLl2sxZQAnPzrKihzeojPn0rKm4NRCj2x9L4UtCG3Cc/eeIn6VY2mi6004zJS1KbdTt2uoASg/vDHINVZI7QO7d3RYLQI5CnTu/lX1PatqFAxHlJijOfuGkpP9KpNjyP4ltXxr5nXnZb2cXTUUxlm02GLdXTyNsRyQcc8nnGK7Yt9u1XadEIhXG5OWGJASl/4OHY4cNt1aCShO5RJV4tp8s4r8eIvbBr1nxtawvcQeQjz3G/0CSKK/7/u01uMpH+8LU/dkY2KurygfoVGq79NlY7EfrLC9RiXwf0nTPalbr9MuMt+5pamvKWorfWUeJWSSc5/p+tU4vT63bnH+NiIZhOr2reUghIHPOUnrVXXDtq11cCBN1PPnD0lqS6P/AJA1pa7VNQut91IkMSUZ3bXIyBz6+ECmJgyoukVFtmxO1m5Y97kRdPNvs28L+HcBCyy4ttZHPnk5AzQFqE3IjNqQ6tqMo7kgpC9ufM4PoB5eVAjrJ19vMqE2c8/dqI/kc1Iialtr5A7p2Mofm25H8v8ASjCuo3gFkJ24m+4NKYfWzGStcdJyHijBc/iI8vlWxi2qaiSZzhCRHjrdH+b8KQOP3lCnHTdxtb0uC/sanMNgNyYzD/dOkZJKkn1OB1z51q7S7mJFobZkBlV2nPBTymUhP3SCSkEAAZKlYB8wioGVmYY65hnEqqcl8SsLRaWJEdRKtj7fCT6+lT2ZzQYX3uEFo+MH2qdJjtNMoQAGypJGR0yDxSbe5QVIVt6uAbwPUVqMNJqZwNwnZnNqFbcBTy8qPokHcf7fpUtE9MqS+6Bwte0n+EY/0oOzJ+FhFIH3ixipzSBFgttkePGT8zS5MMTZgmIS2okkcJHlk/8A9omw8ZTywkpGPChJ43AcAClSJJK5hPVDKSon1PlRGLIw3uQQvPBHvSmFmNU0I72e7u2wuqOUl3wbT6Z5OKuzQfbdMt5bZkKQWQAEpCeBjpiubxO799JU9laQE4V7e9H7fOSkAZoFUDf3hs3j2n6B9m3bxELreJPdKB5BVkfMV09bNc2bX+n1W+ROaadcAUy8CAWnUnLbg9ClQB/WvyAtmpH4Jy08Egc8nAFWpoXtsb03FkyrtFnXZttorRHiLCUIHPjcPB9gBQZdOg2IeKywoz9FLf2mR7LZlxluBKgkrbbH5BkhSRx0SsKHyxVRaz7UnZrziAranJyAea5Bf+0fJvbDkmGt2JEXMdWiK6oF1CVAZ8WOQSPpS1L7YZrktwsvPoa/KHlbjmg6W9GlhuIfUgatSnmdTjtMfsMoyUNMPpXhpQkbsNgn8Y285HXFQe1/SsC+xXpt1saWHWfu5E6O4HEA4JHjTzyMHxA4zXLrfaj38pv9qOSFwySHTFUA4AQeUZ4zTwn7SCrxau4aMgxHI6YjrUhQK1pQju/EQOSoAEmkdU+XFkV8Qv3junXHlQrkNe0TP9oZvZNrOBd7LOE1iMsqbU24MhJyFtKKfIgkZHHtSLf723eLjIlNuKaS44pxLal8tJKlHak+gz1HTFEpL9nXcUPq+GdZbWFFiQFNKUkE+EqScEfTJrfdtP6Y1TEdegMfsmYASPgXtzZ69W1E8e4I+VPZ1R9ZHI5iFV2UoDweJY2qLY/qDsstN1vUpL+pnkLnODHiVGdP3aHBjklKe8z71WtngQ4lwblPzSktJwhlf5TzhWfMY6D3oFpu4ThcH7CzcFyIojEKfkII7jaD0HJwM7QPetrFxQxLiNSFBL7Lw7paT4XUbiFJ6dfP+VBhHw2KnjkScx1qGH0Mcr5PahvxJMSQlU1s7gG/ECgZyFHy8/1NPUe6tltDiTlKgFD5EZqtbmuHIeQth5LCkHBG3IWMkgY8iD515Oom47CUNSEltvwAbhuHXGRTlzKzWBVxRwsFq7qWYuWpEpqdCd7ieyoFtaPzY8j/AOe1V/26dndtnIhdp+n4yGGXJCWNQQGhxGkK4D4HkhzPPkFfPgWdZFsKGcgjH/eiGk9cLhXR+BdcSLXc21RJ8ZX4XW1jrj153D0NMshtPgwf9L8iVY7DXHW8UoIQ25t3AceoojZZioc5ElB3oHDjfnjzrVNbkaa1XdNKTng6lle2NIVx3qMZbJP8SCk1LbtKW4i5K1hJSQEoR4lHrzx0FSGKGmgsmsallrR22bvpxqdFILzCu6eSD+JOMpWB8utBLmhfcK+VE+xHWMPSOqY7siCzNjr3NvMyUBYUlQIOCR4SQcZFHe02wRIT6LnZmJLenblvchGSkhTZScOMqPQqQeM+aSk+dN16toGmhcqdobVnd1rK+OK+8UPesrqkSjWgO7Wcc4/vXqKkd8eOlZWV0gQh1xn1r04AUmsrKiTIzDSHnwlYyP0pmNrix4LhbYSDvAz1PX1rKypkCfZUdorV4BxxWpcdtphgoQEleSojzrKylniM8yG+NjO5PCg4oBQ6jiitk++7ouErUXTyo5PA4rKypX1D6zjwZO1OottRdvGSoH9BSFN/+9Hzz/OsrKs5PVELxN8dRclI3HODRGU8vahG47FDJT5ZrKylQ5kM4t7yh+IugE/Sst5IfJ8wFEfTpWVlK9432khlxQWcGi0WU6OizWVlFBEmLkuqdQCs4Azj3qbZpbylPpLitqklRGepGcVlZS8noManrE+KeWsS3CfGXRyBjqOa+CU6UcrJ4rKygx+ZOTxIsuQ4UkbzgiiNgURAODj7xVZWVGf0TsPri7eXVLv00qOT32KPxVqj2SHIbJQ8p8grHXGayso29Kf3xAX1NDbTyjcgcJBU0FqKUgFSgvqT5/Wl+4yFsAFBAIkLwdoOPF/3rKyqKf8AJ9poN6P78oCNzlOSFpU+tQ3EYJ96JwnFffDORtzz86ysq8woCUF3M8qfcKhlRreXVb0ndzhs5+uKysom8QFmdsBK7pYZR5kOWxoqc8yUrUlP6AAfSgl01DcWrftRKWgKAJ2gDJ+grKyicAkXOQkA1PFs1FcmCFImOJV65zVz6A1Zdrxp252ybOckwFNKkdw4AUh1I8KxxwryyOSODxWVlV8m0sYjfMWHP8ZXzrKysq2JRn//2Q==",
    bio: "天界から遣わされた使者。聖なる光で敵を浄化し、仲間を鼓舞する。"
  },
  {
    id: "c8", job: "demon", name: "リリス", title: "魔王の姫", rarity: "SSR", atk: 55,
    img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAETAScDASIAAhEBAxEB/8QAHQAAAQUBAQEBAAAAAAAAAAAABQMEBgcIAAIBCf/EAEQQAAEDAwMCBAQDBgMGBQUBAAECAwQABREGEiExQQcTIlEUYXGBCDKRFSNCUqGxJGLBFjNy0eHwgpKiwvEXJUNTYzT/xAAaAQADAQEBAQAAAAAAAAAAAAACAwQFAQAG/8QALxEAAgICAgEDAwIFBQEAAAAAAAECEQMhEjFBBBNRIjJhccEFM4GR8BQjQqHR8f/aAAwDAQACEQMRAD8AwsglvqKIQAhToJpolYPBFLoUlAyBV9HUSSVKbdipQkDKetCi0lWeKSZeKgcmnLacDgg01uw5bEDDUTlINKsN4VtI5ova5CYz6VONhxPcGlJMdt6SVto2pJziuV5OVqxoy0OKdoYJFOWoaQM4pVLZBxjiunaGQa29q4pPtT5TG7pXhTGOvWvUeoahkkfOvamcDOKctN7jjFE7dZXrpKZixWlPyX1htptI5UonAFCEkRi5TWLTCclSVhplsck9T7ADuag7fjHcLZcBIt8GIC2QWlTW/O2EdDsPpJ+oNOfHPUEJy9IsNqW1IgWhSkPT2xn4ySeHFg//AK0kbEDuAVdVVWKXCcKXwPaop5HPS6ON8ZaD191TdtW3F6dd5z0+S6oqK3VcAn2HQfQULDYKieAB3r22B5JcVhDfzr4VAhBSOv8ANSkDJ2KNtKOdgIB7nvSYZwsjnd86KQ2AtG5asmiabMxKhqcS9/iUr2loo48vH593QYPHNebSWziV9EeSjJwMmvZQ4Py4SBRJ5uFDZcbS8H5ecAsILiB14KyQP0B+tfXGJbbCQ3BCVn8zz/qJ+QSOn3oOSC4gf41xlzClgEe5qaaZ8QptrSG3FOvx/wCQ+rH0B7feo4q1zJSNyniMcYQ0E4P9/vX1rS91aV5pD6i26EOMncCE4zuPHCetccl0wkmui2NPeLZsWo2rxBaUuQ6Ew5TbfAkMnoVjspBAI9wMGrcu8e36+Q8+XERZza1NrQhIBacBO5Kh355+/FZset37DflNxnS68dzTTzieHkEbiUcc9CM0eg6gnpjN3GA95E+K2AHnB6JbAO1KHRj8ycbQr+IY7iprqSlEsjJpcZEyv+j5toK1LZUptPO4DII9we/06io0pBPQVamjdaW3XUJFrvkRUZ2QgKS06cJc64U2sdf7ig2ttBPaXfLgUZEJeVNyNvUdwrjhQ/qOfetPDm5akKniVco9FfrGOtJEDn2p9IjEKPFNfLJOKtI+hssZFNZCPlRUxSRSL0faORXKs7sDkEV7R7U4daSFdKKWS3omPgFPHeuwXJ0ejtgF5hRQogYFMUtknNTTUENmKMND6ioq6MZwKKcOLOtUxm4ik1Jx3pwoEkk0mUg0hoFjdScjOa6lVjtXUFHqDYZIHIr2lo4+VfW1k4BpZPpI4pp2hLYWzincQFRIPFJPZLgA6/KnkdkggkGuo8FoMZJwVcipPARG2YUgE471HYQIAHUUSZUoHI6UwYuwi1FbW4QTtGa8zIqGVYTyKRQ4o96WC9wwea9QfJVQ0KMdq+pZDigMU68vNclgjoK814FrvYqyzDCS2oLDhBw6ehPt9PnUhltL0d4Nas1kyS1NSW7Tb3ehQ69kOrHzS3nnsV/Ko83HVyQnoDUv/EtqG22zSWmfC+M0oSHF26bIcxgZdUVOZ46kON/ZJrJywnjqLldl0ZRlFyqqMXyB5qyFDDaOVE01eRkJJ4Cj+golqmY1Kv0/yUBDSpLqghIwOVnA+wxSxtqbzGZYjoUiQgnKlD0q456c9s15yS7M5Jt6BMVRlykIxllJ4HvSz+1tCFKJ5KgAPrR7Sum0XF8NsSA6sq2jDZTk4P5c9TRLUGn4mnLmhiNMEhD0dEjzjtKm92coynIyDwaU8qTob7TatgvTWmZ2orhFhtLaiOSHA2354UeueSAMgDHei7sSNbIYVIUmQwTvTvJQpxPICtvTt0/WvLWoG9KsplslCpiF7o7fBJcHUqGM7U/1yaC/H3K/OOuIYjx05JU4hrgHBJCc5ycdh7Uu5SdvobUIql2WDoC8WeJqa3z3W2DHjunH7VbSGFnCspVhJB4547gCo3Ov8ASXI8e3yA0W1LRJlLIRtAUQQ0kdDxjJJFc0q4Wq2WW8fEkrZecERuU2HSpIzlW0jbtJOMfKml1vUd2F5abUww47x5wcWshGSdqAo+kdPfpS1C5X+4TlUa6/oDhrK4JUyuMwxbXEJyXWUZcWcHJUpWffoMCgMqfNlOuKVJfecIKlKU4okgdSal1osLt/tl2W0EkMIQUoJ9RdUrCccdxkH7UAttsdN08pxgHclxpYcO3YCCCr5FPX7U9cU3SEPm0rZ8029ebxObgRbg+2japasuEhCEglRA+QzwKsnSeoHzKkvyS04UxEtgPo3NeR+TYpOPyklKlY5ByRVcy4TtqmxXocjkIQ62+zlCs++OqSDVhaOuMG9TWnZzC48hxQjyTHa3IeQvIWUj+FeDnHQ44xSsqtXWh2F743skOkpkJ7UDls+NMBlTm521yFAqSDk+ZHWeFHGCBwSOOavaIxdxopp+77HrVIcdajXdkZDTrSilSH0YyhaeCQfSpKjWVPEOPbmbY4p5x1m7x5ZZjshobVsjPmFah0IVgjGQd6gMAVK/Br8Sdz8P7jbbdqKO5d7CzIDymXeXNi2/LWDu4WlTZxg+ycGhSk48oDo5IxlxmH9UQRBuDraWRHGSFNJOUtqHVIPtzkfIigaGhvq8fEHSOktUXyJqTSV4Lug560R5Ellouu297Yr87X5kgLwSgnISo7dwAqlVMONLUhxO1aTtUn2I61selzLNH8oRmx8ZX4OWUpGO9NX0gj3pdwYGaZvOFIPerqEMZSMbsUrAuS4aiEnBPemzxKyeKblZz0pV8ZWhfTCcyX5ySSokn3oStXJGKcRm1SHQntRa42AR4aXxyD1o23NWMSclZGVJKjjHJr2YimxyOtLKKA8k+1OpTyHNu3sKXpnEl2BHElCvaupV5O5w11KbBDCmi2mviXCRivvxAdTj2pSI2FLG7pmiCHUK3uvKCsVII8Py0DeKRiqLKRtxin6JYWnBHJpi0EkjyhtKDwKcNjPFeA0CAc8Uu2nBrvZ2j0hJ7Cl2QVK5peNHCyB79PnUjiaFvcplDrFluLza+ErbhuKSr6EJonKMdydBLG2A2288HpT9i1uOR1SAg+SlYbKuwUQSB/SpDevDHU+lmmXbxZn7Uh8bmzNKWt49wCc0GemxbSzvky2mkDqrJxn64wftUWb1GOqhkSf9ymGCVpyg6FlQPhXSzuS6vIQQ3lXqJICeBySfb3oH+KudYNb61t1z0xcQ9eLdFYh3S3vN+W4y7GBSXUEjC0gI5wcjjilxrWAkS7hBfg+ba2viQ5dHSyhRyUpSygZLjm5QIz0xms76o1EEXB4x2WyPJLSd3qcAJyd6sDJByfmSc5AFY8PUZssuMmnXmqH58eKCuKq/zYIkJbZW6va20H1qc84cq2knjd7fIcmvqp6bVBYmJV6XkueSpBBJwcEfI/WgElb89wKeUVqV0HQAfSlmLWlaFqxwkHJ9ziquHyZnufCC1m1JJSFBljy2WxuJHJGM/mP36U+1Tqz9o3iXcYtsiWoTsrbiRgotRxgBSmwrkbiCfucVIP9nW7TaFNLaaejushAW6CkBRTvU8DjoAQPtVcre+LnF5SS2zkJQkDOxA4ApceMnaQyXKKpsdwIaXHfNdyVE8Z7n3NTazyV2G6sSbctpwM7m21rSFIUkghR2/5sn9Ki7amvMK2gQ0BhG4YOPc/Wn8Z8FaQDgZ/p3pripLYpPj0SC8IXKVDD4cdCUlKW2kerYOpAxgZP9qYP2EqeU4EHB9IGOEgds/3NP4ernpcVhhSW2EN+YgutjDjiFKyEk+wxU7tl5tdysxjqbbaWBhtahhIx0+w611KkHdlXm3KZGBkE+xxRA6heYtMiA9EizFPIDaJL7f79oZz6Vjkj5HNTBen2JMVchp5LxzwehV2HHz9vYVHTpKXJuSHkpCop8xpBH8SkjKv74oZKMtM6uUdxCNstdn1tf7WmKwliM3D/wAfGeeS0WVISdy9x/Mnoc9TyDivqdIXJqY1cIjrBtrb4daUxlLIQFKwRkc5x17VG5unltEqUk45xxVl+HHiLa4thj6fvzKU/DOlMaUsANrZVuJaWcekpUd6VdD0PapM0J443Df4KcLhOVT0QHUOk7jdTMLbYejoDkpJWrkIAPTjtggCkbBpOB4hCwM/HqS8pCbasIa9UZzCy0VD+Js+n1ZHcdqtjx3ftvh3rm+wobKFu+cvyIaCFI2LbSdyjjGwlRUAPpWdkGVAZcEZ1xhp1PkvJaUUhac5AOOoyAaLA5ZIX18A5lGE67+SwdK+K+q9Pn4FxUJ6Bb45tcmQmKlYWzvIbTJKcec2lXCFK9SQRg4AFSqPMXqKC9do8F9mOFBMj0qWlhw59JXjv1GevaoT4PXBqx6zZ+Pjpet01lcaSy4MpcaUcLB9+OftVj323Xrwhu02Hbri8NPP/wCJQg8pUFDYkODGHAM+WQeoWFdqqjL2Z8kuwFc4dgR4jaQBTF0cHjNEbmlLUl9LadjYcUEpJzgZ4GflQtas8Vtp2rJ2NlpGFZ4FNCjn5U9UMjBpLYN/TNBLYDPMbe0vKRRd26Ov29TJHFMmgUK6YFOlNIDXUDNe6Q6GkR5xggk55rj6U4706mAAkCmWd3Wl1Qp9iS0HqK6lzgDmurnE8Ltjk5olb46n1gCmTKN3aiUHc0sKHHzrlnkFm2FxlhKjmnaVJUabtueYcnJp3EiqkPJbbSVrWdqUpGST7UzoIfREbwBVueFP4f7p4iT2nJal2i0A5clOI9ahzwhJ78dTxQ/wt09b4851x5pM+cxglxQywyf5U/zq/wA3Qds9a0tY7yti3xYyVhK3jvWP4intn2r5z1/8Ulgm8OJb+f8Aw3/SegU4LJN/0D2lfAOBppxtuxwY0NCesp5AekufNTigcfRIH0q0rze7b4a6ZcuF6uRbYZG0rWrKnFdkIT3JqKXXxQtHhtp74y6SC48pJ8qK2R5jyvZI/wDcelZB8UfFq7eJF5XNnHy20EpjxkqJbYR/Kke/urqayfTelz+tlzt18v8AYozZceFcZePCHfjP4v3fxQvDi48Rm125vKGd4Cninnkn/QVR+oNPh2O9Jlh2SpPCXFOkEqOcJHtxyT2xUyt6HJsxtkEkrVyQM7R1Kj9Bk1MdAeH8XxY8T7Tp6MVmzl7c64vAPwyPU4tXsVAfbIFbr9Pg9J/t41cn/wBL5M95cnqFylqKKft9qXoCyW+5XpuNHj35tb6W3WEreRbmTlx1G4ehTy8NIPXBURVG6kszcSUG3WvIluZkyY4/LGSr1Ia+oScn6gdc1pbxivULWmvNb+JklttWjrBKbs1ig4w3JdbG2OyBjGwbVPL+w71lp+5PXWU+++6p56StTrrizyrJySfqabihxM7NKwW635TRcKcLc/KPYdqetxVoabaTwSM88Zz/AM6SkLQ9cWUOhXkpIK9vXHyokl0SZzbLTR+FLoKGl8qUegKj79BRybXRPFfJ7ukVxVlbhbVKmS1HapSydrLYKl446Z4464oEllUeK2EJCwvgFQ/rT6Zem16uLsNJfjR0mM2lxWQUBJSo/IElSvvSECKtLxQpZc2DKU/y5/1NLgmlsOTt6FGYa1oxzgDNLEfCsLPc+hP1NFoMIrRzxuOMfKm9ziebKZYAwACtWO3amWcSGsVBdCUoPoHVXv8AKiqZDjCCN2E4x9aTYYCBwMJHAFPGreqSW17SUqVtSMdT3P8Ap9aByGKLF7PKuk6UzCiJW44656UjqVHirg1lIj+H0vT1taZQ4uDDUpzeOFuLPqJ++alHgP4ZJZUL7KaCUsgpYBHVzopX0T0Hzz7VX34i5BPiE42Bjy47af6E1Pz55Evgu9r28Lb7YIRdoF2iqbeUlpxTqhn2zUeulhU8xO+GIdUwlSjs53JHcfTigDC1jzAc/mzTxm8yYYyy6ptRVgkdwRgj6HJqq7IX+Sy/GCa34j+IDt0EiO6XIcNtTzDXlNlSIzYXhPbnP3FVk/FhJnzYpOWht2q+o6/rSN0vrxkbUnZsTtITwM+326fagS5LqpLrys7XEDB98HFehFY4qKBnJzk5EtM+LBRG8lI/w8kLDh/MUqTtI/tVyT9Uwb5oq0XK5xky0W8GFIUedjTgwlzHcoUEms2mQVJVuPGKtPw/mC82G6WdxW0So5SCexI4P6gUcql2HjnQSnRsOLCiCQecdKGPMYBwOKI2ZxEvS1tKyBPjqciyW+cjYRsUe3KVY4/kry+zjOelaWOSnGwJxpgVaCM04tkcPyUg16kNDnFfYLojqKscjvRPsWuxzeY6IzoCPbmgzryiMdqdz5hkqJ60OXnHtmvBvvQg8rJ96bA5VmnTjZAJNNsZPSgYDOXk/WupJ9RbrqFyPBRnAopGVnHNCU8GiERXIoEEGmB+tG7chUWMXkqw+4ShGOqU9z984/WgsX3qQIfZhpSp/PloAKgByfkKn9XkcIpLyV+mhyk2/Bbfh42i1WBKXVJbW8fMJV/T+lSW7+IsTT0RTzTodmj0tMHqSOileyRVIM69ly1EsR0MIHpSpZ3n/lTVcxb7inHVFxajkqVyTWHh/hc/UZnm9Tpd18mzk/iEMOJYsG38kpuerp+oZ7ky4ynJUlzqtw9B7Adh8qZhwunHvQdDwJ4opGcCI6lOICkuAoG72xyR/wA6+olWGKUV+iMJXklbZ8XucPlx1KwUkOLBwlQP8PzFam/CxoN6PofVGolq+HkXNpy1Qn1naEICT5rmewBI5/yGs5abtT17ucG1wGt8qW8iOwgd1qOB/fNX5+KXxSh+EulLN4X2J7yWmLUp+6yWzhaYifzJB7LfX6c+yzUGaDhGm7lLsoUk+ukYq/FBrW3S3tO+H+l2xE0rp1pXlKP55L7p3LkunutadqvkFAdqpKINqVOY2g9B7AdBXXu7PX67yZT53PyXVOLPbJOTj5DpS0jCIhx7YrkVSozpy5Oxvb/8U44713KOPpRVTrdvs8ycgkvNfum1Y4DishIHuQNys/IUjZIKFIUV7gw0PWUjOT2T9+amn7Ctl1gRbZcI64sV471SEcfDLWMNqxjnjk57GkZJpaH4sbltFT2pC0rygpQCMZIyallhjYS6sDKlKxk/L/5oTL09Oslxk254tR3Y7hbUpCSdxHcH2IwfvUqsMTyIrCFHccZUo9+vNMtMUotaY5RhhxtHsKErd8+5Sl7vQCG0oHU4/wCtFXkjc24T+ZSjzT+x6PdCQ86kNIUd2SoBS+vTNLlJLsohjcnSE7A3b0yFOXYPFlKSUssJ9S1dgT/CP61ZXh5ZrTqO+MmTOjRCsYSn8jcZsdk56rPQAdMknml9MyNOuxmPj3m27W05t+DiDAWoZz5rh5Ufl0qU6vtei70gpYQi0yNo25T5QxzjHapJZE3RoQwSir0aDgWqDCtTLNvW0YzSAhAaUCAB0rI/jdbXpeurxLI3NofRHAx7Ng0tb9N6m05I86y3t9LYOQlKyUqH05BFJXOfdLsbgzdY4E1ctt4upTgKO3aB98ChguLtMLI3KPFqiu5VoMVLJUnHmt+aPmMkf6UGmtlCgEjnOasrxJZag3aPCYUg/ARGoy1A5BWEkr/9SiKr64OJ2JSGylz/APISc7lZPT2GMVVCTaTIMsUnQClpCM5OT1z709v9qNriW0KGFqjb1A+55/1ovpjSjupL1BjFs+W6rzFkj8rST6lffoKPeLNq3XlltpOB5J4A6AGicvqSBWO4tlUOubU57mpv4V3AqvzSFcJUgII9+1Q2dG2BXyzRrw/WqNfoqgfanomWpFv6fguTdKquKG8oEl1t8pH5XArGT9Rt59zimsjkHJq1fCrQK5FtnW22yyqXcWBd4rcpASh7JU2+x7FBITg9iAeMVHvEPw7uGkVx5D0F+JDlglCX0+ppY/M2r+4Pcfenem9XjyP2r2XZPTyjDnRXb/CMUweWUIOKJymTyOlC5qdoxV7IGINuApPHNJFRUeaVjM7gSTxSiktoaJBrng8NX8qT7Ck220qBpKTIJyB0rmHMNkk0Nps6uxtKTlZwa6vDznqJrqTJ7BYRC+eKfxV5UO1DUnmn8LlwDvXonkSGIcJJ6inL26dL2KXuCcAbeh4z+tJRWcNp96cts856H5UGWDnKNeLKMcuKdj6KwlpsJSOBTpDZxS+mdN3TUkpceAx55bG9xxSghDafdSjwP9aLahsa9LBiO++w9MdG8hhRUEJ7HOO9cfqIwqH/ADfj/PAccLlcl9q8g5tj4UpU4gKJHDZP96XSpb7m5XXoAOgHsKZpdJOT6j3Jp9Af8pRdKd2zkJA5UewqvHja+qbt/wCdAuSf0x6L7/DVYIdout71renEsWnS8JUh15XRDqkE/wDmSgKP1UmsZ+LfibcPESdqnVk5ShI1DP8AJabJ/wB1GbwoNj5AeWPsa0n+KfVn/wBHfw/ab8MIrwRftQ//AHnUBSfUlCiFIaP1ISMezfzrFmqJKkQ7ZAHSNH3KH/8ARw7z/QpH2rOlL3JOZzI+K4gS1x/OfUsj0p4H1708np2ltA7npSsFjyUJQOwyfrSct0/FpIAOAQCema94JqJXo+1TJIaMdSm4qnPKeUD6SOqs8e1T+9RYLMNwSEKdXJHmeS0OQnHp5xxgAVXlgeGnYaRMePmT3gyg7v3eSAo/02pz/m+VWoUNSrcm4oQdikYeSof7tQGDn5GsqbfJs28CjSXkgy7Wi4vtyFtlfm/uyVcklI4ycdccVD4VwcdkOHlLadwA9+TVsKAvGjJDEZCYrcBTry5ufWpQBIQkds9z7VUduT+8UkjBHOPlVOJ2iTOqkSS0xf2i622obiMAD6nFSXxK8ObzYZQkRluJjKT+VKjlPBzg0N0WyF3DOPS3hxX0Chk1tBzT8C9Qwh9lDqFDIJGccdqTmnxkir0+JZIOzDsrwruf+IcR50+GyhDy3Yo/hWnOQk9x0Pzopa/C3Us+beHNPuTHIkJpogSRkrSpOQhScYyOeK1RI8M3LUVPQlqkOKO0DcEFtJz0x2GelGtJ2m4WND8VmE02y84XHHFnLi1kY3EnvjAx04pUMzTal0Pn6ONJwdMpfwdjTJLJZ+HU0thWyTEXnCFc+pGegPtVnao8O5F2YZbifBxUBXmuLW2S4peMDn2FWPpbRkKxypstxxD4kjIbLYCkK5zz7U+ditKXjAxSHd2Varj2ZZv3g5MtXmPLaXcnicspaQVJWrnlZAyAOuO5qBHw5lsvlyZGWk5KhHWNq19eVD+FP9fatnaidatcRTqRkgfrWdfFLxMRp9wtGP8AGXN9JcDQ4CE9lLP9hTY5J9Ilnixr6mVsLDe4MuRLYlLjOuDaS36E7R0SB7DsKa3azagiRVzp7heU4hSAHFblhJz1HamDmpdT32aWmIsNxamPiQpoK9KfYnPBoSxr25bJ0WeFCQ0kjY51BGRz9KoXN70R3i8NkPuqlFhX8xOwfPmiGmJHwtxQsnGFBOfbrQtLqJchKUq37OSoflH0pwztS6B28zOP1wKtRneS9PCPXDujNdWiatxQjraKTuOQEqJzj5E/3rXV7mWvxL0kp0/4iBMaPGPWhQz+ikmsXybW2qNa32hkttKScDrt25/sTVp+F3iMdNz1wZjgFtmEKC1flacxgKPyI4Pt1rE9Z6WcZLNj+5H0HpfURX+3PpkB1hY5Omry9BkYVtO5txI9LiOyh/3waik1eSTWgPE7TSb0w6hspVKay9HIP5geSn6Ecis+zsgKyMY7Gt/0Xq/9Vi5P7l2ZnrMHsZKXT6EIwLnGcUnJBGRmvkR8IWRmvkl8HNXXoh8DRSM17dQlDY55pJThrw86pQGeMUFgpiT2CK6kXVcV1A2Cwoj81FrYjc6KFNcqoxahh4V2PYSJHHBSBRqxWOXfpojw2i4vqpXZI9zQhlQOOMCpdG1LAtOnY7ERp5i6IfLq5XmcHggAADsKD1OSeLG5QWyrDGM5pSeixWZdr0XZTCS8kRmiVurSRvlOgcn6DoB7feqqn3Ry63B6U8dzjqsn5ew+woRLuyrhLQgqKgBk+wHYUqjINQfw3C7lmm7bLPV5U0sUFSQTYSCvjmrD8G7DAuWtWrheFhqwWRld3ubquiWGRux9VK2pA75qsWnlBWBTvxe1udCeD0bS8Rey76sWJ1xUPzNwG1YYaPtvWFOEdwE1s55VCl5M+HdvwVP4t+Jc/wAZvE67akuBO6fJ3NtE8MsjhDY+QSAP1qCzX1TLs4tfO5xSj8gOgp3bCG3FOKHKUE/rQp97e+5tPJOCaz6SWhDbk7YUHojqX70tbYseUgNusub95Up0dNuD6cY74pxaoyHVsoWhpwDny317Eqx2JoxarCudeodubaCPi5DTQKRkfvFYAB54IOftSMs6VDscbpgPxBPkvWa1qbLSo8QOrQoYIW6d3PH8oRVj+GevEXG0P2R0tovDaf3bjv5HE/zH5gdf1qnvEC4rm6+vL3mqebTNcaaWo5/doUUIH/lSKZ2R5xvVUJ5EsQVB1J+JV0b46n+1L9tPGk/1GwzOGVtddGgdVQW7Pb7qIKEpD0dQkob/AN3uwSFpHYkA8e1VDGSpYDrX+8QTwf4h7U7na2uv+1dwt0mWiZCCnIxW0BtVjICwcc85P3r3aYpCQPbivY4uK2HlnHJJUTXwlQLndZzPk7nVxnQhB77k4x/StaeHN6Rc9MQi44PPabSheTgnjhX3GD+vtWZPC61LsuprHc1ZEac47HKuwUkj/mP0rTWnrQLFOcj7AIj6i4wvH5CSSps/ckj6kdqz/UfcbPo9R2TJpSXcYINPGkAc4pOOx6RinqG8UlWWTa8Hg5A+VJFtS1U5cX6fpXiM4lTqd3AzXm6AirdAPV9uWLY2taD5fmJBJHHPaqy1X4f224NLuAi5krRsW6kZKgBgBQPBH/Kts6q0naNQ+CE1iA/GkzAwmU2GyN6Ft+raR16bh96zGx5aoLrSkg7hlOaIWqbZQAZh6KbmTHIKn5D5HCUAAgflT8kjrWffExtMael15sImz1KeWDwEIzwP+/atoXLTvxzziQ3vCElxXHAA7n2rF/ixLRedfT3AMxWFfDMoHJc29SPkTnmq8G2Q+rShDRGYym4sIr4JUfTgYBo/o61sXCNLfkslxYS7sXk4b2oJzj3JIoChr4h8g4O0dug+QqY6TlGJa50ZLQUFIUXFEcpQClRx9SlIrRRjeSfx4shqOzvfUuOlGUMgelKlD1H5ngf1pB5RaykZwPy/T2qRy7Q9DhR5Lih5UlO5pKeiU4BPbrlR/WgkhtKlAHpnk/KmQjcbKZSppBjT2tnGIxiylk7U4jurOdhGcJPy9qi+rUB2ct8JSjz8rKUcAK/ix9+fvSE1ksuqb7JJA+dNZkhT7CUKBK2z1PcH/wCKVHAsWT3IdS7CnmeTH7c+10DEN4cpOUknpTpsDzea8ylJQSAKvXRFQwU2QBSTvHXrSjju6kXBuPWhsERcOK6ucTniuoGzgVaozZhl7FBmQc5o7Y0FT5NMXaCXYeUrAGKYXpxwW9SgraUKSrP3og5wOaaTkCVFLeNxyDj3xXsycoNIbF1JEd09qJLVwcafylLhylZ7HnH2qeNLDhHtUKn6cRPaCm/Q8n8p9/kaN6ZcmRWhGltKUhI9Dp6p+R9/kaVgjLE+L6Z2T5E1sNrjzp6Pi3PIgMpU/Lf/AP1sISVOK/8AKCB8yKz5rrWMnxB1ncLy8ny2314YYHRllI2ttj5JSAKszxS1d/s9opdqYVtmXvh3B5RFQrJH/jWAPo2feqSjLCG956npR5pXKvgXJ0qHb8gMsObT6lekUzjoQp9hIyVE+v268V8WvzVITjA6k0ZsEdp2UU7ASEn1HoOwH3NSydKwIq3Q4+GebUH3ElEZPIUR+brwB3z/AEqa6UuCg1IuqEIbVF8+UkpTyhTTW5A6dArH6moncFJhyhCkx0vhGVqQsqCvUDtQkjocYwfnU/0vpJUHTmp5Tu5ENdqmONJcI3qJQpOcYzhO3GSByahzP6fqLcSqWiilsmSSs+pROST71IdKWVpdwiynT+8ElAaQU5ScHKlKGOQPbvQC2FSo6c/xED+lWRZmGZsqGqK0wsKcbbbQ4cA8/lIHIIPeqMsuKonxR5OyLXK1fDaiVKbRtafec9GP92vJCk9OncfI/KjkJ34dxSFDBUApNEtR252Axcm2zGDbNz8t5CFbllzaooIJH5MbhxQy7RHFW6NKaGFJBP1H/YpcJ3Q9wpMv7w2tKdT+F7zScJkRpjjrDndCwMg/3H3q9dF3Jy+2SM8+ylSikBe09FDg5B6EGs5eBOrmLdpa5MPqA9ZWEdzuTjA+pwK0HpOKu2vMHPl+cykuo93AAM/XqD9Kgy/c0zY9P9qaJ2xwMYxTrAwO9MUPZ6UxvGrLXp0Nm5zmoKHDtSt44Tn5noPvSkUu2GZDQW0tPTIxmotcW7sy8hxuaGmkcFtLQKVjvk9c/SlJHiTpyNhJu0d5auiGVhZP6Uwe8QLHMbdQ4+tpO0gK2hWTg8YB4+9C2hkYzrSGv+3N2XdjHgl6Iw3wqQTgr65wPb5mvSnC2D2pnAeafAdRghXINOZStyeOSeKKkhfNt7IH4qahFk0tcZXnFB2BCGwrG9RPAPvzz9qxpdnAXlnGFuZKlfxK9+ew+VXp+ISc49qU2pqV5qICQH0p/Kh8j1J+ZSMA/PI7VRVxCY7u4thbm0nJ6AD5VpYIcY38mR6zL7kqXgUt0RKUJKuFOEAD2FSa6QX7Y7cExmsQ1BoOOAdMglKfueftUQtUpx4hxfKjz/eprqaaoS22QSW3AhxQ7EhPpP8Aeq1aRnqmmWpbrmq/eFdvcCQXIgG445G390sf0QfvUYLuQc078H5aJkS8WhSxkp85tB7hadqsf+JKDTVTYW5t4B6HdwB9abgdJp+Bk/qUWNbg55slRT6knofemcpoNsgEYVnP2xRtcFLATvBUrqAnuOeaC3V/z3CoJCU9AB2ApcMnuNRh0vIc48E5S7fgHtpBd96QuSdq/qKUbP70Uncjlwd+KsJPAJXkGvBUTnNenOCaTJyMULAPinOK6kVjPGa6ls8SBgcVItOJ3ScGo7HBJqTaaR/ixn2pyGIKy2Skk9BTEd+SKOXRstt8jGaCdQaYelpjiIAgZHU0TjtpdPrWGkAErWeiUgZJP0AJoYykkDAoXr28/srTbjCVYkTstDHUNjlZ+/A+5rrlxVnl8sqrWuoHNT6hkzcFDKiG2Gz/AANJGED9OT8yaYNNqWUtpHpA9RpMJ810/XtT5OG2lbfSKh72KbvY0UnapZ7dKKWZwNpCFApDzqR5gHX5frzQhZLhSgdVK4/0qS2WEsyi0UoDbDSn1+eoJR6c9/mcCkZHSG41ciUWhNplagcN2DK3VHym3C8UqjrwoIUoAYIHpJJ6Yqy73aWNK6H1jLceamtOx2rVAkpeS4qWrbsddBx6kb1L+YPvio94YaJgXGdZZhQlSblIcYemhwbLasA5Ktw2j0kHcokADueKY+NGs03XUl3tVpmIkabjPhqMWkgIfDecO8AcqJUfY5zWW08mRQj0u/6M01WPG5Pt/uimHkCMkBKf936vrj/4o1pKSXbs2ptrzHHV4bbAyd3bHzz/AHphKjOOKUAnJX6APmafaaWbPeYsllHmuwXQ55axwpQ/5k1pzXKNGfj+mSYSuIXcNSB7YUJWvG09RjI5qUIt6VabktOqCVRVKTk9wRlP65AoU2xuvLeSkrK960pP5TyTn2+lFb6Vx3Ano26Eqx7qRkf+4VPXSK1pOQ+8PWXLU6l0JBkMOJXtUMg8ZH681pnRus4t98ohQQ+jqlR5Saom42s6dvNkkY2sS2kxXR2CwAUn+v8ASn7vxdnuAlQ1FtY5yOh+RqXJ9Ts0ML4Rr4NZRXdyRyCKUltMy4zjMhpDzKxhSFpBBHzFVj4beJEe/JREkrDE1I5bUfzfT3q0mihwAEjmp2vDK1vaKtvuj7JGnJd8hlgpyUrQNi0ntgj27VXGptErvkhIiXCaXPN3b0r5J56jGD9a0PfrHGeaIdCXAR0qIpiw7MVEBKUpydyuMD615Wt2UPKnHi4jWw2NWn7O2y5KdlLSMqW7jOftUX1t4sM6UafRAcS9ewClnumMSOXT/mA/KPfntyL1/wCLSVw5ESyLysJIVKxwP+D3+tU9c8KdeUcqKlZKick8dSfer8OFt8pGLmzpXGIHfl+cJansuLWvdlRyo5HJyevNQ2/IG9ZGNyk7EpHOBUqWyHt+9sAhZGP+/rUd1E0G2k+WAMLIJHuB0q1fJmyGVpaShs+6cD65NTW5WZsstvjcVrWkcnIHHH+lQuyBUlXAO3cVE+/HA/vVjqWVWiCFcKUUHJ/4a5KTR7HG0wT4fyU2TW0B+csM7N7ZCsjeSCEgHscngnjjmp1qy3Gz3qaxnKFOFaCB1SrJH/L7VHL9Zo0OQppQckOFgPI8treEAgkhffA+VS6+zxqbSlmuvlpE2KDb5qm04S4Ujc05wB+ZB/8ATXMOVOa/I5wcYOPwRt65vK37lBRUkIKlDnA6UKfVweadPpwKZOir6UdIkk2+xucZ+dJSxuwe9LYwaTlA4HeiB8Ad9OFHNIcjNPZKQlXNNFD2oWDQitQBrqSe/OecV1LPEpYwKkenDulDtUXYVlVH7GVJkgjrTUMgSi67w3hf2FCG05GKITnlrbBXye1DQ5hPBpi6Cn2EIikJebazlS+QMdPqaqXXF8c1BqGauN+8hxh5KFdgkHG77qP9qlOrrpIt8VLjJIUsKZ3Dqkkdf71C48Ztm1MtN8uyVec6cdEjIQn+6vump5ybfEB9AxqPsxtGB0HzNfZpDKUoFEUtjzDj8iBj60JmnzpBCeQKWxY4tLLW9T74bKQQ2jzc7Nx65+396lMN2JYmi/LKH23EKHwWCS9ydpAIBQkYHPX2qHT5rloZjR2UD4lQ8wuqGcFXZP8AQZ7Yp1HbW5lbqitw8qUo5JNSSg5u30Uxkoddkil32ddYoLhDMVSztjM+lvv1H8R5PJ60zcaUphatuQCBn9afphpaht5V/uhwjuSc0SRC32pSdm1LuVj5e2f0rmo6QynJbBtgtJmyS4RlLQKunc9KlrWlBLhIDTaUOreBKwOwJ60jomKRbZSgncoubf0H/wA1OLQW41radkONsN71BTjqglOMnufkK5KQcIfJSmrboLFrOamM0mOUKBOxWcqKclWD756UrG1r+0ZkX4oIcDDnmFATt3AHJB/SoXepbl3vM2aokl95bgJ9iTj+lPYSEqWFBISeh4pnFVsR7jt10X5I1zb9ZOWpgoS2lMxKnCFZxwrpxUrkKZkoU2lSFqHYHnNUJb7ZIjsouLLhZOCG1NLG4r3bduByDzn5g1OrNG1ELEmbJa+Ntttex8PIPlOrBzuSlWAo4HPX+lQzgl0zRxZn5QWuBciPhxpamnUHKVIOCD7ipxpPx3n21KY13aXLQkYEhr8+P8w7/UVSM7XqVz5AV5jccOqS2mUBuCecblDjPb7U/wD20yIbsgjdtQVBPvxxXHB1sbHMruLNWI8RYs2MhZS+AtIUApog4IyKh+qpC9SsuMr8xqIT/u0qwV/8WP7UH8LrxP1RpRL0pDbqmCGBIZSQl0hIzx7jIBI4JqQphO5cCknGfbrQpRQfOU6Kc1HY5FllPxwlbreBscxwQrpk9jQG/ly2LktOJ/es5CgOhIH9qubUulZV2dZVHRx6UvKK8DCTkenv3qLaz0sJxW7sTuwULUSEgDnkk+1Uwz32S5MNbRVIW8hxHmJ3BxAVhI6cZ/TGKF32IlmG2V8qWtain54qeK0Y9aLSkvub33FlfmJ5BTyE446HGfvUS1G2A35aQVqbyteOdoA7/pVGOnG7Jciab0MNNxAUpSE5UTtAA7nNTa3QH5ceMpSMhJS035npSe2T8jwM/Woh4fxpV4bujzCkpchoVI5OMJSCVEce20f+KrAhKU9CSgggeWEpz16cf6UOSW9HcUdbB2uYMm2RYyHXUNupUtC32llCSkklIyBngg8U88Pr9b7pOu9pnThGZm28qadU2EoVKZBUgkY4CsLGep3UvrKdHuEFgpIUpTQUCo4G8DJSSfkFD7CqwfkhVzZeiZC0LCw4ruckjA9qjwJyW+ynM1CdraJi6SoZx15pq4DT0ODySkpHPI+VMZBwa+g7MyQmAAea+TEDaCOleQrJrpKFhsEg4ryeji6BM87cGh5czmn9xHoBoYaBsFiLityjXV8WPVXUtgkpipBWnP8ASjttX5T2RQOOQFA+1GoDmHAoDNMQxBh+Sp1ASelNkDJwa9KWVKzXDnntTUdezxOYh/suY5NZS+whs5bP8RPCQPmSf71W1wKmNylABxZwABgfPA9gMCp9dUrfkIjqISxHHnO56byOAfklPP1VVdTpgudzUpHDKeED5f8AWkzezktKhJavh4hJ6n3rxaYRlrASkqccWEJSOpJPSvN2dBCW09acW2Yq0IVKaWUvwWy/vAGEL6JHzO4ip5ukDFWwHJaW5dnUuAgsqKNp/hIPT9c07auPwrzTa296d+7jrj2pjaXFPKdWslTijlSickk8k04UjdNHskVytHb3aJ1HcgzI6SsrDp9KXWz0+RTUmjW/zXkJbWFR9gQAPftmq4tJ/wDubXskbqsGBcY7EZxUh9EcDopR5PB6CpckX4Lccl5JharUY7Di2mcoU76lIH8QH06mmmtLnAtehbhFksIkSJIXHYjuDB3qP5/cbRk598CvFj8RLTZbYH0yg9KWspcg7fzDnBzjA+uail8mJ1xqByZMlNJeICG47ahhtA6JGevuT3NKimqsfKSd8fJWjlsUkpyCnPPqHP1pdtoAhCBhOMdM1Yc/QvxMY+UlxT6ASgg85+9Rq42yZZojfxEaOH1rAynIdGc+kp6H6+9ULJyJJYnHYq26/c32mktojtpVu9HUHAHXHYJGKuDRiJEDT1yLakSnlrHmicx8ShaFJUnndyk54z7GqoZeFpmNIU0/5i09HmS3zzwPf61Z0VqTbdLruMl1hDLrqYqGmpKFO7lJKhvbGSlGB1Pfik5KqhuO7bKpvWm3ZUyU0yjcjzFLUT6Ujr79PpXiPGQxaEMuPrDiXiAEp3JUkDJwfl7UTuN0fgyZO1Ad84etl1GQsc4OP9RQ1qI7Ity5ZOwpdXhlI6ek5PT6cfKutvycSV67Ne+GNkNk8PLLGWlAX5Adw30IWSoduuDzUmkxkOsMYSARkZx1qs/BLVrV1sTluVIb+KhkfufMBUEFORgHkjr9Ks1re44kKHoHGDWFOM4zfI+ixOEoLiN7bbvikvcD2AqDaw0+442S1HEpTTvmKik4Dye6enXuPpVm2ABMp9rHXkGmdwYZbmuLUkbt3emY5OM2BkipQRTOsbVfJFuRJVZpTLGNoKihLiuDgkA+niqyvlgMKyTXX0JQ8W1bWWvyp69T3VWnL3OQ/HdhLZSWCApLmQef5T34PINU/r61raaLqGw6wTsVn8yM568cg9M1f6fJJqpqiDPjS3FlSeHsllcCXCLaGkrRhRSOXOScq+hx9hUwcuUa121LjqipaRjygOSRkf6VXOlI64txdZUpxp0EhtLaQSpwHASc9AeeaN3suOtu54JJOPatFxUmZsZuKIvqPUMm6stxnAlthhaylCB7nPPviveno37RcaQpJAaOVq909h/pSD0IrlNgI3qUBgY6nPFTCx2kWuIUHl1Zys/2H2p0Mab10I5N9hBWVimz6CadnABzx9KbPnjiqmAxuhGF06knz2scDApt/evTjhUjFeTOp0BZje4kdaGLTtzmi75UhRI5NC3kqWolQoWAxk4rB+VdXpbfqrqAEkrfWi8Inig6TT+E/tGCeRRIYg6kZA709gslxzOwrCBuKf5vZP3OB96FxpAVx0qWxZsfSemZF+lJCy2dzDSv418hA+mcn7CmJhxVsrrxSnDT7YszbgcuD376e4nsTyEf9/KoFBQUMqcV1PvSc6fIvV1fkyFl199wrWo9yacznAyylpI5xSG7diZO3YxU+VSsgAkZxnt86Ru+WYISDjzlcj3Snnn7n+lKNN+S2o43LUee/wBqR1FKccfjwFBIENHl8DB3k7lZ9yCcfalPujq6bPlpR5cYqIxuOacx0+c4tXucUgFBhsJzwlOTUr8L9PHUV1R5iN8VghbueijnhNelJRVhQi5yUUS/w48KpV+cEySVRozg9CQPWse/yFae8P8A8KsrUDTb8KxIeQOj8kZH6qo54GaLj3W4srlJHlJIwkjg1ujScRqPEYjsICGkgABIrFnmlOVWfRRwwwRTq2ZDjfgqevTzkO8WuPEa2EtykRkuoKvZW3Ckj54NUZ4jfg5FhuDzDC37U+nOBt8xpQ9wlXb6Gv1th23zUZHQd6C6t0fbNSR1RrnCaltdMLHqT9D1FdrJBXFivdxZJVOKPxGv1n1d4SOgXNhM+0LVtQ+gkt59geqD8jSI1TYtVx/KkMyEY9RwgOFBH8QI54r9C/HTwDasMeQERVXnS85JbeYWnc4znsfl3ChyCKwPffCRNn1I7bosjZOZeSmO4DhUhtZw2vGOFg+lQ+9Nx5FPUtNC8uJ46ePcWSOytWrUVqMGc/HmY43khJV7LGcFKv8AX5V8g6XgXFlyHLjockxlFBfSNqnEnOxYI9x/UGpJpvw7n3SxTRqOzqtku3TE25193a2HHVJJQAkkKKsDnaCOh701uegZdkkRXoUpAaS6BukE7Ac8oUocgK/oRS3KnQxLkrSAVx8OESVMkSZC/JTsa8xW/wAtPPAJ5A5pS7+CFy014fs3yTAkNWe7zlssXBwAoDraCR2zgkqGTxx8qufwf8Lr/wCKWvo9ldaZixAfMfMYlaUNA8krP2x75FT/APHkzA09atNaSgy3IzTDCk+ShZ8thQA8oqTjHQE56jNBzbf4Ge3FLrZkzQ+kdPXZh2LOS2pLjBQzIcBT5KiSdm9PII7K6diKn9lvup9JWlu0xjAvaW1+VEkXWQWVlPO1tTv5T7JKsdgT0qF2bzJTEaEuAXLiohlLsLkuk5CRs7kn9c0+19ZbrpDzbRdNyHHmkuoQW1oP5vUhSVpBSoY5/pmjvlpgJcFaRYukvFOMu4zYmoGU6XvcIn4m3XFflrAwfUjI9YP+XP3qw4+irtq5lmfaHrZPhyQVsvs3FopWOcjrncO6SNw7is5tFvXiZlhvBcfcgYNunjmRGSU9Er6kD+U8EfSoPPf1P4dXFbL7y21uHPmNqUlicgZwSOyx79R9K48KlLWmdWZxinJWi99aouWndSP2qTBU1KYAyt5W1DiTnCkED1JP831qH6ubn3C0LbZgvOKPJU0QsADJ+vt2odD8QJep/wBn/GzXZRbSppoyDlaMncUE/XOKmdqlE8BKlgAq9I6AdT9BXdwoalDIuzPs2Ki6a3CISvhA462VuvpKA0rAC1KAGQArNWXdfw962nWR67WyBHvsMFW79lSUvODGc/u+FHp0AzXzxPsFmn3Rq4MzkF99hTT6YKg4sKAyhZA7djz2px4Sa71Z4f8AmYjyn0oTx5K0lLiQDgKB9vfrVXuZKUomf7WNScZP+pT8a2PGU4lQUy9GJUoKG1SDnBBBGepAI6jOe1SJpAW2FYKfl7fKrv1Reo3jKUS7rYocCfnAnRU4mEcjC3BgK/4VA1Ut6skjTt4kQXknZ/vGnAOFp9x/qO1XYJty3qyXJjUOnYIcSRTVzAPvT91B5FMnkYqxk7GxwFe9OJDzBYCUIwruTTV4YpstZ555obo5dCclwEnihj5BzgU6cUckZxTNxJwaFsEYuK9VdX0pwo11CCScI3dqWYQAenNJoyT7U9Yb3HiiCQd0jZhers22vIjI9bqv8vt9zxQnx91ClVyj2OIQliInc4lPTeR0+wwKsC1MjRelnbrJKUKSC8Uq7qx6Qfp1+prO86Y7frvIlvElx5ZWrPzr0tKhkvpjXlnm1RAn96s4HvSM979+op5PQUQfcDDOwAULbHmvkkcA4z86W9CDo7pZKpBSVIj/AL1YBx0PHPzOBQcuKckea4re4tRWpR7knJNO746Y0dqOD63v3qwOyf4R9+T+lDkglz6ClrewnrQ5U55pUexOPtWifBKxC36djrUn95IJeVxzz0/pis7sRy/IZjo5UtQSB8ycVrLRTPwzTDCRgNpCB9hipfUSpUX+jjcnI0p4OPiO+0kDHNa/0jKSGWiT2rGnh0osOtEccitQaMuivIQFHisf/kb+RXFF2xLgG2sdqbzJocJJPJqLpvAS2MKpFy8FR5PFUPJozFh3YlrVSZducbIzWcfxC+HNu1t4ftXFuCIGq7A4mXCu8RoJW4hKgVNuYHPAyCe6R7mtCzJAkJIPOa8W62MPIcbfaC21ApKFDIUD1B+VI3ytMtVKHFo/KbxSna0dltruUlV1ZC3pseSykc+coKcUABkHKU+k8px7VO/AfUMzxflP6cftL8y5tMqU8403lpxoZBU5n8igcc96lni14dQ9N6/vOn40xUOQ1cf8C2+D8P5LyCtsKX/+M53I3dDgZqzPAzSDuhdAX6SIa4WoL6+hpqY2UkBojCVggdU5Wcd+KfknH26a2T44SWTknovv8PWj7Z4SeHkqY4pDjjgW69MX+ZbKM7RnA4HP61lxvwh17+KzV8++3BSNP6eky3HGZk1sqcdbydoaRwVADGCcCrh8PtMaus8piLdFu3WyzJbjMazlWEBlHDa1kDooqJI+VWgvVMa63S8SYrqVQrMv4OO3EPLkjvtGOgPpHbqam2h/JW/yAfDH8Nnh34CKRcZChKvCUFQu92WnLYwSS2n8qD8hz86zF+JjUCvGjUX7Z+FcuGnratcVthhRS4Gh+d5C8cKJwcGtDePGhL541aZhR412ZgXdhe+PbVL2sSAchW89cjBIOMfrRHRX4b9K+Dehpt01tdxdpKWi9KUSW4jRwRhCOqzzjJ6+wrtye4+Dv0pfVtvR+eMb4XHmMKbZckpWtTbaz5qChZRtd4GFYwoY4INO3bLHvtiUmapT/nElKlKypGCcEE9CDTyfKsT/AIkXtlFunsWpTjpZbioRvQgoWpJ2K/Okfm2g5IBA6UMtcE3F5EiAtUcrZSpxLaiphxWD60g9O2U8EE1Te7J1pcGVVdYl0jajRbFNJMt5SUNPIAQHR/Csn5d/bmrOk6nTJ04LCh1SPOWlLzzBBU+oZHOP4cjIHfNMNY2NE2Ipi4NKjuJyWZKeiFdiFdvoarbSsR6wvvzpktthhDgZcTnOecBQwO2eKp1NWI/lyp9ML6gtd3s18ctbUuNLUlsO7gfSnIztPsodxT7Rg1KzclJTbFPgDqFp28Zx8sVIHfDVm4uuOp1DEtzjjC3m3ZmVIeUASE7kjIKuxIxUC03L1MZm6FGmKUk5yhBGPv0pqkpLQiUHCW0aE0Bp68uzUsTreylfqWzhzatSeeARwSOwPJo5rDQ7GqLOoNkJktkqZdx0V7H5HoaAWC9azVZYtwudkcMKMrcuU2U+b3yVBJJx8wKsnTtztl3g4hhvKgXC2FcjPXr1/wC+KBSadoc42tmWblCdhPOMvtKZdQopUhQxgjrQmQjdWltaaai3iNIjvDa07hXmpGS04PyuD+xHcfMCs9XW2u2ya/EkI2PsqKVJ7Z9x8j1BrSxZfcX5I8uPgrI+82RTF0bVUWkJwaFSlAHpzTWTDVxsn1U1cSACSaWkPHb8qZuZUDnmgbPDZxQ3HFdXlXXpXVwXZK0DmpVoyyftO6NeYP3SPWr5gf8AXio3bY3xcgJJ2NIBUtX8qR1NWHaJrWmtNSLo+nyypO9KT2SOEJ/1+9Gux0Em7ZFPHjVW9yPY2F+lsBx8D37J+1VZbU5UcDt1r5dri7ernImPEqdeWVHPzpYp+Dhey10LdsVKXKVjSc95jh285OBTixx/Klhb7YUxHy86lRwClI3EH64x96YNPKbf3AAkZxuGRnp0r5epSoNnQxnDsvkjuGkn/wByh/6aRNt6QUK7YFlzF3i6vyloSgurK9iB6UDskfIDiva0BIJ6E9a+QmdjW48FVKONleEj3o1pUL7dsPeH1t/aGqYBWPSlzzSPkkZ/vitVaUjgqR3BrPHhdECbytzH5GcD7kVpPSKOWzWd6jbNn0iqFl16Hb8vYTxV+6Wk+UwjmqD0mvy0tjrVv6enYQkZ7VmPRsdqiyv2h6etfEzCT1yKjQuGB1pRqd6uuaFsBIl8ZYfUAOtSu3xUpZGR96rqFem2FJyfVnrU4st3blp2BY3Aciii9isidFCfjH8JpGoLHDvlnLbTzjjVuuiF4HnxfMC0HOOqFj9FGinh/p12WxCLxzGioShhgdMjgE++OMVJvxH3NUXRkGOlX/8Aont8DuEgq/5Uz8M7k0qNFbcUoFSsghPGEg5J/pXpvaRyF8WyYQ5CJE9yH56ozx3tMKQPXuIIK08cEc0Qt2iLfo7S8Ky25DMWHv2uynyAslWdyyccqV0+VPdGW9LvxNwW3tLyyGwR0T/1yaMX+Q+1bHEwmmHZJICUyDhGO5P0HajitWyee5UjP8i5oY1DqmSy3MeW66GoUwMBMVllpBwN5AP5genXHzp7rLTuqfHJmJYpTjFus8JLT0yYckSHlJyhKU4HIHPPGetTm+6FtVwukO63BJkvsqBVucUlpw5JClIHHp5x/wBapPXPjWq1awetunpgeluR0tGK1jK1rWopcUMcc449iO1LlFJ2yvHKT+3srTXfhPDsd2udvcWZccJS3HurDWHYrrSso8xI6o7ZHTJ7VS71jZ0M7cpSFvF4tksMtLSW0nJOHAR60Yzgjnn5VsGJpibaLU0mWlx6QQVvOlJwVnk/bmqp8V9A/wC1dsdTEaaTNRktlSeFH+U/X+9cT4uvAeSHP6vJXEu2xb9YGpOxCm5DIXtB3AZHIz3weKonVHhuluRIRHdCELOS06sI45OQo1fukHVSFLta7ei1fCspR8KjJCFp9K+D0ycH703vfh6y+t1xknarJKFepOfkD0qqEnBiJwWRIpDT2r7VY4KErUrDSAgcFRwMjv0opK8VLb5O9tb+M4x5fSkddeGbu11bcYhXJ3NcH/lVPXdmdZdrTrI/d+nzCkpKhzwof61TCMZ7JMmTJj01o0TaPFG6W6K2qO+QxjKR7A0cs3iLFmyt8tvY6o5BZPloCvcoAwT86zxZL/Jtg8l0FIwMtO9sjII+oqSxrkjyUONr5PNFxrQHPltGnkz492jAJWneR0JqtvEbSDk1AlMN5fZTjjqtP8v1HOP0qGWjX64JCVqJA4xmp5bddwrpFS2pZQ50w5/zo48oO0cbU1TKWmIAycUJlI3AjFXg9pvTl0U/brihq2uznQYt5QD/AIZ08AOpH5mVHGcDcg+oZGQax1Vo+56Ovku0XiIqHOjK2rbVyCOoUk9FJIwQocEGroZVPXkiljcN+CFTBjApi8vaDnrUicjIUvkUHucRIUccCjYprVgpS66vKk7SRXVwUWxZLKFqiwFDa49iRKP8jY5Sn79fuKE+MWohtatLCtoGFOJB6AdE1MEPI01Y595mne+56yT/ABKP5Uj7/wBBVEXOc7dbi9JeUVLcVkk02WlQ2T4xr5PFtjlb4yMgcmlZ6y48fYcAV7jOeSysDhSuM1yHExnELUgOHcCUnuPal3oSdbrSHXG0O+lxxXQ9G08kqV7YAJ+1Re8TE3e7vPMpKY+drKVdUtp4SD88AZ+ZNSK9umz2RbwUW5F0K0Mt9SiMDhSj/wAShtHuErqKwkbsqPAFIW3YyX0riO0gjA7Cl4THxDqARnJpBa9rfzVxRW3NpYZ8wn1gH047e9GwYq2TrwyCVXOclI/IhAz9zWgdLr8tKKzl4Uvk3WdnqpCVfor/AK1ofTS8hv8AtWfn+42fTbgi4dNS9oTVnWSf6E881UFjd2BHtU+tEzaBzxWe0asWWGifkdetejdA0knNRpFwyOuKaXO7eUyolXGKWEPbhrluJPQ2t0JB5OT2qR+E/iGbxLfdDmW1lSxz/Dnan9cE1j3xX18Y1wWlLpQo/u0nPv1P6VKfCTXq7XCSoHal3GPkkDCa9wdWe5x+00j+ILVTcxdgt+4KPmOSFfQAJ/uaKeGEW7XBKPhYBkKVhP7xflstjnhSsZJ/ygfWqBn6pZ1V4oWxMkuLiRWGwsI6qJUohP0zjNbR0S6iFAZcaQlCQnhCew9q44u1YnklFpEuEW8Wa3JekQorkZA9fwa1bmx77VDkVH13yPOur8dcpCVtBKhHJwcEZCuetF9Qa+Q3a1RgnYSCFE96w94g/iHiQfE+6xC0zLiMoQ2kOcDzEHKeRyOf7U9pS1HwRxUo7kX/AON/ibD0xZH4zb6TKW2pIGcYyD1P9c1Sf4U/CdvxK1pI1hKcDkCM/lpYUD5uBgHpxgAJAPvmsv8Ajz44ytYThbW3gh6Wv/EPpTw22T0wOmckkdgKsjwv13ddG6Oj6f0Tdr5bHA+5Omv+egMzG9u1LrSEAqTjBynngZPSvKFRuXkN5LfGHg/TKbZ47rZQlCduMYxVc6t8I4t1S47GxGfIPKRwfqKzfp78T3iRoWQBe9t/huI8xKZ+FbkHOFNvIAyPnyPfFTTSn43Yl01aImo7Oiy2STtbalsLU6Yq8kFTpIG5B45SPT1ORmjceXgXGbj5IR4gaCk6Su67hJgevYWjJbGUqT7H6Y4zQ3SUVjUFw+BdO1TgJbUO/wD31rUY1nozWV6lWJq8QZcxA9TRWNjoxn0L/K5wR+Umq91j+HpVkujN6028uI4y4HjEUPQrB52+3ekOLj+hbHJGWn2RaZ+G2XdmitlSCCP4hUE1B+Dm63Jp5KrW1LSOxxz9OK2vpmdHuFqjvMjGUgKQeqT3B+Yo4hkODA4oo/hipZHdNH5C+J34Sr/prc9EgSYwQMeRIbUWiPYKH5aqGx22JbL7cLPqFU2yrVGW5EdWNzYeTyAogHKFYxnjGQTX7oTdPNzGyl1CXAeoUMis2fib8ENNWvRtx1YwzGtl0tyC82shKUPE8Fsgg53gkcDNULJOOntErhjk+UdP/o/Kez3Va1q8zgk9FdqkLVyVHRu8wAfWiPijoy1wn35FnkM+adrqPh3MtupUncBjA2kZ2n2KeetVtEdkKWQ8VJKTylXaro1LZBL6XRYp1FJlwkNOuEo85sNE+4UCf6A09v8Ar+7eI0kzrm8uUqI38OhW3hpreooSTj/MQKCaXs7mqvNaZkoYdabUQkoUpLSAk5UogHBJGPrTWzuSLGwBGeWWrjFUiQ28wAnAWfSM5zjAIVwQaCMl7mu0MlfD8McLABzigd1Ci4SBxR0EKbOeMULmEKQrAzV/kmfRHSnKjkV1KKCgs8cZrqIQTPxo1QH57VkjL/cxPU8U9C4R0+wqs2ckn3pWZKXLkuvvLLjriitSj3J5NOLVBVMeAAwkclXsK422zzfJjmJGwgOKBV2SPc0rbbUblc/JccS2kEqcdJ9LSEglSj/wpBNO7k4mP5bDQwpI690/9aHX6X+ybCWUp2v3DKMj+FlKvV/5lAD6JVS8ja0uxkUrt+CM6jvK9RXl2V5YZaVtbYZHRppICUI+yQPqcnvXhDQZZxjmk4kfKt5pw96f70SSSoU25O2IJy6+E9hRZZ8toJ/iI/SmFsa3r3Ed6fuHe/tHTNcZ2JMvDFHlXpST/Gyf7g1f+ml7CkVQGg1+XqKOPdCx/Sr20+9hQ7VBn+42PSv6KLVsbm5KMniprBe2pTVf2N0BCccCpdDlZSBUDRpxeiSfF4STmo7qa8+VEcGc8Us9M2pOOlQ7UkwuNOZOKGgm6Rn7xP8AOu2qIzSDhtKVOOKNP9PajegvtM5PljimN9zL1c4nOUJQkGntzbjw4C3QAhSU8H59B/WqH0kRp7ci1tAXH9oag+JSCVuOhKOOw9I/1rX1nVd48iAkuFhpWC44TjykjOf6Vib8OmoYjt6iOXRTzbkXCs+TuTlJVjlJ9ST8xlJHcVs7xF1EynTbbUJ8IekMheTwQgg8A456EfapMmpUPxtSimVH+JH8Sc+3rkQbOhSUklpqSeC4eRx9Pf51iG76rdYVJnPrLsx1RCd3UqOcqNXH4qpa+KdmPOlYZQoDefSjucVRmkmm9TatZlvxkyYjK/MRGXkIcxylKiOxI5PtVeJKMOTJM8nKSii7fwweHtg1s7Kd1VbP2m3LdRFDoUsPMOq3EuI29diRkj51MpHhU74f3qw66td3jW7SBd+OhTLotKX20IdKXULYAKnFEZ5SMKT3zmolo7xRtfhJbrg1p6G1eXlOny7g4gpQZJSS5ICSnKQkK2IHQgEkc0W0FrtWq9SKN2typVylkQ23nfU0lDilJLaUkYQjCirj2+dIayycp19J2LxpRjey21eIelZNsuDWkYkzUGm3pSnW2XtkdqI96t6WdyStKVAgkHGQaJ6V0no7xAsVyuC4Fn0wuDkSI8+apt1AwSFhXAKT0GAeR0qNX3wTY/DtrOSyp1+daHUIfVHZ/PIjlRBU2kj87ZzhP8QGO9e77puDqAuOMMiTFOXocoo2+a0d2HBxweCCk8gjFcfFasYuTV0ROBpEWnUS7jpmdFmMMqUtVvkkAuNerOUkYWg/zD1DrXS/HzVfhHqqXIst0kK0+8d/7NlrVJjeoZ27FE7SFbhlCh0FI6x07Os0aLLCHW21qKmJCQU5UnqUnHUUzhzYeorTdnZlqLsyFCXKlxEIy3MaScLU3x6HfUCU9FYJGCKak0uXaFtq+L0zSvgz+KazavebkSG02OU8SHEreBiPkZzhZ5bUBj8wxzjNats9yYuEZt5lwONrGQQa/IuPoeHdEt3mzS3bRaXkuoAlAkx3ACShfYA8ckmrh/DN+Ke4eHuoU6T1WpRt63djUkrygAkgKQfryU9weMEUPFRbcf7HXJySUv7n6XtKBT71lj8a9ysGpI9v0ncLg/b3IQTdZKm20lBaUS2PzYClDCiBnrWjLPc0TGEOocC21pCkrB4UD0IrJn4jLzL1R+JGyWO32eDPudsWzDZjvgKE5DyA4tL2eNg3Yxxjk0xPn0J48HsxZqDQsZ5b8MvMsyErUqK5JHkqdbOcIUMYBOM5BPWidu8A4F506yzeWJMa4rU6lqUwMra28jI6OIKSogdfSQDU48ZNGLOoriH7QNP3iHKUxLtLST5DW8q2qa4OUq45BI5BBq5rVo+Bp6wQrbd0yYMS2KjMouhTuCXigrWhfGcZJ2kdDXMuRwiqewseNTk7WjB022XHwyu8m2ykSUoKgtxuMvaiUgZKFjIwR04P3ptpexXS/wCopjbFvmXB74V6a6zCZLqmkAFSlkJHCE9VKHFa21DprT/iEqVaJC0qW264qDI2bFqTz6k8cK909D2rOGs7BffDPVLaG5LrcZ9BiolxFltLrR4KDt7EdUng0/HJyl8NickFBX2kRKSkpQT8qFKc6g0VuLmdyccUFWobjWszPboauJG4/WurnknJ7V1esXQEt9sdnLBAwgdVHtUpt8MN4ZaASjqpZ7AdVH6UhGUHsNsja2nqflRa7rVaLSiG0kJmzAFOZHKGv4U/Unk/aut0tdhwXkYi0/EXVKHEqhhYLpceIPlsAElZHbgE8+4FQO/XT9u3d2QhBbj8IYaP8DY4SPrjk/MmpNqNP+zem2mAT8fdwXHSTyiMlWAP/GoH7I+dRCOjOSe1TQVtyZ3I6XFDltISkAU2fO7IHVRwKWcc2INJw0+Y9k8hNOEBCK2GGScflFeoLS3ngcFR68CuP5AkjO49KK21rynAncEBQKdx6DIoZOkMiraJR4b2ly6akQhl1lEhCVFthxRC31YPoRxjd9cZ6dTU7keINn04Eqck/EOkbg1Hwo4+fYfeoPoC2uyLw7JbfbjrhMOSRlYDjhSDtDYIO5e7BA74NC7tYX9WzH7pZLTJcSmOZVyjNJ3fDuJVh1YA5LZPqzj07iOAM1A/rnUujQjJ48f0LZdWmvHi3St5VBkssNAeY6VAhGeBn6mrd0JrnTWsWH/htR2+NKb2huLNc8lb5JIwgqwnjBJJNZL0KQ3OMRy2GbCfQpqRFa/M431JBxwpJAUk+6R2q8fDLSLNhv8AO8ttq4vNRAzFEmPuaU04d3n7SgjcUZBH8KuM0iainRViy5Gky1ZN4YcQstvtugcEtrCh+oqA6rvhQhznjB4qjbndH1apnPQ1C2BLi1uPMAsttpyrJKR0H+XqelB5evJgfdDcpUtClErDgIQpPOCkdUnHUfSurHTo8/UWtkgiXUztRzV5z6gn+letbXFKUwoii4Ny/O9Cd35emflmhGjXEPyZE1xadi1FWRwAKL6fZRqTVLr0qc01CKwEqZIUtptOfUAe/U/emOk2/gS25RS+S6fw1aXXqS8m3wobrt9ff2oZU3tQElJJfCscADJOegFXV+NK2z/CqBYrW3clzLY/CSIzKH+DgFK1pTgbQVEYPbmhHhLNf8NdRXP9lItc9yFbWVvOz5SBHSuSv/Dla0Dhzn8hPPIrPniJ4gXa8QbqL0iRcHBcXCy7I3fuASorbAI9KTnIA6VmY0smTnX/AMK5NwhxvRX2o9Xuz9Pzo83z1paQslWM4SThKSfkT96BeHWtHNFLensNoMxDKksuKSCGXFAjfgjqBnFCdXyl/slbqFExlyAh3A4yAduePrQFx7ZEiIQrBc3PKHsOif7GtlY4yVPyZUsklK/gtLTL71n1vZ2Lqz5jDz0Z95hfqDrLh384HOUqPHY1dTd80xpa9+bZpCbmqNvW61LVhLh83e02jAyAgJwecnFZ90dMlTGBPLTT8q1tKbjuPqxtSMkEDjcW+ce2aeWielk7ircVEnJ75pLx+5Lb6Hxy+3G0u9mtdRePl78UGQzdfhWGi+45ujMAObFgpUgqOSRtxx7jNWt4Z+GMufoh/UzEx65Q4rpjz4yOSqNgFEhKQPS43n1d1Jz7Viu2anbjoTuVjFXz4QfiVvXh6x5VtmpjwFqy/DeQFNv8EHfn5HHFDPCqqKGQzO9snniz4Z6g08gPTmprlvJPw7z+S2AecJP5RnOeKo6Vc5lqU6mPKdZQvhaEKISsDOAod8VZesfxD3LVWl27JIlOiHbllloFXoW2fU0enUJO3/w1SN0v7Dq1r3hRyeBXcUbjTPZJU7TD72uJiY90dlQmm0Skoc+JKQUKfQNpWobeStOQrtigNusj1otzWr7rY/2tpKc67BkK6I3DlwDHLahkKSr3FQW+3X9+ZEZ1TT6e4USk/VJ4IqWab8doQ8K39G3eIY6m7gqUxKYICEhxJCw4n+JGcKHXHTsKGeJwVwXZyOVTlUn0bS/C94tsRrMzpiTejdG4wC7ZNePrkwyfSD//AERylSflWVkeMlzvP4jtQanjyNkxF2ekMq3AeWlOUtYyOgSkDHzqEWe6N6N1fYYlgdlzYMttuVGzyUSSD5jSFAcpPTn9KBXiBA0j4jKuEMKTp6chb0eRcmz6m1pPmFIGNykq3JA98ZoMKUW0/PQzNLkoteHs354aaQuXjfd/9s9TQ3nb0xHYRBjXWJ5LN2LW4kODGUpxgJUDjJz2Iox44axsV2gWq3wUpQtDi35UUtlKoxxgNLBH5grf/Sgv4PPHOJ/9NLeifNmOQID0iDBmXQgyFxkqykqOMDaPSEg/Kgf4lvEu0aqROm2u1qEhEtCxPZjnKmQgpWpxQGACopAzSOSlkp+GNUZKNpaoq3UiY8R8Oxj5a0HcFIOFJUOhBHQjsaD6iukLW9pktXBDRmoG5wYCQ6P5wMcKzjOO/PeoZcNYtqQoqX6j37VC7rrFuO95gc9YBKQP4uOnyz0q2WNtX8E8cqT35I1qWzrtNwdZWd6FEqQv+YVGXEYcNFP9q/24t5pwFGF+YylRyUjuM00ko3ZUnrWnF2tmdOr0NHGwR711fFurSOK6vCw9oWGy87AS42lYWslQPcgZGaESz+0dTzPiT5uXyOfbdjH6V1dRT8jl9iAfi96PEvUUdICWYsoxWEAcNtIAShI+QAqMI4bFdXUjF9i/RAZv5kv1Z4XypINOYYCWOBjJOa6upvkSP4w3SU55xRZaR5ecDNdXUPgYiS2d5cGalcc+UpDHmpUkchWxXP1qZa3bTp/xx00i2j4FMiBaS6GDt3+fGQl/OP5wpQPvk11dWU/5i/R/sacf5f8AVESsMlyFHd8hZaISoZT19OQKt7wc1XdZOuLdYHpinbPNYW3IiLQkpWktLWeoyPUAcgjmurqY0mm2ci2lorbWyEptzraUhDe91wpSMblAnBOOpHbNU0p5alqUVclKuRx2z/eurqdi7ZPl8EpschxvSj+1RHUce2aOaXiMuxFrUgFaVEA/RJNdXUfyD5j+hqvU9it+k/wr+HF1tERqDcdRTbgq7SEDKpnw+7yN+c5COoHQHnrWbNb3WXNjWtTz6lmQ0/IdA4C3N6xuIHf0j9K6uqCCXK/z/wCl7b4P/PJTWpJbzk3YpxRQpIWU54J98V9aWo3cDPAUEgewx0rq6tVdGM+2S2atTIhMtnY0GSvaPcnk04hSHAlz1HjpXV1Lh9qHT+4PQH3ClPqPNGvOWuMWyolCsgj34NdXUSPCOgbzNlquTL0lxxttISlKj0AXwP6mvlxfcbmPISohIUcD25NdXUtfexz/AJcQVJfWQcqJoBOJ81P+YkH5iurqaIYq1cJLdgIS8pPkyAWyk4KCUEnB6jJotqafIm6Q0qZDyni3GlIQVnO1IdOAPYc11dUzStfr+w+P2y/T90aS0i+uDY7ZDYIaioixWg0kDG1aQpX3J5J61XninrO+K08bZ+05CLeu+OqXHbVsQshsY3AYzj511dWdgSeTfyaWV1j18FcPzpBb5dVQKVJdU4QVkgg9a6urX8GSB4LihdmcHHrx/Wpa7wTj2rq6qEJGLvWurq6vHj//2Q==",
    bio: "魔界を統べる姫君。優雅な佇まいの裏に、圧倒的な魔力を秘める。"
  }
];

// Back-compat alias used in a few places
CHARACTERS.forEach(c => { c.emoji = c.img; });

const ENEMY_EMOJIS = ["👾", "🧟", "👻", "🦖", "🦇", "🕷️", "🦂", "🤖"];

// ========== STATE ==========
let state = {
  coins: 300,
  ownedChars: ["c1"],
  activeChar: "c1",   // selected for upgrade UI (legacy + detail panel)
  party: ["c1"],      // up to 3 character ids for battle
  weakWords: [],
  level: "3",
  characterLevels: {},
  duplicateCards: {},
  limitBreaks: {},
  cardAtkBonuses: {},
  castleLevel: 1,
  battleHistory: []
};

function normalizeParty() {
  let party = Array.isArray(state.party) ? state.party.slice() : [];
  // Migrate from single activeChar if party is empty
  if (party.length === 0 && state.activeChar) party = [state.activeChar];
  // Keep only owned, unique, max 3
  const seen = new Set();
  party = party.filter(id => {
    if (!id || !state.ownedChars.includes(id) || seen.has(id)) return false;
    seen.add(id);
    return true;
  }).slice(0, 3);
  if (party.length === 0) {
    const fallback = state.ownedChars[0] || "c1";
    party = [fallback];
    if (!state.ownedChars.includes(fallback)) state.ownedChars = [fallback];
  }
  state.party = party;
  if (!state.activeChar || !state.ownedChars.includes(state.activeChar)) {
    state.activeChar = party[0];
  }
}

function loadState() {
  try {
    const s = localStorage.getItem("wordGuardSave");
    if (s) {
      const parsed = JSON.parse(s);
      state = { ...state, ...parsed };
    }
  } catch (e) {}
  if (!state.duplicateCards || typeof state.duplicateCards !== "object") state.duplicateCards = {};
  if (!state.limitBreaks || typeof state.limitBreaks !== "object") state.limitBreaks = {};
  if (!state.cardAtkBonuses || typeof state.cardAtkBonuses !== "object") state.cardAtkBonuses = {};
  if (!Array.isArray(state.battleHistory)) state.battleHistory = [];
  state.castleLevel = Math.max(1, Number(state.castleLevel) || 1);
  normalizeParty();
}
function saveState() {
  try {
    normalizeParty();
    localStorage.setItem("wordGuardSave", JSON.stringify(state));
  } catch (e) {}
}
loadState();

// ========== UI HELPERS ==========
function showScreen(id) {
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
  updateUI();
  if (id === "zukan") renderZukan();
  if (id === "gacha") document.getElementById("gachaCoin").textContent = state.coins;
  if (id === "chars") renderChars();
  if (id === "history") renderBattleHistory();
}
function updateUI() {
  document.getElementById("coinDisplay").textContent = state.coins;
  document.getElementById("gachaCoin").textContent = state.coins;
  document.getElementById("levelSelect").value = state.level;
  renderMenuPartyPreview();
}
function renderMenuPartyPreview() {
  const line = document.getElementById("menuPartyLine");
  if (!line) return;
  normalizeParty();
  const members = getPartyCharacters();
  const portraits = members.map(c =>
    `<img src="${c.img}" alt="${c.name}" style="width:28px;height:28px;border-radius:50%;border:1.5px solid #3a4568;object-fit:cover;vertical-align:middle;">`
  ).join("");
  const names = members.map(c => c.name).join("・");
  line.innerHTML = `
    <span style="display:inline-flex;gap:4px;align-items:center;">${portraits}</span>
    <span>${names}</span>
    <span style="color:var(--gold);font-weight:700;">合計 ATK ${formatAtk(getPartyTotalAtk())}</span>
    <span style="color:var(--muted);font-size:0.8rem;">（${members.length}/3）</span>
  `;
}
document.getElementById("levelSelect").addEventListener("change", e => {
  state.level = e.target.value;
  saveState();
});

function showModal(title, body) {
  document.getElementById("modalTitle").textContent = title;
  document.getElementById("modalBody").textContent = body;
  document.getElementById("modal").classList.add("show");
}
function closeModal() {
  document.getElementById("modal").classList.remove("show");
}

// ========== BATTLE ==========
let battle = null;

async function startBattle() {
  state.level = document.getElementById("levelSelect").value;
  const startBtn = document.querySelector('#menu .menu-grid .btn');
  if (startBtn) {
    startBtn.disabled = true;
    startBtn.textContent = "単語データ読み込み中…";
  }
  await ensureWordBanks();
  if (startBtn) {
    startBtn.disabled = false;
    startBtn.textContent = "バトル開始";
  }
  saveState();
  normalizeParty();
  const partyChars = getPartyCharacters();
  const partyAtk = getPartyTotalAtk();
  battle = {
    baseHp: getCastleMaxHp(),
    maxBaseHp: getCastleMaxHp(),
    coinsEarned: 0,
    wave: 1,
    waveSize: 5,
    totalWords: 1500,
    wordIndex: 0,
    waveWords: [],
    combo: 0,
    enemies: [],
    currentQuiz: null,
    answered: false,
    // 問題文・例文の準備中は、敵の進行とスポーンを完全に停止する
    pausedForQuizPrep: false,
    wavePreparing: false,
    prefetchedWaves: {},
    _prefetchingWave: 0,
    spawnTimer: 0,
    tick: null,
    partyIds: partyChars.map(c => c.id),
    charAtk: partyAtk,
    killCount: 0,
    over: false,
    spGauge: 0,
    spMax: 100,
    waitingExplanation: false,
    userPaused: false
  };
  // Show party on the field
  const bp = document.getElementById("battleParty");
  if (bp) {
    bp.innerHTML = partyChars.map(c =>
      `<div class="bp-unit" title="${c.name}"><img src="${c.img}" alt="${c.name}"></div>`
    ).join("");
  }
  // Each level is an independent 1,500-word course. A run shuffles all
  // 1,500 words once, then consumes them exactly once: 5 words per wave × 300 waves.
  const sourceBank = (WORD_BANKS && WORD_BANKS[state.level]) || [];
  const uniqueWords = [];
  const seenWords = new Set();
  sourceBank.forEach(item => {
    const key = String(item.w || "").toLowerCase();
    if (key && !seenWords.has(key)) { seenWords.add(key); uniqueWords.push(item); }
  });
  if (uniqueWords.length < 1500) {
    battle = null;
    showModal("単語データ不足", `このレベルの単語データが1,500語未満です（${uniqueWords.length}語）。`);
    return;
  }
  battle.waveWords = shuffle(uniqueWords.slice(0, 1500));
  document.getElementById("battleCoin").textContent = "0";
  document.getElementById("waveNum").textContent = "1";
  document.getElementById("waveTotal").textContent = "/300";
  document.getElementById("waveProgress").textContent = "1/5";
  document.getElementById("baseHp").textContent = battle.maxBaseHp;
  document.getElementById("comboDisplay").textContent = "";
  updateSpGaugeUI();
  clearEnemies();
  showScreen("battle");
  setBattlePauseUI(false);
  battle.tick = setInterval(gameLoop, 50);
  // 1WAVE目: 問題をまとめて取得してから出題
  (async () => {
    await prepareCurrentWave();
    if (battle && !battle.over) nextQuiz();
  })();
}

function setBattlePauseUI(paused) {
  const battleScreen = document.getElementById("battle");
  const overlay = document.getElementById("pauseOverlay");
  const btn = document.getElementById("pauseBtn");
  if (battleScreen) battleScreen.classList.toggle("is-paused", !!paused);
  if (overlay) overlay.classList.toggle("show", !!paused);
  if (btn) {
    btn.classList.toggle("is-paused", !!paused);
    btn.textContent = paused ? "▶ 再開" : "⏸ 一時停止";
  }
}

function toggleBattlePause() {
  if (!battle || battle.over) return;
  battle.userPaused = !battle.userPaused;
  setBattlePauseUI(battle.userPaused);
}

function resumeBattleIfPaused() {
  if (battle && battle.userPaused) {
    battle.userPaused = false;
    setBattlePauseUI(false);
  }
}


function recordUnansweredCurrentQuiz(reason) {
  if (!battle || !battle.currentQuiz || battle.answered) return false;
  const q = battle.currentQuiz;
  if (!q.word) return false;
  const correct = q.isMeaning ? q.word.m : (q.word.answerForm || q.word.w);
  const label = reason === "retreat"
    ? "（未回答・撤退）"
    : "（未回答・城撃破）";
  addBattleHistory(q, label, correct, false);
  addWeakWord(q.word);
  // Prevent double-recording if called again
  battle.answered = true;
  return true;
}

function endBattle() {
  if (battle) {
    // 撤退時も、画面に出ていた未回答の問題を履歴へ
    recordUnansweredCurrentQuiz("retreat");
    if (battle.tick) clearInterval(battle.tick);
    if (battle.coinsEarned > 0) {
      state.coins += battle.coinsEarned;
      saveState();
    }
  }
  battle = null;
  setBattlePauseUI(false);
  showScreen("menu");
  updateUI();
}

function clearEnemies() {
  document.querySelectorAll(".enemy").forEach(e => e.remove());
}

function gameLoop() {
  if (!battle || battle.over) return;
  // 例文・問題生成中は敵の行進を止める。spawnTimerも進めない。
  if (battle.pausedForQuizPrep || battle.wavePreparing || battle.waitingExplanation || battle.userPaused) return;
  battle.spawnTimer++;
  if (battle.spawnTimer > 80 - Math.min(battle.wave * 3, 40)) {
    spawnEnemy();
    battle.spawnTimer = 0;
  }
  const fieldW = document.getElementById("field").offsetWidth;
  for (let i = battle.enemies.length - 1; i >= 0; i--) {
    const en = battle.enemies[i];
    en.x -= 0.35 + battle.wave * 0.02;
    en.el.style.left = en.x + "px";
    if (en.x < 62) {
      battle.baseHp -= 15;
      document.getElementById("baseHp").textContent = Math.max(0, battle.baseHp);
      en.el.remove();
      battle.enemies.splice(i, 1);
      const base = document.getElementById("base");
      base.classList.add("shake");
      setTimeout(() => base.classList.remove("shake"), 300);
      if (battle.baseHp <= 0) {
        battleOver(false);
      }
    }
  }
}

function spawnEnemy() {
  if (!battle || battle.enemies.length >= 5) return;
  const field = document.getElementById("field");
  const el = document.createElement("div");
  el.className = "enemy";
  const emoji = ENEMY_EMOJIS[Math.floor(Math.random() * ENEMY_EMOJIS.length)];
  const hp = 30 + battle.wave * 12;
  el.innerHTML = emoji + `<div class="ehp">${hp}</div>`;
  el.style.left = (field.offsetWidth - 10) + "px";
  field.appendChild(el);
  battle.enemies.push({ el, x: field.offsetWidth - 10, hp, maxHp: hp });
}

function meaningTokens(text) {
  return new Set(
    String(text || "")
      .toLowerCase()
      .replace(/[・、。/（）()「」『』]/g, " ")
      .split(/\s+/)
      .flatMap(x => x.split(/[、,／]/))
      .filter(x => x.length >= 2)
  );
}

function likelySameMeaning(a, b) {
  if (!a || !b) return false;
  const am = meaningTokens(a.m);
  const bm = meaningTokens(b.m);
  for (const token of am) {
    if (bm.has(token)) return true;
  }

  // Also reject obvious English morphological relatives.
  const aw = a.w.toLowerCase().replace(/[^a-z]/g, "");
  const bw = b.w.toLowerCase().replace(/[^a-z]/g, "");
  if (aw === bw) return true;
  if (aw.length >= 5 && bw.length >= 5 &&
      (aw.startsWith(bw) || bw.startsWith(aw))) return true;

  return false;
}

/** Orthographic vowel start (Eiken-friendly a/an rule). */
function startsWithVowelLetter(w) {
  return /^[aeiou]/i.test(String(w || "").trim());
}

/**
 * If the blank is immediately after a/an, return "a" or "an".
 * Matches blanks like "___", "______".
 */
function getIndefiniteArticleBeforeBlank(sentence) {
  const s = String(sentence || "");
  const m = s.match(/\b(an?)\s+(?:_{2,}|_{3,}|…+)/i);
  if (m) return m[1].toLowerCase();
  return null;
}

/**
 * Keep only headwords that fit the a/an constraint.
 * "an" → vowel-initial only; "a" → consonant-initial only.
 */
function matchesArticleConstraint(headword, article) {
  if (!article) return true;
  const vowel = startsWithVowelLetter(headword);
  return article === "an" ? vowel : !vowel;
}

function getQuestionDistractors(bank, word, count = 3, articleConstraint = null) {
  const targetPos = word.pos || inferPartOfSpeech(word.w, word.m);
  let candidates = bank.filter(x =>
    x !== word &&
    (x.pos || inferPartOfSpeech(x.w, x.m)) === targetPos &&
    !likelySameMeaning(x, word) &&
    matchesArticleConstraint(x.w, articleConstraint)
  );

  // Prefer words whose meanings have no shared Japanese tokens at all.
  const strict = candidates.filter(x => {
    const a = meaningTokens(x.m);
    const b = meaningTokens(word.m);
    return ![...a].some(t => b.has(t));
  });

  let pool = strict.length >= count ? strict.slice() : candidates.slice();
  shuffle(pool);

  const result = [];
  const seen = new Set([String(word.w || "").toLowerCase()]);
  for (const item of pool) {
    if (result.length >= count) break;
    const key = item.w.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      result.push(item);
    }
  }

  // Fallback: same POS ignored, but still honor a/an so the article cannot leak the answer.
  if (result.length < count) {
    const fallback = bank.filter(x =>
      x !== word &&
      !likelySameMeaning(x, word) &&
      matchesArticleConstraint(x.w, articleConstraint)
    );
    shuffle(fallback);
    for (const item of fallback) {
      if (result.length >= count) break;
      if (!result.some(x => x.w.toLowerCase() === item.w.toLowerCase())) result.push(item);
    }
  }

  // Last resort without article constraint only if still short (should be rare)
  if (result.length < count && articleConstraint) {
    const loose = bank.filter(x => x !== word && !likelySameMeaning(x, word));
    shuffle(loose);
    for (const item of loose) {
      if (result.length >= count) break;
      if (!result.some(x => x.w.toLowerCase() === item.w.toLowerCase())) result.push(item);
    }
  }
  return result;
}

async function nextQuiz() {
  if (!battle || battle.over) return;

  if (battle.wordIndex >= battle.totalWords) {
    finishLevel();
    return;
  }
  const waveStart = Math.floor(battle.wordIndex / battle.waveSize) * battle.waveSize;
  const waveEnd = Math.min(waveStart + battle.waveSize, battle.totalWords);
  const calculatedWave = Math.floor(battle.wordIndex / battle.waveSize) + 1;
  if (battle.wave !== calculatedWave) {
    battle.wave = calculatedWave;
    clearEnemies();
    battle.enemies = [];
    battle.spawnTimer = 0;
  }
  battle.answered = false;
  document.getElementById("resultMsg").textContent = "";
  document.getElementById("waveNum").textContent = battle.wave;
  document.getElementById("waveTotal").textContent = "/" + Math.ceil(battle.totalWords / battle.waveSize);
  document.getElementById("waveProgress").textContent = formatWaveProgress();

  const word = battle.waveWords[battle.wordIndex];
  const typeEl = document.getElementById("quizType");
  const wordEl = document.getElementById("quizWord");
  const sentEl = document.getElementById("quizSentence");
  const choicesEl = document.getElementById("choices");

  // IMPORTANT: never reveal the target word while the example is being prepared.
  choicesEl.innerHTML = "";
  battle.currentQuiz = null;

  let example;
  if (hasExampleSentence(word)) {
    // ストック済み → 即出題
    example = { ex: word.exSentence, ja: word.exJa || "", source: word.exSource || "cache" };
    ensurePhonetic(word).catch(() => {});
  } else {
    // まだ無い → 出題前に最終取得（最大約3秒）。失敗時のみ意味問題に確定
    typeEl.textContent = "【準備中】問題を作成しています…";
    wordEl.textContent = "";
    sentEl.textContent = "例文を準備中…";
    battle.pausedForQuizPrep = true;
    try {
      clearExampleFailure(word);
      word._finalAttempt = true;
      example = await Promise.race([
        ensureNaturalExample(word),
        new Promise(resolve => setTimeout(() => resolve(null), 5000))
      ]);
      if (!example && !hasExampleSentence(word)) {
        word.exSource = "none";
        word._exampleFinalized = true;
      }
      ensurePhonetic(word).catch(() => {});
    } finally {
      if (word) word._finalAttempt = false;
      if (battle) battle.pausedForQuizPrep = false;
    }
  }
  if (!battle || battle.over || battle.waveWords[battle.wordIndex] !== word) return;

  // If no vetted sentence exists, never manufacture one. Use a direct meaning
  // question instead; this keeps every displayed English sentence natural.
  const isMeaning = !example?.ex ? true : (Math.random() < 0.35);
  battle.currentQuiz = { word, isMeaning, options: [] };
  const bank = (WORD_BANKS && WORD_BANKS[state.level]) || battle.waveWords || [];

  if (isMeaning) {
    typeEl.textContent = "【意味・文脈】この単語の意味は？";
    wordEl.textContent = word.w;
    if (word.exSentence && word.exSource && word.exSource !== "none") {
      sentEl.textContent = word.exSentence;
    } else {
      sentEl.textContent = "（意味に合う自然な例文が見つからなかったため、単語の意味そのものを問います）";
    }

    const distractors = getQuestionDistractors(bank, word, 3);
    let opts = [word.m, ...distractors.map(x => x.m)];
    shuffle(opts);
    battle.currentQuiz.options = opts.slice();
    choicesEl.innerHTML = opts.map(o => `<div class="choice" data-v="${o}">${o}</div>`).join("");
  } else {
    typeEl.textContent = "【使い方・文脈】空欄に入る語は？";
    wordEl.textContent = "";
    const blankSrc = (word.ex && String(word.ex).includes("___"))
      ? word.ex
      : (createBlankSentence(word.exSentence || "", word.w, word.answerForm || word.w).blank || word.ex || "");
    const blankSentence = String(blankSrc).replace(/___/g, "______");
    sentEl.textContent = blankSentence;

    // a/an の直後が空欄のときは、選択肢の語頭を母音／子音で統一して特定できないようにする
    const article = getIndefiniteArticleBeforeBlank(blankSentence);
    // 正解自体が a/an と矛盾する場合は、意味問題にフォールバック
    if (article && !matchesArticleConstraint(word.w, article)) {
      typeEl.textContent = "【意味・文脈】この単語の意味は？";
      wordEl.textContent = word.w;
      sentEl.textContent = word.exSentence || blankSentence.replace("______", word.w);
      battle.currentQuiz.isMeaning = true;
      const distractors = getQuestionDistractors(bank, word, 3, null);
      let opts = [word.m, ...distractors.map(x => x.m)];
      shuffle(opts);
      battle.currentQuiz.options = opts.slice();
      choicesEl.innerHTML = opts.map(o => `<div class="choice" data-v="${o}">${o}</div>`).join("");
    } else {
      const answer = word.answerForm || word.w;
      const distractors = getQuestionDistractors(bank, word, 3, article);
      let opts = [answer, ...distractors.map(x => x.w)];
      // 最終ガード: 混在していれば制約に合うものだけ残す（正解は常に含める）
      if (article) {
        opts = opts.filter(o => o === word.w || matchesArticleConstraint(o, article));
        // 足りなければ再補充
        if (opts.length < 4) {
          const extra = getQuestionDistractors(bank, word, 6, article)
            .map(x => x.w)
            .filter(w => !opts.includes(w));
          opts = opts.concat(extra).slice(0, 4);
        }
      }
      shuffle(opts);
      battle.currentQuiz.options = opts.slice();
      choicesEl.innerHTML = opts.map(o => `<div class="choice" data-v="${o}">${o}</div>`).join("");
    }
  }

  choicesEl.querySelectorAll(".choice").forEach(c => {
    c.onclick = () => answer(c.dataset.v, c);
  });

  // 現WAVEの未取得分 + 次WAVEをバトル中に先読み（待機なし）
  prefetchRemainingCurrentWave();
  prefetchNextWaveInBackground();
}

function answer(val, el) {
  if (!battle || battle.answered || battle.over || battle.userPaused) return;
  battle.answered = true;
  const q = battle.currentQuiz;
  const correct = q.isMeaning ? q.word.m : (q.word.answerForm || q.word.w);
  const isCorrect = val === correct;
  addBattleHistory(q, val, correct, isCorrect);

  document.querySelectorAll(".choice").forEach(c => {
    c.style.pointerEvents = "none";
    if (c.dataset.v === correct) c.classList.add("correct");
  });
  if (!isCorrect) el.classList.add("wrong");

  if (isCorrect) {
    battle.combo++;
    document.getElementById("comboDisplay").textContent = battle.combo > 1 ? `🔥 ${battle.combo} COMBO!` : "✔ 正解!";
    document.getElementById("resultMsg").textContent = "攻撃！";
    document.getElementById("resultMsg").style.color = "var(--success)";
    dealDamage();
    // 正解時は従来どおり短時間後に次へ
    battle.wordIndex++;
    setTimeout(() => {
      if (!battle || battle.over) return;
      proceedAfterAnswer();
    }, 900);
  } else {
    battle.combo = 0;
    document.getElementById("comboDisplay").textContent = "";
    addWeakWord(q.word);
    // 不正解時: 解説＋日本語訳を表示し、OK 待ち
    battle.waitingExplanation = true;
    showWrongExplanation(q, correct, val);
    // 問題消費は OK 押下時に行う
  }
}

function showWrongExplanation(q, correct, selected) {
  const w = q.word || {};
  let sentence = w.exSentence || (w.ex ? String(w.ex).replace(/___/g, w.w) : "") || "";
  if (sentence && (!isNaturalExample(sentence, w.w) || isSenseTrapSentence(sentence, w.w))) sentence = "";
  let ja = hasUsableJapaneseTranslation(w.exJa) ? w.exJa : "";
  const meaning = w.m || "";
  const result = document.getElementById("resultMsg");
  result.style.color = "var(--danger)";

  const bindOk = () => {
    const btn = document.getElementById("btnExplainOk");
    if (btn) {
      btn.onclick = () => {
        if (!battle || battle.over) return;
        battle.waitingExplanation = false;
        // 誤答時は進捗（wordIndex）を進めず、同じ問題に再挑戦
        result.innerHTML = "";
        battle.answered = false;
        nextQuiz();
      };
    }
  };

  const renderBox = (ipa, sent, trans) => {
    const ipaHtml = ipa ? ipaSpan(ipa) : "";
    const correctIsEnglish = !q.isMeaning;
    const correctHtml = correctIsEnglish
      ? `<span class="ex-correct">${escapeHtml(correct || "")}</span>${ipaHtml}`
      : `<span class="ex-correct">${escapeHtml(correct || "")}</span>`;
    const sentShow = sent || "（例文を取得中…）";
    const jaShow = trans || (sent ? "（日本語訳を取得できませんでした）" : "（取得中…）");
    const wordEnc = encodeURIComponent(String(w.w || ""));
    const sentRaw = (sent && !String(sent).includes("取得中") && !String(sent).includes("例文なし")) ? String(sent) : "";
    const sentEnc = encodeURIComponent(sentRaw);
    result.innerHTML = `
    <div class="explain-box">
      <div class="ex-title">✗ 不正解</div>
      <div class="ex-row"><span class="ex-label">単語</span><span class="ex-word">${escapeHtml(w.w || "")}</span>${ipaHtml}</div>
      <div class="ex-row"><span class="ex-label">発音</span>${ipa ? escapeHtml(formatIpa(ipa)) : "（取得中…）"}</div>
      <div class="ex-row"><span class="ex-label">意味</span>${escapeHtml(meaning)}</div>
      <div class="ex-row"><span class="ex-label">あなたの解答</span>${escapeHtml(selected || "")}</div>
      <div class="ex-row"><span class="ex-label">正解</span>${correctHtml}</div>
      <div class="hist-speak-row" style="margin:8px 0;">
        ${w.w ? `<button type="button" class="speak-btn hist-speak-btn" data-speak="${wordEnc}">🔊 単語を聞く</button>` : ""}
        ${sentRaw ? `<button type="button" class="speak-btn hist-speak-btn" data-speak="${sentEnc}">🔊 例文を聞く</button>` : ""}
      </div>
      <div class="ex-sentence">${escapeHtml(sentShow)}</div>
      <div class="ex-ja">訳：${escapeHtml(jaShow || "—")}</div>
    </div>
    <button type="button" class="btn-ok-next" id="btnExplainOk">OK — 次の問題へ</button>
  `;
    result.querySelectorAll("button[data-speak]").forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        speakFromDataAttr(btn);
      });
    });
    bindOk();
  };

  renderBox(w.ipa || "", sentence, ja);

  // Phonetic fill
  const phoneticPromise = w.ipa ? Promise.resolve(w.ipa) : ensurePhonetic(w);
  // Example fill if missing
  const examplePromise = sentence
    ? (async () => ({ ex: sentence, ja: ja || await fetchJapaneseSentenceTranslation(sentence) }))()
    : (async () => {
        const got = await fetchNaturalExample(w);
        if (got?.ex) {
          const translated = got.ja || await fetchJapaneseSentenceTranslation(got.ex);
          w.exSentence = got.ex;
          w.exJa = translated || "";
          w.exSource = got.source;
          return { ...got, ja: translated };
        }
        // Minimal sense-bearing fallback for explanation only (not used as battle question text)
        const fb = `This word means "${w.m || "..."}": ${w.w}.`;
        return { ex: fb, ja: `この単語は「${w.m || ""}」という意味です。`, source: "fallback" };
      })();

  Promise.all([phoneticPromise, examplePromise]).then(([ipa, exObj]) => {
    if (!battle || battle.over) return;
    sentence = (exObj && exObj.ex) || sentence;
    ja = (exObj && exObj.ja) || ja;
    if (ipa) w.ipa = ipa;
    renderBox(ipa || "", sentence, ja);
    // If still no ipa
    if (!ipa) {
      result.querySelectorAll(".ex-row").forEach(r => {
        if (r.textContent.includes("発音") && (r.textContent.includes("取得中") || r.textContent.includes("なし"))) {
          r.innerHTML = `<span class="ex-label">発音</span>（取得できませんでした）`;
        }
      });
    }
  });
}

function formatWaveProgress() {
  if (!battle) return "";
  const size = battle.waveSize || 5;
  // wordIndex = number of correct answers so far
  const inWave = (battle.wordIndex % size) + 1; // current question slot (1..size)
  return `${inWave}/${size}`;
}

function showWaveClearCelebration(clearedWave) {
  document.querySelectorAll(".wave-clear-layer").forEach(el => el.remove());
  const partyChars = (battle?.partyIds || [])
    .map(id => CHARACTERS.find(c => c.id === id))
    .filter(Boolean);
  const pool = partyChars.length ? partyChars : CHARACTERS.filter(c => (state.ownedChars || []).includes(c.id));
  const star = pool.length ? pool[Math.floor(Math.random() * pool.length)] : null;

  const layer = document.createElement("div");
  layer.className = "wave-clear-layer";
  const colors = ["#ffd740","#ff4081","#69f0ae","#40c4ff","#ea80fc","#ffab40","#fff59d","#ff80ab"];
  let confetti = "";
  for (let i = 0; i < 48; i++) {
    const left = Math.random() * 100;
    const delay = Math.random() * 0.8;
    const dur = 1.6 + Math.random() * 1.2;
    const color = colors[i % colors.length];
    const w = 6 + Math.random() * 8;
    confetti += `<div class="wc-confetti" style="left:${left}%;background:${color};width:${w}px;height:${w * 1.3}px;animation-duration:${dur}s;animation-delay:${delay}s;"></div>`;
  }
  layer.innerHTML = `
    ${confetti}
    ${star && star.img ? `<img class="wc-char" src="${star.img}" alt="">` : `<div class="wc-char" style="display:flex;align-items:center;justify-content:center;font-size:3rem;">🎉</div>`}
    ${star ? `<div class="wc-name">${star.name || ""} ${star.title ? "· " + star.title : ""}</div>` : ""}
    <div class="wc-title">WAVE CLEAR!</div>
    <div class="wc-sub">WAVE ${clearedWave} クリア</div>
  `;
  document.body.appendChild(layer);
  setTimeout(() => layer.remove(), 2500);
}

function proceedAfterAnswer() {
  if (!battle || battle.over) return;
  if (battle.wordIndex >= battle.totalWords) {
    finishLevel();
    return;
  }
  const newWave = Math.floor(battle.wordIndex / battle.waveSize) + 1;
  if (newWave !== battle.wave) {
    const cleared = battle.wave;
    battle.wave = newWave;
    clearEnemies();
    battle.enemies = [];
    battle.spawnTimer = 0;
    document.getElementById("resultMsg").textContent = "";
    showWaveClearCelebration(cleared);
    setTimeout(async () => {
      if (!battle || battle.over) return;
      // 2WAVE以降: 各問題オブジェクトに例文が載っていれば即出題
      if (!isWaveContentReady(newWave)) {
        await Promise.race([
          fetchWaveContent(newWave),
          new Promise(r => setTimeout(r, WAVE_SOFT_WAIT_MS))
        ]);
      }
      if (battle && !battle.over) {
        nextQuiz();
        // さらに次のWAVEを先読み
        prefetchNextWaveInBackground();
      }
    }, 2200);
  } else {
    nextQuiz();
  }
}

function showBattleFx(text, x, y, cls = "attack") {
  const field = document.getElementById("field");
  if (!field) return;
  const fx = document.createElement("div");
  fx.className = `battle-fx ${cls}`;
  fx.textContent = text;
  fx.style.left = `${x}px`;
  fx.style.top = `${y}px`;
  field.appendChild(fx);
  setTimeout(() => fx.remove(), 1000);
}

function showDamagePop(text, x, y) {
  const field = document.getElementById("field");
  if (!field) return;
  const pop = document.createElement("div");
  pop.className = "damage-pop";
  pop.textContent = text;
  pop.style.left = `${x}px`;
  pop.style.top = `${y}px`;
  field.appendChild(pop);
  setTimeout(() => pop.remove(), 650);
}

function healCastle(amount) {
  if (!battle || battle.over) return;
  const before = battle.baseHp;
  battle.baseHp = Math.min(battle.maxBaseHp, battle.baseHp + amount);
  const actual = battle.baseHp - before;
  if (actual <= 0) return;
  document.getElementById("baseHp").textContent = battle.baseHp;
  const base = document.getElementById("base");
  const x = base.offsetLeft + base.offsetWidth / 2;
  const y = base.offsetTop;
  showBattleFx(`💚 城HP +${actual}`, x, y, "heal");
  base.classList.add("pop");
  setTimeout(() => base.classList.remove("pop"), 400);
}

function getJobAttackMeta(job) {
  const j = String(job || "guardian").toLowerCase();
  const map = {
    guardian:    { cls: "guardian",    label: "🛡 守護撃", ult: "🛡 聖域展開" },
    archer:      { cls: "archer",      label: "🏹 翠矢", ult: "🏹 千矢の雨" },
    star_witch:  { cls: "star_witch",  label: "✦ 星詠み", ult: "✦ 星落とし" },
    holy_knight: { cls: "holy_knight", label: "⚔ 聖斬", ult: "⚔ 天罰斬" },
    phoenix:     { cls: "phoenix",     label: "🔥 炎翼", ult: "🔥 炎鳥滅却" },
    dragon:      { cls: "dragon",      label: "🐉 竜爪", ult: "🐉 竜爪乱撃" },
    seraph:      { cls: "seraph",      label: "✝ 天光", ult: "✝ 天界の裁き" },
    demon:       { cls: "demon",       label: "☠ 魔呪", ult: "☠ 魔王の終焉" }
  };
  return map[j] || map.guardian;
}

function updateSpGaugeUI() {
  if (!battle) return;
  const fill = document.getElementById("spGaugeFill");
  const pct = document.getElementById("spGaugePct");
  if (!fill || !pct) return;
  const p = Math.max(0, Math.min(100, Math.round((battle.spGauge / battle.spMax) * 100)));
  fill.style.width = p + "%";
  pct.textContent = p + "%";
  fill.classList.toggle("full", p >= 100);
}

function showJobAttackFx(job, x, y, opts = {}) {
  const field = document.getElementById("field");
  if (!field) return;
  const meta = getJobAttackMeta(job);
  const fx = document.createElement("div");
  fx.className = `job-fx ${meta.cls}` + (opts.ultimate ? " ultimate" : "") + (opts.comboChain ? " combo-chain" : "");
  fx.style.left = `${x}px`;
  fx.style.top = `${y}px`;
  if (meta.cls === "dragon") {
    const claw3 = document.createElement("div");
    claw3.className = "claw3";
    fx.appendChild(claw3);
  }
  const label = document.createElement("div");
  label.className = "fx-label";
  label.textContent = opts.ultimate ? meta.ult : meta.label;
  fx.appendChild(label);
  field.appendChild(fx);
  setTimeout(() => fx.remove(), opts.ultimate ? 900 : 720);
}

function showComboHitLabel(n, x, y) {
  const field = document.getElementById("field");
  if (!field) return;
  const el = document.createElement("div");
  el.className = "combo-hit" + (n > 2 ? " late" : "");
  el.textContent = n >= 5 ? `${n} HIT!!` : `${n} HIT!`;
  el.style.left = `${x + (Math.random() * 20 - 10)}px`;
  el.style.top = `${y}px`;
  field.appendChild(el);
  setTimeout(() => el.remove(), 500);
}

function showUltimateFx(job, x, y, partyChars, opts = {}) {
  const field = document.getElementById("field");
  const chars = (Array.isArray(partyChars) ? partyChars : []).filter(Boolean);
  const showCutin = opts.showCutin !== false;

  // Full-screen cut-in for all party members (mobile viewport)
  if (showCutin && chars.length) {
    // Remove any existing cut-in layer
    document.querySelectorAll(".ult-cutin-layer").forEach(el => el.remove());
    const layer = document.createElement("div");
    layer.className = `ult-cutin-layer n${Math.min(3, chars.length)}`;
    layer.innerHTML = chars.slice(0, 3).map(ch => {
      const meta = getJobAttackMeta(ch.job);
      return `
        <div class="ult-cutin">
          <img src="${ch.img || ""}" alt="${ch.name || ""}">
          <div class="ult-cutin-text">
            <div class="ult-cutin-name">${ch.name || ""}</div>
            <div class="ult-cutin-title">${ch.title || ""}</div>
            <div class="ult-cutin-skill">💥 ${meta.ult}</div>
          </div>
        </div>`;
    }).join("");
    document.body.appendChild(layer);
    setTimeout(() => layer.remove(), 1200);
  }

  if (!field) return;

  const overlay = document.createElement("div");
  overlay.className = "ult-overlay";
  field.appendChild(overlay);
  setTimeout(() => overlay.remove(), 900);

  const burst = document.createElement("div");
  burst.className = "ult-burst";
  burst.style.left = `${x}px`;
  burst.style.top = `${y}px`;
  field.appendChild(burst);
  setTimeout(() => burst.remove(), 800);

  const ring = document.createElement("div");
  ring.className = "ult-ring";
  ring.style.left = `${x}px`;
  ring.style.top = `${y}px`;
  field.appendChild(ring);
  setTimeout(() => ring.remove(), 750);

  const leadJob = (chars[0] && chars[0].job) || job || "guardian";
  const meta = getJobAttackMeta(leadJob);
  const lab = document.createElement("div");
  lab.className = "ult-label";
  lab.textContent = "💥 " + meta.ult;
  lab.style.left = `${x}px`;
  lab.style.top = `${Math.max(20, y - 36)}px`;
  field.appendChild(lab);
  setTimeout(() => lab.remove(), 950);

  field.classList.add("ult-shake");
  setTimeout(() => field.classList.remove("ult-shake"), 520);
}

function dealDamage() {
  if (!battle.enemies.length) return;
  const sorted = [...battle.enemies].sort((a, b) => a.x - b.x);
  const partyChars = (battle.partyIds || [])
    .map(id => CHARACTERS.find(c => c.id === id))
    .filter(Boolean);
  const partySize = Math.max(1, partyChars.length || (battle.partyIds || []).length || 1);

  // Ultimate if gauge was full
  const isUltimate = battle.spGauge >= battle.spMax;
  if (isUltimate) {
    battle.spGauge = 0;
  } else {
    // Charge SP: base 22 + combo bonus (cap at max)
    const gain = 22 + Math.min(18, Math.floor(battle.combo * 2.5));
    battle.spGauge = Math.min(battle.spMax, battle.spGauge + gain);
  }
  updateSpGaugeUI();

  // Damage: combo multiplier + ultimate 2.2x
  let mult = 1 + battle.combo * 0.15;
  if (isUltimate) mult *= 2.2;
  const totalDmg = Math.floor(battle.charAtk * mult);
  let remaining = totalDmg;
  const hits = Math.min(partySize, sorted.length);

  const first = sorted[0];
  if (isUltimate) {
    showBattleFx("💥 必殺技発動!!", first.x, 48, "ultimate");
    showUltimateFx((partyChars[0] && partyChars[0].job) || "guardian", first.x, 50, partyChars, { showCutin: true });
  } else if (battle.combo >= 5) {
    showBattleFx("⚡ CRITICAL ATTACK! ⚡", first.x, 52, "crit");
  } else if (battle.combo >= 2) {
    showBattleFx(`⚔️ ${battle.combo}連撃!`, first.x, 52, "attack");
  } else {
    showBattleFx("⚔️ ATTACK!", first.x, 52, "attack");
  }

  // Combo chain count (extra visual hits)
  const chainCount = battle.combo <= 1 ? 0 : Math.min(5, battle.combo);

  for (let i = 0; i < hits && remaining > 0; i++) {
    const target = sorted[i];
    const attacker = partyChars[i] || partyChars[0] || { job: "guardian" };
    const share = i === 0
      ? Math.ceil(remaining * (hits === 1 ? 1 : 0.55))
      : Math.ceil(remaining / (hits - i));
    const dmg = Math.min(share, remaining);
    remaining -= dmg;
    target.hp -= dmg;
    target.el.querySelector(".ehp").textContent = Math.max(0, target.hp);
    target.el.classList.add("shake");
    showDamagePop(`-${dmg}`, target.x, 48 + i * 12);

    // Main job VFX (ultimate-enhanced if active)
    showJobAttackFx(attacker.job, target.x, 40 + i * 10, { ultimate: isUltimate });

    // 連撃: staggered extra hits for combo
    if (chainCount > 0 && i === 0) {
      for (let h = 1; h <= chainCount; h++) {
        const delay = h * 90;
        const hx = target.x + (Math.random() * 16 - 8);
        const hy = 36 + (h % 3) * 10;
        setTimeout(() => {
          if (!battle || battle.over) return;
          showJobAttackFx(attacker.job, hx, hy, { comboChain: true });
          showComboHitLabel(h + 1, hx, hy - 8);
          if (target.el && target.el.parentNode) {
            target.el.classList.add("shake");
            setTimeout(() => target.el && target.el.classList.remove("shake"), 200);
          }
        }, delay);
      }
    }

    setTimeout(() => target.el && target.el.classList.remove("shake"), 300);
  }

  // Ultimate also hits extra enemies with splash visual
  if (isUltimate && sorted.length > 1) {
    for (let i = 1; i < Math.min(sorted.length, 4); i++) {
      const t = sorted[i];
      setTimeout(() => {
        if (!battle || battle.over) return;
        showUltimateFx((partyChars[0] && partyChars[0].job) || "guardian", t.x, 48, partyChars, { showCutin: false });
        showJobAttackFx((partyChars[0] && partyChars[0].job) || "guardian", t.x, 42, { ultimate: true });
      }, 80 * i);
    }
  }

  let defeated = 0;
  for (let i = battle.enemies.length - 1; i >= 0; i--) {
    const en = battle.enemies[i];
    if (en.hp <= 0) {
      defeated++;
      battle.killCount++;
      const ex = en.x;
      en.el.classList.add("defeat-flash");
      showBattleFx("💥 撃破!", ex, 45, "defeat");
      setTimeout(() => en.el.remove(), 420);
      battle.enemies.splice(i, 1);
      // Every defeated enemy gives a fixed 30 coins.
      battle.coinsEarned += 30;
      // Every 5 kills, restore a little castle HP.
      if (battle.killCount % 5 === 0) healCastle(10);
    }
  }
  document.getElementById("battleCoin").textContent = battle.coinsEarned;
}

function finishLevel() {
  if (!battle || battle.over) return;
  battle.over = true;
  clearInterval(battle.tick);
  state.coins += battle.coinsEarned;
  saveState();
  showModal(
    `${state.level === "3" ? "英検3級" : state.level === "pre2" ? "英検準2級" : state.level === "2" ? "英検2級" : state.level === "pre1" ? "英検準1級" : "英検1級"} COMPLETE!`,
    `1,500語をすべて学習しました！\n獲得コイン: ${battle.coinsEarned}`
  );
  setTimeout(() => {
    battle = null;
    showScreen("menu");
    updateUI();
  }, 1800);
}

function battleOver(win) {
  if (!battle) return;
  // 城撃破時: 出題中で未回答の最後の問題も履歴に残す
  if (!win) recordUnansweredCurrentQuiz("defeat");
  battle.over = true;
  battle.waitingExplanation = false;
  battle.userPaused = false;
  setBattlePauseUI(false);
  clearInterval(battle.tick);
  state.coins += battle.coinsEarned;
  saveState();
  showModal(
    win ? "勝利！" : "基地が陥落…",
    `獲得コイン: ${battle.coinsEarned}\nWAVE: ${battle.wave}`
  );
  setTimeout(() => {
    battle = null;
    showScreen("menu");
    updateUI();
  }, 1600);
}

function speakEnglish(text) {
  const t = String(text || "").trim();
  if (!t) return false;
  if (!window.speechSynthesis) {
    try { showModal("音声非対応", "この端末では音声の読み上げに対応していません。"); } catch (e) {}
    return false;
  }
  try {
    // iOS/Safari: voices may load asynchronously
    const voices = speechSynthesis.getVoices() || [];
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(t);
    u.lang = "en-US";
    u.rate = 0.92;
    const enVoice =
      voices.find(v => /en-US/i.test(v.lang) && /English/i.test(v.name || "")) ||
      voices.find(v => /^en(-|$)/i.test(v.lang)) ||
      voices.find(v => /en/i.test(v.lang));
    if (enVoice) u.voice = enVoice;
    // Some mobile browsers need a tiny delay after cancel
    setTimeout(() => {
      try { speechSynthesis.speak(u); } catch (e) {}
    }, 40);
    return true;
  } catch (e) {
    return false;
  }
}

// Prime voice list (Chrome/Safari)
if (typeof speechSynthesis !== "undefined") {
  try {
    speechSynthesis.getVoices();
    speechSynthesis.onvoiceschanged = () => { try { speechSynthesis.getVoices(); } catch (e) {} };
  } catch (e) {}
}

function speakWord() {
  if (!battle || !battle.currentQuiz || !battle.currentQuiz.word) return;
  speakEnglish(battle.currentQuiz.word.w);
}

function speakFromDataAttr(el) {
  if (!el) return;
  let raw = el.getAttribute("data-speak") || "";
  try { raw = decodeURIComponent(raw); } catch (e) {}
  speakEnglish(raw);
}


function addBattleHistory(q, selected, correct, isCorrect) {
  if (!q || !q.word) return;
  const w = q.word;
  const example = w.exSentence || (w.ex ? String(w.ex).replace(/___/g, w.w) : "");
  const entry = {
    timestamp: Date.now(),
    level: state.level,
    wave: battle?.wave || 1,
    number: (battle?.wordIndex || 0) + 1,
    word: w.w,
    ipa: w.ipa || PHONETIC_CACHE[String(w.w || "").toLowerCase()] || "",
    meaning: w.m,
    type: q.isMeaning ? "意味・文脈" : "使い方・文脈",
    sentence: example,
    translation: w.exJa || "",
    choices: q.options ? q.options.slice() : [],
    selected: selected,
    correct: correct,
    isCorrect: !!isCorrect,
    source: w.exSource || "none"
  };
  if (!Array.isArray(state.battleHistory)) state.battleHistory = [];
  state.battleHistory.unshift(entry);
  // Keep a generous history without allowing localStorage to grow forever.
  if (state.battleHistory.length > 3000) state.battleHistory.length = 3000;
  saveState();
}

function clearBattleHistory() {
  if (!Array.isArray(state.battleHistory) || !state.battleHistory.length) return;
  if (!confirm("バトル履歴をすべて消去しますか？")) return;
  state.battleHistory = [];
  saveState();
  renderBattleHistory();
}

let historyLevelFilter = "all";

function setHistoryLevelFilter(level) {
  historyLevelFilter = level || "all";
  renderBattleHistory();
}

function renderBattleHistory() {
  const list = document.getElementById("battleHistoryList");
  const summary = document.getElementById("historySummary");
  if (!list || !summary) return;
  const all = Array.isArray(state.battleHistory) ? state.battleHistory : [];
  const levelNames = {"3":"3級","pre2":"準2級","2":"2級","pre1":"準1級","1":"1級"};
  const filter = historyLevelFilter || "all";
  const history = filter === "all" ? all : all.filter(h => String(h.level) === String(filter));

  // Tab counts + active state
  const tabs = document.getElementById("historyLevelTabs");
  if (tabs) {
    const counts = { all: all.length, "3": 0, pre2: 0, "2": 0, pre1: 0, "1": 0 };
    for (const h of all) {
      const lv = String(h.level || "");
      if (counts[lv] != null) counts[lv]++;
    }
    tabs.querySelectorAll(".hist-tab").forEach(btn => {
      const lv = btn.getAttribute("data-level");
      btn.classList.toggle("active", lv === filter);
      const n = counts[lv] != null ? counts[lv] : 0;
      const baseLabel = lv === "all" ? "すべて" : (levelNames[lv] || lv);
      btn.innerHTML = `${baseLabel}<span class="hist-count">(${n})</span>`;
    });
  }

  const total = history.length;
  const correct = history.filter(x => x.isCorrect).length;
  const rate = total ? Math.round(correct / total * 100) : 0;
  const scope = filter === "all" ? "全級" : (levelNames[filter] || filter);
  summary.textContent = total
    ? `【${scope}】 ${total} 問　／　正解 ${correct} 問　／　不正解 ${total - correct} 問　／　正答率 ${rate}%`
    : (all.length ? `【${scope}】この級の履歴はまだありません。` : "まだバトル履歴がありません。");

  if (!history.length) {
    list.innerHTML = all.length
      ? `<div class="empty">【${scope}】の履歴はありません。<br>別の級タブを選ぶか、バトルで学習しましょう。</div>`
      : '<div class="empty">バトルで問題に解答すると、ここに履歴が残ります。</div>';
    return;
  }

  list.innerHTML = history.map((h) => {
    const result = h.isCorrect ? "✓ 正解" : "✗ 不正解";
    const resultClass = h.isCorrect ? "var(--success)" : "var(--danger)";
    const date = h.timestamp ? new Date(h.timestamp).toLocaleString("ja-JP") : "日時不明";
    const sentence = h.sentence || "（例文なし）";
    const choices = Array.isArray(h.choices) ? h.choices : [];
    const wordEnc = encodeURIComponent(String(h.word || ""));
    const sentEnc = encodeURIComponent(String(h.sentence || "").trim());
    const hasSentence = !!(h.sentence && String(h.sentence).trim() && !String(h.sentence).includes("例文なし") && !String(h.sentence).startsWith("This word means"));
    return `<div class="card-item" style="display:block;margin-bottom:10px;">
      <div style="display:flex;justify-content:space-between;gap:8px;align-items:center;">
        <h3 style="margin:0;display:flex;align-items:center;flex-wrap:wrap;gap:6px;">
          <span>${escapeHtml(h.word || "")}${h.ipa ? `<span class="history-ipa">${escapeHtml(formatIpa(h.ipa))}</span>` : ""}</span>
          <small style="color:var(--muted);font-weight:400;">(${levelNames[h.level] || h.level || ""} / WAVE ${h.wave || "-"})</small>
        </h3>
        <strong style="color:${resultClass};white-space:nowrap;">${result}</strong>
      </div>
      <div class="hist-speak-row">
        ${h.word ? `<button type="button" class="speak-btn hist-speak-btn" data-speak="${wordEnc}">🔊 単語</button>` : ""}
        ${hasSentence ? `<button type="button" class="speak-btn hist-speak-btn" data-speak="${sentEnc}">🔊 例文</button>` : ""}
      </div>
      <p style="margin:5px 0 0;color:var(--muted);font-size:.78rem;">${escapeHtml(date)}　${escapeHtml(h.type || "")}</p>
      <p style="margin:8px 0 3px;line-height:1.5;">${escapeHtml(sentence)}</p>
      ${h.translation ? `<p style="margin:3px 0;color:var(--muted);">訳：${escapeHtml(h.translation)}</p>` : ""}
      <p style="margin:7px 0 2px;font-size:.82rem;">あなたの解答：<strong>${escapeHtml(h.selected || "")}</strong>${h.selected && String(h.selected).includes("未回答") ? (String(h.selected).includes("撤退") ? ' <span style="color:var(--danger);font-size:.75rem;">（撤退のため未解答）</span>' : ' <span style="color:var(--danger);font-size:.75rem;">（城撃破のため未解答）</span>') : ""}</p>
      <p style="margin:2px 0;font-size:.82rem;">正解：<strong>${escapeHtml(h.correct || "")}</strong>${(h.ipa && h.correct && String(h.correct).toLowerCase() === String(h.word || "").toLowerCase()) ? `<span class="history-ipa">${escapeHtml(formatIpa(h.ipa))}</span>` : ""}</p>
      ${choices.length ? `<div style="margin-top:6px;color:var(--muted);font-size:.76rem;">選択肢：${choices.map(c => escapeHtml(c)).join(" ／ ")}</div>` : ""}
    </div>`;
  }).join("");

  // Bind speak buttons (data-speak) — avoids broken inline onclick quoting
  list.querySelectorAll("button[data-speak]").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      speakFromDataAttr(btn);
    });
  });
}

function addWeakWord(word) {
  if (state.weakWords.some(w => w.w === word.w && w.level === state.level)) return;
  state.weakWords.push({
    w: word.w,
    m: word.m,
    ex: word.ex,
    exSentence: word.exSentence || word.ex.replace("___", word.w),
    exJa: word.exJa || "",
    exSource: word.exSource || "none",
    level: state.level
  });
  saveState();
}

function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// ========== ZUKAN ==========
async function renderZukan() {
  const list = document.getElementById("zukanList");
  if (!state.weakWords.length) {
    list.innerHTML = `<div class="empty">まだ苦手単語はありません。<br>バトルで間違えるとここにストックされます。</div>`;
    return;
  }
  const levelNames = { "3": "3級", "pre2": "準2級", "2": "2級", "pre1": "準1級", "1": "1級" };
  list.innerHTML = state.weakWords.map((w, i) => `
    <div class="card-item">
      <div class="info">
        <h3>${w.w} <small style="color:var(--muted);font-weight:400;">(${levelNames[w.level] || w.level})</small></h3>
        <p>${w.m}</p>
        <p style="margin-top:3px;">例文: ${escapeHtml(w.exSentence || String(w.ex || "").replace("___", w.w))}</p>
        <p style="margin-top:3px;color:var(--muted);">訳: ${escapeHtml(w.exJa || "日本語訳を取得中…")}</p>
      </div>
      <button class="btn btn-sm btn-pink" onclick="graduate(${i})">卒業</button>
    </div>
  `).join("");

  // Old weak-word records created by previous versions did not store the
  // Japanese translation. Hydrate those records from the same source used in
  // battle so the review card is identical to the battle example.
  let changed = false;
  for (const weak of state.weakWords) {
    if (weak.exSentence && hasUsableJapaneseTranslation(weak.exJa)) continue;
    if (weak.exSentence && !hasUsableJapaneseTranslation(weak.exJa)) {
      const translated = await fetchJapaneseSentenceTranslation(weak.exSentence);
      if (translated) {
        weak.exJa = translated;
        changed = true;
      }
      continue;
    }
    const temp = { w: weak.w, m: weak.m, ex: weak.ex || `The word ___ is useful in everyday English.`, exJa: weak.exJa || "" };
    const result = await ensureNaturalExample(temp);
    if (result?.ex) {
      weak.exSentence = result.ex;
      weak.ex = result.ex.replace(new RegExp(weak.w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"), "___");
      weak.exJa = result.ja || weak.exJa;
      weak.exSource = result.source || weak.exSource;
      if (!hasUsableJapaneseTranslation(weak.exJa)) {
        const translated = await fetchJapaneseSentenceTranslation(weak.exSentence);
        if (translated) weak.exJa = translated;
      }
      changed = true;
    }
  }
  if (changed) {
    saveState();
    // Re-render once after hydration, but do not recursively hydrate complete entries.
    list.innerHTML = state.weakWords.map((w, i) => `
      <div class="card-item">
        <div class="info">
          <h3>${escapeHtml(w.w)} <small style="color:var(--muted);font-weight:400;">(${levelNames[w.level] || w.level})</small></h3>
          <p>${escapeHtml(w.m)}</p>
          <p style="margin-top:3px;">例文: ${escapeHtml(w.exSentence || String(w.ex || "").replace("___", w.w))}</p>
          <p style="margin-top:3px;color:var(--muted);">訳: ${escapeHtml(w.exJa || "日本語訳はありません")}</p>
        </div>
        <button class="btn btn-sm btn-pink" onclick="graduate(${i})">卒業</button>
      </div>
    `).join("");
  }
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function graduate(idx) {
  state.weakWords.splice(idx, 1);
  saveState();
  renderZukan();
}

// ========== GACHA ==========
const GACHA_COST_SINGLE = 100;
const GACHA_COST_MULTI = 1000;
const GACHA_MULTI_COUNT = 10;

function rollGachaRarity() {
  const r = Math.random();
  if (r < 0.03) return "SSR";
  if (r < 0.20) return "SR";
  if (r < 0.50) return "R";
  return "N";
}

/** Draw one character; applies ownership / duplicate material. Returns result meta. */
function pullOneCharacter() {
  const rarity = rollGachaRarity();
  const pool = CHARACTERS.filter(c => c.rarity === rarity);
  const got = pool[Math.floor(Math.random() * pool.length)];
  const isNew = !state.ownedChars.includes(got.id);
  if (isNew) {
    state.ownedChars.push(got.id);
    if (!state.characterLevels[got.id]) state.characterLevels[got.id] = 1;
  } else {
    // Duplicate cards are kept as enhancement materials instead of being wasted.
    state.duplicateCards[got.id] = (Number(state.duplicateCards[got.id]) || 0) + 1;
  }
  return {
    char: got,
    isNew,
    duplicateCount: Number(state.duplicateCards[got.id]) || 0
  };
}

function doGacha(count = 1) {
  count = count === 10 ? 10 : 1;
  const cost = count === 10 ? GACHA_COST_MULTI : GACHA_COST_SINGLE;
  if (state.coins < cost) {
    showModal(
      "コイン不足",
      count === 10
        ? `10連ガチャには${GACHA_COST_MULTI}コイン必要です。\nバトルで稼ぎましょう！`
        : `ガチャには${GACHA_COST_SINGLE}コイン必要です。\nバトルで稼ぎましょう！`
    );
    return;
  }
  state.coins -= cost;
  const results = [];
  for (let i = 0; i < count; i++) {
    results.push(pullOneCharacter());
  }
  saveState();
  updateUI();
  document.getElementById("gachaCoin").textContent = state.coins;

  const res = document.getElementById("gachaResult");
  if (count === 1) {
    const { char: got, isNew, duplicateCount } = results[0];
    res.innerHTML = `
      <div class="gacha-single-wrap">
        <div class="char-portrait rarity-${got.rarity.toLowerCase()} pop"><img src="${got.img}" alt="${got.name}"></div>
        <div class="rarity-${got.rarity.toLowerCase()}">${got.rarity}</div>
        <div style="font-weight:700;margin-top:4px;">${got.name}</div>
        <div style="font-size:0.82rem;color:var(--muted);">${got.title || ""}</div>
        <div style="font-size:0.88rem;color:var(--muted);margin-top:2px;">ATK ${got.atk}</div>
        <div style="margin-top:8px;color:${isNew ? "var(--success)" : "var(--muted)"};">
          ${isNew ? "🎉 NEW!" : `🔄 かぶり！ 強化素材 +1（現在 ${duplicateCount}枚）`}
        </div>
      </div>
    `;
    return;
  }

  // 10連表示
  const newCount = results.filter(x => x.isNew).length;
  const ssrCount = results.filter(x => x.char.rarity === "SSR").length;
  const srCount = results.filter(x => x.char.rarity === "SR").length;
  const itemsHtml = results.map(({ char: got, isNew, duplicateCount }, idx) => `
    <div class="gacha-multi-item">
      <div class="char-portrait rarity-${got.rarity.toLowerCase()}"><img src="${got.img}" alt="${got.name}"></div>
      <div class="gm-body">
        <div class="gm-rarity rarity-${got.rarity.toLowerCase()}">${got.rarity}</div>
        <div class="gm-name">${got.name}</div>
        <div class="gm-title">${got.title || ""}</div>
      </div>
      <div class="gm-tag ${isNew ? "new" : "dupe"}">${isNew ? "🎉 NEW" : "素材+1"}</div>
    </div>
  `).join("");

  res.innerHTML = `
    <div style="font-weight:800;font-size:1.05rem;margin-bottom:4px;">🎰 10連結果</div>
    <div class="gacha-multi-grid">${itemsHtml}</div>
    <div class="gacha-summary">
      NEW ${newCount}体　／　SSR ${ssrCount}　SR ${srCount}<br>
      かぶりは強化素材としてストックされます
    </div>
  `;
}


// ========== CHARACTER DUPLICATES / LIMIT BREAK / CASTLE ==========
function getDuplicateCount(id) { return Math.max(0, Number(state.duplicateCards?.[id]) || 0); }
function getLimitBreak(id) { return Math.min(10, Math.max(0, Number(state.limitBreaks?.[id]) || 0)); }
const MAX_LIMIT_BREAK = 10;
function getLimitBreakStars(id) { const n = getLimitBreak(id); return "★".repeat(n) + "☆".repeat(MAX_LIMIT_BREAK - n); }
function getCastleMaxHp() { return 100 + (Math.max(1, Number(state.castleLevel) || 1) - 1) * 50; }
function getCastleUpgradeCost() { const lv = Math.max(1, Number(state.castleLevel) || 1); return Math.floor(150 * Math.pow(1.5, lv - 1)); }
function upgradeCastle() {
  const cost = getCastleUpgradeCost();
  if (state.coins < cost) { showModal("コイン不足", `城の強化には ${cost} コイン必要です。`); return; }
  state.coins -= cost;
  state.castleLevel = Math.max(1, Number(state.castleLevel) || 1) + 1;
  saveState(); updateUI(); renderChars();
  showModal("城を強化！", `城 Lv.${state.castleLevel} になりました！\n最大HP: ${getCastleMaxHp()}`);
}
function limitBreakCharacter(id) {
  if (!state.ownedChars.includes(id)) return;
  const current = getLimitBreak(id);
  if (current >= MAX_LIMIT_BREAK) { showModal("限界突破MAX", `「${CHARACTERS.find(c => c.id === id)?.name || id}」は限界突破★10が最大です。`); return; }
  const count = getDuplicateCount(id);
  if (count < 10) { showModal("素材不足", `限界突破には同じキャラのカードが10枚必要です。\n現在: ${count}/10`); return; }
  state.duplicateCards[id] = count - 10;
  state.limitBreaks[id] = Math.min(MAX_LIMIT_BREAK, current + 1);
  saveState(); updateUI(); renderChars();
  const char = CHARACTERS.find(c => c.id === id);
  showModal("限界突破！", `「${char?.name || id}」が限界突破しました！\n限界突破 ★${getLimitBreak(id)} / ★${MAX_LIMIT_BREAK}\nATK +10`);
}
function renderGrowthSummary() {
  const el = document.getElementById("growthSummary");
  if (!el) return;
  const castleLv = Math.max(1, Number(state.castleLevel) || 1);
  const cost = getCastleUpgradeCost();
  el.innerHTML = `
    <div class="party-panel" style="margin-bottom:10px;">
      <h3>🏰 城の強化</h3>
      <div class="party-total">城 Lv.${castleLv}　／　最大HP <span>${getCastleMaxHp()}</span></div>
      <button class="btn btn-gold" onclick="upgradeCastle()" style="width:100%;margin-top:10px;">HP +50　💰 ${cost}コイン</button>
    </div>`;
}

// ========== CHARS / PARTY ==========
function getCharLevel(id) {
  const lv = Number(state.characterLevels?.[id]);
  return Number.isFinite(lv) && lv >= 1 ? Math.floor(lv) : 1;
}
function getCharAtk(char) {
  const lv = getCharLevel(char.id);
  const bonus = Number(state.cardAtkBonuses?.[char.id]) || 0;
  return char.atk + (lv - 1) * 3 + getLimitBreak(char.id) * 10 + bonus;
}
function formatAtk(value) {
  // 小数第2位を四捨五入して小数第1位までにそろえる（浮動小数のゴミも除去）
  const n = Math.round((Number(value) || 0) * 10) / 10;
  if (Number.isInteger(n)) return String(n);
  return n.toFixed(1);
}

// Card attack enhancement: the coin-based level-up grants +3 ATK, so one
// material card starts at half that value (+1.5), multiplied by rarity.
// Coefficient is based on material rarity relative to the target rarity.
const RARITY_ORDER = ["N", "R", "SR", "SSR"];
const MATERIAL_RARITY_COEFFICIENTS = {
  "-3": 0.4,
  "-2": 0.6,
  "-1": 0.8,
  "0": 1.1,
  "1": 1.3,
  "2": 1.5,
  "3": 1.7
};
function getMaterialRarityCoefficient(targetChar, materialChar) {
  const ti = RARITY_ORDER.indexOf(targetChar?.rarity);
  const mi = RARITY_ORDER.indexOf(materialChar?.rarity);
  if (ti < 0 || mi < 0) return 1.1;
  return MATERIAL_RARITY_COEFFICIENTS[String(mi - ti)] ?? 1.1;
}
function getMaterialCardGain(targetChar, materialChar) {
  return 1.5 * getMaterialRarityCoefficient(targetChar, materialChar);
}
let materialSelection = {};
function getSelectedMaterialCount() {
  return Object.values(materialSelection).reduce((sum, n) => sum + Math.max(0, Number(n) || 0), 0);
}
function getSelectedMaterialGain(targetChar) {
  return Object.entries(materialSelection).reduce((sum, [id, count]) => {
    const material = CHARACTERS.find(c => c.id === id);
    return sum + (material ? getMaterialCardGain(targetChar, material) * Math.max(0, Number(count) || 0) : 0);
  }, 0);
}
function adjustMaterialSelection(sourceId, delta, evt) {
  if (evt) {
    try { evt.preventDefault(); evt.stopPropagation(); } catch (e) {}
  }
  const list = document.getElementById("materialListScroll");
  const scrollTop = list ? list.scrollTop : 0;
  const available = getDuplicateCount(sourceId);
  const current = Math.max(0, Number(materialSelection[sourceId]) || 0);
  const next = Math.max(0, Math.min(available, current + delta));
  if (next) materialSelection[sourceId] = next;
  else delete materialSelection[sourceId];
  renderMaterialEnhancement();
  const list2 = document.getElementById("materialListScroll");
  if (list2) {
    list2.scrollTop = scrollTop;
  }
  // Keep modal scroll stable on iOS (avoid jumping the page behind)
  const modal = document.getElementById("materialModal");
  if (modal) modal.scrollTop = 0;
}
function closeMaterialEnhancement() {
  materialSelection = {};
  document.getElementById("materialModal")?.classList.remove("show");
}
function openMaterialEnhancement(targetId) {
  if (!state.ownedChars.includes(targetId)) return;
  materialSelection = {};
  state.activeChar = targetId;
  renderMaterialEnhancement();
  document.getElementById("materialModal")?.classList.add("show");
}
function renderMaterialEnhancement() {
  const card = document.getElementById("materialCard");
  if (!card) return;
  const target = CHARACTERS.find(c => c.id === state.activeChar);
  if (!target || !state.ownedChars.includes(target.id)) return;
  const selectedCount = getSelectedMaterialCount();
  const gain = getSelectedMaterialGain(target);
  const cards = CHARACTERS.filter(c => state.ownedChars.includes(c.id)).map(material => {
    const available = getDuplicateCount(material.id);
    const selected = Math.min(available, Math.max(0, Number(materialSelection[material.id]) || 0));
    const coef = getMaterialRarityCoefficient(target, material);
    const perCard = getMaterialCardGain(target, material);
    return `<div style="display:flex;align-items:center;gap:8px;padding:8px;border:1px solid var(--border);border-radius:10px;margin-bottom:7px;background:rgba(255,255,255,.025);${available ? "" : "opacity:.45;"}">
      <img src="${material.img}" alt="${escapeHtml(material.name)}" style="width:46px;height:46px;border-radius:8px;object-fit:cover;border:1px solid var(--border);">
      <div style="flex:1;min-width:0;text-align:left;">
        <div style="font-weight:700;">${escapeHtml(material.name)} <span style="font-size:.72rem;color:var(--gold);">${material.rarity}</span></div>
        <div style="font-size:.72rem;color:var(--muted);">所持素材 ${available}枚　／　1枚 +${formatAtk(perCard)} ATK（係数×${coef}）</div>
      </div>
      <button type="button" class="btn btn-sm btn-outline" onclick="adjustMaterialSelection('${material.id}',-1,event)" ${selected<=0 ? "disabled" : ""}>−</button>
      <strong style="min-width:22px;text-align:center;">${selected}</strong>
      <button type="button" class="btn btn-sm btn-outline" onclick="adjustMaterialSelection('${material.id}',1,event)" ${selected>=available ? "disabled" : ""}>＋</button>
    </div>`;
  }).join("");
  const targetAtk = getCharAtk(target);
  card.innerHTML = `<h2 style="margin-bottom:5px;">⚔ カードで攻撃力強化</h2>
    <p style="color:var(--muted);font-size:.78rem;margin:0 0 10px;">対象：${escapeHtml(target.name)}（${target.rarity}）　／　コイン強化1回（+3 ATK）の半分を基準に、素材カードのレアリティで補正します。</p>
    <div style="padding:9px;border-radius:10px;background:rgba(255,255,255,.04);margin-bottom:10px;text-align:center;">
      現在 ATK <strong>${formatAtk(targetAtk)}</strong>　→　<strong style="color:var(--gold);">${formatAtk(targetAtk + gain)}</strong><br>
      <span style="font-size:.8rem;color:var(--muted);">選択 ${selectedCount}枚 ／ ATK +${formatAtk(gain)}</span>
    </div>
    <div id="materialListScroll" style="max-height:48vh;overflow:auto;-webkit-overflow-scrolling:touch;padding-right:2px;">${cards || `<div class="empty">使用できる強化素材カードがありません。</div>`}</div>
    <div style="display:flex;gap:8px;margin-top:10px;">
      <button class="btn btn-outline" style="flex:1;" onclick="closeMaterialEnhancement()">キャンセル</button>
      <button class="btn btn-gold" style="flex:1;" onclick="confirmMaterialEnhancement()" ${selectedCount<=0 ? "disabled" : ""}>${selectedCount}枚を消費して強化</button>
    </div>`;
}
function confirmMaterialEnhancement() {
  const target = CHARACTERS.find(c => c.id === state.activeChar);
  if (!target || !state.ownedChars.includes(target.id)) return;
  const selectedCount = getSelectedMaterialCount();
  if (selectedCount <= 0) return;
  for (const [id, countRaw] of Object.entries(materialSelection)) {
    const count = Math.max(0, Number(countRaw) || 0);
    if (count > getDuplicateCount(id)) {
      showModal("素材不足", "選択した素材カードの枚数が現在の所持数を超えています。もう一度選択してください。");
      materialSelection = {};
      renderMaterialEnhancement();
      return;
    }
  }
  const gain = getSelectedMaterialGain(target);
  for (const [id, countRaw] of Object.entries(materialSelection)) {
    const count = Math.max(0, Number(countRaw) || 0);
    if (count > 0) state.duplicateCards[id] = getDuplicateCount(id) - count;
  }
  state.cardAtkBonuses[target.id] = (Number(state.cardAtkBonuses[target.id]) || 0) + gain;
  saveState();
  materialSelection = {};
  document.getElementById("materialModal")?.classList.remove("show");
  updateUI();
  renderChars();
  showModal("攻撃力強化！", `「${target.name}」をカード${selectedCount}枚で強化しました。\nATK +${formatAtk(gain)}\n現在ATK: ${formatAtk(getCharAtk(target))}`);
}

function getPartyCharacters() {
  normalizeParty();
  return state.party
    .map(id => CHARACTERS.find(c => c.id === id))
    .filter(Boolean);
}
function getPartyTotalAtk() {
  const sum = getPartyCharacters().reduce((sum, c) => sum + getCharAtk(c), 0);
  return Math.round((Number(sum) || 0) * 10) / 10;
}
function getUpgradeCost(id) {
  const lv = getCharLevel(id);
  return Math.floor(80 * Math.pow(1.35, lv - 1));
}
function upgradeCharacter(id) {
  if (!state.ownedChars.includes(id)) return;
  const char = CHARACTERS.find(c => c.id === id);
  if (!char) return;
  const lv = getCharLevel(id);
  const cost = getUpgradeCost(id);
  if (state.coins < cost) {
    showModal("コイン不足", `「${char.name}」の強化には ${cost} コイン必要です。\nバトルでコインを集めましょう！`);
    return;
  }
  state.coins -= cost;
  state.characterLevels[id] = lv + 1;
  saveState();
  updateUI();
  renderChars();
  showModal("レベルアップ！", `「${char.name}」が Lv.${lv + 1} になりました！\n攻撃力: ${getCharAtk(char)}\nパーティー合計 ATK: ${getPartyTotalAtk()}`);
}
function toggleParty(id) {
  if (!state.ownedChars.includes(id)) return;
  normalizeParty();
  const idx = state.party.indexOf(id);
  if (idx >= 0) {
    // Remove (keep at least 1)
    if (state.party.length <= 1) {
      showModal("パーティー", "パーティーには最低1人必要です。");
      return;
    }
    state.party.splice(idx, 1);
  } else {
    if (state.party.length >= 3) {
      showModal("パーティー満員", "パーティーは最大3人です。\nスロットをタップして外してから追加してください。");
      return;
    }
    state.party.push(id);
  }
  state.activeChar = id;
  saveState();
  renderChars();
}
function removeFromParty(slotIndex) {
  normalizeParty();
  if (slotIndex < 0 || slotIndex >= state.party.length) return;
  if (state.party.length <= 1) {
    showModal("パーティー", "パーティーには最低1人必要です。");
    return;
  }
  state.party.splice(slotIndex, 1);
  saveState();
  renderChars();
}
function renderPartySlots() {
  const slotsEl = document.getElementById("partySlots");
  const totalEl = document.getElementById("partyTotal");
  if (!slotsEl) return;
  normalizeParty();
  const members = getPartyCharacters();
  let html = "";
  for (let i = 0; i < 3; i++) {
    const c = members[i];
    if (c) {
      html += `
        <div class="party-slot filled" onclick="removeFromParty(${i})" title="タップで外す">
          <span class="slot-num">${i + 1}</span>
          <div class="slot-portrait"><img src="${c.img}" alt="${c.name}"></div>
          <div class="slot-name">${c.name}</div>
          <div class="slot-atk">ATK ${getCharAtk(c)}</div>
        </div>`;
    } else {
      html += `
        <div class="party-slot">
          <span class="slot-num">${i + 1}</span>
          <div class="slot-empty">空き<br><small>下から選択</small></div>
        </div>`;
    }
  }
  slotsEl.innerHTML = html;
  if (totalEl) {
    totalEl.innerHTML = `合計 ATK <span>${formatAtk(getPartyTotalAtk())}</span>（${members.length}/3人）`;
  }
}
function renderUpgradePanel() {
  const panel = document.getElementById("upgradePanel");
  if (!panel) return;
  const char = CHARACTERS.find(c => c.id === state.activeChar);
  if (!char || !state.ownedChars.includes(char.id)) {
    panel.innerHTML = "キャラクターを選択すると育成できます。";
    return;
  }
  const lv = getCharLevel(char.id);
  const atk = getCharAtk(char);
  const cost = getUpgradeCost(char.id);
  const inParty = state.party.includes(char.id);
  panel.innerHTML = `
    <div class="up-portrait" onclick="showCharProfile('${char.id}')" title="タップで拡大">
      <img src="${char.img}" alt="${char.name}">
    </div>
    <div style="font-size:0.72rem;color:var(--muted);margin-bottom:4px;">画像をタップで拡大</div>
    <h3>${char.name}</h3>
    <div style="font-size:0.82rem;color:var(--gold);margin:5px 0;">🔄 強化素材カード: ${getDuplicateCount(char.id)}枚　／　✨ 限界突破: ${getLimitBreakStars(char.id)}</div>
    <div style="font-size:0.8rem;color:var(--muted);margin-bottom:6px;">${char.title || ""} · ${char.rarity}</div>
    <div class="upgrade-stats">Lv.${lv}　⚔ ATK ${formatAtk(atk)}${inParty ? "　／　パーティー入り" : ""}<br>次のレベル: ATK ${formatAtk(atk + 3)}　／　💰 ${cost}コイン<br><span style="font-size:.75rem;color:var(--muted);">カード強化ボーナス: +${formatAtk(Number(state.cardAtkBonuses?.[char.id]) || 0)} ATK</span></div>
    <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;">
      <button class="btn btn-sm ${inParty ? "btn-outline" : "btn-pink"}" style="min-width:120px" onclick="toggleParty('${char.id}')">
        ${inParty ? "パーティーから外す" : "パーティーに入れる"}
      </button>
      <button class="btn btn-gold btn-sm" style="min-width:120px" onclick="upgradeCharacter('${char.id}')" ${state.coins < cost ? "disabled" : ""}>
        ⬆ 攻撃力を強化
      </button>
      <button class="btn btn-sm btn-pink" style="min-width:120px" onclick="openMaterialEnhancement('${char.id}')" ${CHARACTERS.some(c => state.ownedChars.includes(c.id) && getDuplicateCount(c.id) > 0) ? "" : "disabled"}>
        🃏 カードで強化
      </button>
    </div>
    <div style="margin-top:10px;padding:9px;border:1px solid var(--border);border-radius:10px;background:rgba(255,255,255,.03);">
      <div style="font-size:.82rem;color:var(--gold);font-weight:700;">✨ 限界突破 ${getLimitBreakStars(char.id)}</div>
      <div style="font-size:.75rem;color:var(--muted);margin:4px 0 7px;">同じキャラのカード10枚で★+1　／　最大★10　／　1段階ごとにATK +10</div>
      <button class="btn btn-sm ${getLimitBreak(char.id) >= MAX_LIMIT_BREAK ? "btn-outline" : "btn-pink"}" style="width:100%;" onclick="limitBreakCharacter('${char.id}')" ${getLimitBreak(char.id) >= MAX_LIMIT_BREAK || getDuplicateCount(char.id) < 10 ? "disabled" : ""}>
        ${getLimitBreak(char.id) >= MAX_LIMIT_BREAK ? "★10 MAX" : `カード10枚で限界突破（${getDuplicateCount(char.id)}/10）`}
      </button>
    </div>`;
}

function showCharProfile(id) {
  const char = CHARACTERS.find(c => c.id === id);
  if (!char || !state.ownedChars.includes(char.id)) return;
  const lv = getCharLevel(char.id);
  const atk = getCharAtk(char);
  const inParty = state.party.includes(char.id);
  const rarityClass = "rarity-" + char.rarity.toLowerCase();
  const rarityColor = { N: "#94a3b8", R: "#38bdf8", SR: "#a855f7", SSR: "#f59e0b" }[char.rarity] || "#94a3b8";
  const card = document.getElementById("profileCard");
  card.innerHTML = `
    <div class="profile-img-wrap ${rarityClass}">
      <img src="${char.img}" alt="${char.name}">
    </div>
    <div class="profile-name">${char.name}</div>
    <div class="profile-title">${char.title || ""}</div>
    <div class="profile-rarity" style="color:${rarityColor};">${char.rarity}</div>
    <div class="profile-stats">
      <div class="profile-stat">レベル<br><span>Lv.${lv}</span></div>
      <div class="profile-stat">攻撃力<br><span>ATK ${atk}</span></div>
      <div class="profile-stat">基礎ATK<br><span>${char.atk}</span></div>
      <div class="profile-stat">編成<br><span>${inParty ? "パーティー入り" : "待機中"}</span></div>
    </div>
    <div class="profile-bio">${char.bio || ""}</div>
    <button class="btn" style="width:100%;" onclick="closeCharProfile()">閉じる</button>
  `;
  document.getElementById("profileModal").classList.add("show");
}
function closeCharProfile() {
  document.getElementById("profileModal").classList.remove("show");
}
function renderChars() {
  normalizeParty();
  renderGrowthSummary();
  renderPartySlots();
  const grid = document.getElementById("charGrid");
  grid.innerHTML = CHARACTERS.map(c => {
    const owned = state.ownedChars.includes(c.id);
    const selected = state.activeChar === c.id;
    const inParty = state.party.includes(c.id);
    const slotNum = inParty ? state.party.indexOf(c.id) + 1 : 0;
    const rarityClass = "rarity-" + c.rarity.toLowerCase();
    return `
      <div class="char-card ${selected ? "selected" : ""} ${inParty ? "in-party" : ""} ${rarityClass}" style="opacity:${owned ? 1 : 0.45}"
           onclick="${owned ? `selectCharOrToggle('${c.id}')` : ""}">
        <div class="portrait ${owned ? "" : "locked"}">
          ${owned ? `<img src="${c.img}" alt="${c.name}">` : "❓"}
        </div>
        <div class="name">${owned ? c.name : "???"}</div>
        ${owned ? `<div class="title">${c.title || ""}</div>` : ""}
        <div class="atk">${owned ? "ATK " + getCharAtk(c) : c.rarity}</div>
        ${owned ? `<div class="level">Lv.${getCharLevel(c.id)}</div>` : ""}
        ${inParty ? `<div class="party-badge">パーティー ${slotNum}</div>` : ""}
      </div>
    `;
  }).join("");
  renderUpgradePanel();
}
function selectChar(id) {
  if (!state.ownedChars.includes(id)) return;
  state.activeChar = id;
  saveState();
  renderChars();
}

/** Quick-add: double-tap same char toggles party membership */
let _lastCharTap = { id: null, t: 0 };
function selectCharOrToggle(id) {
  if (!state.ownedChars.includes(id)) return;
  const now = Date.now();
  if (_lastCharTap.id === id && now - _lastCharTap.t < 400) {
    _lastCharTap = { id: null, t: 0 };
    toggleParty(id);
    return;
  }
  _lastCharTap = { id, t: now };
  selectChar(id);
}

// Prevent accidental scroll/zoom on battle
document.getElementById("battle").addEventListener("touchmove", function(e) {
  if (e.target.closest(".quiz-panel") === null) e.preventDefault();
}, { passive: false });

updateUI();
// Begin loading the expanded vocabulary in the background.
ensureWordBanks();

(function(){
  // 実際のページ読み込み状態を確認できるようにする。
  window.addEventListener('load', function(){
    const nav = performance.getEntriesByType('navigation')[0];
    if(nav){
      console.info('[Loading] page load:', Math.round(nav.loadEventEnd), 'ms');
    }
  }, {once:true});
})();
